// BaseFile.h: interface for the CBaseFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASEFILE_H__B34EB668_E92C_4F16_BEC2_18122A0256DB__INCLUDED_)
#define AFX_BASEFILE_H__B34EB668_E92C_4F16_BEC2_18122A0256DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "inifile.h"
//#include <stdlib.h>
//#include <stdio.h>
#include <string>

//using namespace std;

class CBaseFile   :  public CIniFile
{
public:
	CBaseFile();
	virtual ~CBaseFile();
	
private:
    void DeleteSection(QString lpAppName, QString path);
    void DeleteKey(QString lpAppName, QString lpKeyName, QString path);

public:


};

#endif // !defined(AFX_BASEFILE_H__B34EB668_E92C_4F16_BEC2_18122A0256DB__INCLUDED_)
