//l/#include "StdAfx.H"
#include "math.h"
#include "trans.h"
#include "Matrix.h"

#ifdef _DEBUG
#define new DEBUG_NEW
//#include "NoDump.h"
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif




//转化地心大地坐标系到地心空间直角坐标系.
//LBH为输入地心大地坐标系,L,B,H;LB为弧度（L=L*PI/180）
//gXYZ为输出地心空间直角坐标系,x\y\z
void LBH2gXYZ(Ground_Coord LBH,Cart_Coord & gXYZ)
{
	  double Ng=ELP_A/sqrt(1-ELP_ES*sin(LBH.B)*sin(LBH.B));

	  gXYZ.X=(Ng+LBH.H)*cos(LBH.B)*cos(LBH.L);
	  gXYZ.Y=(Ng+LBH.H)*cos(LBH.B)*sin(LBH.L);
	  gXYZ.Z=(Ng*(1-ELP_ES)+LBH.H)*sin(LBH.B);
}

//地心空间直角坐标系转化到地心大地坐标系 LB为弧度（L=L*PI/180）
void gXYZ2LBH(Cart_Coord gXYZ,Ground_Coord & LBH)
{
	double B0,N,B1,temp;;
	B0=atan(gXYZ.Z/sqrt(gXYZ.X*gXYZ.X+gXYZ.Y*gXYZ.Y));
	for(int i=0;i<6;i++)
	{
		N=ELP_A/sqrt(1-ELP_ES*sin(B0)*sin(B0));
		temp=(gXYZ.Z+N*ELP_ES*sin(B0))/sqrt(gXYZ.X*gXYZ.X+gXYZ.Y*gXYZ.Y);
		B1=atan(temp);
		if((B1-B0)<0.00001*3.14/180)
			break;
		else
			B0=B1;
	}
	//temp=(gXYZ.Y)/sqrt(gXYZ.X*gXYZ.X+gXYZ.Y*gXYZ.Y);
	LBH.L=atan2(gXYZ.Y,gXYZ.X);
	LBH.B=B1;
	LBH.H=sqrt(gXYZ.X*gXYZ.X+gXYZ.Y*gXYZ.Y)/cos(B1)-N;
}

//将法线实算坐标系(nXYZ)中一点nXYZ，转化到地心空间直角坐标系中
//LBH为法线实算坐标系的原点位置,LB为角度，nXYZ为法线实算坐标系(nXYZ)中一点（直角坐标表示）
//gXYZ为点nXYZ在地心空间直角坐标系中的位置表示（直角坐标形式）
void nXYZ2gXYZ(Ground_Coord LBH,Cart_Coord nXYZ,Cart_Coord & gXYZ,double nEjectAngle)
{
	Cart_Coord gXYZ0;
	LBH.L = LBH.L*3.14159265358979/180;
	LBH.B = LBH.B*3.14159265358979/180;//需要角度转弧度
	LBH2gXYZ(LBH,gXYZ0);
	CMatrix	L0(3,3);
	L0(1,1)=-1*sin(LBH.L),L0(1,2)=cos(LBH.L),L0(1,3)=0.0;
	L0(2,1)=cos(LBH.L),L0(2,2)=sin(LBH.L),L0(2,3)=0.0;
	L0(3,1)=0.0,L0(3,2)=0.0,L0(3,3)=1.0;
	
	Cart_Coord temp_nXYZ;
	XYRotate(nXYZ, 0-nEjectAngle, temp_nXYZ);//从发射角转为正北角

	CMatrix	B0(3,3);
	B0(1,1)=0.0,B0(1,2)=0.0,B0(1,3)=1.0;
	B0(2,1)=-1*sin(LBH.B),B0(2,2)=cos(LBH.B),B0(2,3)=0.0;
	B0(3,1)=cos(LBH.B),B0(3,2)=sin(LBH.B),B0(3,3)=0.0;
	CMatrix n(3,1);
	n(1,1)=temp_nXYZ.X;
	n(2,1)=temp_nXYZ.Y;
	n(3,1)=temp_nXYZ.Z;
	CMatrix g(3,1);
	g(1,1)=gXYZ0.X;
	g(2,1)=gXYZ0.Y;
	g(3,1)=gXYZ0.Z;

	
	CMatrix t=L0*B0*n+g;
	gXYZ.X=t(1,1);
	gXYZ.Y=t(2,1);
	gXYZ.Z=t(3,1);
}

//将地心空间直角坐标系中的一点转化为法线实算坐标系(nXYZ)中
//法线实算坐标系(nXYZ)中的原点为LBH。LB为角度
//还需要根据发射角进行水平面上的坐标旋转
//为nXYZ2gXYZ逆转化。
void gXYZ2nXYZ(Ground_Coord LBH,Cart_Coord gXYZ,Cart_Coord & nXYZ,double nEjectAngle)
{
	Cart_Coord gXYZ0;
	LBH.L = LBH.L*3.14159265358979/180;
	LBH.B = LBH.B*3.14159265358979/180;//需要角度转弧度
	LBH2gXYZ(LBH,gXYZ0);
	CMatrix	L0(3,3);
	L0(1,1)=-1*sin(LBH.L),L0(1,2)=cos(LBH.L),L0(1,3)=0.0;
	L0(2,1)=cos(LBH.L),L0(2,2)=sin(LBH.L),L0(2,3)=0.0;
	L0(3,1)=0.0,L0(3,2)=0.0,L0(3,3)=1.0;
	CMatrix	B0(3,3);
	B0(1,1)=0.0,B0(1,2)=0.0,B0(1,3)=1.0;
	B0(2,1)=-1*sin(LBH.B),B0(2,2)=cos(LBH.B),B0(2,3)=0.0;
	B0(3,1)=cos(LBH.B),B0(3,2)=sin(LBH.B),B0(3,3)=0.0;
	CMatrix n(3,1);
	n(1,1)=gXYZ.X,n(2,1)=gXYZ.Y,n(3,1)=gXYZ.Z;
	CMatrix g(3,1);
	g(1,1)=gXYZ0.X,g(2,1)=gXYZ0.Y,g(3,1)=gXYZ0.Z;

	CMatrix t=B0.reverse()*L0.reverse()*(n-g);
	Cart_Coord temp_nXYZ;
	temp_nXYZ.X=t(1,1);
	temp_nXYZ.Y=t(2,1);
	temp_nXYZ.Z=t(3,1);

	XYRotate(temp_nXYZ, nEjectAngle, nXYZ);
}
//对三维坐标进行三维旋转
/*
void XYRotate(Cart_Coord XY,double sita,Cart_Coord & rXY)
{/ *
	sita=-sita;
	CMatrix transM(2,2);
	transM(1,1)=cos(sita);transM(1,2)=-sin(sita);
	transM(2,1)=sin(sita);transM(2,2)=cos(sita);
	CMatrix XY0(2,1);
	XY0(1,1)=XY.X;XY0(2,1)=XY.Z;
	CMatrix m1=transM*XY0;
	rXY.X=m1(1,1);rXY.Y=XY.Y;rXY.Z =m1(2,1);
	* /

	sita=-sita;//实际输入角度（与正北方向顺时针为正）与数学的逆时针为正，相反，所以加负号
	rXY.X=XY.X*cos(sita)-XY.Z*sin(sita);
    rXY.Z=XY.X*sin(sita)+XY.Z*cos(sita);
	rXY.Y=XY.Y;
}
*/

void XYRotate(Cart_Coord XY,double sita,Cart_Coord & rXY)
{

	sita=sita*3.14159265358979/180;
	sita=-sita;//实际输入角度（与正北方向顺时针为正）与数学的逆时针为正，相反，所以加负号
	rXY.X=XY.X*cos(sita)-XY.Z*sin(sita);
    rXY.Z=XY.X*sin(sita)+XY.Z*cos(sita);
	rXY.Y=XY.Y;
}
