﻿#include "commu.h"
#include"Dlg_Debug.h"
#include <QApplication>
#include<QTextCodec>
#include"CDlg_MsgDisplay.h"
#include"CommuDlg.h"
#include "GlabalDefine.h"
#include "inifile.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QTextCodec *utf8=QTextCodec::codecForName("UTF-8");
    QTextCodec::setCodecForTr(utf8);
    QTextCodec::setCodecForLocale(utf8);
    QTextCodec::setCodecForCStrings(utf8);

    CCommuDlg  commu;
    commu.show();

    return app.exec();
}
