/********************************************************************************
** Form generated from reading UI file 'modifyoid.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODIFYOID_H
#define UI_MODIFYOID_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_ModifyOID
{
public:
    QDialogButtonBox *buttonBox;
    QLineEdit *OID;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLineEdit *Name;
    QLineEdit *Snytax;
    QLineEdit *Value;
    QLineEdit *Access;
    QLineEdit *Descr;
    QLineEdit *Index;
    QLineEdit *Status;
    QLineEdit *lineEdit;
    QLineEdit *isTrap;
    QLabel *label_9;

    void setupUi(QDialog *ModifyOID)
    {
        if (ModifyOID->objectName().isEmpty())
            ModifyOID->setObjectName(QString::fromUtf8("ModifyOID"));
        ModifyOID->resize(937, 314);
        buttonBox = new QDialogButtonBox(ModifyOID);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(700, 100, 81, 241));
        buttonBox->setOrientation(Qt::Vertical);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        OID = new QLineEdit(ModifyOID);
        OID->setObjectName(QString::fromUtf8("OID"));
        OID->setGeometry(QRect(120, 80, 171, 31));
        label = new QLabel(ModifyOID);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 90, 31, 17));
        label_2 = new QLabel(ModifyOID);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(70, 130, 41, 17));
        label_3 = new QLabel(ModifyOID);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(70, 180, 51, 17));
        label_4 = new QLabel(ModifyOID);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(70, 230, 41, 17));
        label_5 = new QLabel(ModifyOID);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(440, 90, 51, 17));
        label_6 = new QLabel(ModifyOID);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(440, 130, 41, 17));
        label_7 = new QLabel(ModifyOID);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(440, 170, 41, 17));
        label_8 = new QLabel(ModifyOID);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(440, 220, 51, 17));
        Name = new QLineEdit(ModifyOID);
        Name->setObjectName(QString::fromUtf8("Name"));
        Name->setGeometry(QRect(120, 120, 171, 31));
        Snytax = new QLineEdit(ModifyOID);
        Snytax->setObjectName(QString::fromUtf8("Snytax"));
        Snytax->setGeometry(QRect(120, 170, 171, 31));
        Value = new QLineEdit(ModifyOID);
        Value->setObjectName(QString::fromUtf8("Value"));
        Value->setGeometry(QRect(120, 220, 171, 31));
        Access = new QLineEdit(ModifyOID);
        Access->setObjectName(QString::fromUtf8("Access"));
        Access->setGeometry(QRect(120, 270, 171, 31));
        Descr = new QLineEdit(ModifyOID);
        Descr->setObjectName(QString::fromUtf8("Descr"));
        Descr->setGeometry(QRect(500, 130, 121, 31));
        Index = new QLineEdit(ModifyOID);
        Index->setObjectName(QString::fromUtf8("Index"));
        Index->setGeometry(QRect(500, 170, 121, 31));
        Status = new QLineEdit(ModifyOID);
        Status->setObjectName(QString::fromUtf8("Status"));
        Status->setGeometry(QRect(500, 210, 121, 31));
        lineEdit = new QLineEdit(ModifyOID);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setEnabled(false);
        lineEdit->setGeometry(QRect(60, 10, 591, 27));
        isTrap = new QLineEdit(ModifyOID);
        isTrap->setObjectName(QString::fromUtf8("isTrap"));
        isTrap->setGeometry(QRect(500, 90, 121, 31));
        label_9 = new QLabel(ModifyOID);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(70, 270, 51, 17));

        retranslateUi(ModifyOID);
        QObject::connect(buttonBox, SIGNAL(accepted()), ModifyOID, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), ModifyOID, SLOT(reject()));

        QMetaObject::connectSlotsByName(ModifyOID);
    } // setupUi

    void retranslateUi(QDialog *ModifyOID)
    {
        ModifyOID->setWindowTitle(QApplication::translate("ModifyOID", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ModifyOID", "Oid", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("ModifyOID", "Name", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("ModifyOID", "Snytax", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("ModifyOID", "Value", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("ModifyOID", "other", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("ModifyOID", "Descr", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("ModifyOID", "Index", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("ModifyOID", "Status", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("ModifyOID", "access", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ModifyOID: public Ui_ModifyOID {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODIFYOID_H
