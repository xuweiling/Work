﻿#ifndef DLG_SETINNER_H
#define DLG_SETINNER_H

#include "GlabalDefine.h"
#include <QDialog>
#include <qstring.h>
#include <QTableWidget>
#include <vector>

using namespace std;

namespace Ui {
class CDlg_SetInner;
}

class CDlg_SetInner : public QDialog
{
    Q_OBJECT
// Construction
public:
    explicit CDlg_SetInner(QWidget *parent = 0);// standard constructor
    ~CDlg_SetInner();
    void init();

    bool isZK;
    DWORD Addr_1;
    DWORD Addr_2;
    vector<unsigned long> FZSet1;
    vector<unsigned long> FZSet2;
    int FZNum;


private slots:
    void on_okButton_clicked();
    void OnButtonCancel();

    void on_ipAdd_clicked();

    void on_ipDelete_clicked();

public:
    Ui::CDlg_SetInner *getui(){return ui;}
    Ui::CDlg_SetInner *ui;
};

#endif // DLG_SETINNER_H
