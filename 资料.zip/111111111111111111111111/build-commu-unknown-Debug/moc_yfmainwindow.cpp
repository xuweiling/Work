/****************************************************************************
** Meta object code from reading C++ file 'yfmainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../commu/yfmainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'yfmainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_YFMainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x08,
      37,   13,   13,   13, 0x08,
      59,   13,   13,   13, 0x08,
      78,   13,   13,   13, 0x08,
     108,  103,   13,   13, 0x08,
     140,   13,   13,   13, 0x08,
     168,   13,   13,   13, 0x08,
     196,   13,   13,   13, 0x08,
     221,   13,   13,   13, 0x08,
     244,   13,   13,   13, 0x08,
     274,  268,   13,   13, 0x08,
     315,   13,   13,   13, 0x08,
     342,   13,   13,   13, 0x08,
     358,   13,   13,   13, 0x0a,
     381,   13,   13,   13, 0x0a,
     413,  405,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_YFMainWindow[] = {
    "YFMainWindow\0\0on_stopAgent_clicked()\0"
    "on_traptest_clicked()\0on_reset_clicked()\0"
    "on_ReadFButton_clicked()\0item\0"
    "GetOneLineOID(QListWidgetItem*)\0"
    "on_ModifyButton_2_clicked()\0"
    "on_DeleteButton_2_clicked()\0"
    "on_AddButton_2_clicked()\0"
    "on_WriteFile_clicked()\0on_writeagent_clicked()\0"
    "index\0on_listWidget_doubleClicked(QModelIndex)\0"
    "on_UpUIFromAgent_clicked()\0UpUIFromAgent()\0"
    "on_quitAgent_clicked()\0on_startAgent_clicked()\0"
    "recData\0TransData(const char*)\0"
};

void YFMainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        YFMainWindow *_t = static_cast<YFMainWindow *>(_o);
        switch (_id) {
        case 0: _t->on_stopAgent_clicked(); break;
        case 1: _t->on_traptest_clicked(); break;
        case 2: _t->on_reset_clicked(); break;
        case 3: _t->on_ReadFButton_clicked(); break;
        case 4: _t->GetOneLineOID((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 5: _t->on_ModifyButton_2_clicked(); break;
        case 6: _t->on_DeleteButton_2_clicked(); break;
        case 7: _t->on_AddButton_2_clicked(); break;
        case 8: _t->on_WriteFile_clicked(); break;
        case 9: _t->on_writeagent_clicked(); break;
        case 10: _t->on_listWidget_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 11: _t->on_UpUIFromAgent_clicked(); break;
        case 12: _t->UpUIFromAgent(); break;
        case 13: _t->on_quitAgent_clicked(); break;
        case 14: _t->on_startAgent_clicked(); break;
        case 15: _t->TransData((*reinterpret_cast< const char*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData YFMainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject YFMainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_YFMainWindow,
      qt_meta_data_YFMainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &YFMainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *YFMainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *YFMainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_YFMainWindow))
        return static_cast<void*>(const_cast< YFMainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int YFMainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
