/********************************************************************************
** Form generated from reading UI file 'yfdoubleclick_trapid.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YFDOUBLECLICK_TRAPID_H
#define UI_YFDOUBLECLICK_TRAPID_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_YFDoubleClick_TrapID
{
public:
    QLineEdit *TrapID;
    QLabel *label;
    QPushButton *addButton;
    QPushButton *ModifyButton;
    QPushButton *deleteButton;

    void setupUi(QDialog *YFDoubleClick_TrapID)
    {
        if (YFDoubleClick_TrapID->objectName().isEmpty())
            YFDoubleClick_TrapID->setObjectName(QString::fromUtf8("YFDoubleClick_TrapID"));
        YFDoubleClick_TrapID->resize(400, 112);
        TrapID = new QLineEdit(YFDoubleClick_TrapID);
        TrapID->setObjectName(QString::fromUtf8("TrapID"));
        TrapID->setGeometry(QRect(140, 20, 191, 27));
        label = new QLabel(YFDoubleClick_TrapID);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 20, 67, 17));
        addButton = new QPushButton(YFDoubleClick_TrapID);
        addButton->setObjectName(QString::fromUtf8("addButton"));
        addButton->setGeometry(QRect(40, 60, 99, 27));
        ModifyButton = new QPushButton(YFDoubleClick_TrapID);
        ModifyButton->setObjectName(QString::fromUtf8("ModifyButton"));
        ModifyButton->setGeometry(QRect(160, 60, 99, 27));
        deleteButton = new QPushButton(YFDoubleClick_TrapID);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));
        deleteButton->setGeometry(QRect(280, 60, 99, 27));

        retranslateUi(YFDoubleClick_TrapID);

        QMetaObject::connectSlotsByName(YFDoubleClick_TrapID);
    } // setupUi

    void retranslateUi(QDialog *YFDoubleClick_TrapID)
    {
        YFDoubleClick_TrapID->setWindowTitle(QApplication::translate("YFDoubleClick_TrapID", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("YFDoubleClick_TrapID", "TRAPID", 0, QApplication::UnicodeUTF8));
        addButton->setText(QApplication::translate("YFDoubleClick_TrapID", "add", 0, QApplication::UnicodeUTF8));
        ModifyButton->setText(QApplication::translate("YFDoubleClick_TrapID", "modify", 0, QApplication::UnicodeUTF8));
        deleteButton->setText(QApplication::translate("YFDoubleClick_TrapID", "delete", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class YFDoubleClick_TrapID: public Ui_YFDoubleClick_TrapID {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YFDOUBLECLICK_TRAPID_H
