﻿#ifndef CDLG_MSGDISPLAY_H
#define CDLG_MSGDISPLAY_H

#include "GlabalDefine.h"
//#include "afxwin.h"

typedef unsigned int    UINT;
typedef unsigned long  DWORD;
typedef unsigned char  BYTE;
typedef unsigned short WORD;

#include <QDialog>
#include <QVector>
#include<QString>
#include<QTimer>

namespace Ui {
class CDlg_MsgDisplay;
}

class CDlg_MsgDisplay : public QDialog
{
    Q_OBJECT

public:
    explicit CDlg_MsgDisplay(QWidget *parent = 0);
    ~CDlg_MsgDisplay();

    void InitContent(Sockettp recvType, Sockettp sendType);
    void UnInitData();
    void FreshMsg(int sourceNO, BYTE* pChar, int pLength, int type);

    bool	IsHandleWay;							//是否手工指定数据源路由
    int		SourceWayNO;							//手工选择的路由 1->路由1 <> 2->路由2

    int TimeRecvLagCount_St;

protected:
    void mouseDoubleClickEvent(QMouseEvent *event);//鼠标双击事件


    long FreshSendMsg(uint wParam, long lParam);	//long  uint   long ????????、、？？？？？？？？？？？？？？、

    int TimeSendLagCount;							//是否持续发送数据的判据
    int TimeRecvLagCount_1;							//是否持续接收到数据的判据
    int TimeRecvLagCount_2;							//是否持续接收到数据的判据
    QTimer *Timer1SecondHWND;
    //UINT Timer1SecondHWND;							//整秒定时器
    bool TimeSendContinueFlag;						//是否持续发送数据
    bool TimeRecvContinueFlag_1;					//是否持续接收到数据
    bool TimeRecvContinueFlag_2;					//是否持续接收到数据
    DWORD TimerCount_1;								//常时数目
    DWORD TimerCount_2;								//常时数目
    DWORD TimerCount_3;								//常时数目
    DWORD DataCount_1;								//数据数目
    DWORD DataCount_2;								//数据数目
    DWORD DataCount_3;								//数据数目
    DWORD DataCount_4;								//数据数目

    bool ReadIniFile();								//读取配置文件
    bool IsSource1( int sourceNO );					//根据序号判断是否显示在第一个框内
    bool IsSource2( int sourceNO );					//根据序号判断是否显示在第二个框内
    void DisplayRecv_1( BYTE* pChar, int pLength, int type );							//将数据内容转译并显示在第一个框内
    void DisplayRecv_2( BYTE* pChar, int pLength, int type );							//将数据内容转译并显示在第二个框内
    void DisplaySend( BYTE* pChar, int pLength, int type );							//将数据内容转译并显示在发送框内

    double		EjectPosB;							//发射点的大地直角坐标系坐标 Jerry 20110707++
    double		EjectPosL;							//发射点的大地直角坐标系坐标 Jerry 20110707++
    double		EjectPosH;							//发射点的大地直角坐标系坐标 Jerry 20110707++
    double		EjectAngle;							//发射点的发射角 Jerry 20110907++
    int			DisplayAddIndex1;
    int			DisplayAddIndex2;//显示的源
    QVector<AddStruct> CTP2PSet;			//Socket配置(单播)  QVECTOR
    QVector<AddStruct> CTMulSetSe;			//Socket配置(组播)
    QVector<AddStruct> CTMulSetRe;			//Socket配置(组播)
    int			CTP2PNum;							//单播地址数目
    int			CTMulNumRe;							//组播地址数目
    int			CTMulNumSe;							//组播地址数目
    int			INI_DATALENGTH_MEASURE;				//实算数据中数据区有效长度 = 32, 22+10
    int			INI_DATALENGTH_THEORY;				//引入数据中数据区有效长度 = 28
    int			INI_DATALENGTH_EXAM;				//时延测试数据区长度
    int			INI_DATALENGTH_T0;					//T0数据区长度
    int			INI_REVERSE_DATALENGTH;				//正式实算数据中最后保留的数据长度		Jerry 20110629
    int			INI_DATALENGTH_ZK;					//分站主控发送的数据长度

    QString		INI_REVERSE_DATACONTENT;			//正式实算数据中最后保留的数据内容	Jerry 20110629
    HEADERStruct	MeasureHEADER;						//实算数据帧头信息
    HEADERStruct	TimerSendHEADER;						//常时数据帧头信息(发送)
    HEADERStruct	TimerRecvHEADER;						//常时数据帧头信息(接收)
    HEADERStruct	ExamSendHEADER;						//时延测试帧头信息(发送)
    HEADERStruct	ExamRecvHEADER;						//时延测试帧头信息(接收)
    HEADERStruct	T0HEADER;								//T0数据帧头信息
    HEADERStruct	WYDHEADER[30];						//外部说明数据帧头信息

    DWORD		BIDMeasure;							//实算数据帧BID(仅供SaveFile使用)
    DWORD		BIDTimer;							//常时数据帧BID(仅供SaveFile使用)
    DWORD		BIDExam;							//时延测试帧BID(仅供SaveFile使用)
    DWORD		BIDT0;								//T0数据帧BID(仅供SaveFile使用)

    Sockettp	SendSocketTP;						//发送网络属性
    Sockettp	RecvSocketTP;						//接收网络属性


public slots:
    void OnButtonSelect1();
    void OnButtonSelect2();
    void OnBnClickedCheckSend1();
    void OnBnClickedCheckSend2();
    void OnCheckAutohandle();
    void OnTimer();
private slots:

signals:
    void WM_USER_CHECK_SEND1(unsigned int, long );
    void WM_USER_CHECK_SEND2(unsigned int, long);
    void WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(bool,int);

public:
     Ui::CDlg_MsgDisplay *getui(){return ui;}
     Ui::CDlg_MsgDisplay *ui;

};

#endif // CDLG_MSGDISPLAY_H
