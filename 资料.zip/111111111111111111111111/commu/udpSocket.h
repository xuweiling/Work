﻿/*LX//////////////////////////////////////////////////////////////////////
// udpSocket.h: interface for the udpSocket class.
// author: chenyanan
// date: 2014-12-13
//LX*/

#ifndef __udpSocket_H__
#define __udpSocket_H__

#include <unistd.h>   //放在第一个
#include <stdlib.h>   //exit()
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include "string.h"  //strlrn
#include <assert.h>
#include "stdafx.h"

class udpSocket
{
public:
	udpSocket();
	virtual ~udpSocket();
	
    udpSocket(unsigned short int port, bool isbind=1, const char *addr="0.0.0.0",int buff_length=MACRO_BUFFER_SIZE);
	
	int get_sockfd();
	
    int create(unsigned short int port=0, const char *addr="0.0.0.0");
    int create(unsigned short int port, unsigned long int addr,bool isbind=1);

	/*send*/
	void set_toAddress(unsigned short int port=0, const char *addr="0.0.0.0");
    int udpsendto(const void*msg, int sendLength, unsigned short int port=0, const char *addr="0.0.0.0");
    int udpsend(const void *msg);
	
	/*receive*/
    int udprecvfrom(unsigned char *buff, int buff_len, bool set_toAddr=0, unsigned short int port=0, const char *addr="0.0.0.0");
	int udprecv(char *buff, int buff_len);
    uint32_t get_recvAddress();
	
	/*组播*/
    void addMcastGroup(const char *mcastAddr, uint32_t interface, int loop=1, int ttl=1, int reuse=1,
	                   const char *iaddr="0.0.0.0");
    void addSourceMcastGroup(const char *mcastAddr, const char *sourceAddr, uint32_t interface,
                       int loop=1, int ttl=1, int reuse=1,const char *iaddr="0.0.0.0");
	void dropMcastGroup();
    void dropMcastGroup(const char *mcastAddr, uint32_t interface);
    void dropSourceMcastGroup(const char *mcastAddr, const char *sourceAddr, uint32_t interface);

    bool udpClose();

private:
	int sockfd;
	struct sockaddr_in myAddress,toAddress,recvAddress;
    unsigned char *buffer;
	int buff_size;
	struct in_addr moreAddr;  //设置多网卡
	struct ip_mreq group; 
    fd_set testfds,recvfds;
    struct timeval timeout;
	void set_recvAddress(unsigned short int port=0, const char *addr="0.0.0.0");
};


#endif
