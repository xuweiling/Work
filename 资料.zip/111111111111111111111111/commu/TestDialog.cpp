#include "TestDialog.h"
#include "ui_TestDialog.h"

CTestDialog::CTestDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CTestDialog)
{
    ui->setupUi(this);
}

CTestDialog::~CTestDialog()
{
    delete ui;
}
