/****************************************************************************
** Meta object code from reading C++ file 'CDlg_MsgDisplay.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../commu/CDlg_MsgDisplay.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CDlg_MsgDisplay.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CDlg_MsgDisplay[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      19,   17,   16,   16, 0x05,
      50,   17,   16,   16, 0x05,
      81,   17,   16,   16, 0x05,

 // slots: signature, parameters, type, tag, flags
     130,   16,   16,   16, 0x0a,
     148,   16,   16,   16, 0x0a,
     166,   16,   16,   16, 0x0a,
     190,   16,   16,   16, 0x0a,
     214,   16,   16,   16, 0x0a,
     234,   16,   16,   16, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_CDlg_MsgDisplay[] = {
    "CDlg_MsgDisplay\0\0,\0WM_USER_CHECK_SEND1(uint,long)\0"
    "WM_USER_CHECK_SEND2(uint,long)\0"
    "WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(bool,int)\0"
    "OnButtonSelect1()\0OnButtonSelect2()\0"
    "OnBnClickedCheckSend1()\0OnBnClickedCheckSend2()\0"
    "OnCheckAutohandle()\0OnTimer()\0"
};

void CDlg_MsgDisplay::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CDlg_MsgDisplay *_t = static_cast<CDlg_MsgDisplay *>(_o);
        switch (_id) {
        case 0: _t->WM_USER_CHECK_SEND1((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2]))); break;
        case 1: _t->WM_USER_CHECK_SEND2((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2]))); break;
        case 2: _t->WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->OnButtonSelect1(); break;
        case 4: _t->OnButtonSelect2(); break;
        case 5: _t->OnBnClickedCheckSend1(); break;
        case 6: _t->OnBnClickedCheckSend2(); break;
        case 7: _t->OnCheckAutohandle(); break;
        case 8: _t->OnTimer(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CDlg_MsgDisplay::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CDlg_MsgDisplay::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_CDlg_MsgDisplay,
      qt_meta_data_CDlg_MsgDisplay, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CDlg_MsgDisplay::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CDlg_MsgDisplay::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CDlg_MsgDisplay::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CDlg_MsgDisplay))
        return static_cast<void*>(const_cast< CDlg_MsgDisplay*>(this));
    return QDialog::qt_metacast(_clname);
}

int CDlg_MsgDisplay::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void CDlg_MsgDisplay::WM_USER_CHECK_SEND1(unsigned int _t1, long _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CDlg_MsgDisplay::WM_USER_CHECK_SEND2(unsigned int _t1, long _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CDlg_MsgDisplay::WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(bool _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
