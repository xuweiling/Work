﻿#include "stdafx.h"
//#include "Commu.h"
#include "Dlg_Debug.h"
#include "ui_Dlg_Debug.h"
#include <QApplication>
#include <QTime>

#include "BaseFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



Dlg_Debug::Dlg_Debug(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dlg_Debug)
{
    ui->setupUi(this);

      connect(ui->DEBUG_SENDTO,SIGNAL(clicked()),this,SLOT(OnButtonSendZK()));//
      connect(ui->DEBUG_STOPTO,SIGNAL(clicked()),this,SLOT(OnButtonStopTO()));//
      connect(ui->DEBUG_APPLY,SIGNAL(clicked()),this,SLOT(OnButtonApply()));//
      connect(ui->DEBUG_SAVE,SIGNAL(clicked()),this,SLOT(OnButtonSave()));//
      connect(ui->DEBUG_CANCEL,SIGNAL(clicked()),this,SLOT(OnDebugCancel()));//
      connect(ui->DEBUG_STARTLOST,SIGNAL(clicked()),this,SLOT(OnBnClickedDebugStartlost()));//
      connect(ui->DEBUG_CHECK_STATUSSWITCH,SIGNAL(clicked()),this,SLOT(OnBnClickedDebugCheckStatusswitch()));//
      connect(ui->DEBUG_CHECK_STATUSSWITCH2,SIGNAL(clicked()),this,SLOT(OnBnClickedDebugCheckStatusswitch2()));//
      connect(ui->DEBUG_SENDEXAM,SIGNAL(clicked()),this,SLOT(OnBnClickedButtonDebugSendexam()));//
//各种初始化
      ui->m_A->setText("0.0");//为float类型
      ui->m_E->setText("0.0");//为float类型
      ui->m_ExamAve1->setText("0");
      ui->m_ExamAve2->setText("0");
      ui->m_ExamAve3->setText("0");
      ui->m_ExamAve4->setText("0");
      ui->m_ExamAve5->setText("0");
      ui->m_ExamAve6->setText("0");
      ui->m_ExamMax1->setText("0");
      ui->m_ExamMax2->setText("0");
      ui->m_ExamMax3->setText("0");
      ui->m_ExamMax4->setText("0");
      ui->m_ExamMax5->setText("0");
      ui->m_ExamMax6->setText("0");
      ui->m_ExamMin1->setText("0");
      ui->m_ExamMin2->setText("0");
      ui->m_ExamMin3->setText("0");
      ui->m_ExamMin4->setText("0");
      ui->m_ExamMin5->setText("0");
      ui->m_ExamMin6->setText("0");
      ui->m_OffsetX->setText("0.0");//为float类型
      ui->m_OffsetY->setText("0.0");//为float类型
      ui->m_MID->clear();
      ui->m_SID->clear();
      ui->m_DID->clear();
      ui->m_BID_Exam->clear();
      ui->m_BID_Measure->clear();
      ui->m_BID_Timer->clear();
      ui->m_BID_TO->clear();
      ui->m_BID_Wyd->clear();
      ui->m_Ver->clear();
      ui->m_Wyd_X->setText("0.0");//为double类型
      ui->m_Wyd_Y->setText("0.0");//为double类型
      ui->m_Wyd_Z->setText("0.0");//为double类型
      ui->m_IsTarget->setChecked(FALSE);
//      ui->m_ServerMode->clear();




     // COLORREF Backcolor=0x00afaf00;????????????????????????????//???????????怎么改设置背景
      //	SetBackgroundColor(Backcolor);
      //SetBackgroundImage(IDB_BITMAP4, BACKGR_TILE);

      ZKStatus = 0;

}

/************************************************************************/
/* 调试数据读取                                                         */
/************************************************************************/
void Dlg_Debug::InitDebugData()
{

    QString iniFilePath = INIFILE;
    QString iniFilePath_a;
    iniFilePath_a=QApplication::applicationDirPath();
    //char iniFilePath_a[256];
    // GetCurrentDirectory(256, iniFilePath_a);
    iniFilePath = iniFilePath_a;
    iniFilePath+="/settest.ini";

    CBaseFile iniFile;
    QString sectionName;
    QString secContent;
    int secValue = 0;
    BYTE ip1, ip2, ip3, ip4;
    QString tempName;
    QString tempDID;
    QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
    DWORD tempValue;
    int CTCounter=0;
    int tempCTCounter=0;

//读取调试区数据
    HEADERStruct HEADER;
    HEADER.v_Version = 128;
    HEADER.v_SP1[1] = 0;
    HEADER.v_SP1[0] = 15;
    HEADER.v_SP2[3] = 0x60;
    HEADER.v_SP2[2] = 0x01;
    HEADER.v_SP2[1] = 0x0c;
    HEADER.v_SP2[0] = 0x00;
    HEADER.v_SP3[3] = 0x11;
    HEADER.v_SP3[2] = 0x11;
    HEADER.v_SP3[1] = 0x01;
    HEADER.v_SP3[0] = 0x00;
    HEADER.v_SP4[3] = 0;
    HEADER.v_SP4[2] = 2;
    HEADER.v_SP4[1] = 1;
    HEADER.v_SP4[0] = 0;

    WORD diffDay = GetDate();//Globaldefine.h中定义的函数（GetData）
    memcpy((HEADER.v_Date), &diffDay, 2);

    sectionName = "协议设置";
    INI_DATALENGTH_MEASURE = iniFile.GetIniInt(sectionName, "实算数据区长度", iniFilePath);

    sectionName = "调试数据配置";
    secContent = iniFile.GetIniStr(sectionName, "T_Ver", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(&(HEADER.v_Version), &tempValue, 1);

    secContent = iniFile.GetIniStr(sectionName, "T_MID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "T_SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "T_DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

//调试实算数据
    secContent = iniFile.GetIniStr(sectionName, "T_BID实算数据", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = INI_DATALENGTH_MEASURE;
    HEADER.v_Length[1] = 0;

    memcpy(&DebugHEADER_Measure, &HEADER, sizeof(HEADERStruct));

//调试常时数据
    secContent = iniFile.GetIniStr(sectionName, "T_BID常时", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = 04;
    HEADER.v_Length[1] = 0;

    memcpy(&DebugHEADER_Timer, &HEADER, sizeof(HEADERStruct));


    secContent	= iniFile.GetIniStr(sectionName, "T_外引导X", iniFilePath);
    ui->m_Wyd_X->setText(secContent);
    WydX = atof(secContent.toAscii());


    secContent	= iniFile.GetIniStr(sectionName, "T_外引导Y", iniFilePath);
    ui->m_Wyd_Y->setText(secContent);
    WydY= atof(secContent.toAscii());


    secContent	= iniFile.GetIniStr(sectionName, "T_外引导Z", iniFilePath);
    ui->m_Wyd_Z->setText(secContent);
    WydZ= atof(secContent.toAscii());


    secContent	= iniFile.GetIniStr(sectionName, "T_X", iniFilePath);
    ui->m_OffsetX->setText(secContent);
    OffsetX= atof(secContent.toAscii());


    secContent	= iniFile.GetIniStr(sectionName, "T_Y", iniFilePath);
    ui->m_OffsetY->setText(secContent);
    OffsetY=atof(secContent.toAscii());

    secContent	= iniFile.GetIniStr(sectionName, "T_A", iniFilePath);
    ui->m_A->setText(secContent);
    A = atof(secContent.toAscii());

    secContent	= iniFile.GetIniStr(sectionName, "T_E", iniFilePath);
    ui->m_E->setText(secContent);
     E= atof(secContent.toAscii());


    secContent	= iniFile.GetIniStr(sectionName, "T_Mode", iniFilePath);
     secContent=QString::fromLocal8Bit(secContent.toAscii());


     if(secContent ==tr(  "单杆"))
     {
         ui->m_ServerMode->setCurrentIndex(0);
     }
     if(secContent == tr( " 程序引导"))
     {
         ui->m_ServerMode->setCurrentIndex(1);
     }
     if(secContent == tr( "外引导"))
     {
        ui->m_ServerMode->setCurrentIndex(2);
     }
     if(secContent == tr( "电视自动跟踪"))//电视自动跟踪
     {
         ui->m_ServerMode->setCurrentIndex(3);
     }
     if(secContent ==tr(  "正弦引导"))//正弦引导
     {
         ui->m_ServerMode->setCurrentIndex(4);
     }
     if(secContent ==tr( "等速引导"))//程序外部说明
     {
         ui->m_ServerMode->setCurrentIndex(5);
     }
     if(secContent ==tr(  "定位"))//程序外部说明
     {
         ui->m_ServerMode->setCurrentIndex(6);
     }
//     if(secContent == "加权")//程序外部说明
//     {
//         ui->m_ServerMode->setCurrentIndex(0);							//Status
//     }

   // ui->m_ServerMode->setItemText(0,secContent);
    ServerMode =  secContent;
    ui->m_IsTarget->setChecked(TRUE);

//界面刷新
    tempValue=0;
    QString temp_mid;
    memcpy(&tempValue,	DebugHEADER_Timer.	v_SP4, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_BID_Timer->setText(temp_mid);//.Format("%.8x", tempValue);
    temp_mid.clear();

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP4, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_BID_Measure->setText(temp_mid);//
    temp_mid.clear();
    //m_BID_Measure.Format("%.8x", tempValue);

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP3, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_DID->setText(temp_mid);//
    temp_mid.clear();
    //m_DID.Format("%.8x", tempValue);

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP2, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_SID->setText(temp_mid);//
    temp_mid.clear();
    //m_SID.Format("%.8x", tempValue);

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP1, 2);
    temp_mid.sprintf("%.4x",tempValue);
    ui->m_MID->setText(temp_mid);//
    temp_mid.clear();
    //m_MID.Format("%.4x", tempValue);

    tempValue=0;
    memcpy(&tempValue, &(DebugHEADER_Measure.	v_Version), 1);
    temp_mid.sprintf("%.2x",tempValue);
    ui->m_Ver->setText(temp_mid);//
    temp_mid.clear();
    //m_Ver.Format("%.2x", tempValue);

    IsLostExaming =FALSE;

    //UpdateData(false);

}

Dlg_Debug::~Dlg_Debug()
{
    delete ui;
}


void  Dlg_Debug::OnButtonSendZK()
{

   qDebug("OnButtonSendZK");


   ZKStatus = 1;
   ZKDebugIndex = 0;
   QTime currenttime;
   currenttime=QTime::currentTime();
   ZKT0=currenttime.hour()*60*60*1000*10 + currenttime.minute()*60*1000*10 + currenttime.second()*1000*10 + currenttime.msec()*10;//精确到0.1MS

   //SYSTEMTIME currentTime;
   //GetSystemTime(&currentTime);
   //ZKT0 = currentTime.wHour*60*60*1000*10 + currentTime.wMinute*60*1000*10 + currentTime.wSecond*1000*10 + currentTime.wMilliseconds*10;//精确到0.1MS


}


void Dlg_Debug::OnButtonStopTO()
{

       qDebug("OnButtonStopTO");

       ZKStatus = 0;
       ZKDebugIndex = 0;

}



void Dlg_Debug::OnButtonApply()
{
        qDebug("OnButtonApply");
        DWORD tempValue = 0;
        //UpdateData();

        tempValue =CharToHex(ui->m_Ver->text());//不得超过4byte
        memcpy(&(DebugHEADER_Measure.v_Version),	&tempValue, 1);
        memcpy(&(DebugHEADER_Timer.v_Version),	&tempValue, 1);
        tempValue =CharToHex(ui->m_MID->text());//不得超过4byte
        memcpy(DebugHEADER_Timer.v_SP1,			&tempValue, 2);
        memcpy(DebugHEADER_Measure.v_SP1,			&tempValue, 2);
        tempValue =CharToHex(ui->m_SID->text());//不得超过4byte
        memcpy(DebugHEADER_Timer.v_SP2,			&tempValue, 4);
        memcpy(DebugHEADER_Measure.v_SP2,			&tempValue, 4);
        tempValue =CharToHex(ui->m_DID->text());//不得超过4byte
        memcpy(DebugHEADER_Timer.v_SP3,			&tempValue, 4);
        memcpy(DebugHEADER_Measure.v_SP3,			&tempValue, 4);

        tempValue =CharToHex(ui->m_BID_Timer->text());//不得超过4byte
        memcpy(DebugHEADER_Timer.v_SP4,			&tempValue, 4);
        tempValue =CharToHex(ui->m_BID_Measure->text());//不得超过4byte
        memcpy(DebugHEADER_Measure.v_SP4,			&tempValue, 4);

        double dou;
        QString temp_mid;

        dou=0;
        temp_mid= ui->m_A->text();
        dou=temp_mid.toDouble();
        A			= dou;
        temp_mid.clear();

        dou=0;
        temp_mid= ui->m_E->text();
        dou=temp_mid.toDouble();
        E			= dou;
        temp_mid.clear();
        temp_mid.clear();

        dou=0;
        temp_mid=ui->m_OffsetX->text();
        dou=temp_mid.toDouble();
        OffsetX		=dou;
        temp_mid.clear();

        dou=0;
        temp_mid=ui->m_OffsetY->text();
        dou=temp_mid.toDouble();
        OffsetY		= dou;
        temp_mid.clear();

        dou=0;
        temp_mid=ui->m_Wyd_X->text();
        dou=temp_mid.toDouble();
        WydX		= dou;
        temp_mid.clear();

        dou=0;
        temp_mid=ui->m_Wyd_Y->text();
        dou=temp_mid.toDouble();
        WydY		= dou;
        temp_mid.clear();

        dou=0;
        temp_mid=ui->m_Wyd_Z->text();
        dou=temp_mid.toDouble();
        WydZ		= dou;
        temp_mid.clear();
        //?????????????????????????????、？？？？？？？？、MFC的combobox???????????????？？？？？？？？？？？？？？？？
        ServerMode=ui->m_ServerMode->currentText();


}



void Dlg_Debug::OnButtonSave()
{
     qDebug("OnButtonSave");

     OnButtonApply();

     QString iniFilePath = INIFILE;
     QString iniFilePath_a;
     iniFilePath_a=QApplication::applicationDirPath();
     //char iniFilePath_a[256];
     // GetCurrentDirectory(256, iniFilePath_a);
     iniFilePath = iniFilePath_a;
     iniFilePath+="/settest.ini";

     CBaseFile iniFile;
     QString sectionName;
     QString secContent;
     int secValue = 0;
     BYTE ip1, ip2, ip3, ip4;
     QString tempName;
     QString tempDID;
     QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
     DWORD tempValue;
     int CTCounter=0;
     int tempCTCounter=0;

     sectionName = "调试数据配置";
     secContent.sprintf("%.2x",DebugHEADER_Measure.v_Version);//.Format("%.2x", DebugHEADER_Measure.v_Version);
     iniFile.WriteIniVal(sectionName, "T_VER", secContent, iniFilePath);

     memcpy(&tempValue,			DebugHEADER_Measure.v_SP2, 4);
     secContent.sprintf("%.8x",tempValue);//.Format("%.8x",	tempValue);
     iniFile.WriteIniVal(sectionName, "T_SID", secContent, iniFilePath);
     memcpy(&tempValue,			DebugHEADER_Measure.v_SP3, 4);
     secContent.sprintf("%.8x",tempValue);//.Format("%.8x",	tempValue);
     iniFile.WriteIniVal(sectionName, "T_DID", secContent, iniFilePath);
     memcpy(&tempValue,			DebugHEADER_Measure.v_SP1, 2);
     secContent.sprintf("%.4x",tempValue);//.Format("%.4x",	tempValue);
     iniFile.WriteIniVal(sectionName, "T_MID", secContent, iniFilePath);
     memcpy(&tempValue,			DebugHEADER_Timer.v_SP4, 2);
     secContent.sprintf("%.8x",tempValue);//.Format("%.8x",	tempValue);
     iniFile.WriteIniVal(sectionName, "T_BID常时", secContent, iniFilePath);
     memcpy(&tempValue,			DebugHEADER_Measure.v_SP4, 4);
     secContent.sprintf("%.8x",tempValue);//.Format("%.8x",	tempValue);
     iniFile.WriteIniVal(sectionName, "T_BID实算数据", secContent, iniFilePath);
 //????????????????????????????？？？？？？？？？？？？？？有没有问题？？？？？？？？？？？？？？？？、？？？？？？？？？结合后面给lineedit赋值的情况
     secContent=ui->m_Wyd_X->text();//.Format("%f",	m_Wyd_X);
     iniFile.WriteIniVal(sectionName, "T_外引导X", secContent, iniFilePath);
     secContent=ui->m_Wyd_Y->text();//.Format("%f",	m_Wyd_Y);
     iniFile.WriteIniVal(sectionName, "T_外引导Y", secContent, iniFilePath);
     secContent=ui->m_Wyd_Z->text();//.Format("%f",	m_Wyd_Z);
     iniFile.WriteIniVal(sectionName, "T_外引导Z", secContent, iniFilePath);
     secContent=ui->m_OffsetX->text();//.Format("%f",	m_OffsetX);
     iniFile.WriteIniVal(sectionName, "T_X", secContent, iniFilePath);
     secContent=ui->m_OffsetY->text();//.Format("%f",	m_OffsetY);
     iniFile.WriteIniVal(sectionName, "T_Y", secContent, iniFilePath);
     secContent=ui->m_A->text();//.Format("%f",	m_A);
     iniFile.WriteIniVal(sectionName, "T_A", secContent, iniFilePath);
     secContent=ui->m_E->text();//.Format("%f",	m_E);
     iniFile.WriteIniVal(sectionName, "T_E", secContent, iniFilePath);

     QString ModeTmp=ui->m_ServerMode->currentText().toLocal8Bit();
     iniFile.WriteIniVal(sectionName, "T_Mode", ModeTmp, iniFilePath);

     fileConvert();
}



void Dlg_Debug::OnDebugCancel()
{

    qDebug("OnDebugCancel");

    DWORD tempValue;
    tempValue=0;
    QString temp_mid;
    memcpy(&tempValue,	DebugHEADER_Timer.	v_SP4, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_BID_Timer->setText(temp_mid);//.Format("%.8x", tempValue);
    temp_mid.clear();

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP4, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_BID_Measure->setText(temp_mid);//
    temp_mid.clear();
    //m_BID_Measure.Format("%.8x", tempValue);

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP3, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_DID->setText(temp_mid);//
    temp_mid.clear();
    //m_DID.Format("%.8x", tempValue);

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP2, 4);
    temp_mid.sprintf("%.8x",tempValue);
    ui->m_SID->setText(temp_mid);//
    temp_mid.clear();
    //m_SID.Format("%.8x", tempValue);

    tempValue=0;
    memcpy(&tempValue,	DebugHEADER_Measure.	v_SP1, 2);
    temp_mid.sprintf("%.4x",tempValue);
    ui->m_MID->setText(temp_mid);//
    temp_mid.clear();
    //m_MID.Format("%.4x", tempValue);

    tempValue=0;
    memcpy(&tempValue, &(DebugHEADER_Measure.	v_Version), 1);
    temp_mid.sprintf("%.2x",tempValue);
    ui->m_Ver->setText(temp_mid);//
    temp_mid.clear();
    //m_Ver.Format("%.2x", tempValue);

/*    //界面刷新
        DWORD tempValue=0;
        memcpy(&tempValue,	DebugHEADER_Timer.	v_SP4, 4);
        m_BID_Timer.Format("%.8x", tempValue);
        tempValue=0;
        memcpy(&tempValue,	DebugHEADER_Measure.	v_SP4, 4);
        m_BID_Timer.Format("%.8x", tempValue);
        tempValue=0;
        memcpy(&tempValue,	DebugHEADER_Measure.	v_SP3, 4);
        m_DID.Format("%.8x", tempValue);
        tempValue=0;
        memcpy(&tempValue,	DebugHEADER_Measure.	v_SP2, 4);
        m_SID.Format("%.8x", tempValue);
        tempValue=0;
        memcpy(&tempValue,	DebugHEADER_Measure.	v_SP1, 2);
        m_MID.Format("%.4x", tempValue);
        tempValue=0;
        memcpy(&tempValue, &(DebugHEADER_Measure.	v_Version), 1);
        m_Ver.Format("%.2x", tempValue);
*/


        temp_mid.sprintf("%f",WydX);
        ui->m_Wyd_X->setText(temp_mid);
        temp_mid.clear();
        //m_Wyd_X = WydX;

        temp_mid.sprintf("%f",WydY);
        ui->m_Wyd_Y->setText(temp_mid);
        temp_mid.clear();
        //m_Wyd_Y = WydY;

        temp_mid.sprintf("%f",WydZ);
        ui->m_Wyd_Z->setText(temp_mid);
        temp_mid.clear();
        //m_Wyd_Z = WydZ;

        temp_mid.sprintf("%f",OffsetX);
        ui->m_OffsetX->setText(temp_mid);
        temp_mid.clear();
        //m_OffsetX = OffsetX;

        temp_mid.sprintf("%f",OffsetY);
        ui->m_OffsetY->setText(temp_mid);
        temp_mid.clear();
        //m_OffsetY = OffsetY;

        temp_mid.sprintf("%f",A);
        ui->m_A->setText(temp_mid);
        temp_mid.clear();
        //m_A = A;

        temp_mid.sprintf("%f",E);
        ui->m_E->setText(temp_mid);
        temp_mid.clear();
        //m_E = E;


        ui->m_ServerMode->addItem(ServerMode);

}

/************************************************************************/
/* 清除数据                                                         */
/************************************************************************/

void Dlg_Debug::UnInitDebugData()
{
    qDebug("UnInitDebugData");

        memset(&DebugHEADER_Measure, 0, sizeof(HEADERStruct));
        memset(&DebugHEADER_Timer, 0, sizeof(HEADERStruct));
        INI_DATALENGTH_MEASURE = 0;

        A = 0.0;
        E = 0.0;
        OffsetX = 0.0;
        OffsetY = 0.0;
        WydX = 0.0;
        WydY = 0.0;
        WydZ = 0.0;
        ServerMode = "";
        ZKStatus = 0;

}


void Dlg_Debug::OnBnClickedDebugStartlost()
{

     qDebug("OnBnClickedDebugStartlost");


     IsLostExaming = !IsLostExaming;
         if(IsLostExaming)
         {
             //::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_USER_STARTLOST, 1, 0);
             emit WM_USER_STARTLOST(1,0);
             ui->DEBUG_STARTLOST->setText("正在测试丢包中");
         }
         else
         {
             //::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_USER_STARTLOST, 0, 0);
             emit WM_USER_STARTLOST(0,0);
             ui->DEBUG_STARTLOST->setText("未开始测试丢包");
         }

}


void Dlg_Debug::OnBnClickedDebugCheckStatusswitch()
{

     qDebug("OnBnClickedDebugCheckStatusswitch");
     //????????????????????????????????????????？？？？？？？？？？？？？？？？？？？？？？？？？？、、？？？？？？？？？、
     //::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_COMMAND, IDC_CHECK_STATUSSWITCH, 0);
     emit  WM_COMMANDStatus();
}







void Dlg_Debug::OnBnClickedDebugCheckStatusswitch2()
{

     qDebug("OnBnClickedDebugCheckStatusswitch2");
    //????????????????????????????????????????？？？？？？？？？？？？？？？？？？？？？？？？？？、、？？？？？？？？？、
     //::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_COMMAND, IDC_CHECK_STATUSSWITCH2, 0);
      emit  WM_COMMANDStatus2();
}


void Dlg_Debug::OnBnClickedButtonDebugSendexam()
{

    qDebug("OnBnClickedButtonDebugSendexam");
    //????????????????????????????????????????？？？？？？？？？？？？？？？？？？？？？？？？？？、、？？？？？？？？？、
    //::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_COMMAND, IDC_BUTTON_SENDEXAM, 0);
     emit  WM_COMMANDSendexam();
}

