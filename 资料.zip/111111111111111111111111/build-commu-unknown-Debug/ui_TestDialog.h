/********************************************************************************
** Form generated from reading UI file 'TestDialog.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTDIALOG_H
#define UI_TESTDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_CTestDialog
{
public:
    QPushButton *okButton;
    QPushButton *cancleButton;

    void setupUi(QDialog *CTestDialog)
    {
        if (CTestDialog->objectName().isEmpty())
            CTestDialog->setObjectName(QString::fromUtf8("CTestDialog"));
        CTestDialog->resize(400, 300);
        okButton = new QPushButton(CTestDialog);
        okButton->setObjectName(QString::fromUtf8("okButton"));
        okButton->setGeometry(QRect(290, 20, 99, 27));
        cancleButton = new QPushButton(CTestDialog);
        cancleButton->setObjectName(QString::fromUtf8("cancleButton"));
        cancleButton->setGeometry(QRect(290, 70, 99, 27));

        retranslateUi(CTestDialog);

        QMetaObject::connectSlotsByName(CTestDialog);
    } // setupUi

    void retranslateUi(QDialog *CTestDialog)
    {
        CTestDialog->setWindowTitle(QApplication::translate("CTestDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        okButton->setText(QApplication::translate("CTestDialog", "OK", 0, QApplication::UnicodeUTF8));
        cancleButton->setText(QApplication::translate("CTestDialog", "Cancle", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CTestDialog: public Ui_CTestDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTDIALOG_H
