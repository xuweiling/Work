#include "yfdoubleclick_trapid.h"
#include "ui_yfdoubleclick_trapid.h"

YFDoubleClick_TrapID::YFDoubleClick_TrapID(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::YFDoubleClick_TrapID)
{
    ui->setupUi(this);
}

YFDoubleClick_TrapID::~YFDoubleClick_TrapID()
{
    delete ui;
}


void YFDoubleClick_TrapID::on_addButton_clicked()
{
    text = ui->TrapID->text();
    other = ADDBUTTON;

    accept();
}

void YFDoubleClick_TrapID::on_ModifyButton_clicked()
{
    text = ui->TrapID->text();
    other = MODIFYBUTTON;

    accept();
}

void YFDoubleClick_TrapID::on_deleteButton_clicked()
{
    other = DELETEBUTTON;

    accept();
}
