﻿#ifndef YFMAINWINDOW_H
#define YFMAINWINDOW_H

#include <QMainWindow>
#include "QListWidget"
#include "QString"
#include "yfmIbbrowerview.h"
#include <QFile>
#include "WinDef.h"

#define   YFAGENTPARNUM   10

//#define Uint32 unsigned int
//主控软件与数据交互软件的数据格式
struct LenImageSystemStatus
{
    u_int8_t CameraWorkStatus;//相机工作状态"0":正常;"1":故障
    u_int8_t ImageRecordStatus;//图像记录系统状态"0":空闲;"1":记录;"2":故障
    u_int8_t LightStatus;//调光小系统状态"0":正常;"1":故障
    u_int8_t FocusStatus;//调焦小系统状态"0":正常;"1":故障
    u_int8_t ImageDownloadStatus;//图像下载状态"0":空闲;"1":下载;"2":故障
    u_int16_t PhotoFrequency;//拍摄帧频
} ;

struct TrackSystemStatus
{
    u_int8_t TrackSysWorkStatus;//跟踪分系统工作状态"0":已启动;"1":未启动;
    u_int8_t TrackSysStatus;//跟踪状态0:没有跟踪;1: 质心;2: 边缘;3:相关
    u_int8_t TargetMode;//目标类型"0":亮目标;"1":暗目标
    u_int8_t TrackThreshold;//阈值0~255
} ;//跟踪系统状态

struct TargetParam
{
    int32_t TargetOffsetX;//方位脱靶量 二进制补码 0.1" 无效时填7FFFFFFFH
    int32_t TargetOffsetY;//俯仰脱靶量 二进制补码 0.1" 无效时填7FFFFFFFH
    int32_t TargetVelo;//目标测速值 二进制补码 0.001m/s 无效时填7FFFFFFFH
    int32_t TargetDistance;//测距值 无符号整数 0.01m 无效时填"0"
    u_int16_t TargetLuminance;//目标亮度 二进制补码 0.1星等 无效时填7FFFH
} ;//目标参数
struct MasterControl2SJ
{
    u_int8_t  FillDataLocation[32];//由交互计算机填充数据，发送时全部填为0x00  B0~31
    u_int32_t CurrentTime;//当前时刻 无符号整数 0.1ms 测量数据对应时刻B32~35
    u_int8_t  EquipmentStatus;//设备状态 二进制代码  B36 b3～b0 0000:半自动未跟踪目标;0001:程序引导;0010:数字引导;0011:同步引导;0100:半自动跟踪;0101:电视自动跟踪;0110:中波红外自动跟踪;
                           //0111:长波红外自动跟踪;1000:短波红外自动跟踪;1001:多路复合跟踪（GS-1301指加权跟踪）;1010:激光自动跟踪;1011:雷达自动跟踪
    int32_t   AngleA;//方位角 二进制补码 360°/pow（2，31）B37~40
    int32_t   AngleE;//俯仰角 二进制补码 360°/pow（2，31）B41~44
    u_int8_t  TargetNum;// 目标总数 无符号整数 B45
    TargetParam TargetOne;//当前跟踪目标的脱靶量有效值 B46~63
    u_int8_t  StationWorkStatus;//单站工作状态 "0":正常;"1":故障;"2":关机 B64
    u_int8_t  ServoStatus;//伺服跟踪模式  B65 "0":半自动未跟踪（待机）;"1":程序引导;"2":数字引导;"3":同步引导;"4":定点引导;"5":半自动跟踪;"6":多路复合跟踪（融合跟踪）;"7":激光自动跟踪;"8":雷达自动跟踪;
                       //"9":事前设置（凝视）模式;"11":电视1自动跟踪;"12":电视2自动跟踪; … "21":红外1自动跟踪;"22":红外2自动跟踪; … "31":紫外自动跟踪 … 其他自定义"…"表示可扩展
    u_int8_t  StickAStatus;//单杆方位状态  B66 0:没有电压;1:正电压;2:负电压
    u_int8_t  StickEStatus;//单杆俯仰状态  B67 0:没有电压;1:正电压;2:负电压
    u_int8_t  AServoStatus;//方位伺服系统工作状态 B68  "0":未启动;"1":已启动(正常);"2":方位负限位; "3":方位正限位;"4":方位锁紧;"9""故障
    u_int8_t  EServoStatus;//高低伺服系统工作状态 B69 "0":未启动;"1":已启动(正常);"2":俯仰负限位; "3":俯仰正限位;"4":俯仰锁紧;"9""故障
    u_int8_t  AEncodeStatus;//单站方位编码器工作状态 B70 "0":正常;"1":故障
    u_int8_t  EEncodeStatus;//单站高低编码器工作状态 B71"0":正常;"1":故障
    u_int8_t  TimeTerminusStatus;//单站时统系统工作状态 B72 "0":正常;"1":故障
    u_int8_t  TimeSynStatus;//单站时统系统时间同步状态 B73 "0":正常;"1":故障
    u_int8_t  TimeFreAccuracyStatus;//单站时统系统时间频率准确度状态 B74 "0":正常;"1":故障
    u_int8_t  TimeSynSource;//单站时统系统时间同步源 B75 "0":无;"1":GPS;"2":Glonass;"3":北斗;"4":B码
    LenImageSystemStatus LenImageSysStatusFirst; //B76~82
    LenImageSystemStatus LenImageSysStatusSecond; //B83~89
    TrackSystemStatus    TrackSysStatusFirst; //B90~93
    TrackSystemStatus    TrackSysStatusSecond;//B93~97
    u_int8_t  EquipmentWorkStatus;//设备工作状态 B98 INTEGER "0":设备待命;"1":设备自检;"2":设备调试;"3":设备标校;"4":接收任务数据;"5":测量数据上传;"6":设备执行任务;"7":测量数据事后处理
} ;



namespace Ui {
class YFMainWindow;
}

class YFMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit YFMainWindow(QWidget *parent = 0);
    ~YFMainWindow();

     QString GetOneLine;
     QListWidgetItem * QLWitem;
     bool isTimerStarting;

     void upUI(void);
     void upUIFromAgent();
     void *getui() {return this;}

private slots:
 //   void on_startAgent_clicked();

    void on_stopAgent_clicked();

    void on_traptest_clicked();

    void on_reset_clicked();

    void on_ReadFButton_clicked();

    void GetOneLineOID(QListWidgetItem * item);

    void on_ModifyButton_2_clicked();

    void on_DeleteButton_2_clicked();

    void on_AddButton_2_clicked();

    void on_WriteFile_clicked();

    void on_writeagent_clicked();

    void on_listWidget_doubleClicked(const QModelIndex &index);

    void on_UpUIFromAgent_clicked();

    void UpUIFromAgent();

public slots:
    void on_quitAgent_clicked();
    void on_startAgent_clicked();
     void TransData(const char  *recData);

private:
    Ui::YFMainWindow *ui;
    QTimer *timer;
    MasterControl2SJ pData;

    QString GetValuefromfile2UI(QTreeNode *&currentNode);
    void GetValueFromUI2Agnet(QTreeNode *&currentNode,QString Value);
    void GetABValueFromCYN(QTreeNode *&currentNode,char Value);
    QString GetValueFromAgnet2UI(QTreeNode *&currentNode);

    int GetAValueFromCYN(QTreeNode *&currentNode,char Value);
    int GetBValueFromCYN(QTreeNode *&currentNode,int Value);

    void SaveUIData2file();
};

void upUI(void);

#endif // YFMAINWINDOW_H
