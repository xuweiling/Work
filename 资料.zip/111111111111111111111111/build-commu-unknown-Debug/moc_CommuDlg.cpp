/****************************************************************************
** Meta object code from reading C++ file 'CommuDlg.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../commu/CommuDlg.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CommuDlg.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CCommuDlg[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      13,   11,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
      36,   10,   10,   10, 0x0a,
      54,   10,   10,   10, 0x0a,
      67,   10,   10,   10, 0x0a,
      86,   10,   10,   10, 0x0a,
     108,   10,   10,   10, 0x0a,
     142,  131,   10,   10, 0x0a,
     166,   10,   10,   10, 0x0a,
     195,  181,  176,   10, 0x0a,
     217,  181,  176,   10, 0x0a,
     237,  181,  176,   10, 0x0a,
     259,  181,  176,   10, 0x0a,
     279,   10,   10,   10, 0x0a,
     292,  181,  176,   10, 0x0a,
     315,   10,   10,   10, 0x0a,
     328,  181,  176,   10, 0x0a,
     355,  181,  176,   10, 0x0a,
     379,  181,  176,   10, 0x0a,
     419,  403,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_CCommuDlg[] = {
    "CCommuDlg\0\0,\0WM_USER_1Hz(uint,long)\0"
    "OnButtonConnect()\0OnCoCancel()\0"
    "OnButtonSendExam()\0OnCheckStatusSwitch()\0"
    "OnCheckStatusswitch2()\0nID,lParam\0"
    "OnSysCommand(uint,long)\0OnTimer()\0"
    "long\0wParam,lParam\0ReceivedCT(uint,long)\0"
    "SendedCT(uint,long)\0ReceivedZK(uint,long)\0"
    "SendedZK(uint,long)\0ParamApply()\0"
    "OnTimer20Hz(uint,long)\0OnTimer1Hz()\0"
    "OnStartLostExam(uint,long)\0"
    "OnCheckSend1(uint,long)\0OnCheckSend2(uint,long)\0"
    "HandleWay,WayNO\0ChangeIshandleway(bool,int)\0"
};

void CCommuDlg::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CCommuDlg *_t = static_cast<CCommuDlg *>(_o);
        switch (_id) {
        case 0: _t->WM_USER_1Hz((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2]))); break;
        case 1: _t->OnButtonConnect(); break;
        case 2: _t->OnCoCancel(); break;
        case 3: _t->OnButtonSendExam(); break;
        case 4: _t->OnCheckStatusSwitch(); break;
        case 5: _t->OnCheckStatusswitch2(); break;
        case 6: _t->OnSysCommand((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2]))); break;
        case 7: _t->OnTimer(); break;
        case 8: { long _r = _t->ReceivedCT((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 9: { long _r = _t->SendedCT((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 10: { long _r = _t->ReceivedZK((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 11: { long _r = _t->SendedZK((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 12: _t->ParamApply(); break;
        case 13: { long _r = _t->OnTimer20Hz((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 14: _t->OnTimer1Hz(); break;
        case 15: { long _r = _t->OnStartLostExam((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 16: { long _r = _t->OnCheckSend1((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 17: { long _r = _t->OnCheckSend2((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = _r; }  break;
        case 18: _t->ChangeIshandleway((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CCommuDlg::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CCommuDlg::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_CCommuDlg,
      qt_meta_data_CCommuDlg, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CCommuDlg::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CCommuDlg::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CCommuDlg::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CCommuDlg))
        return static_cast<void*>(const_cast< CCommuDlg*>(this));
    return QWidget::qt_metacast(_clname);
}

int CCommuDlg::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void CCommuDlg::WM_USER_1Hz(unsigned int _t1, long _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
