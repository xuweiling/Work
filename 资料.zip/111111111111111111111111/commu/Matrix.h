// Matrix.h: interface for the CMatrix class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATRIX_H__623373B2_D450_40CD_AF2A_165354D9B651__INCLUDED_)
#define AFX_MATRIX_H__623373B2_D450_40CD_AF2A_165354D9B651__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//linux
#define     ZeroMemory(Destination,Length)      memset((Destination),0,(Length))


class CMatrix  
{
protected:
	double * buffer;
	
	
private:
	CMatrix * M_temp;
public :
	int rows;
	int cols;
	char name[20];
	int error;
	CMatrix& operator * (const CMatrix & m1);
	CMatrix& operator=( const CMatrix & m1); 
	CMatrix& operator+( CMatrix & m1);
	CMatrix& operator-( CMatrix & m1);
	double&  operator()( int row,int col);
	CMatrix& MatrixMultil(const CMatrix & m1,const CMatrix & m2);
	void SetAt(int row,int col,double value);
	CMatrix & reverse();
	double GetAt(int row,int col);
	void reshape(int row,int col);
	void Print();
	
public:
	CMatrix();
	CMatrix(int row,int col);
	CMatrix(CMatrix & m1);
//	CMatrix(double row,...);
	virtual ~CMatrix();

};

#endif // !defined(AFX_MATRIX_H__623373B2_D450_40CD_AF2A_165354D9B651__INCLUDED_)
