﻿// NetCommuCT.h: interface for the CNetCommuCT class.
//
//////////////////////////////////////////////////////////////////////

/************************************************************************/
/*
注意:
    本类负责数据收发和编解码,什么时候发送数据由调用者调用Send即可，
数据的互斥由调用者保证（只要BufferSend_Passed保证不冲突即可）
接收的数据直接由BufferRecv_Passed采集即可（通过消息通知调用者来
收集数据）
一张网卡对应一个实例

  使用:
  a.初始化    1.实例化；2.StartConnect; 3.设置PDlg、CurrentMode、TimeSource、DebugHEADER、
                        BufferSaveFilePath_Send、BufferSaveFilePath_Recv
                        至此初始化完毕
  b.当接收到WM_USER_RECEIVED_CT消息时，可从BufferRecv_Passed中取数据；
                从pBufferRecvLength中得到数据长度，从DataSource中得到数据源
  c.当需要发送数据时，只要设置了BufferSend_Passed的内容、pBufferSendLength数据长度、
                如有时时修改的需要，还要设置CurrentMode、TimeSource和DebugHEADER
                发送完毕后，自BufferSended_Passed可得到重新编码后的数据,
                自pBufferSendedLength得到该数据的长度
  d.关闭：CloseConnect、SaveFile即可
                                                                      */
/************************************************************************/

#ifndef NETCOMMUCT_H
#define NETCOMMUCT_H

#include "NetCommu.h"
#include "CTSocket.h"
#include <vector>
#include <QObject>
#include"GlabalDefine.h"

using namespace std;

class CNetCommuCT : public QObject,public CNetCommu
{
    Q_OBJECT
public:
        explicit CNetCommuCT(QObject *parent = 0);
        virtual ~CNetCommuCT();

        bool StartConnect(int paramWayNo, Sockettp paramSendSocketTP, Sockettp paramRecvSocketTP);//网络启动，线程启动
        bool SendData(int type);								//发送数据
        bool SendData(BYTE* sendDataBuffer, int sendDataBufferLength, SocketSetting	DestSet, int type);//发送数据
        bool CloseConnect( );							//关闭连接
        bool Receive( );								//由窗口调用，通知处理

        int TransZK2CT(BYTE* pSource, int pSourceLength, BYTE* pDest, int pDestLength, int type=-1);//转换函数

        SocketSetting DataSource;						//用于保存数据来源，以便窗口查阅

        static QString	BufferSaveFilePath_Send;		//将要保存的发送数据文件路径
        static QString	BufferSaveFilePath_Recv;		//将要保存的接收数据文件路径
        static bool SaveFile();							//保存到文件中
        static bool FormatOctFile( QString SaveFileName_Send, QString SaveFileName_Recv );					//保存到文件中
    //	static BYTE BufferSave_Send[MACRO_FILE_SIZE];	//将要保存到文件中的发送数据
    //	static BYTE BufferSave_Recv[MACRO_FILE_SIZE];	//将要保存到文件中的接收数据
        static int BufferSave_SendLength;				//将要保存到文件中的发送数据长度
        static int BufferSave_RecvLength;				//将要保存到文件中的接收数据长度 使用static,这样所有的数据都保存在一个文件中
        static SYSTEMTIME	StartTime;						//起始时刻
        static SYSTEMTIME	EndTime;						//保存时刻

        double		EjectPosB;							//发射点的大地直角坐标系坐标 Jerry 20110707++
        double		EjectPosL;							//发射点的大地直角坐标系坐标 Jerry 20110707++
        double		EjectPosH;							//发射点的大地直角坐标系坐标 Jerry 20110707++
        double		EjectAngle;							//发射点的发射角 Jerry 20110907++

        bool		SocketEnable;						//本通信类是否使用，这决定于Socket是否成功绑定
        bool    SendEnable;						//仅控制是否发送数据

        DWORD LostWYD;						//外引导丢包统计
        DWORD WYDCount;					//外引导数量
        DWORD MulWYD;						//外引导乱序统计
        DWORD Index0;							//上一帧外引导序号
        DWORD Index1;							//本帧外引导序号

        static DWORD WYDCOUNT;
        static DWORD T0COUNT;
        static DWORD LinkRecvCOUNT;
        static DWORD LinkSendCOUNT;
        static DWORD MeasureCOUNT;
        static DWORD TimeExamSendCOUNT;
        static DWORD TimeExamRecvCOUNT;
        static DWORD ZKSendCOUNT;
        static DWORD ZKRecvCOUNT;
        static DWORD FZSendCOUNT;
        static DWORD FZRecvCOUNT;

        static DWORD RecentTime;							//最新收到的时间
        static DWORD RecentDate;							//最新收到的日期
        static DWORD RecentDateTime;

protected:
    CCTSocket		theSendSocket;					//通信端口
    CCTSocket		theRecvSocket;					//通信端口
    SocketSetting	LocalSet;						//Socket配置（本地）
    vector<AddStruct> CTP2PSet;//Socket配置（单播）
    vector<AddStruct> CTMulSetSe;//Socket配置（组播）
    vector<AddStruct> CTMulSetRe;//Socket配置（组播）
    vector<DWORD> CTSrcSet;//Socket配置（组播源）
    int				CTP2PNum;						//单播地址数目
    int				CTMulNumSe;						//组播地址数目
    int				CTMulNumRe;						//组播地址数目
    int				CTSrcNum;						//组播源地址数目

    bool ReadIniFile( );							//读取配置内容：文件名为"\\配置.ini"(MACRO_INI_FILEPATH)
//继承时必须读取到的:网卡的IP，收发端口；监控机的IP、路由；包头固定信息;各个数据区长度;(发射点信息依据坐标系是否需要转换而定

    int			INI_DATALENGTH_ZK;					//分站主控发送的数据长度
    int			INI_DATALENGTH_MEASURE;				//实算数据中数据区有效长度 = 32, 22+10
    int			INI_DATALENGTH_THEORY;				//引入数据中数据区有效长度 = 28
    int			INI_DATALENGTH_EXAM;				//时延测试数据区长度
    int			INI_DATALENGTH_T0;					//T0数据区长度
    int			INI_REVERSE_DATALENGTH;				//正式实算数据中最后保留的数据长度		Jerry 20110629
    QString		INI_REVERSE_DATACONTENT;			//正式实算数据中最后保留的数据内容	Jerry 20110629

    int			WayNO;
    Sockettp	SendSocketTP;						//发送网络属性
    Sockettp	RecvSocketTP;						//接收网络属性

//下面为临时变量
    DWORD MeasurePackIndex;				//实算数据的数目
    DWORD TimerPackIndex;					//发送的常时数据的数目
    DWORD ExamPackIndex;					//时延测试数据的数目
    DWORD DebugPackIndex;					//用来测试BID
    DWORD BIDTest;									//用来测试BID

    QString SaveFileName_Send;
    QString SaveFileName_Recv;
    QString OctFileName_Send;
    QString OctFileName_Recv;
    int SendFile;
    int RecvFile;
    int SendFileOct;
    int RecvFileOct;

    DWORD DesI;
    void OctSwitch( int type, QString InputString,  QString* OutputString );

signals:
            void  WM_USER_RECEIVED_CT(unsigned int ,long );
            void  WM_USER_SENDED_CT(unsigned int,long);

public slots:

};

#endif // !defined(AFX_NETCOMMUCT_H__C1E77E9F_7608_4476_B5F8_2643D7C64CF7__INCLUDED_)
