﻿#include "CDlg_MsgDisplay.h"
#include "ui_CDlg_MsgDisplay.h"
 #include <QMouseEvent>
#include"GlabalDefine.h"
#include "BaseFile.h"
#include <math.h>
#include "NetCommuCT.h"
#include "NetCommuZK.h"

CDlg_MsgDisplay::CDlg_MsgDisplay(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CDlg_MsgDisplay)
{
    ui->setupUi(this);
    Timer1SecondHWND = new QTimer(this);

    connect(ui->m_Select_1,SIGNAL(clicked()),this,SLOT(OnButtonSelect1()));
    connect(ui->m_Select_2,SIGNAL(clicked()),this,SLOT(OnButtonSelect2()));
    connect(ui->m_ChkSend1,SIGNAL(clicked()),this,SLOT(OnBnClickedCheckSend1()));
    connect(ui->m_ChkSend2,SIGNAL(clicked()),this,SLOT(OnBnClickedCheckSend2()));
    connect(Timer1SecondHWND, SIGNAL(timeout()), this, SLOT(Ontimer()));
    connect(ui->m_SetWayAutoHandle,SIGNAL(clicked()),this,SLOT(OnCheckAutohandle()));

    DisplayAddIndex1 = 3;
    DisplayAddIndex2 = 3;

      //COLORREF Backcolor=0x00afaf00;??????????????????????????????????????设置背景?????？？？？？？？？？？？？？？？？？？？
    //	SetBackgroundColor(Backcolor);
       //SetBackgroundImage(IDB_BITMAP4, BACKGR_TILE);
//????????????????????????????????????????////?????????????设置图片????????？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        ui->m_NetStatus1->clear();//.ShowWindow(SW_HIDE);//
  //      ui->m_NetStatus1->set.ShowWindow(SW_SHOW);
        ui->m_NetStatus2->clear();//.ShowWindow(SW_HIDE);错误的的为m_NetStatus1_2
    //    ui->m_NetStatus2.ShowWindow(SW_SHOW);

        CTP2PNum=0;
        CTMulNumRe=0;
        CTMulNumSe=0;
        ui->m_StIndexInfo->setHidden(true);
        ui->m_BuffetLeftLength->setHidden(true);
        ui->m_LagTime->setHidden(true);
}



CDlg_MsgDisplay::~CDlg_MsgDisplay()
{
    delete ui;
}


// CDlg_MsgDisplay message handlers
/*
显示接收数据
参数：
    sourceNO：数据来源：-3:本地主控；-2:本机；-1:中心站；0~n:监控机
    pChar：数据
    pLength：数据长度
type:
    1:HEADER 发送的实算数据
    2.发送的常时
    3.发送的主动时延测试
    4.发送的被动时延测试

    5.接收的T0
    6.接收的外引导
    7.接收的常时
    8.接收的时延测试

    9.中心站/主控台发送的T0
    10.中心站/主控台发送的外部说明数据
    11.中心站/主控台发送的远控数据
    12.发送给中心站/主控台的实算数据

  根据来源选择在哪个框内显示

  暂时不处理3、4、9、10、11、12
*/
void CDlg_MsgDisplay::FreshMsg(int sourceNO, BYTE* pChar, int pLength, int type)
{

    switch (type)
    {
    case 1:
        {
            DisplaySend(pChar, pLength, type);//本类中自定义函数
            TimeSendLagCount = 0;

            break;
        }
    case 2:
        {
            DisplaySend(pChar, pLength, type);
            break;
        }
    case 3:
        {
            break;
        }
    case 4:
        {
            DisplaySend(pChar, pLength, type);
            break;
        }
    case 5:
        {
            if(sourceNO == -1)//第一路由组播
            {
                ui->m_StType1->setText("T0");
                DisplayRecv_1(pChar, pLength, type);//本类中自定义函数
                TimeRecvLagCount_1 = 0;
            }
            else if(sourceNO == -2)//第2路由组播
            {
                ui->m_StType2->setText("T0");
                DisplayRecv_2(pChar, pLength, type);
                TimeRecvLagCount_2 = 0;
            }
            else
            {
                if(IsSource1(sourceNO))
                {
                    ui->m_StType1->setText("T0");
                    DisplayRecv_1(pChar, pLength, type);
                    TimeRecvLagCount_1 = 0;
                }
                if(IsSource2(sourceNO))
                {
                    ui->m_StType2->setText("T0");
                    DisplayRecv_2(pChar, pLength, type);
                    TimeRecvLagCount_2 = 0;
                }
            }

            break;
        }

    case 6:
            {
                if(sourceNO == -1)//第一路由组播
                {
                    ui->m_StType1->setText(tr("外引导"));
                    DisplayRecv_1(pChar, pLength, type);
                    TimeRecvLagCount_1 = 0;
                }
                else if(sourceNO == -2)//第2路由组播
                {
                    ui->m_StType2->setText(tr("外引导"));
                    DisplayRecv_2(pChar, pLength, type);
                    TimeRecvLagCount_2 = 0;
                }
                else
                {
                    if(IsSource1(sourceNO))///本类中自定义函数
                    {
                        ui->m_StType1->setText(tr("外引导"));
                        DisplayRecv_1(pChar, pLength, type);
                        TimeRecvLagCount_1 = 0;
                    }
                    if(IsSource2(sourceNO))//////本类中自定义函数
                    {
                        ui->m_StType2->setText(tr("外引导"));
                        DisplayRecv_2(pChar, pLength, type);
                        TimeRecvLagCount_2 = 0;
                    }
                }

                break;
            }

    case 7:
            {
                if(sourceNO == -1)//第一路由组播
                {
                    ui->m_StType1->setText(tr("常时"));
                    DisplayRecv_1(pChar, pLength, type);
                    TimeRecvLagCount_1 = 0;
                }
                else if(sourceNO == -2)//第2路由组播
                {
                    ui->m_StType2->setText(tr("常时"));
                    DisplayRecv_2(pChar, pLength, type);
                    TimeRecvLagCount_2 = 0;
                }
                else
                {
                    if(IsSource1(sourceNO))
                    {
                        ui->m_StType1->setText(tr("常时"));
                        DisplayRecv_1(pChar, pLength, type);
                        TimeRecvLagCount_1 = 0;
                    }
                    if(IsSource2(sourceNO))
                    {
                        ui->m_StType2->setText(tr("常时"));
                        DisplayRecv_2(pChar, pLength, type);
                        TimeRecvLagCount_2 = 0;
                    }
                }

                break;
            }
        case 8:
            {
                if(sourceNO == -1)//第一路由组播
                {
                    ui->m_StType1->setText(tr("时延测试"));
                    DisplayRecv_1(pChar, pLength, type);
                    TimeRecvLagCount_1 = 0;
                }
                else if(sourceNO == -2)//第2路由组播
                {
                    ui->m_StType2->setText(tr("时延测试"));
                    DisplayRecv_2(pChar, pLength, type);
                    TimeRecvLagCount_2 = 0;
                }
                else
                {
                    if(IsSource1(sourceNO))
                    {
                        ui->m_StType1->setText(tr("时延测试"));
                        DisplayRecv_1(pChar, pLength, type);
                        TimeRecvLagCount_1 = 0;
                    }
                    if(IsSource2(sourceNO))
                    {
                        ui->m_StType2->setText(tr("时延测试"));
                        DisplayRecv_2(pChar, pLength, type);
                        TimeRecvLagCount_2 = 0;
                    }
                }


                break;
            }
        case 9:
            {
                break;
            }
        case 10:
            {
                break;
            }
        case 11:
            {
                break;
            }
        case 12:
            {
                break;
            }
        }
}

/****************************************************************************/
/*鼠标双击事件*/
/*****************************************************************************/
void CDlg_MsgDisplay::mouseDoubleClickEvent(QMouseEvent *event)
{

         ui->m_LagTime->clear();//????????????????????????????????????????????????注意？？？？？？？？？？？？？？？时延项
         ui->m_Send_Time_2->clear();
         ui->m_Send_Time_1->clear();
         ui->m_Recv_Time_2_2->clear();
         ui->m_Recv_Time_2_1->clear();
         ui->m_Recv_Time_1_2->clear();
         ui->m_Recv_Time_1_1->clear();
         ui->m_Recv_Z_2->clear();
         ui->m_Recv_Z_1->clear();
         ui->m_Recv_Y_2->clear();
         ui->m_Recv_Y_1->clear();
         ui->m_Recv_X_2->clear();
         ui->m_Recv_X_1->clear();
         ui->m_RecvT0_2->clear();
         ui->m_RecvT0_1->clear();
         ui->m_SendSID->clear();
         ui->m_RecvSID_2->clear();
         ui->m_RecvSID_1->clear();
         ui->m_SendMID->clear();
         ui->m_RecvMID_2->clear();
         ui->m_RecvMID_1->clear();
         ui->m_SendDID->clear();
         ui->m_RecvDID_2->clear();//错误的为m_RecvTXp3_2
         ui->m_RecvDID_1->clear();//错误的为m_RecvTXp3_1
         ui->m_PackCount3->clear();
         ui->m_PackCount2->clear();
         ui->m_PackCount1->clear();
         ui->m_Send_Offset->clear();
         ui->m_Send_Mode->clear();
         ui->m_Send_E->clear();
         ui->m_Send_A->clear();

         ui->m_Send_1->clear();
         ui->m_Send_2->clear();
         ui->m_Recv_2_2->clear();
         ui->m_Recv_2_1->clear();
         ui->m_Recv_1_2->clear();
         ui->m_Recv_1_1->clear();
         ui->m_StType1->clear();
         ui->m_StType2->clear();
}



/************************************************************************/
/* 初始化内容。包括从文件中读取
                                                                     */
/************************************************************************/
void CDlg_MsgDisplay::InitContent(Sockettp recvType, Sockettp sendType)
{
    ReadIniFile();
    ui->m_DisplayAdd1->clear();//对应clear（）；
    ui->m_DisplayAdd2->clear();//对应clear（）；

    QString tempAdd;

    RecvSocketTP = recvType;
    SendSocketTP = sendType;

    if(recvType == Socket_Udp)//Socket_Udp 在globaldefine.h定义
        //针对发送端口作处理 UDP单播
    {
        for(int CTCounter=0; CTCounter<CTP2PNum; CTCounter++)
        {
            tempAdd=tempAdd.sprintf("%s",CTP2PSet[CTCounter].Name); //= CTP2PSet[CTCounter].Name;//arg
            if(CTP2PSet[CTCounter].WayChose==0)
            {
                ui->m_DisplayAdd1->addItem(tempAdd);//:addItem(QString );
            }
            if(CTP2PSet[CTCounter].WayChose==1)
            {
                ui->m_DisplayAdd2->addItem(tempAdd);//:addItem(QString );
            }
        }
    }
    else
    {
        for(int CTCounter=0; CTCounter<CTMulNumRe; CTCounter++)
        {
            tempAdd.sprintf("%s",CTMulSetRe[CTCounter].Name);// = CTMulSetRe[CTCounter].Name;//sprintf("%s");
            ui->m_DisplayAdd1->addItem(tempAdd);//:addItem(QString );
            ui->m_DisplayAdd2->addItem(tempAdd);//:addItem(QString );
        }
    }
    ui->m_DisplayAdd1->setCurrentIndex(0);//m_DisplayAdd1.SetCurSel(0);//
    ui->m_DisplayAdd2->setCurrentIndex(0);//m_DisplayAdd2.SetCurSel(1);//

    DisplayAddIndex1 = 0;
    DisplayAddIndex2 = 1;
    TimeSendLagCount = 0;
    TimeRecvLagCount_1 = 0;
    TimeRecvLagCount_2 = 0;
    TimeSendContinueFlag = true;
    TimeRecvContinueFlag_1 = true;
    TimeRecvContinueFlag_2 = true;
    TimerCount_1 = 0;
    TimerCount_2 = 0;
    TimerCount_3 = 0;
    DataCount_1 = 0;
    DataCount_2 = 0;
    DataCount_3 = 0;
    DataCount_4 = 0;

    TimeRecvLagCount_St=0;

    //Timer1SecondHWND = SetTimer(1, 1000, 0);//
    Timer1SecondHWND->start(1000);
    IsHandleWay = false;
    SourceWayNO = 1;
    ui->m_SetWayAutoHandle->setChecked(FALSE);//SetCheck(BST_UNCHECKED);
    //UpdateData(false);
    return;
}



long CDlg_MsgDisplay::FreshSendMsg(uint wParam, long lParam)
{
    return true;
}


//??????????????????????????????????????????????????????????????????????下面的应该不需要移植过去？???？？？？？？？？？？？？？？？？
/*********************************************************************************************/
/*int CDlg_MsgDisplay::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CBCGPDialog::OnCreate(lpCreateStruct) == -1)
        return -1;

    // TODO: Add your specialized creation code here
    return 0;
}*/
/*********************************************************************************************/


/************************************************************************/
/* 清除数据                                                         */
/************************************************************************/
void CDlg_MsgDisplay::UnInitData()
{
        int addrIndex = 0;
        int byteCounter = 0;

        for(addrIndex=0; addrIndex<CTP2PNum; addrIndex++)
        {
            memset(&(CTP2PSet[addrIndex]), 0, sizeof(AddStruct));
        }
        CTP2PNum = 0;
        CTP2PSet.clear();
        for(addrIndex=0; addrIndex<CTMulNumRe; addrIndex++)
        {
            memset(&(CTMulSetRe[addrIndex]), 0, sizeof(AddStruct));
        }
        CTMulSetRe.clear();
        CTMulNumRe = 0;
        for(addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
        {
            memset(&(CTMulSetSe[addrIndex]), 0, sizeof(AddStruct));
        }
        CTMulSetSe.clear();
        CTMulNumSe = 0;
        ui->m_DisplayAdd1->clear();//ResetContent();
        ui->m_DisplayAdd2->clear();//.ResetContent();

         Timer1SecondHWND->stop();
        //KillTimer(Timer1SecondHWND);//关闭定时器

}


/************************************************************************/
/* 读取配置文件
必须读取到的:
    网卡的IP，收发端口
    网卡的IP，收发端口；
    监控机的IP、路由；
    包头固定信息；
    各个数据区长度
(发射点信息依据坐标系是否需要转换而定)
                             */
/************************************************************************/
bool CDlg_MsgDisplay::ReadIniFile()
{
    //?????????????????????????????????????????????????????
    QString tempPathString_a;
    tempPathString_a=QApplication::applicationDirPath();
    QString tempPathString;
    tempPathString = tempPathString_a;
    tempPathString +="/settest.ini";
        CBaseFile iniFile;
        QString sectionName;
        QString secContent;
        int secValue = 0;
        BYTE ip1, ip2, ip3, ip4;
        QString tempName;
        QString tempDID;
        QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
        DWORD tempValue;
        DWORD tempValueRecvPort;
        DWORD tempValueSendPort;
        int tempCTCounter=0;

    //IP设置
        sectionName = "网络配置";
        tempValueRecvPort = iniFile.GetIniInt(sectionName, "监控机接收端口", tempPathString);	//24584
        tempValueSendPort = iniFile.GetIniInt(sectionName, "监控机发送端口", tempPathString);		//24576

    //单播
        sectionName = "单播网络配置";
        CTP2PNum = iniFile.GetIniInt(sectionName, "远端数目", tempPathString);//远端数目
        CTP2PSet.resize(CTP2PNum);//
        for(tempCTCounter=0; tempCTCounter<CTP2PNum; tempCTCounter++)//第2次循环保存到数组中
        {
            valueItem1.sprintf("远端%d_IP1",tempCTCounter+1);//.Format("远端%d_IP1",			tempCTCounter+1);
            valueItem2.sprintf("远端%d_IP2",tempCTCounter+1);//.Format("远端%d_IP2",			tempCTCounter+1);
            valueItem3.sprintf("远端%d_IP3",tempCTCounter+1);//.Format("远端%d_IP3",			tempCTCounter+1);
            valueItem4.sprintf("远端%d_IP4",tempCTCounter+1);//.Format("远端%d_IP4",			tempCTCounter+1);
            valueItem7.sprintf("远端%d_DID",tempCTCounter+1);//.Format("远端%d_DID",			tempCTCounter+1);
            valueItem8.sprintf("远端%d_地址名称",tempCTCounter+1);//Format("远端%d_地址名称",	tempCTCounter+1);
            valueItem9.sprintf("远端%d_路由",tempCTCounter+1);//.Format("远端%d_路由",		tempCTCounter+1);

            secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);

            ip1 = iniFile.GetIniInt(sectionName, valueItem1, tempPathString);
            ip2 = iniFile.GetIniInt(sectionName, valueItem2, tempPathString);
            ip3 = iniFile.GetIniInt(sectionName, valueItem3, tempPathString);
            ip4 = iniFile.GetIniInt(sectionName, valueItem4, tempPathString);

            CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
            CTP2PSet[tempCTCounter].PortReceive = tempValueRecvPort;
            CTP2PSet[tempCTCounter].PortSend = tempValueSendPort;
            tempDID = iniFile.GetIniStr(sectionName, valueItem7, tempPathString);
            tempValue = 0;
            tempValue = CharToHex(tempDID);//Globaldefine.h定义
            memcpy(CTP2PSet[tempCTCounter].DID, &tempValue, 4);
            tempName = iniFile.GetIniStr(sectionName, valueItem8, tempPathString);
            memcpy(CTP2PSet[tempCTCounter].Name,tempName.toAscii(), 40);
            CTP2PSet[tempCTCounter].WayChose = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        }//此时，将所有的单播网络远端都读入了

        //组播
        sectionName = "组播网络配置";
        CTMulNumRe = iniFile.GetIniInt(sectionName, "接收远端数目", tempPathString);//远端数目
        CTMulSetRe.resize(CTMulNumRe);
        for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)//第2次循环保存到数组中
        {
            valueItem1.sprintf("接收远端%d_IP1",tempCTCounter+1);//.Format("接收远端%d_IP1",			tempCTCounter+1);
            valueItem2.sprintf("接收远端%d_IP2",tempCTCounter+1);//.Format("接收远端%d_IP2",			tempCTCounter+1);
            valueItem3.sprintf("接收远端%d_IP3",tempCTCounter+1);//.Format("接收远端%d_IP3",			tempCTCounter+1);
            valueItem4.sprintf("接收远端%d_IP4",tempCTCounter+1);//.Format("接收远端%d_IP4",			tempCTCounter+1);
            valueItem7.sprintf("接收远端%d_DID",tempCTCounter+1);//.Format("接收远端%d_DID",			tempCTCounter+1);/
            valueItem8.sprintf("接收远端%d_地址名称",tempCTCounter+1);//.Format("接收远端%d_地址名称",	tempCTCounter+1);
            valueItem9.sprintf("接收远端%d_路由",tempCTCounter+1);//.Format("接收远端%d_路由",		tempCTCounter+1);
            secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
            ip1 = iniFile.GetIniInt(sectionName, valueItem1, tempPathString);
            ip2 = iniFile.GetIniInt(sectionName, valueItem2, tempPathString);
            ip3 = iniFile.GetIniInt(sectionName, valueItem3, tempPathString);
            ip4 = iniFile.GetIniInt(sectionName, valueItem4, tempPathString);
            //????????????????????????????????????????????????/？？？？？？？？？？？？？？？？？、？、关于IPAdd.sin_addr.S_un.S_addr？？？？？？？？？？？？？？？？？？
            CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
            CTMulSetRe[tempCTCounter].PortReceive = tempValueRecvPort;
            CTMulSetRe[tempCTCounter].PortSend	= tempValueSendPort;;
            tempDID = iniFile.GetIniStr(sectionName, valueItem7, tempPathString);
            tempValue = 0;
            tempValue = CharToHex(tempDID);//Globaldefine.h定义
            memcpy(CTMulSetRe[tempCTCounter].DID, &tempValue, 4);
            tempName = iniFile.GetIniStr(sectionName, valueItem8, tempPathString);
            memcpy(CTMulSetRe[tempCTCounter].Name, tempName.toAscii(), 40);
            CTMulSetRe[tempCTCounter].WayChose = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        }//此时，将所有的组播网络远端都读入了

        CTMulNumSe = iniFile.GetIniInt(sectionName, "发送远端数目", tempPathString);//远端数目
        CTMulSetSe.resize(CTMulNumSe);
        for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)//第2次循环保存到数组中
        {
            valueItem1.sprintf("发送远端%d_IP1",tempCTCounter+1);//.Format("发送远端%d_IP1",			tempCTCounter+1);
            valueItem2.sprintf("发送远端%d_IP2",tempCTCounter+1);//.Format("发送远端%d_IP2",			tempCTCounter+1);
            valueItem3.sprintf("发送远端%d_IP3",tempCTCounter+1);//.Format("发送远端%d_IP3",			tempCTCounter+1);
            valueItem4.sprintf("发送远端%d_IP4",tempCTCounter+1);//.Format("发送远端%d_IP4",			tempCTCounter+1);
            valueItem7.sprintf("发送远端%d_DID",tempCTCounter+1);//.Format("发送远端%d_DID",			tempCTCounter+1);
            valueItem8.sprintf("发送远端%d_地址名称",tempCTCounter+1);//.Format("发送远端%d_地址名称",	tempCTCounter+1);
            valueItem9.sprintf("发送远端%d_路由",tempCTCounter+1);//.Format("发送远端%d_路由",		tempCTCounter+1);
            secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
            ip1 = iniFile.GetIniInt(sectionName, valueItem1, tempPathString);
            ip2 = iniFile.GetIniInt(sectionName, valueItem2, tempPathString);
            ip3 = iniFile.GetIniInt(sectionName, valueItem3, tempPathString);
            ip4 = iniFile.GetIniInt(sectionName, valueItem4, tempPathString);

            CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
            CTMulSetSe[tempCTCounter].PortReceive = tempValueRecvPort;
            CTMulSetSe[tempCTCounter].PortSend	= tempValueSendPort;;
            tempDID = iniFile.GetIniStr(sectionName, valueItem7, tempPathString);
            tempValue = 0;
            tempValue = CharToHex(tempDID);//Globaldefine.h定义
            memcpy(CTMulSetSe[tempCTCounter].DID, &tempValue, 4);
            tempName = iniFile.GetIniStr(sectionName, valueItem8, tempPathString);
            memcpy(CTMulSetSe[tempCTCounter].Name, tempName.toAscii(), 40);
            CTMulSetSe[tempCTCounter].WayChose = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        }//此时，将所有的组播网络远端都读入了

   //协议设置
            sectionName = "协议设置";
            INI_DATALENGTH_MEASURE = iniFile.GetIniInt	(sectionName, "实算数据区长度", tempPathString);
            INI_DATALENGTH_THEORY = iniFile.GetIniInt	(sectionName, "引入数据区长度", tempPathString);
            INI_DATALENGTH_EXAM = iniFile.GetIniInt		(sectionName, "时延测试数据区长度", tempPathString);
            INI_DATALENGTH_T0 = iniFile.GetIniInt		(sectionName, "T0数据区长度", tempPathString);
            INI_REVERSE_DATALENGTH = iniFile.GetIniInt	(sectionName, "填充区长度", tempPathString); //Jerry 20110629++
            INI_REVERSE_DATACONTENT = iniFile.GetIniStr	(sectionName, "填充区内容", tempPathString);//Jerry 20110629++

        //HEADER固定值
            HEADERStruct tempHEADER;
            memset(&tempHEADER, 0, sizeof(HEADERStruct));

            sectionName = "包头数据";
            secContent = iniFile.GetIniStr(sectionName, "VER", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(&(tempHEADER.v_Version), &tempValue, 1);

        //以上为共有的信息，下面只处理BID和MID


            secContent = iniFile.GetIniStr(sectionName, "MID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP1, &tempValue, 2);


        //Time 发常时信息
            secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP2, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP3, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "MID_T", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP1, &tempValue, 2);

            secContent = iniFile.GetIniStr(sectionName, "BID常时", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP4, &tempValue, 4);

            tempHEADER.v_Length[0] = 04;
            tempHEADER.v_Length[1] = 0;

            memcpy(&TimerSendHEADER, &tempHEADER, sizeof(HEADERStruct));

        //Time 收常时信息 注意SID和DID要颠倒
            secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP3, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP2, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "MID_T", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP1, &tempValue, 2);

            secContent = iniFile.GetIniStr(sectionName, "BID常时", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP4, &tempValue, 4);

            tempHEADER.v_Length[0] = 04;
            tempHEADER.v_Length[1] = 0;

            memcpy(&TimerRecvHEADER, &tempHEADER, sizeof(HEADERStruct));

        //实算
            secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP2, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP3, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "MID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP1, &tempValue, 2);

            secContent = iniFile.GetIniStr(sectionName, "BID实算数据", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP4, &tempValue, 4);

            tempHEADER.v_Length[0] = INI_DATALENGTH_MEASURE;
            tempHEADER.v_Length[1] = 0;

            memcpy(&MeasureHEADER, &tempHEADER, sizeof(HEADERStruct));

        //时延测试	发
            secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP2, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP3, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "BID时延测试", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

            tempHEADER.v_Length[0] = INI_DATALENGTH_EXAM;
            tempHEADER.v_Length[1] = 0;

            memcpy(&ExamSendHEADER, &tempHEADER, sizeof(HEADERStruct));

        //时延测试	收
            secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP3, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP2, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "BID时延测试", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

            tempHEADER.v_Length[0] = INI_DATALENGTH_EXAM;
            tempHEADER.v_Length[1] = 0;

            memcpy(&ExamRecvHEADER, &tempHEADER, sizeof(HEADERStruct));

        //T0
            secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP3, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP2, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "BID绝对时T0", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

            tempHEADER.v_Length[0] = INI_DATALENGTH_T0;
            tempHEADER.v_Length[1] = 0;

            memcpy(&T0HEADER, &tempHEADER, sizeof(HEADERStruct));

        //外部说明
            secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP3, &tempValue, 4);

            secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
            memcpy(tempHEADER.v_SP2, &tempValue, 4);

            for(int tem_I=0; tem_I<30; tem_I++)
            {
                QString temp_DD;
                temp_DD.sprintf("BID引入%d", tem_I+1);//.Format("BID引入%d", tem_I+1);
                secContent = iniFile.GetIniStr(sectionName, temp_DD, tempPathString);
                tempValue =CharToHex(secContent);//不得超过4byte//Globaldefine.h定义
                memcpy(tempHEADER.v_SP4, &tempValue, 4);
                tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
                tempHEADER.v_Length[1] = 0;
                memcpy(&WYDHEADER[tem_I], &tempHEADER, sizeof(HEADERStruct));
            }
        /*
            secContent = iniFile.GetIniStr(sectionName, "BID引入1", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER1, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入2", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER2, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入3", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER3, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入4", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER4, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入5", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER5, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入6", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER6, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入7", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER7, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入8", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER8, &tempHEADER, sizeof(HEADERStruct));

            secContent = iniFile.GetIniStr(sectionName, "BID引入9", tempPathString);
            tempValue =CharToHex(secContent);//不得超过4byte
            memcpy(tempHEADER.v_SP4, &tempValue, 4);
            tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
            tempHEADER.v_Length[1] = 0;
            memcpy(&WYDHEADER9, &tempHEADER, sizeof(HEADERStruct));
        */


        /*
            memcpy(&BIDWYD1, WYDHEADER1.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD2, WYDHEADER2.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD3, WYDHEADER3.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD4, WYDHEADER4.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD5, WYDHEADER5.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD6, WYDHEADER6.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD7, WYDHEADER7.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD8, WYDHEADER8.v_SP4, 4);			//复制标准
            memcpy(&BIDWYD9, WYDHEADER9.v_SP4, 4);			//复制标准
        */
            memcpy(&BIDT0, T0HEADER.v_SP4, 4);			//复制标准
            memcpy(&BIDExam, ExamSendHEADER.v_SP4, 4);	//复制标准
            memcpy(&BIDTimer, TimerSendHEADER.v_SP4, 4);	//复制标准
            memcpy(&BIDMeasure, MeasureHEADER.v_SP4, 4);	//复制标准

            return true;

}


/************************************************************************/
/* 根据序号判断是否显示在第一个框内         */
/************************************************************************/
bool CDlg_MsgDisplay::IsSource1( int sourceNO )
{
        QString addName;
         QString tName= ui->m_DisplayAdd1->currentText();//.GetCurSel();
        if(CTP2PSet[sourceNO].WayChose==0&&(tName == QString(CTP2PSet[sourceNO].Name)))
        {
            return true;
        }
        else
         {
            return false;
         }

}


/************************************************************************/
/* 根据序号判断是否显示在第二个框内         */
/************************************************************************/
bool CDlg_MsgDisplay::IsSource2( int sourceNO )
{

        QString addName;
        QString tName = ui->m_DisplayAdd2->currentText();//.GetCurSel();
        if(CTP2PSet[sourceNO].WayChose==1&&(tName == QString(CTP2PSet[sourceNO].Name)))
        {
            return true;
        }
        else
         {
            return false;
         }

}

/************************************************************************/
/*
将数据内容转译并显示在第一个框内
type:
5.接收的T0
6.接收的外引导
7.接收的常时
8.接收的时延测试
其它参数参见FreshMsg
*/
/************************************************************************/
void CDlg_MsgDisplay::DisplayRecv_1( BYTE* pChar, int pLength, int type )
{

        DWORD tempValue_DW = 0;
        WORD tempValue_W = 0;
        double tempValue_D = 0.0;
        int hou, min, sec, mse;
        QString tempContent;
        QString tempMessage;
        QString startMessage;
        long tempValue_1 = 0;

        switch(type)
        {
        case 5:
            {
                if((DataCount_1%5)==0)
                {
                    memcpy(&tempValue_DW, pChar+26, 4);
                    hou = tempValue_DW / 3600 / 10000;
                    min = (tempValue_DW / 10000 / 60) % 60;
                    sec = (tempValue_DW / 10000) % 60;
                    mse = (tempValue_DW % 10000) / 10;
                    tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//.Format("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);
                    ui->m_Recv_Time_1_1->setText(tempContent);//
                    memcpy(&tempValue_DW, pChar+3, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//.Format("%.8x", tempValue_DW);//接收的SID
                    ui->m_RecvSID_1->setText(tempContent);
                    memcpy(&tempValue_DW, pChar+7, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//.Format("%.8x", tempValue_DW);//接收的DID/
                    ui->m_RecvDID_1->setText(tempContent);//SetWindowText(tempContent);
                    memcpy(&tempValue_W, pChar+1, 2);
                    tempContent.sprintf("%.4x", tempValue_W);//.Format("%.4x", tempValue_W);//接收的MID
                    ui->m_RecvMID_1->setText(tempContent);

                    memcpy(&tempValue_DW, pChar+sizeof(HEADERStruct), 4);
                    hou = tempValue_DW / 3600 / 10000;
                    min = (tempValue_DW / 10000 / 60) % 60;
                    sec = (tempValue_DW / 10000) % 60;
                    mse = (tempValue_DW % 10000) / 10;
                    tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的T0//???????????????
                    ui->m_RecvT0_1->setText(tempContent);

                    startMessage = "";
                    for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                    {
                        int temp_Char = (BYTE)(pChar[byteCounter]);
                        tempMessage.sprintf("%.2x", temp_Char);//.Format("%.2x", temp_Char);//???????????????
                        startMessage = startMessage + tempMessage;
                        if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                        {
                            startMessage = startMessage + " ";
                        }
                    }
                    ui->m_Recv_1_1->setText(startMessage);

                }

                DataCount_1++;
                if(DataCount_1 > 2000000000)
                    DataCount_1 = 0;
                break;
            }
        case 6:
            {
                if((DataCount_1%5)==0)
                {
                    memcpy(&tempValue_DW, pChar+26, 4);
                    hou = tempValue_DW / 3600 / 10000;
                    min = (tempValue_DW / 10000 / 60) % 60;
                    sec = (tempValue_DW / 10000) % 60;
                    mse = (tempValue_DW % 10000) / 10;
                    tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//.Format("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的时间
                    ui->m_Recv_Time_1_1->setText(tempContent);
                    memcpy(&tempValue_DW, pChar+3, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//.Format("%.8x", tempValue_DW);//接收的SID
                    ui->m_RecvSID_1->setText(tempContent);
                    memcpy(&tempValue_DW, pChar+7, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//.Format("%.8x", tempValue_DW);//接收的DID
                    ui->m_RecvDID_1->setText(tempContent);//.SetWindowText(tempContent);
                    memcpy(&tempValue_W, pChar+1, 2);
                    tempContent.sprintf("%.4x", tempValue_W);//.Format("%.4x", tempValue_W);//接收的MID
                    ui->m_RecvMID_1->setText(tempContent);//.SetWindowText(tempContent);

                    int tmp=0;
//                    memcpy(&tempValue_1, pChar+sizeof(HEADERStruct)+4, 4);//X
//                    tempValue_D = tempValue_1-pow(2,32);
                    memcpy(&tmp, pChar+sizeof(HEADERStruct)+4, 4);//X
                    tempValue_D = tmp;
                    tempValue_D = tempValue_D/10;
                    tempContent.sprintf("%.1f", tempValue_D);//.Format("%.1f", tempValue_D);//接收的X
                    ui->m_Recv_X_1->setText(tempContent);
                    memcpy(&tmp, pChar+sizeof(HEADERStruct)+8, 4);//Y
                    tempValue_D = tmp;
                    tempValue_D = tempValue_D/10;
                    tempContent.sprintf("%.1f", tempValue_D);//.Format("%.1f", tempValue_D);//接收的Y
                    ui->m_Recv_Y_1->setText(tempContent);
                    memcpy(&tmp, pChar+sizeof(HEADERStruct)+12, 4);//Y
                    tempValue_D = tmp;
                    tempValue_D = tempValue_D/10;
                    tempContent.sprintf("%.1f", tempValue_D);//.Format("%.1f", tempValue_D);//接收的Y
                    ui->m_Recv_Z_1->setText(tempContent);



                    startMessage = "";
                    for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                    {
                        int temp_Char = (BYTE)(pChar[byteCounter]);
                        tempMessage.sprintf("%.2x", temp_Char);//.Format("%.2x", temp_Char);
                        startMessage = startMessage + tempMessage;
                        if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                        {
                            startMessage = startMessage + " ";
                        }
                    }
                    ui->m_Recv_1_1->setText(startMessage);
                }

                DataCount_1++;
                if(DataCount_1 > 2000000000)
                    DataCount_1 = 0;
                break;
            }
        case 7:
            {

                memcpy(&tempValue_DW, pChar+sizeof(HEADERStruct), 4);
                hou = tempValue_DW / 3600 / 10000;
                min = (tempValue_DW / 10000 / 60) % 60;
                sec = (tempValue_DW / 10000) % 60;
                mse = (tempValue_DW % 10000) / 10;
                tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的T0

                ui->m_Recv_Time_1_2->setText(tempContent);

                startMessage = "";
                for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                {
                    int temp_Char = (BYTE)(pChar[byteCounter]);
                    tempMessage.sprintf("%.2x", temp_Char);
                    startMessage = startMessage + tempMessage;
                    if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                    {
                        startMessage = startMessage + " ";
                    }
                }
                ui->m_Recv_1_2->setText(startMessage);

                TimerCount_1++;
                if(TimerCount_1 > 2000000000)
                    TimerCount_1 = 0;
                break;
            }
        case 8://暂不作处理，如果需要显示再增加代码
            {
                startMessage = "";
                for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                {
                    int temp_Char = (BYTE)(pChar[byteCounter]);
                    tempMessage.sprintf("%.2x", temp_Char);
                    startMessage = startMessage + tempMessage;
                }
                ui->m_Recv_1_1->setText(startMessage);

                DataCount_1++;
                if(DataCount_1 > 2000000000)
                    DataCount_1 = 0;
                break;
            }

        }

        QString pstr;
        pstr.sprintf("%d", DataCount_1+TimerCount_1);
        ui->m_PackCount1->setText(pstr);
        return;
}

/************************************************************************/
/* 将数据内容转译并显示在第二个框内
type:
5.接收的T0
6.接收的外引导
7.接收的常时
8.接收的时延测试
其它参数参见FreshMsg

!!!如果协议发生改动，则要重点改动此处（即继承后需要改动这里）
*/
/************************************************************************/
void CDlg_MsgDisplay::DisplayRecv_2( BYTE* pChar, int pLength, int type )
{
        DWORD tempValue_DW = 0;
        WORD tempValue_W = 0;
        double tempValue_D = 0.0;
        int hou, min, sec, mse;
        QString tempContent;
        QString tempMessage;
        QString startMessage;
        long tempValue_1 = 0;

        switch(type)
        {
        case 5:
            {
                if((DataCount_2%5)==0)
                {
                    memcpy(&tempValue_DW, pChar+26, 4);
                    hou = tempValue_DW / 3600 / 10000;
                    min = (tempValue_DW / 10000 / 60) % 60;
                    sec = (tempValue_DW / 10000) % 60;
                    mse = (tempValue_DW % 10000) / 10;
                    tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的时间
                    ui->m_Recv_Time_2_1->setText(tempContent);
                    memcpy(&tempValue_DW, pChar+3, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//接收的SID
                    ui->m_RecvSID_2->setText(tempContent);
                    memcpy(&tempValue_DW, pChar+7, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//接收的DID
                    ui->m_RecvDID_2->setText(tempContent);
                    memcpy(&tempValue_W, pChar+1, 2);
                    tempContent.sprintf("%.4x", tempValue_W);//接收的MID
                    ui->m_RecvMID_2->setText(tempContent);

                    memcpy(&tempValue_DW, pChar+sizeof(HEADERStruct), 4);
                    hou = tempValue_DW / 3600 / 10000;
                    min = (tempValue_DW / 10000 / 60) % 60;
                    sec = (tempValue_DW / 10000) % 60;
                    mse = (tempValue_DW % 10000) / 10;
                    tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的T0
                    ui->m_RecvT0_2->setText(tempContent);

                    startMessage = "";
                    for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                    {
                        int temp_Char = (BYTE)(pChar[byteCounter]);
                        tempMessage.sprintf("%.2x", temp_Char);
                        startMessage = startMessage + tempMessage;
                        if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                        {
                            startMessage = startMessage + " ";
                        }
                    }
                    ui->m_Recv_2_1->setText(startMessage);
                }

                DataCount_2++;
                if(DataCount_2 > 2000000000)
                    DataCount_2 = 0;
                break;
            }
        case 6:
            {
                if((DataCount_2%5)==0)
                {
                    memcpy(&tempValue_DW, pChar+26, 4);
                    hou = tempValue_DW / 3600 / 10000;
                    min = (tempValue_DW / 10000 / 60) % 60;
                    sec = (tempValue_DW / 10000) % 60;
                    mse = (tempValue_DW % 10000) / 10;
                    tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的时间
                    ui->m_Recv_Time_2_1->setText(tempContent);
                    memcpy(&tempValue_DW, pChar+3, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//接收的SID
                    ui->m_RecvSID_2->setText(tempContent);
                    memcpy(&tempValue_DW, pChar+7, 4);
                    tempContent.sprintf("%.8x", tempValue_DW);//接收的DID
                    ui->m_RecvDID_2->setText(tempContent);
                    memcpy(&tempValue_W, pChar+1, 2);
                    tempContent.sprintf("%.4x", tempValue_W);//接收的MID
                    ui->m_RecvMID_2->setText(tempContent);

                    int tmp=0;
                    memcpy(&tmp, pChar+sizeof(HEADERStruct)+4, 4);//X
                    tempValue_D = tmp;
                    tempValue_D = tempValue_D/10;
                    tempContent.sprintf("%.1f", tempValue_D);//接收的X
                    ui->m_Recv_X_2->setText(tempContent);
                    memcpy(&tmp, pChar+sizeof(HEADERStruct)+8, 4);//Y
                    tempValue_D = tmp;
                    tempValue_D = tempValue_D/10;
                    tempContent.sprintf("%.1f", tempValue_D);//接收的Y
                    ui->m_Recv_Y_2->setText(tempContent);
                    memcpy(&tmp, pChar+sizeof(HEADERStruct)+12, 4);//Y
                    tempValue_D = tmp;
                    tempValue_D = tempValue_D/10;
                    tempContent.sprintf("%.1f", tempValue_D);//接收的Y
                    ui->m_Recv_Z_2->setText(tempContent);

                    startMessage = "";
                    for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                    {
                        int temp_Char = (BYTE)(pChar[byteCounter]);
                        tempMessage.sprintf("%.2x", temp_Char);
                        startMessage = startMessage + tempMessage;
                        if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                        {
                            startMessage = startMessage + " ";
                        }
                    }
                    ui->m_Recv_2_1->setText(startMessage);
                }


                DataCount_2++;
                if(DataCount_2 > 2000000000)
                    DataCount_2 = 0;
                break;
            }
        case 7:
            {
                memcpy(&tempValue_DW, pChar+sizeof(HEADERStruct), 4);
                hou = tempValue_DW / 3600 / 10000;
                min = (tempValue_DW / 10000 / 60) % 60;
                sec = (tempValue_DW / 10000) % 60;
                mse = (tempValue_DW % 10000) / 10;
                tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的T0
                ui->m_Recv_Time_2_2->setText(tempContent);

                startMessage = "";
                for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                {
                    int temp_Char = (BYTE)(pChar[byteCounter]);
                    tempMessage.sprintf("%.2x", temp_Char);
                    startMessage = startMessage + tempMessage;
                    if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                    {
                        startMessage = startMessage + " ";
                    }
                }
                ui->m_Recv_2_2->setText(startMessage);

                TimerCount_2++;
                if(TimerCount_2 > 2000000000)
                    TimerCount_2 = 0;
                break;
            }
        case 8://暂不作处理，如果需要显示再增加代码
            {
                startMessage = "";
                for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                {
                    int temp_Char = (BYTE)(pChar[byteCounter]);
                    tempMessage.sprintf("%.2x", temp_Char);
                    startMessage = startMessage + tempMessage;
                }
                ui->m_Recv_2_1->setText(startMessage);

                DataCount_2++;
                if(DataCount_2 > 2000000000)
                    DataCount_2 = 0;
                break;
            }

        }

        QString pstr;
        pstr.sprintf("%d", DataCount_2+TimerCount_2);
        ui->m_PackCount2->setText(pstr);
        return;
}

/************************************************************************/
/* 将数据内容转译并显示在发送框内         */
/************************************************************************/
void CDlg_MsgDisplay::DisplaySend( BYTE* pChar, int pLength, int type )
{
        DWORD tempValue_DW = 0;
        WORD tempValue_W = 0;
        long tempValue_L;
        double tempValue_D = 0.0;
        BYTE tempValue_B = 0;
        int hou, min, sec, mse;
        QString tempContent;
        QString tempMessage;
        QString startMessage;
        float tempValue_F = 0;

        if(type == 1)//实算数据
        {
            if((DataCount_3%5)==0)
            {
                memcpy(&tempValue_DW, pChar+32, 4);
                hou = tempValue_DW / 3600 / 10000;
                min = (tempValue_DW / 10000 / 60) % 60;
                sec = (tempValue_DW / 10000) % 60;
                mse = (tempValue_DW % 10000) / 10;
                tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//发送的时间
                ui->m_Send_Time_1->setText(tempContent);
                memcpy(&tempValue_DW, pChar+3, 4);
                tempContent.sprintf("%.8x", tempValue_DW);//发送的SID
                ui->m_SendSID->setText(tempContent);
                memcpy(&tempValue_DW, pChar+7, 4);
                tempContent.sprintf("%.8x", tempValue_DW);//发送的DID
                ui->m_SendDID->setText(tempContent);
                memcpy(&tempValue_W, pChar+1, 2);
                tempContent.sprintf("%.4x", tempValue_W);//发送的MID
                ui->m_SendMID->setText(tempContent);

                memcpy(&tempValue_B, pChar+sizeof(HEADERStruct)+4, 1);//Status
                if(tempValue_B == 0)//半自动未跟踪
                {
                    tempContent = "单杆";
                }
                else if(tempValue_B == 1)//程序外部说明
                {
                    tempContent = "程序外部说明";
                }
                else if(tempValue_B == 2)//外引导
                {
                    tempContent = "外引导";
                }
                else if(tempValue_B == 6)//电视自动跟踪
                {
                    tempContent = "自动跟踪";
                }
                else if(tempValue_B == 9)//加权跟踪
                {
                    tempContent = "加权跟踪";
                }
                ui->m_Send_Mode->setText(tempContent);

                memcpy(&tempValue_L, pChar+sizeof(HEADERStruct)+5, 4);//A
                tempValue_D = tempValue_L;
                tempValue_D = tempValue_D*360/pow((float)2, 31);
                tempContent.sprintf("%.5f", tempValue_D);//发送的A
                ui->m_Send_A->setText(tempContent);
                memcpy(&tempValue_L, pChar+sizeof(HEADERStruct)+9, 4);//E
                tempValue_D = tempValue_L;
                tempValue_D = tempValue_D*360/pow((float)2, 31);
                tempContent.sprintf("%.5f", tempValue_D);//发送的E
                ui->m_Send_E->setText(tempContent);

                memcpy(&tempValue_B, pChar+sizeof(HEADERStruct)+13, 1);//Status
                if(tempValue_B>=1)												//目标
                {
                    memcpy(&tempValue_L, pChar+sizeof(HEADERStruct)+14, 4);//Status
                    tempValue_D = tempValue_L;
                    tempValue_D = tempValue_D/10;
                    startMessage.sprintf("%.1f\"/", tempValue_D);
                    memcpy(&tempValue_L, pChar+sizeof(HEADERStruct)+18, 4);//Status
                    tempValue_D = tempValue_L;
                    tempValue_D = tempValue_D/10;
                    tempContent.sprintf("%.1f\"", tempValue_D);
                    startMessage = startMessage + tempContent;
                    ui->m_Send_Offset->setText(startMessage);
                }

                startMessage = "";
                for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                {
                    int temp_Char = (BYTE)(pChar[byteCounter]);
                    tempMessage.sprintf("%.2x", temp_Char);
                    startMessage = startMessage + tempMessage;
                    if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                    {
                        startMessage = startMessage + " ";
                    }
                }
                ui->m_Send_1->setText(startMessage);
            }


            DataCount_3++;
            if(DataCount_3 > 20000000)
                DataCount_3 = 0;
        }
        else if(type == 2)//常时数据
        {
            memcpy(&tempValue_DW, pChar+sizeof(HEADERStruct), 4);
            hou = tempValue_DW / 3600 / 10000;
            min = (tempValue_DW / 10000 / 60) % 60;
            sec = (tempValue_DW / 10000) % 60;
            mse = (tempValue_DW % 10000) / 10;
            tempContent.sprintf("%.2d:%.2d:%.2d::%.3d", hou, min, sec, mse);//接收的T0
            ui->m_Send_Time_2->setText(tempContent);

            startMessage = "";
            for(int byteCounter=0; byteCounter<pLength; byteCounter++)
            {
                int temp_Char = (BYTE)(pChar[byteCounter]);
                tempMessage.sprintf("%.2x", temp_Char);
                startMessage = startMessage + tempMessage;
                if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                {
                    startMessage = startMessage + " ";
                }
            }
            ui->m_Send_2->setText(startMessage);

            TimerCount_3++;
            if(TimerCount_3 > 2000000000)
                TimerCount_3 = 0;

        }
        else if(type == 4)//时延测试
        {
            if((DataCount_4%5)==0)
            {
                memcpy(&tempValue_DW, pChar+sizeof(HEADERStruct), 4);
                startMessage = "";
                for(int byteCounter=0; byteCounter<pLength; byteCounter++)
                {
                    int temp_Char = (BYTE)(pChar[byteCounter]);
                    tempMessage.sprintf("%.2x", temp_Char);
                    startMessage = startMessage + tempMessage;
                    if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
                    {
                        startMessage = startMessage + " ";
                    }
                }
                ui->m_Send_1->setText(startMessage);
            }
            DataCount_4++;
            if(DataCount_4 > 2000000000)
                DataCount_4 = 0;

        }
        else
        {

        }

        QString pstr;
        pstr.sprintf("%d", DataCount_3+TimerCount_3);
        ui->m_PackCount3->setText(pstr);
        return;


}



/************************************************************************/
/* 定时器，用于刷新网络状态图标
                                                                     */
/************************************************************************/
void CDlg_MsgDisplay::OnTimer()
{
        TimeSendLagCount++;
        TimeRecvLagCount_1++;
        TimeRecvLagCount_2++;

        TimeRecvLagCount_St++;

        if(TimeRecvLagCount_1>4)//发送了4个常时后（4秒如果没有接收到数据，则认为网络已断）
        {
            if(TimeRecvContinueFlag_1)//只有当原先是连接状态时才设置图标
            {
                ui->m_NetStatus1->clear();//ShowWindow(SW_HIDE);
                //????????????????????????????????????????////?????????????设置图片????????？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
                //m_NetStatus3.ShowWindow(SW_SHOW);
                TimeRecvContinueFlag_1 = false;
            }
        }
        else//收到过数据
        {
            if(!TimeRecvContinueFlag_1)//只有当原先是断开状态时才设置图标
            {
                //????????????????????????????????????????////?????????????设置图片????????？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
                //m_NetStatus3.ShowWindow(SW_HIDE);
                //m_NetStatus1.ShowWindow(SW_SHOW);
                TimeRecvContinueFlag_1 = true;
            }
        }
        if(TimeRecvLagCount_2>5)//发送了4个常时后（4秒如果没有接收到数据，则认为网络已断）
        {
            if(TimeRecvContinueFlag_2)//只有当原先是连接状态时才设置图标
            {
                //????????????????????????????????????????////?????????????设置图片????????？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
                //m_NetStatus2.ShowWindow(SW_HIDE);
                //m_NetStatus4.ShowWindow(SW_SHOW);
                TimeRecvContinueFlag_2 = false;
            }
        }
        else//收到过数据
        {
            if(!TimeRecvContinueFlag_2)//只有当原先是断开状态时才设置图标
            {
                //????????????????????????????????????????////?????????????设置图片????????？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
                //m_NetStatus4.ShowWindow(SW_HIDE);
                //m_NetStatus2.ShowWindow(SW_SHOW);
                TimeRecvContinueFlag_2 = true;
            }
        }

        if(TimeSendLagCount>1)//发送了4个常时后（4秒如果没有接收到数据，则认为网络已断）
        {
            if(TimeSendContinueFlag)//只有当原先是连接状态时才设置图标
            {
                TimeSendContinueFlag = false;
            }
        }
        else//收到过数据
        {
            if(!TimeSendContinueFlag)//只有当原先是断开状态时才设置图标
            {
                TimeSendContinueFlag = true;
            }
        }

        double sendLengthZK = CNetCommuZK::BufferSave_SendLength;//CNetCommuZK.h中定义
        double sendLengthCT = CNetCommuCT::BufferSave_SendLength;//CNetCommuZK.h中定义
        double recvLengthZK = CNetCommuZK::BufferSave_RecvLength;//CNetCommuZK.h中定义
        double recvLengthCT = CNetCommuCT::BufferSave_RecvLength;//CNetCommuZK.h中定义
    /*
        QString temp_BufferLeftLength;
        temp_BufferLeftLength.Format("缓冲区剩余空间提示:发送主控=%.3fM; 接收主控=%.3fM; 发送中心=%.3fM; 接收中心=%.3fM",
            (MACRO_FILE_SIZE-sendLengthZK)/1024/1024, (MACRO_FILE_SIZE-recvLengthZK)/1024/1024,
            (MACRO_FILE_SIZE-sendLengthCT)/1024/1024, (MACRO_FILE_SIZE-recvLengthCT)/1024/1024);
        m_BuffetLeftLength.SetWindowText(temp_BufferLeftLength);
    */
        ui->m_StType1->setText("");
        ui->m_StType2->setText("");


        // CBCGPDialog::OnTimer(nIDEvent);

}


void CDlg_MsgDisplay::OnCheckAutohandle()
{

    // TODO: Add your control notification handler code here
        if(IsHandleWay)
        {
            IsHandleWay = false;//转为自动
            SourceWayNO = 1;
            ui->m_Select_1->setText(tr("自动状态中"));
            ui->m_Select_2->setText(tr("自动状态中"));
            ui->m_SetWayAutoHandle->setChecked(false);
            emit WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(false,1);
        }
        else
        {
            IsHandleWay = true;//转为手动
            SourceWayNO = 1;
            ui->m_Select_1->setText(tr("激活状态中"));
            ui->m_Select_2->setText(tr("停用状态中"));
            ui->m_SetWayAutoHandle->setChecked(true);
            emit WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(true,1);

        }
}



void CDlg_MsgDisplay::OnButtonSelect1()
{

            qDebug("OnButtonSelect1");

            ui->m_SetWayAutoHandle->setChecked(true);
            IsHandleWay = true;//转为手动
            SourceWayNO = 1;
            ui->m_Select_1->setText(tr("激活状态中"));
            ui->m_Select_2->setText(tr("停用状态中"));
             emit WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(true,1);
}


void CDlg_MsgDisplay::OnButtonSelect2()
{

    qDebug("OnButtonSelect2");

        ui->m_SetWayAutoHandle->setChecked(true);
        IsHandleWay = true;//转为手动
        SourceWayNO = 2;
        ui->m_Select_1->setText(tr("停用状态中"));
        ui->m_Select_2->setText(tr("激活状态中"));
         emit WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(true,2);
}


void CDlg_MsgDisplay::OnBnClickedCheckSend1()
{

         qDebug("OnBnClickedCheckSend1");



         emit WM_USER_CHECK_SEND1(1, 0 );
             //::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_USER_CHECK_SEND1, 1, 0);
             //	m_BtnStartLost.SetWindowText("路由1停发");
}


void CDlg_MsgDisplay::OnBnClickedCheckSend2()
{

    qDebug("OnBnClickedCheckSend2");

    emit WM_USER_CHECK_SEND2(2,0);
       // ::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_USER_CHECK_SEND2, 2, 0);
}
