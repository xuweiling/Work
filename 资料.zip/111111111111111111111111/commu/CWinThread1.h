﻿#ifndef CWINTHREAD1_H
#define CWINTHREAD1_H

#include <QThread>

class CWinThread1 : public QThread
{
    Q_OBJECT
public:
    explicit CWinThread1(QThread *parent = 0);
    void stop();
protected :
    void run();
private :
     volatile bool stopped;
signals:
     void WM_USER_20Hz(unsigned int ,long );
public slots:

};

#endif // CWINTHREAD1_H
