﻿#include <stdlib.h>
#include <signal.h>

#include <agent_pp/agent++.h>
#include <agent_pp/snmp_group.h>
#include <agent_pp/system_group.h>
#include <agent_pp/snmp_target_mib.h>
#include <agent_pp/snmp_notification_mib.h>
#include <agent_pp/snmp_community_mib.h>
#include <agent_pp/notification_originator.h>
#include <agent_pp/notification_log_mib.h>
#include <agent_pp/agentpp_simulation_mib.h>
#include <agent_pp/agentpp_config_mib.h>
#include <agent_pp/v3_mib.h>
#include <agent_pp/mib_policy.h>
#include <agent_pp/vacm.h>

#include <snmp_pp/oid_def.h>
#include <snmp_pp/mp_v3.h>
#include <snmp_pp/log.h>

//#include "atm_mib.h"
//#include "agentpp_notifytest_mib.h"
//#include "agentpp_test_mib.h"


#ifdef SNMP_PP_NAMESPACE
using namespace Snmp_pp;
#endif

#ifdef AGENTPP_NAMESPACE
using namespace Agentpp;
#endif

// table size policies
#include "yfprocessrequest.h"
#include "yfmIbbrowerview.h"
#include "yfgroup.h"
#include "yftree2leaf.h"
extern TreeNode YFHRoot;
void tree2leaf(TreeNode *ht,YFGroup *&YFgroup)
{
	if(ht==NULL)
		return;
	else
	{
		Oidx id(ht->Mibdata.POid.c_str());
		mib_access access;
		if(ht->Mibdata.PAccess == "NOTACCESS")
			access = NOACCESS;
		else if(ht->Mibdata.PAccess == "READONLY")
			access = READONLY;
		else if(ht->Mibdata.PAccess == "READWRITE")
			access = READWRITE;
		else access = READONLY;

		if(ht->Mibdata.PSnytax == "Int")
		{
			YFLeaf *yfleaf;
			yfleaf = new YFLeaf(id,access,new SnmpInt32(ht->Mibdata.PIValue));
//			yfleaf->set_value(ht->Mibdata.PIValue);
			YFgroup->add(yfleaf);
		}
		else
		{
			YFSLeaf *yfleaf;
            yfleaf = new YFSLeaf(id,access,new OctetStr(ht->Mibdata.PSValue.c_str()));
			YFgroup->add(yfleaf);
		}

        if(ht->LChildren != NULL) tree2leaf(ht->LChildren,YFgroup);
        if(ht->RChildren != NULL) tree2leaf(ht->RChildren,YFgroup);
	}
}

void edittreeagain(string YFOidString,string snytax,int ivalue,string svalue)
{
	YFOidString=YFOidString.substr(0,YFOidString.find_last_of("0")-1);
	LOG_BEGIN(EVENT_LOG | 2);
	LOG(YFOidString.c_str());
	LOG_END;

	TreeNode *SubRootconst = NULL;
	SearchNodeFromOID(&YFHRoot,SubRootconst, YFOidString);
	if(SubRootconst == NULL)
	{
	    LOG_BEGIN(WARNING_LOG | 2);
	    LOG("no objects");
	    LOG_END;
	}
	else
	{
	    if(snytax == "Int")
	    {
	    	SubRootconst->Mibdata.PSnytax = "Int";
	    	SubRootconst->Mibdata.PIValue = ivalue;
	    }
	    else
	    {
	    	SubRootconst->Mibdata.PSnytax = "String";
	    	SubRootconst->Mibdata.PSValue = svalue;
	    }
	}
}

//LeafNodeList leafnodelist = {0,0,0};
//void tree2leaf(TreeNode *&ht,LeafNodeList *&hleafnodelist)
//{
//	if(ht == NULL)
//		return;
//	else
//	{
//		LeafNode *leafnode = new LeafNode();
//		leafnode->Descr = ht->Mibdata.PDescr;
//		if(ht->Mibdata.PAccess == "NOTACCESS")
//			leafnode->Access = NOACCESS;
//		else if(ht->Mibdata.PAccess == "READONLY")
//			leafnode->Access = READONLY;
//		else if(ht->Mibdata.PAccess == "READWRITE")
//			leafnode->Access = READWRITE;
//		if(ht->Mibdata.PSnytax == "Int")
//			leafnode->IValue = ht->Mibdata.PIValue;
//		else
//			leafnode->SValue;//.set_data((char *)(ht->Mibdata.PSValue.c_str()),(ht->Mibdata.PSValue.length()));
//		leafnode->Index = ht->Mibdata.PIndex;
//		leafnode->Integer = ht->Mibdata.PInteger;
//		leafnode->Oid;//.set_data((ht->Mibdata.POid),ht->Mibdata.POid.length());
//		if(ht->Mibdata.PSnytax == "Int")
//			leafnode->Snytax = 0;//0表示INT
//		else
//			leafnode->Snytax = 1;//1为string
//		leafnode->Status = ht->Mibdata.PStatus;
//		leafnodelist.len++;
//		LeafNodeList *subleftnodelist = new LeafNodeList;
//		subleftnodelist->leafnode = leafnode;
//		hleafnodelist->next = subleftnodelist;
//
//		if(ht->LChildren != NULL) tree2leaf(ht->LChildren,subleftnodelist);
//		if(ht->RChildren != NULL) tree2leaf(ht->RChildren,subleftnodelist);
//	}
//
//}
