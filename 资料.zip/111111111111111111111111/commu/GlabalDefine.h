﻿

#if !defined(AFX_GLOBAL_H__623373B2_D450_40CD_AF2A_165354D9B651__INCLUDED_)
#define AFX_GLOBAL_H__623373B2_D450_40CD_AF2A_165354D9B651__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"
#include <sys/types.h>
#include <WinDef.h>
#include <qstring.h>
#include <sys/socket.h>
#include <netdb.h>   //struct sockaddr_in, INADDR_ANY
#include "time.h"

#define SOCKADDR_IN struct sockaddr_in
//#define SYSTEMTIME  struct tm
#define SYSTEMTIME  struct LINUXTIME

struct LINUXTIME
{
    int tm_msec;//0-999
    int tm_sec; //0-61
    int tm_min; //0-59
    int tm_hour;//0-23
    int tm_mday; //1-31
    int tm_mon; //0-11
    int tm_year;//since 1900
};

struct HEADERStruct 
{
	BYTE	v_Version;

    BYTE	v_SP1[2];
	BYTE	v_SP2[4];
	BYTE	v_SP3[4];
	BYTE	v_SP4[4];
    BYTE	v_No[4];

    BYTE v_Flag;
    BYTE v_Reserve[4];

    BYTE v_Date[2]; //date
    BYTE	 v_Time[4];//time
    BYTE	 v_Length[2];//length
};

enum Runtp
{
	Disconnect, //未连接
	Normal,		//正常收发
	ZK_Debug,	//向主控发送T0和外引导
	CT_Debug,	//向监控机发送调试数据
	ZK_CT_Debug	//向主控发送T0和外引导,同时向监控机发送调试数据
};

enum CTtp
{
	FromCt, FromCt2
};

enum Sockettp
{
	Socket_Udp, Socket_Multicast_ASM, Socket_Multicast_SSM
};

struct AddStruct								//每一个地址
{
    SOCKADDR_IN IPAdd;							//本地地址()
	WORD  PortReceive;							//接收端口
	WORD  PortSend;								//发送端口
	int   WayChose;								//路由选择
    BYTE  DID[4];								//DID代码
	char  Name[40];								//命名
};

struct SocketSetting							//每一个地址
{
	SOCKADDR_IN IPAdd;							//本地地址()
	DWORD  PortReceive;							//接收端口
	DWORD  PortSend;							//发送端口
	int   WayChose;								//路由号码
};

struct DisMasgStruct							//从远端得到的数据，但是不是命令的来源
{
	char* SocketBufferFromCTNotSource;
	int AddIndex;
	int MsgLength;
};

enum TimeSourceType
{
	Time_NULL, Time_GPS, Time_DC, Time_ZK, Time_AC, Time_Local
};

struct ExamResult
{
	DWORD TfTime;
	DWORD TsTime;
	DWORD TzTime;
	DWORD TqTime;
};

extern DWORD CharToHex(QString inputText);//不得超过4byte 返回无符号整型 输入高位在前
extern DWORD CharToHex(char* inputText, int TextLength);//不得超过4byte 返回无符号整型 输入高位在前
extern DWORD CharToUnsignedHexReverse(QString inputText);//不得超过4byte 返回无符号整型 输入低位在前
extern LONG CharToSignedHexReverse(QString inputText);//不得超过4byte 返回有符号整型 输入低位在前
extern void TransCoor(float Input_x, float Input_y, float Input_z, float Input_u, float Input_v, float Input_w, float Input_t, double* Output_x, double* Output_y, double* Output_z, int CalcuType);
extern void Str2Time(QString pInput, SYSTEMTIME *pOutput);
#ifdef LINUXTIME
extern DWORD GetTimeFromPIO( );
extern DWORD GetTimeFromTCRC( );
#endif
extern unsigned short GetDate();
extern DWORD GetTime(TimeSourceType TimeSource);
extern SYSTEMTIME GetTimeMilli(TimeSourceType TimeSource);
extern bool PrePost(float A1, float A2, float A3, float A4, float *A5);
void GetSystemTime(SYSTEMTIME *currentTime);

#endif // !defined(AFX_GLOBAL_H__623373B2_D450_40CD_AF2A_165354D9B651__INCLUDED_)
