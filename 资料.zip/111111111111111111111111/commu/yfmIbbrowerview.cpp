﻿/*
 * MIbBrowserView.cpp
 *
 *  Created on: Dec 9, 2014
 *      Author: feng
 */
#include <iostream>
#include <string>
#include <string.h>
#include <fstream>
using namespace std;
#include <stdlib.h>
#include "yfmIbbrowerview.h"
#include <algorithm>
#include <vector>
#include <QString>
#include <qfile.h>
#include <QTextCodec>

TreeNode YFHRoot;
string YFIndexString; //保存索引字符串信息
QTreeNode YFQHRoot;


//初始化一个数据类型为MIBNode结构提数据变量
void InitNodeData(MibNode *Pnode)
{
    Pnode->PSnytax=' ';
    Pnode->PAccess=' ';
    Pnode->PDescr=' ';
    Pnode->PIndex=' ';
    Pnode->PStatus=' ';
	Pnode->POid=' ';
	Pnode->PIValue = 0;
	Pnode->PSValue=' ';
//	Pnode->PInteger=NULL;
}
void InitTreeData(TreeNode *Pnode)
{
	Pnode->Currentname = "";
//	Pnode->Mibdata = NULL;
	Pnode->LChildren = NULL;
	Pnode->RChildren = NULL;
}
//
void preorderPrintf(TreeNode *ht)
{
	if(ht == NULL)
		return;
	else
	{
		cout << ht->Mibdata.POid << ht->Mibdata.PIValue << ht->Mibdata.PSValue << endl;
		if(ht->LChildren != NULL) preorderPrintf(ht->LChildren);
		if(ht->RChildren != NULL) preorderPrintf(ht->RChildren);
	}
}

void SearchNodeFromOID(TreeNode *hSubRoot,TreeNode *&SubRootconst, string &text)
{
   if (hSubRoot == NULL || SubRootconst != NULL)
   		return;
   else
   {
       	if (hSubRoot->Mibdata.POid == text)
       	{
       		SubRootconst = *(&hSubRoot);
       		return;
       	}
       	if(hSubRoot->LChildren != NULL) SearchNodeFromOID(hSubRoot->LChildren,SubRootconst,text);
       	if(hSubRoot->RChildren != NULL) SearchNodeFromOID(hSubRoot->RChildren,SubRootconst,text);
    }
}

void Mibdata2Mibdata(MibNode &src, MibNode *from)
{
	src.PAccess = from->PAccess;
	src.PDescr = from->PDescr;
	src.PIndex = from->PIndex;
	src.POid = from->POid;
	src.PSnytax = from->PSnytax;
	src.PStatus = from->PStatus;
	src.PIValue = from->PIValue;
	src.PSValue = from->PSValue;
}
  //  先序遍历树
void FindNode(TreeNode *hSubRoot,TreeNode *&SubRootconst, string &text)
{
    if (hSubRoot == NULL || SubRootconst != NULL)
		return;
    else
    {
    	if (hSubRoot->Currentname == text)
    	{
    		SubRootconst = *(&hSubRoot);
    		return;
    	}
    	if(hSubRoot->LChildren != NULL) FindNode(hSubRoot->LChildren,SubRootconst,text);
    	if(hSubRoot->RChildren != NULL) FindNode(hSubRoot->RChildren,SubRootconst,text);
    }
}

void FindEndNode(TreeNode *hSubRoot,TreeNode *&SubRootconst)
{
	if(SubRootconst != NULL)
		return;
	if(hSubRoot->RChildren == NULL)
		SubRootconst = *(&(hSubRoot));
	else FindEndNode(hSubRoot->RChildren,SubRootconst);
}

void DeleteTree(TreeNode *hSubRoot)
{
    if (hSubRoot == NULL)
        return;
    if(hSubRoot->LChildren != NULL) DeleteTree(hSubRoot->LChildren);
    if(hSubRoot->RChildren != NULL) DeleteTree(hSubRoot->RChildren);
    free(hSubRoot);
}

void AddPlaceHolder(TreeNode *ht,string &Parent_name,string &Child_name,string &num)
{
	string OidStr;
	int n1,n2;
	n1 = Parent_name.find_first_not_of(" ");
	n2 = Parent_name.length()-n1;
	if(n1 == -1)
		n1 = 0;
	Parent_name = Parent_name.substr(n1,n2);
	n2 = Parent_name.find_last_not_of(" ");
	Parent_name = Parent_name.substr(0,n2+1); //？？？？？取出左右测空格

	n1 = Child_name.find_first_not_of(" ");
	n2 = Child_name.length()-n1;
	if(n1 == -1)
		n1 = 0;
	Child_name = Child_name.substr(n1,n2);
	n2 = Child_name.find_last_not_of(" ");
	Child_name = Child_name.substr(0,n2+1); //？？？？？取出左右测空格

	//查找父节点
	TreeNode *hParent = NULL;
	FindNode(ht,hParent,Parent_name);
	if (hParent==NULL)
	{
		//父节点不存在
		cout << "请确认注册了顶端节点" << endl;
		return;
	}
	else
	{
		//父节点存在，增加字节点
		OidStr=hParent->Mibdata.POid;
		OidStr=OidStr+'.'+num;
		MibNode*P_node = new MibNode;
		InitNodeData(P_node);
		P_node->POid = OidStr;
		TreeNode *CurrentNode = new TreeNode;
		InitTreeData(CurrentNode);
		CurrentNode->Currentname = Child_name;
		Mibdata2Mibdata(CurrentNode->Mibdata, P_node);

		TreeNode *FriendNode = NULL;
		if(hParent->LChildren == NULL)
			hParent->LChildren = CurrentNode;
		else
		{
			FindEndNode(hParent->LChildren,FriendNode);
			FriendNode->RChildren = CurrentNode;
		}
	}
}
//增加叶子节点
void AddObject(TreeNode *ht,string &Parent_name,
							 string &Child_name,string &num,MibNode *p)
{
	            string OidStr;
	            int n1,n2;
	           	n1 = Parent_name.find_first_not_of(" ");
	           	n2 = Parent_name.length()-n1;
	           	if(n1 == -1)
	           		n1 = 0;
	           	Parent_name = Parent_name.substr(n1,n2);
	           	n2 = Parent_name.find_last_not_of(" ");
	           	Parent_name = Parent_name.substr(0,n2+1); //？？？？？取出左右测空格

	           	n1 = Child_name.find_first_not_of(" ");
	           	n2 = Child_name.length()-n1;
	           	if(n1 == -1)
	           		n1 = 0;
	           	Child_name = Child_name.substr(n1,n2);
	           	n2 = Child_name.find_last_not_of(" ");
	           	Child_name = Child_name.substr(0,n2+1); //？？？？？取出左右测空格

			   //查找父节点
	           	TreeNode *hParent = NULL;
	           	FindNode(ht,hParent,Parent_name);
               if (hParent==NULL)
			   {
            	   //父节点不存在
            	   cout << "请确认注册了父节点" << endl;
            	   return;
			   }
               else
               {
				   //父节点存在
            	   OidStr=hParent->Mibdata.POid;
            	   OidStr=OidStr+'.'+num;
            	   p->POid = OidStr;
            	   TreeNode *CurrentNode = new TreeNode;
            	   InitTreeData(CurrentNode);
            	   CurrentNode->Currentname = Child_name;
            	   Mibdata2Mibdata(CurrentNode->Mibdata, p);

            	   TreeNode *FriendNode = NULL;
            	   if(hParent->LChildren == NULL)
            		   hParent->LChildren = CurrentNode;
            	   else
            	   {
            		   FindEndNode(hParent->LChildren,FriendNode);
            		   FriendNode->RChildren = CurrentNode;
            	   }
			   }
}

void WorkOnInt(string &str,vector<string> *p)
{
	   int n1=str.find('{');
	   int n2=str.find('}')-n1-1;
	   str=str.substr(n1+1,n2)+',';
	   //AfxMessageBox((LPCTSTR)str);
	   while (str.length()>3)
	   {
		   string str1=str.substr(0,str.find(','));
	       str=str.substr((str.find(',')+1),(str.length()-str.find(',')));
	       int n3=str1.find('(');
	       int n4=str1.find(')')-n3-1;
		   string list=str1.substr(n3+1,n4);//()内
		   n1 = list.find_first_not_of(" ");
		   n2 = list.length()-n1;
		   if(n1 == -1)
			   n1 = 0;
		   list = list.substr(n1,n2);
		   n2 = list.find_last_not_of(" ");
		   list = list.substr(0,n2+1); //？？？？？取出左右测空格

		   p->push_back(list);
	       list=str1.substr(0,n3);
	       n1 = list.find_first_not_of(" ");
	       n2 = list.length()-n1;
	       if(n1 == -1)
	       		n1 = 0;
	       list = list.substr(n1,n2);
	       n2 = list.find_last_not_of(" ");
	       list = list.substr(0,n2+1); //？？？？？取出左右测空格
	       p->push_back(list);
	   }
}

void AddNode(MibNode *&SubNode,string &CurrentName)
{
	string SParantOid;
    SParantOid = SubNode->POid;
    if(SParantOid[SParantOid.length()-1] == '0')
        SParantOid = SubNode->POid.substr(0,SubNode->POid.find_last_of('.0')-1);
    SParantOid = SParantOid.substr(0,SParantOid.find_last_of('.'));

	TreeNode *SubRootconst = NULL;
	SearchNodeFromOID(&YFHRoot,SubRootconst,SParantOid);//查找父节点
	if (SubRootconst==NULL)
	{
		//父节点不存在
	    cout << "请确认注册了父节点" << endl;
	    return;
	}
	else
	{
		//父节点存在
	    TreeNode *CurrentNode = new TreeNode;
	    InitTreeData(CurrentNode);
	    CurrentNode->Currentname = CurrentName;
	    Mibdata2Mibdata(CurrentNode->Mibdata, SubNode);

	    TreeNode *FriendNode = NULL;
	    if(SubRootconst->LChildren == NULL)
	    	SubRootconst->LChildren = CurrentNode;
	    else
	    {
	         FindEndNode(SubRootconst->LChildren,FriendNode);
	         FriendNode->RChildren = CurrentNode;
	    }
	}
}

int YFQLoadMId(void)
{
    int n1,n2;
    string Line;        //临时保存文件中读入的一行
    QString QLine;
    QTreeNode *QpNode;//叶子节点
    QTreeNode *currentTreeNode;

    currentTreeNode = &YFQHRoot;

    QFile file("MyMib.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return 0;

    while (!file.atEnd()) {
        QLine = file.readLine();
        Line = QLine.toStdString();

        if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
        if (Line.find("--")==0) continue;    //注释行直接读下一行
        n1 = Line.find("--");
        if (n1 > 0)           //去掉行后边注释部分
            Line=Line.substr(0,Line.find("--")+1);
        n1 = Line.find_first_not_of(" ");
        n2 = Line.length()-n1;
        if(n1 == -1)
            n1 = 0;
        Line = Line.substr(n1,n2);
        n2 = Line.find_last_not_of(" ");
        Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
        n1 = Line.find_first_not_of("\t");
        n2 = Line.length()-n1;
        if(n1 == -1)
            n1 = 0;
        Line = Line.substr(n1,n2);
        if(Line == "\r") continue;
        //辅助节点定义行，从该行中可以读得的信息有：辅助节点的名字，该辅助节点的父节点名字，
        //该辅助节点在兄弟节点中的位置。这些信息被传递给函数Tree control中添加辅助节点的函数
        //AddPlaceHolder。有该函数完成Tree Control中增加行应的节点
//		while(!Line.length())
        {
            QpNode = new QTreeNode();

            n1 = Line.find("POid:");
            if(n1 != string::npos)
            {
                n2 = Line.find_first_of(',',Line.find("POid:"));
                string oid = Line.substr((n1+5),(n2-n1-5));
//                if(oid.find_last_of(".0") != oid.length()-2)
//                {
//                    delete QpNode;
//                    continue;
//                }
                QpNode->QMibdata.POid = oid.c_str();
            }

            n1 = Line.find("Name:");
            if(n1 != string::npos)
            {
                n2 = Line.find_first_of(',',Line.find("Name:"));
                QpNode->QMibdata.Currentname=Line.substr(n1+5,n2-n1-5).c_str();
            }

            n1 = Line.find("PSnytax:");
            if(n1 != string::npos)
            {
                n2 = Line.find_first_of(',',Line.find("PSnytax:"));
                QpNode->QMibdata.PSnytax=Line.substr(n1+8,n2-n1-8).c_str();
            }

            n1 = Line.find("PValue:");
            if(n1 != string::npos)
            {
                n2 = Line.find_first_of(',',Line.find("PValue:"));
                if(QpNode->QMibdata.PSnytax == "Int")
                    QpNode->QMibdata.PIValue = atoi(Line.substr(n1+7,n2-n1-7).c_str());
                else
                    QpNode->QMibdata.PSValue=Line.substr(n1+7,n2-n1-7).c_str();
            }

            n1 = Line.find("PAccess:");
            if(n1 != string::npos)
            {
                n2 = Line.find_first_of(',',Line.find("PAccess:"));
                QpNode->QMibdata.PAccess=Line.substr(n1+8,n2-n1-8).c_str();
            }

            n1 = Line.find("PIsTrap:");
            if(n1 != string::npos)
            {
                n2 = Line.find_first_of(',',Line.find("PIsTrap:"));
                QpNode->QMibdata.isTrap=Line.substr(n1+8,n2-n1-8).c_str();
            }

            currentTreeNode->LChildren = QpNode;
            currentTreeNode = currentTreeNode->LChildren;
        }
     }
}

//加载MIB
int LoadMid(void)
{
	int n1,n2;  //用于查找字符所在位置
    int isRootFlag = 0;
//	string tmp;
//	cout << "Enter MIB file name: ";
//	string filename;
//	cin >> filename;
//	const char *ch = filename.c_str();
//
//	InitTreeData(&YFHRoot);
//	cout << "Enter MIB root name: ";
//	cin >> tmp;
//	tmp = "MYGroup";
//	YFHRoot.Currentname = tmp;
//	cout << "Enter MIB root oid: ";
//	cin >> tmp;
//	tmp = "1.3.6.1.1.4.1.1";
//	YFHRoot.Mibdata.POid = tmp;

    MibNode* pNode;//叶子节点
    string Line;        //临时保存文件中读入的一行

    fstream fsFile;
//    fsFile.open(ch, ios_base::in);  //???此处文件名
    fsFile.open("MyMib.txt", ios_base::in);  //???此处文件名
    if (!fsFile.is_open())
    {
    	 cout << "读取 MyText.txt 文件失败!" << endl;
    	 return 0;
    }

	YFIndexString=' ';    //初始化索引字符串
	 while ( !fsFile.eof() )  //逐行读入并处理
	 {
		getline(fsFile, Line);
		if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
		if (Line.find("--")==0) continue;    //注释行直接读下一行
		n1 = Line.find("--");
		if (n1 > 0)           //去掉行后边注释部分
			Line=Line.substr(0,Line.find("--")+1);
		n1 = Line.find_first_not_of(" ");
		n2 = Line.length()-n1;
		if(n1 == -1)
			n1 = 0;
		Line = Line.substr(n1,n2);
		n2 = Line.find_last_not_of(" ");
		Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
		n1 = Line.find_first_not_of("\t");
		n2 = Line.length()-n1;
		if(n1 == -1)
			n1 = 0;
		Line = Line.substr(n1,n2);
		if(Line == "\r") continue;
		//辅助节点定义行，从该行中可以读得的信息有：辅助节点的名字，该辅助节点的父节点名字，
		//该辅助节点在兄弟节点中的位置。这些信息被传递给函数Tree control中添加辅助节点的函数
		//AddPlaceHolder。有该函数完成Tree Control中增加行应的节点
//		while(!Line.length())
		{
			pNode = new MibNode();
			string CurrentName;

			n1 = Line.find("Name:");
			if(n1 != string::npos)
			{
				n2 = Line.find_first_of(',',Line.find("Name:"));
				CurrentName=Line.substr(n1+5,n2-n1-5);
			}

			n1 = Line.find("PSnytax:");
			if(n1 != string::npos)
			{
				n2 = Line.find_first_of(',',Line.find("PSnytax:"));
				pNode->PSnytax=Line.substr(n1+8,n2-n1-8);
			}

			n1 = Line.find("PValue:");
			if(n1 != string::npos)
			{
				n2 = Line.find_first_of(',',Line.find("PValue:"));
				if(pNode->PSnytax == "Int")
					pNode->PIValue = atoi(Line.substr(n1+7,n2-n1-7).c_str());
				else
                {
                    QTextCodec *utf8=QTextCodec::codecForName("UTF-8");
                    QTextCodec *gbk = QTextCodec::codecForName("GBK");

                    string stringTmp=Line.substr(n1+7,n2-n1-7);
                    QString tmp = QString::fromLocal8Bit(stringTmp.c_str());
                    //tmp=tmp.toAscii();
                    QTextCodec::setCodecForCStrings(gbk);
                    pNode->PSValue=tmp.toStdString();
                    QTextCodec::setCodecForCStrings(utf8);
                }
			}

			n1 = Line.find("PAccess:");
			if(n1 != string::npos)
			{
				n2 = Line.find_first_of(',',Line.find("PAccess:"));
				pNode->PAccess=Line.substr(n1+8,n2-n1-8);
			}
			n1 = Line.find("POid:");
			if(n1 != string::npos)
			{
				n2 = Line.find_first_of(',',Line.find("POid:"));
				pNode->POid=Line.substr((n1+5),(n2-n1-5));
                if(isRootFlag == 0)
                {
                    isRootFlag = 1;
                    YFHRoot.Currentname = CurrentName;
                    YFHRoot.Mibdata.POid = pNode->POid;
                }
                else
                    AddNode(pNode,CurrentName);
			}
		}
/*
		n1 = Line.find("OBJECT IDENTIFIER ::=");
		if (n1 > 2)
		{
			n1 = Line.find('{');
			n2 = Line.find('}');
			if ((n1 > 10) && (n2 > 10))
			{
				string ParentName,NodeName,Pos;
				NodeName=Line.substr(0,Line.find("OBJECT IDENTIFIER ::="));
				n1=Line.find('{');
				n2=Line.find('}')-n1-1;
				Line=Line.substr(n1+1,n2);
				n1 = Line.find_first_not_of(" ");
				n2 = Line.length()-n1;
				if(n1 == -1)
					n1 = 0;
				Line = Line.substr(n1,n2);
				n2 = Line.find_last_not_of(" ");
				Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
				ParentName=Line.substr(0,Line.find(' '));
				Pos=Line.substr(Line.find(' ')+1,Line.length() - Line.find(' '));
				AddPlaceHolder(&YFHRoot,ParentName,NodeName,Pos);
				continue;
			}
		}
			//辅助节点定义行，和上边的格式不同的是，这个定义有多行组成，因此要接着读入后边的定义语句，
			//才能获取全部的信息。IF 语句的限制条件是因为MIB文件的头部说明部分往往也包含这样的关键字，
			//要滤除掉
		n1 = Line.find("MODULE-IDENTITY");
		n2 = Line.find(',');
			if ((n1 > 2) && (n2 == -1))
			{
				string ParentName,NodeName,Pos;
				NodeName=Line.substr(0,Line.find("MODULE-IDENTITY"));
               	while (getline(fsFile, Line))
				{
               		if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
               		if (Line.find("--")==0) continue;    //注释行直接读下一行
               		n1 = Line.find("--");
               		if (n1 > 0)           //去掉行后边注释部分
               		Line=Line.substr(0,Line.find("--"));
               		n1 = Line.find_first_not_of(" ");
               		n2 = Line.length()-n1;
               		if(n1 == -1)
               			n1 = 0;
               		Line = Line.substr(n1,n2);
               		n2 = Line.find_last_not_of(" ");
               		Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
               		n1 = Line.find_first_not_of("\t");
               		n2 = Line.length()-n1;
               		if(n1 == -1)
               			n1 = 0;
               		Line = Line.substr(n1,n2);
               		if ((Line.find("::=")==0)&&(Line.find('}')>3)&&(Line.find('{')>1))
					{
						n1=Line.find('{');
						n2=Line.find('}')-n1-1;
						Line=Line.substr(n1+1,n2);
						n1 = Line.find_first_not_of(" ");
						n2 = Line.length()-n1;
						if(n1 == -1)
							n1 = 0;
						Line = Line.substr(n1,n2);
						n2 = Line.find_last_not_of(" ");
						Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
						ParentName=Line.substr(0,Line.find(' '));
						Pos=Line.substr(Line.find(' ')+1,Line.length()-Line.find(' '));
						AddPlaceHolder(&YFHRoot,ParentName,NodeName,Pos);
						break;
					}
				}//	while (MibFile.ReadString(Line))
				continue;
			}
			//另一种辅助节点定义行形式，处理方式同第一种形式
			n1 = Line.find("OBJECT-IDENTITY");
			n2 = Line.find(',');
			if ((n1 > 2) && (n2 == -1))
			{
				string ParentName,NodeName,Pos;
				NodeName=Line.substr(0,Line.find("OBJECT-IDENTITY"));
				n1=Line.find('{');
				n2=Line.find('}')-n1-1;
				Line=Line.substr(n1+1,n2);
				n1 = Line.find_first_not_of(" ");
				n2 = Line.length()-n1;
				if(n1==-1)
					n1 = 0;
				Line = Line.substr(n1,n2);
				n2 = Line.find_last_not_of(" ");
				Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
				ParentName=Line.substr(0,Line.find(' '));
				Pos=Line.substr(Line.find(' ')+1,Line.length() - Line.find(' '));
				AddPlaceHolder(&YFHRoot,ParentName,NodeName,Pos);
				continue;
			}
			//
			n1 = Line.find("OBJECT-TYPE");
			n2 = Line.find(',');
			if ((n1 > 2) && (n2 == -1))
						{
							string ParentName,NodeName,Pos;
							NodeName=Line.substr(0,Line.find("OBJECT-TYPE"));
							n1 = Line.find_first_not_of(" ");
							n2 = Line.length()-n1;
							if(n1 == -1)
								n1 = 0;
							Line = Line.substr(n1,n2);
							n2 = Line.find_last_not_of(" ");
							Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
							pNode=new MibNode;
							InitNodeData(pNode);
							//z逐行读入后续的定义行
							while (getline(fsFile, Line))
							{
								if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
								if (Line.find("--")==0) continue;    //注释行直接读下一行
								n1 = Line.find("--");
								if (n1 > 0)           //去掉行后边注释部分
								    Line=Line.substr(0,Line.find("--"));
								n1 = Line.find_first_not_of(" ");
								n2 = Line.length()-n1;
								if(n1 == -1)
								    n1 = 0;
								Line = Line.substr(n1,n2);
								n2 = Line.find_last_not_of(" ");
								Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
								n1 = Line.find_first_not_of("\t");
								n2 = Line.length()-n1;
								if(n1 == -1)
								    n1 = 0;
								Line = Line.substr(n1,n2);

								n1 = Line.find("SYNTAX");//定义数据类型
								if(n1 == 0)
								{
									//整数类型
									n1 = Line.find("INTEGER");
									if (n1 > 0)
									{
										pNode->PSnytax="INTEGER";
										//判断是否为枚举类型第2种定义形式
										n1 = Line.find('{');
										n2 = Line.find('}');
										if ((n1 > 10) && (n2 > 10))
										{
											//保存定义信息    ??????
											pNode->PInteger=new vector<string>();
											WorkOnInt(Line,pNode->PInteger);
										}
										//判断是否为枚举类型第3.4种定义形式
										if ((n1 > 10) && (n2 == -1))
										{
											string Line1="{";
											while (getline(fsFile, Line))
											{
												if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
												if (Line.find("--")==0) continue;    //注释行直接读下一行
												n1 = Line.find("--");
												if (n1 > 0)           //去掉行后边注释部分
													Line=Line.substr(0,Line.find("--"));
												n1 = Line.find_first_not_of(" ");
												n2 = Line.length()-n1;
												if(n1 == -1)
													n1 = 0;
												Line = Line.substr(n1,n2);
												n2 = Line.find_last_not_of(" ");
												Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
												n1 = Line.find_first_not_of("\t");
												n2 = Line.length()-n1;
												if(n1 == -1)
													 n1 = 0;
												Line = Line.substr(n1,n2);
												Line1 += Line;

												n2 = Line.find('}');
												if (n2 != -1) break;
											}
											//？？？？？？？？？？？
											pNode->PInteger=new vector<string>();
											WorkOnInt(Line,pNode->PInteger);
										}
									}
									else   //非INTEGER的其他类型
									{
										Line=Line.substr(6,Line.length() - 6);
										n1 = Line.find_first_not_of(" ");
										n2 = Line.length()-n1;
										if(n1 == -1)
											n1 = 0;
										Line = Line.substr(n1,n2);
										n2 = Line.find_last_not_of(" ");
										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格

										pNode->PSnytax=Line;
									}
									continue;
								}// if(Line.Find("SYNTAX")==0)
								//判断是否为枚举类型整数的第一种定义形式
								n2 = Line.find('{');
								if ((n2 ==0) && (pNode->PSnytax.find("INTEGER")==0))
								{
									string Line1=Line;
									while (getline(fsFile, Line))
									{
										if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
										if (Line.find("--")==0) continue;    //注释行直接读下一行
										n1 = Line.find("--");
										if (n1 > 0)           //去掉行后边注释部分
											Line=Line.substr(0,Line.find("--"));
										n1 = Line.find_first_not_of(" ");
										n2 = Line.length()-n1;
										if(n1 == -1)
											n1 = 0;
										Line = Line.substr(n1,n2);
										n2 = Line.find_last_not_of(" ");
										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
										n1 = Line.find_first_not_of("\t");
										n2 = Line.length()-n1;
										if(n1 == -1)
											n1 = 0;
										Line = Line.substr(n1,n2);
										Line1+=Line;
										n2 = Line.find('}');
										if (n2 != -1) break;
									}
									//???????????
									pNode->PInteger=new vector<string>();
									WorkOnInt(Line,pNode->PInteger);
									continue;
								}
								//定义访问权限的行
								n1 = Line.find("ACCESS");
								n2 = Line.find("MAX-ACCESS");
								if ((n1 == 0)||(n2 == 0))
								{
									Line=Line.substr(Line.find(" "),Line.length() - Line.find(" "));
									n1 = Line.find_first_not_of(" ");
									n2 = Line.length()-n1;
									if(n1 == -1)
										n1 = 0;
									Line = Line.substr(n1,n2);
									n2 = Line.find_last_not_of(" ");
									Line = Line.substr(0,n2+1); //？？？？？取出左右测空格

									pNode->PAccess=Line;
									continue;
								}
								//定义对象状态的行
								n1 = Line.find("STATUS");
								if ((n1 == 0))
								{
									Line=Line.substr(Line.find(" "),Line.length() - Line.find(" "));
									n1 = Line.find_first_not_of(" ");
									n2 = Line.length()-n1;
									if(n1 == -1)
										n1 = 0;
									Line = Line.substr(n1,n2);
									n2 = Line.find_last_not_of(" ");
									Line = Line.substr(0,n2+1); //？？？？？取出左右测空格

									pNode->PStatus=Line;
									continue;
								}
								//定义表索引的行
								n1 = Line.find("INDEX");
								if ((n1 == 0))
								{
									Line=Line.substr(Line.find(" "),Line.length() - Line.find(" "));
									string Line1=Line;
									n2 = Line.find('}');
									if (n2 == -1)
									{
										while (getline(fsFile, Line))
										{
											if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
											if (Line.find("--")==0) continue;    //注释行直接读下一行
											n1 = Line.find("--");
											if (n1 > 0)           //去掉行后边注释部分
												Line=Line.substr(0,Line.find("--"));
											n1 = Line.find_first_not_of(" ");
											n2 = Line.length()-n1;
											if(n1 == -1)
												n1 = 0;
											Line = Line.substr(n1,n2);
											n2 = Line.find_last_not_of(" ");
											Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
											n1 = Line.find_first_not_of("\t");
											n2 = Line.length()-n1;
											if(n1 == -1)
												n1 = 0;
											Line = Line.substr(n1,n2);

											Line1=Line1+' '+Line;
											n2 = Line.find('}');
											if (n2 != -1) break;
										}
									}
									n1 = Line1.find_first_of("{");
									n2 = Line1.length()-n1+1;
									if(n1 == -1)
										n1 = 0;
									Line1 = Line1.substr(n1,n2);
									n2 = Line1.find_last_of("}");
									Line1 = Line1.substr(0,n2+2); //？？？？？取出左右测空格
									pNode->PIndex=Line1;
									YFIndexString=Line1;
									continue;
								}
								n1 = Line.find("DESCRIPTION");
								if  ((n1 == 0))
								{
									string Line1;
									while (getline(fsFile, Line))
									{
										if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
										if (Line.find("--")==0) continue;    //注释行直接读下一行
										n1 = Line.find("--");
										if (n1 > 0)           //去掉行后边注释部分
											Line=Line.substr(0,Line.find("--"));
										n1 = Line.find_first_not_of(" ");
										n2 = Line.length()-n1;
										if(n1 == -1)
											n1 = 0;
										Line = Line.substr(n1,n2);
										n2 = Line.find_last_not_of(" ");
										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
										n1 = Line.find_first_not_of("\t");
										n2 = Line.length()-n1;
										if(n1 == -1)
											n1 = 0;
										Line = Line.substr(n1,n2);

										Line1+=Line;
										//
										n2 = Line.find('"',2);
										if (n2 > 2) break;
									}
									pNode->PDescr=Line1;
									continue;
								}
								//定义被管理对象的最后一行，获取其他信息后，退出
								n1 = Line.find("::=");
								if ((n1 == 0))
								{
									n1 = Line.find('}');
									n2 = Line.find('{');
									if((n1 > 3) && (n2 > 1))
									{
										n1=Line.find('{');
										n2=Line.find('}')-n1-1;
										Line=Line.substr(n1+1,n2);
										n1 = Line.find_first_not_of(" ");
										n2 = Line.length()-n1;
										if(n1 == -1)
											n1 = 0;
										Line = Line.substr(n1,n2);
										n2 = Line.find_last_not_of(" ");
										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格

										ParentName=Line.substr(0,Line.find(' ')+1);
										Pos=Line.substr(Line.find(' ')+1,Line.length()-Line.find(' '));
										AddObject(&YFHRoot,ParentName,NodeName,Pos,pNode);
										break;
									}
								}
						}//	while (MibFile.ReadString(Line))
						continue;
					  }*/
	 }
	 preorderPrintf(&YFHRoot);
//	 TreeNode *treenode = NULL;
//	 string a = "1.23.2.1";
//	 SearchNodeFromOID(&YFHRoot,treenode,a);
//	 cout << treenode->Currentname << endl;
	fsFile.close();  //???此处文件名
    return 0;
}

//加载MIB
//int LoadMin(void)
//{
//	int n1,n2;  //用于查找字符所在位置
//	string tmp;
////	cout << "Enter MIB file name: ";
////	string filename;
////	cin >> filename;
////	const char *ch = filename.c_str();
////
////	InitTreeData(&YFHRoot);
////	cout << "Enter MIB root name: ";
////	cin >> tmp;
//	tmp = "ciscoMgmt";
//	YFHRoot.Currentname = tmp;
////	cout << "Enter MIB root oid: ";
////	cin >> tmp;
//	tmp = "1";
//	YFHRoot.Mibdata.POid = tmp;
//
//    MibNode* pNode;//叶子节点
//    string Line;        //临时保存文件中读入的一行
//
//    fstream fsFile;
////    fsFile.open(ch, ios_base::in);  //???此处文件名
//    fsFile.open("CISCO-CDP-MIB_my.txt", ios_base::in);  //???此处文件名
//    if (!fsFile.is_open())
//    {
//    	 cout << "读取 MyText.txt 文件失败!" << endl;
//    	 return 0;
//    }
//
//	YFIndexString=' ';    //初始化索引字符串
//	 while ( !fsFile.eof() )  //逐行读入并处理
//	 {
//		getline(fsFile, Line);
//		if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
//		if (Line.find("--")==0) continue;    //注释行直接读下一行
//		n1 = Line.find("--");
//		if (n1 > 0)           //去掉行后边注释部分
//			Line=Line.substr(0,Line.find("--")+1);
//		n1 = Line.find_first_not_of(" ");
//		n2 = Line.length()-n1;
//		if(n1 == -1)
//			n1 = 0;
//		Line = Line.substr(n1,n2);
//		n2 = Line.find_last_not_of(" ");
//		Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//		n1 = Line.find_first_not_of("\t");
//		n2 = Line.length()-n1;
//		if(n1 == -1)
//			n1 = 0;
//		Line = Line.substr(n1,n2);
//		//辅助节点定义行，从该行中可以读得的信息有：辅助节点的名字，该辅助节点的父节点名字，
//		//该辅助节点在兄弟节点中的位置。这些信息被传递给函数Tree control中添加辅助节点的函数
//		//AddPlaceHolder。有该函数完成Tree Control中增加行应的节点
//		n1 = Line.find("OBJECT IDENTIFIER ::=");
//		if (n1 > 2)
//		{
//			n1 = Line.find('{');
//			n2 = Line.find('}');
//			if ((n1 > 10) && (n2 > 10))
//			{
//				string ParentName,NodeName,Pos;
//				NodeName=Line.substr(0,Line.find("OBJECT IDENTIFIER ::="));
//				n1=Line.find('{');
//				n2=Line.find('}')-n1-1;
//				Line=Line.substr(n1+1,n2);
//				n1 = Line.find_first_not_of(" ");
//				n2 = Line.length()-n1;
//				if(n1 == -1)
//					n1 = 0;
//				Line = Line.substr(n1,n2);
//				n2 = Line.find_last_not_of(" ");
//				Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//				ParentName=Line.substr(0,Line.find(' '));
//				Pos=Line.substr(Line.find(' ')+1,Line.length() - Line.find(' '));
//				AddPlaceHolder(&YFHRoot,ParentName,NodeName,Pos);
//				continue;
//			}
//		}
//			//辅助节点定义行，和上边的格式不同的是，这个定义有多行组成，因此要接着读入后边的定义语句，
//			//才能获取全部的信息。IF 语句的限制条件是因为MIB文件的头部说明部分往往也包含这样的关键字，
//			//要滤除掉
//		n1 = Line.find("MODULE-IDENTITY");
//		n2 = Line.find(',');
//			if ((n1 > 2) && (n2 == -1))
//			{
//				string ParentName,NodeName,Pos;
//				NodeName=Line.substr(0,Line.find("MODULE-IDENTITY"));
//               	while (getline(fsFile, Line))
//				{
//               		if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
//               		if (Line.find("--")==0) continue;    //注释行直接读下一行
//               		n1 = Line.find("--");
//               		if (n1 > 0)           //去掉行后边注释部分
//               		Line=Line.substr(0,Line.find("--"));
//               		n1 = Line.find_first_not_of(" ");
//               		n2 = Line.length()-n1;
//               		if(n1 == -1)
//               			n1 = 0;
//               		Line = Line.substr(n1,n2);
//               		n2 = Line.find_last_not_of(" ");
//               		Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//               		n1 = Line.find_first_not_of("\t");
//               		n2 = Line.length()-n1;
//               		if(n1 == -1)
//               			n1 = 0;
//               		Line = Line.substr(n1,n2);
//               		if ((Line.find("::=")==0)&&(Line.find('}')>3)&&(Line.find('{')>1))
//					{
//						n1=Line.find('{');
//						n2=Line.find('}')-n1-1;
//						Line=Line.substr(n1+1,n2);
//						n1 = Line.find_first_not_of(" ");
//						n2 = Line.length()-n1;
//						if(n1 == -1)
//							n1 = 0;
//						Line = Line.substr(n1,n2);
//						n2 = Line.find_last_not_of(" ");
//						Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//						ParentName=Line.substr(0,Line.find(' '));
//						Pos=Line.substr(Line.find(' ')+1,Line.length()-Line.find(' '));
//						AddPlaceHolder(&YFHRoot,ParentName,NodeName,Pos);
//						break;
//					}
//				}//	while (MibFile.ReadString(Line))
//				continue;
//			}
//			//另一种辅助节点定义行形式，处理方式同第一种形式
//			n1 = Line.find("OBJECT-IDENTITY");
//			n2 = Line.find(',');
//			if ((n1 > 2) && (n2 == -1))
//			{
//				string ParentName,NodeName,Pos;
//				NodeName=Line.substr(0,Line.find("OBJECT-IDENTITY"));
//				n1=Line.find('{');
//				n2=Line.find('}')-n1-1;
//				Line=Line.substr(n1+1,n2);
//				n1 = Line.find_first_not_of(" ");
//				n2 = Line.length()-n1;
//				if(n1==-1)
//					n1 = 0;
//				Line = Line.substr(n1,n2);
//				n2 = Line.find_last_not_of(" ");
//				Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//				ParentName=Line.substr(0,Line.find(' '));
//				Pos=Line.substr(Line.find(' ')+1,Line.length() - Line.find(' '));
//				AddPlaceHolder(&YFHRoot,ParentName,NodeName,Pos);
//				continue;
//			}
//			//
//			n1 = Line.find("OBJECT-TYPE");
//			n2 = Line.find(',');
//			if ((n1 > 2) && (n2 == -1))
//						{
//							string ParentName,NodeName,Pos;
//							NodeName=Line.substr(0,Line.find("OBJECT-TYPE"));
//							n1 = Line.find_first_not_of(" ");
//							n2 = Line.length()-n1;
//							if(n1 == -1)
//								n1 = 0;
//							Line = Line.substr(n1,n2);
//							n2 = Line.find_last_not_of(" ");
//							Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//							pNode=new MibNode;
//							InitNodeData(pNode);
//							//z逐行读入后续的定义行
//							while (getline(fsFile, Line))
//							{
//								if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
//								if (Line.find("--")==0) continue;    //注释行直接读下一行
//								n1 = Line.find("--");
//								if (n1 > 0)           //去掉行后边注释部分
//								    Line=Line.substr(0,Line.find("--"));
//								n1 = Line.find_first_not_of(" ");
//								n2 = Line.length()-n1;
//								if(n1 == -1)
//								    n1 = 0;
//								Line = Line.substr(n1,n2);
//								n2 = Line.find_last_not_of(" ");
//								Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//								n1 = Line.find_first_not_of("\t");
//								n2 = Line.length()-n1;
//								if(n1 == -1)
//								    n1 = 0;
//								Line = Line.substr(n1,n2);
//
//								n1 = Line.find("SYNTAX");//定义数据类型
//								if(n1 == 0)
//								{
//									//整数类型
//									n1 = Line.find("INTEGER");
//									if (n1 > 0)
//									{
//										pNode->PSnytax="INTEGER";
//										//判断是否为枚举类型第2种定义形式
//										n1 = Line.find('{');
//										n2 = Line.find('}');
//										if ((n1 > 10) && (n2 > 10))
//										{
//											//保存定义信息    ??????
//											pNode->PInteger=new vector<string>();
//											WorkOnInt(Line,pNode->PInteger);
//										}
//										//判断是否为枚举类型第3.4种定义形式
//										if ((n1 > 10) && (n2 == -1))
//										{
//											string Line1="{";
//											while (getline(fsFile, Line))
//											{
//												if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
//												if (Line.find("--")==0) continue;    //注释行直接读下一行
//												n1 = Line.find("--");
//												if (n1 > 0)           //去掉行后边注释部分
//													Line=Line.substr(0,Line.find("--"));
//												n1 = Line.find_first_not_of(" ");
//												n2 = Line.length()-n1;
//												if(n1 == -1)
//													n1 = 0;
//												Line = Line.substr(n1,n2);
//												n2 = Line.find_last_not_of(" ");
//												Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//												n1 = Line.find_first_not_of("\t");
//												n2 = Line.length()-n1;
//												if(n1 == -1)
//													 n1 = 0;
//												Line = Line.substr(n1,n2);
//												Line1 += Line;
//
//												n2 = Line.find('}');
//												if (n2 != -1) break;
//											}
//											//？？？？？？？？？？？
//											pNode->PInteger=new vector<string>();
//											WorkOnInt(Line,pNode->PInteger);
//										}
//									}
//									else   //非INTEGER的其他类型
//									{
//										Line=Line.substr(6,Line.length() - 6);
//										n1 = Line.find_first_not_of(" ");
//										n2 = Line.length()-n1;
//										if(n1 == -1)
//											n1 = 0;
//										Line = Line.substr(n1,n2);
//										n2 = Line.find_last_not_of(" ");
//										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//
//										pNode->PSnytax=Line;
//									}
//									continue;
//								}// if(Line.Find("SYNTAX")==0)
//								//判断是否为枚举类型整数的第一种定义形式
//								n2 = Line.find('{');
//								if ((n2 ==0) && (pNode->PSnytax.find("INTEGER")==0))
//								{
//									string Line1=Line;
//									while (getline(fsFile, Line))
//									{
//										if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
//										if (Line.find("--")==0) continue;    //注释行直接读下一行
//										n1 = Line.find("--");
//										if (n1 > 0)           //去掉行后边注释部分
//											Line=Line.substr(0,Line.find("--"));
//										n1 = Line.find_first_not_of(" ");
//										n2 = Line.length()-n1;
//										if(n1 == -1)
//											n1 = 0;
//										Line = Line.substr(n1,n2);
//										n2 = Line.find_last_not_of(" ");
//										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//										n1 = Line.find_first_not_of("\t");
//										n2 = Line.length()-n1;
//										if(n1 == -1)
//											n1 = 0;
//										Line = Line.substr(n1,n2);
//										Line1+=Line;
//										n2 = Line.find('}');
//										if (n2 != -1) break;
//									}
//									//???????????
//									pNode->PInteger=new vector<string>();
//									WorkOnInt(Line,pNode->PInteger);
//									continue;
//								}
//								//定义访问权限的行
//								n1 = Line.find("ACCESS");
//								n2 = Line.find("MAX-ACCESS");
//								if ((n1 == 0)||(n2 == 0))
//								{
//									Line=Line.substr(Line.find(" "),Line.length() - Line.find(" "));
//									n1 = Line.find_first_not_of(" ");
//									n2 = Line.length()-n1;
//									if(n1 == -1)
//										n1 = 0;
//									Line = Line.substr(n1,n2);
//									n2 = Line.find_last_not_of(" ");
//									Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//
//									pNode->PAccess=Line;
//									continue;
//								}
//								//定义对象状态的行
//								n1 = Line.find("STATUS");
//								if ((n1 == 0))
//								{
//									Line=Line.substr(Line.find(" "),Line.length() - Line.find(" "));
//									n1 = Line.find_first_not_of(" ");
//									n2 = Line.length()-n1;
//									if(n1 == -1)
//										n1 = 0;
//									Line = Line.substr(n1,n2);
//									n2 = Line.find_last_not_of(" ");
//									Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//
//									pNode->PStatus=Line;
//									continue;
//								}
//								//定义表索引的行
//								n1 = Line.find("INDEX");
//								if ((n1 == 0))
//								{
//									Line=Line.substr(Line.find(" "),Line.length() - Line.find(" "));
//									string Line1=Line;
//									n2 = Line.find('}');
//									if (n2 == -1)
//									{
//										while (getline(fsFile, Line))
//										{
//											if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
//											if (Line.find("--")==0) continue;    //注释行直接读下一行
//											n1 = Line.find("--");
//											if (n1 > 0)           //去掉行后边注释部分
//												Line=Line.substr(0,Line.find("--"));
//											n1 = Line.find_first_not_of(" ");
//											n2 = Line.length()-n1;
//											if(n1 == -1)
//												n1 = 0;
//											Line = Line.substr(n1,n2);
//											n2 = Line.find_last_not_of(" ");
//											Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//											n1 = Line.find_first_not_of("\t");
//											n2 = Line.length()-n1;
//											if(n1 == -1)
//												n1 = 0;
//											Line = Line.substr(n1,n2);
//
//											Line1=Line1+' '+Line;
//											n2 = Line.find('}');
//											if (n2 != -1) break;
//										}
//									}
//									n1 = Line1.find_first_of("{");
//									n2 = Line1.length()-n1+1;
//									if(n1 == -1)
//										n1 = 0;
//									Line1 = Line1.substr(n1,n2);
//									n2 = Line1.find_last_of("}");
//									Line1 = Line1.substr(0,n2+2); //？？？？？取出左右测空格
//									pNode->PIndex=Line1;
//									YFIndexString=Line1;
//									continue;
//								}
//								n1 = Line.find("DESCRIPTION");
//								if  ((n1 == 0))
//								{
//									string Line1;
//									while (getline(fsFile, Line))
//									{
//										if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
//										if (Line.find("--")==0) continue;    //注释行直接读下一行
//										n1 = Line.find("--");
//										if (n1 > 0)           //去掉行后边注释部分
//											Line=Line.substr(0,Line.find("--"));
//										n1 = Line.find_first_not_of(" ");
//										n2 = Line.length()-n1;
//										if(n1 == -1)
//											n1 = 0;
//										Line = Line.substr(n1,n2);
//										n2 = Line.find_last_not_of(" ");
//										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//										n1 = Line.find_first_not_of("\t");
//										n2 = Line.length()-n1;
//										if(n1 == -1)
//											n1 = 0;
//										Line = Line.substr(n1,n2);
//
//										Line1+=Line;
//										//
//										n2 = Line.find('"',2);
//										if (n2 > 2) break;
//									}
//									pNode->PDescr=Line1;
//									continue;
//								}
//								//定义被管理对象的最后一行，获取其他信息后，退出
//								n1 = Line.find("::=");
//								if ((n1 == 0))
//								{
//									n1 = Line.find('}');
//									n2 = Line.find('{');
//									if((n1 > 3) && (n2 > 1))
//									{
//										n1=Line.find('{');
//										n2=Line.find('}')-n1-1;
//										Line=Line.substr(n1+1,n2);
//										n1 = Line.find_first_not_of(" ");
//										n2 = Line.length()-n1;
//										if(n1 == -1)
//											n1 = 0;
//										Line = Line.substr(n1,n2);
//										n2 = Line.find_last_not_of(" ");
//										Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
//
//										ParentName=Line.substr(0,Line.find(' ')+1);
//										Pos=Line.substr(Line.find(' ')+1,Line.length()-Line.find(' '));
//										AddObject(&YFHRoot,ParentName,NodeName,Pos,pNode);
//										break;
//									}
//								}
//						}//	while (MibFile.ReadString(Line))
//						continue;
//					  }
//	 }
//	 preorderPrintf(&YFHRoot);
////	 TreeNode *treenode = NULL;
////	 string a = "1.23.2.1";
////	 SearchNodeFromOID(&YFHRoot,treenode,a);
////	 cout << treenode->Currentname << endl;
//	fsFile.close();  //???此处文件名
//    return 0;
//}
//
