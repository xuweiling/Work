﻿// NetCommuCT.cpp: implementation of the CNetCommuCT class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "commu.h"
#include "BaseFile.h"
#include <math.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include "NetCommuCT.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//BYTE CNetCommuCT::BufferSave_Send[MACRO_FILE_SIZE];				//将要保存到文件中的发送数据
//BYTE CNetCommuCT::BufferSave_Recv[MACRO_FILE_SIZE];				//将要保存到文件中的接收数据
int CNetCommuCT::BufferSave_SendLength;							//将要保存到文件中的发送数据长度
int CNetCommuCT::BufferSave_RecvLength;							//将要保存到文件中的接收数据长度 使用static,这样所有的数据都保存在一个文件中
DWORD CNetCommuCT::RecentTime;									//最新收到的时间
DWORD CNetCommuCT::RecentDate;									//最新收到的日期
DWORD CNetCommuCT::RecentDateTime;

QString CNetCommuCT::BufferSaveFilePath_Send;					//将要保存的发送数据文件路径
QString CNetCommuCT::BufferSaveFilePath_Recv;					//将要保存的接收数据文件路径
SYSTEMTIME CNetCommuCT::StartTime;							//起始时刻
SYSTEMTIME CNetCommuCT::EndTime;								//保存时刻
DWORD	CNetCommu::BIDMeasure;									//实算数据帧BID(仅供SaveFile使用)
DWORD	CNetCommu::BIDTimer;									//常时数据帧BID(仅供SaveFile使用)
DWORD	CNetCommu::BIDExam;										//时延测试帧BID(仅供SaveFile使用)
DWORD	CNetCommu::BIDT0;										//T0数据帧BID(仅供SaveFile使用)
DWORD	CNetCommu::BIDWYD[30];										//外部说明数据帧头信息(仅供SaveFile使用)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNetCommuCT::CNetCommuCT(QObject *parent) :
    QObject(parent)
{
    KeepConnecting = false;
    CurrentMode = Normal;
    TimeSource = Time_GPS;
    memset(BufferRecv_Passed, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend_Passed, 0, MACRO_BUFFER_SIZE);
#ifdef LINUXQT
    PDlg = NULL;
#endif
    memset(BufferRecv, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend, 0, MACRO_BUFFER_SIZE);
//	memset(BufferSave_Send, 0, MACRO_FILE_SIZE);
//	memset(BufferSave_Recv, 0, MACRO_FILE_SIZE);
    BufferSave_SendLength = 0;
    BufferSave_RecvLength = 0;
    memset(&MeasureHEADER, 0, sizeof(HEADERStruct));
    memset(&TimerSendHEADER, 0, sizeof(HEADERStruct));
    memset(&TimerRecvHEADER, 0, sizeof(HEADERStruct));
    memset(&ExamSendHEADER, 0, sizeof(HEADERStruct));
    memset(&ExamRecvHEADER, 0, sizeof(HEADERStruct));
    memset(&T0HEADER, 0, sizeof(HEADERStruct));
    memset(WYDHEADER, 0, 30*sizeof(HEADERStruct));

    CTP2PNum = 0;
    CTMulNumRe = 0;
    CTMulNumSe = 0;
    CTSrcNum = 0;

    WayNO = 0;
    SendSocketTP = Socket_Udp;
    RecvSocketTP = Socket_Udp;
    EjectPosB = 0;
    EjectPosL = 0;
    EjectPosH = 0;
//	EjectPosX = 0;
//	EjectPosY = 0;
//	EjectPosZ = 0;
    EjectAngle = 0;

    MeasurePackIndex = 0;
    TimerPackIndex = 0;
    ExamPackIndex = 0;
    DebugPackIndex = 0;
    RecentTime = 0;
    RecentDate = 0;
    RecentDateTime=0;
    BIDTest = 0;
    pBufferRecvLength = 0;
    pBufferSendLength = 0;
    pBufferSendedLength = 0;

    INI_DATALENGTH_MEASURE = 32;						//实算数据中数据区有效长度 = 32, 22+10
    INI_DATALENGTH_THEORY = 60;							//引入数据中数据区有效长度 = 28
    INI_DATALENGTH_EXAM = 48;							//时延测试数据区长度
    INI_DATALENGTH_T0 = 36;								//T0数据区长度
    INI_REVERSE_DATALENGTH = 10;						//正式实算数据中最后保留的数据长度
    INI_REVERSE_DATACONTENT = "7fffffff000000007fff";	//正式实算数据中最后保留的数据内容

    unsigned short diffDay = GetDate();
    memcpy(MeasureHEADER.v_Date, &diffDay, 2);
    memcpy(TimerSendHEADER.v_Date, &diffDay, 2);
    memcpy(TimerRecvHEADER.v_Date, &diffDay, 2);
    memcpy(ExamSendHEADER.v_Date, &diffDay, 2);
    memcpy(ExamRecvHEADER.v_Date, &diffDay, 2);
    memcpy(T0HEADER.v_Date, &diffDay, 2);
    for(int tem_I=0; tem_I<30; tem_I++)
    {
        memcpy(WYDHEADER[tem_I].v_Date, &diffDay, 2);				//在程序开启时得到日期
    }
}

CNetCommuCT::~CNetCommuCT()
{

}

/************************************************************************/
/* 网络启动，线程启动
参数:
1.路由编号
2.发送网络类型(单播/组播)
3.接收网络类型(单播/组播)
*/
/************************************************************************/
bool CNetCommuCT::StartConnect(int paramWayNo, Sockettp paramSendSocketTP, Sockettp paramRecvSocketTP)
{
    bool ret = false;
    WayNO = paramWayNo;
    SendSocketTP = paramSendSocketTP;
    RecvSocketTP = paramRecvSocketTP;
    KeepConnecting = true;
    memset(BufferRecv_Passed, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend_Passed, 0, MACRO_BUFFER_SIZE);
    memset(BufferRecv, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend, 0, MACRO_BUFFER_SIZE);
//	memset(BufferSave_Send, 0, MACRO_FILE_SIZE);
//	memset(BufferSave_Recv, 0, MACRO_FILE_SIZE);
    BufferSave_SendLength = 0;
    BufferSave_RecvLength = 0;

    MeasurePackIndex = 0;
    TimerPackIndex = 0;
    ExamPackIndex = 0;
    DebugPackIndex = 0;
    RecentTime = 0;
    RecentDate = 0;
    RecentDateTime=0;
    BIDTest = 0;
    pBufferRecvLength = 0;
    pBufferSendLength = 0;
    pBufferSendedLength = 0;

    ReadIniFile();					//读取配置
    memcpy( &(theRecvSocket.LocalSet), &LocalSet, sizeof(SocketSetting));
    memcpy( &(theSendSocket.LocalSet), &LocalSet, sizeof(SocketSetting));

    theRecvSocket.Type = 0;
    theSendSocket.Type = 1;

    theRecvSocket.pSaveBuffer = BufferRecv;
    ret = theRecvSocket.Initial( this, true );		//接收Socket初始化
    if(!ret)
    {
        QString pMessage = QString("网卡:%1.%2.%3.%4绑定失败 \n  请检查网络连接和交换机\n  之后重新启动本软件，否则本网卡失效")
                        .arg((LocalSet.IPAdd.sin_addr.s_addr)&0xff)
                        .arg((LocalSet.IPAdd.sin_addr.s_addr>>8)&0xff)
                        .arg((LocalSet.IPAdd.sin_addr.s_addr>>16)&0xff)
                        .arg((LocalSet.IPAdd.sin_addr.s_addr>>24)&0xff);
        AfxMessageBox(pMessage);
        SocketEnable = false;
        theRecvSocket.ShutDown(2);
    }
    else
    {
        SocketEnable = true;
    }
    ret = theSendSocket.Initial( this, false );		//发送Socket初始化
    if(!ret)
    {
        QString pMessage = QString("网卡:%1.%2.%3.%4绑定失败 \n  请检查网络连接和交换机")
                        .arg((LocalSet.IPAdd.sin_addr.s_addr)&0xff)
                        .arg((LocalSet.IPAdd.sin_addr.s_addr>>8)&0xff)
                        .arg((LocalSet.IPAdd.sin_addr.s_addr>>16)&0xff)
                        .arg((LocalSet.IPAdd.sin_addr.s_addr>>24)&0xff);
        AfxMessageBox(pMessage);
        SocketEnable = false;
        theSendSocket.ShutDown(2);
    }
    else
    {
        SocketEnable = true;
    }

//组播
    int addrIndex = 0;
    int addrIndex2 = 0;
    if(RecvSocketTP == Socket_Multicast_ASM)//组播收
    {
        for(addrIndex=0; addrIndex<CTMulNumRe; addrIndex++)
        {
            QString pAddStr = QString("%1.%2.%3.%4")
                            .arg((CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr)&0xff)
                            .arg((CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr>>8)&0xff)
                            .arg((CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr>>16)&0xff)
                            .arg((CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr>>24)&0xff);
            theRecvSocket.JoinBroadCastGroup(pAddStr.toAscii());
        }
    }
    else if(RecvSocketTP == Socket_Multicast_SSM)
    {
        addrIndex = 0;
        addrIndex2 = 0;
        for(addrIndex=0; addrIndex<CTSrcNum; addrIndex++)
        {
            for(addrIndex2=0; addrIndex2<CTMulNumRe; addrIndex2++)
            {
                QString pAddStr1 = QString("%1.%2.%3.%4")
                                .arg((CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr)&0xff)
                                .arg((CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr>>8)&0xff)
                                .arg((CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr>>16)&0xff)
                                .arg((CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr>>24)&0xff);
                QString pAddStr2 = QString("%1.%2.%3.%4")
                                .arg((CTSrcSet[addrIndex])&0xff)
                                .arg((CTSrcSet[addrIndex]>>8)&0xff)
                                .arg((CTSrcSet[addrIndex]>>16)&0xff)
                                .arg((CTSrcSet[addrIndex]>>24)&0xff);
                theRecvSocket.JoinSSMBroadCastGroup(pAddStr1.toAscii(), pAddStr2.toAscii());//指定源的组播则需要加入源地址
            }
        }
    }

    if(SendSocketTP == Socket_Multicast_ASM)//组播发
    {
        addrIndex = 0;
        addrIndex2 = 0;
        for(addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
        {
            QString pAddStr = QString("%1.%2.%3.%4")
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr)&0xff)
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr>>8)&0xff)
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr>>16)&0xff)
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr>>24)&0xff);
            theSendSocket.JoinBroadCastGroup(pAddStr.toAscii());
        }
    }
    else if(SendSocketTP == Socket_Multicast_SSM)
    {
        addrIndex = 0;
        addrIndex2 = 0;
        for(addrIndex=0; addrIndex<CTSrcNum; addrIndex++)
        {
            for(addrIndex2=0; addrIndex2<CTMulNumSe; addrIndex2++)
            {
                QString pAddStr1 = QString("%1.%2.%3.%4")
                                .arg((CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr)&0xff)
                                .arg((CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr>>8)&0xff)
                                .arg((CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr>>16)&0xff)
                                .arg((CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr>>24)&0xff);
                QString pAddStr2 = QString("%1.%2.%3.%4")
                                .arg((CTSrcSet[addrIndex])&0xff)
                                .arg((CTSrcSet[addrIndex]>>8)&0xff)
                                .arg((CTSrcSet[addrIndex]>>16)&0xff)
                                .arg((CTSrcSet[addrIndex]>>24)&0xff);
                theSendSocket.JoinSSMBroadCastGroup(pAddStr1.toAscii(), pAddStr2.toAscii());//指定源的组播则需要加入源地址
            }
        }
    }


    GetSystemTime(&StartTime);					//起始时刻
//文件初始化，等待写入
    QString startMessage;
    SaveFileName_Send.sprintf("/发送中心%d-%d年%d月%d日%d时%d分%d秒.txt", WayNO+1, StartTime.tm_year, StartTime.tm_mon,
        StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    startMessage.sprintf("%d年%d月%d日%d时%d分%d秒 开始记录: \n", StartTime.tm_year, StartTime.tm_mon,
                         StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    SaveFileName_Send = BufferSaveFilePath_Send + SaveFileName_Send;
    SendFile=::open(SaveFileName_Send.toAscii(),O_CREAT|O_RDWR,S_IRUSR|S_IRGRP|S_IROTH);
    ::write(SendFile,startMessage.toAscii(),strlen(startMessage.toAscii()));

    SaveFileName_Recv=QString("/接收中心%1-%2年%3月%4日%5时%6分%7秒.txt")
            .arg(WayNO+1)
            .arg(StartTime.tm_year)
            .arg(StartTime.tm_mon)
            .arg(StartTime.tm_mday)
            .arg(StartTime.tm_hour)
            .arg(StartTime.tm_min)
            .arg(StartTime.tm_sec);
    startMessage=QString("%1年%2月%3日%4时%5分%6秒 开始记录: \n")
            .arg(StartTime.tm_year)
            .arg(StartTime.tm_mon)
            .arg(StartTime.tm_mday)
            .arg(StartTime.tm_hour)
            .arg(StartTime.tm_min)
            .arg(StartTime.tm_sec);

    SaveFileName_Recv = BufferSaveFilePath_Recv + SaveFileName_Recv;
    RecvFile=::open(SaveFileName_Recv.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    ::write(RecvFile,startMessage.toAscii(),strlen(startMessage.toAscii()));

    OctFileName_Send = SaveFileName_Send.left(SaveFileName_Send.lastIndexOf('.')) + "解码.txt";
    OctFileName_Recv = SaveFileName_Recv.left(SaveFileName_Recv.lastIndexOf('.')) + "解码.txt";
    SendFileOct=::open(OctFileName_Send.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    RecvFileOct=::open(OctFileName_Recv.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    startMessage=QString("发送中心数据\n序号    本地时间    时间    类别    方位角A(度)    俯仰角E(度)    伺服模式    目标数目    脱靶量X(秒)    脱靶量Y(秒)    时延发起    时延收到    时延返回    \n");
    ::write(SendFileOct,startMessage.toAscii(),strlen(startMessage.toAscii()));//写入标题
    startMessage=QString("接收中心数据\n序号    本地时间    时间    源地址IP    类别    大地坐标X(米)    大地坐标Y(米)    大地坐标Z(米)    速度X(米/秒)    速度Y(米/秒)    速度Z(米/秒)    起飞时刻    时延发起    时延收到    时延返回    \n");
    ::write(RecvFileOct,startMessage.toAscii(),strlen(startMessage.toAscii()));

    DesI = 0;
    SendEnable = true;
    return true;
}

/************************************************************************/
/* 发送数据，数据转换在这里进行
1.准备状态：BufferSend_Passed具有数据，数据可能是实算数据、时延测试、常时
            注意要保证互斥性(格式可能是符合HEADER的时延测试、常时、调试数据，
            也可能是自身原设定的实算数据)
2.参数；1=实算数据;2=常时;3=时延测试发起;4=时延测试响应
本函数将原始的数据 BufferSend_Passed 进行转换，然后用发送端口发出，同时记录
到文件中，同时还要通知窗口进行显示更新。不处理与中心站的发送
a.复制
b.转换
c.网络发送
d.通知窗口更新显示
e.数据存盘
f.记录该型数据的总数
                           */
/************************************************************************/
bool CNetCommuCT::SendData(int type)
{
    if(!SocketEnable)
        return false;
    if(!KeepConnecting)
    {
        return false;
    }
    if(!SendEnable)
        return false;

//a.复制
    memset(BufferSend, 0, MACRO_BUFFER_SIZE);
    memcpy(BufferSend, BufferSend_Passed, MACRO_BUFFER_SIZE);

//b.转换
    int sendLength = TransZK2CT(BufferSend, MACRO_BUFFER_SIZE, BufferSendtemp, MACRO_BUFFER_SIZE, type);
    memcpy(BufferSend, BufferSendtemp, MACRO_BUFFER_SIZE);

//c.网络发送
    //单播发送
    if(SendSocketTP == Socket_Udp)
    {
        for(int addrIndex=0; addrIndex<CTP2PNum; addrIndex++)
        {
            QString pAddStr = QString("%1.%2.%3.%4")
                            .arg((CTP2PSet[addrIndex].IPAdd.sin_addr.s_addr)&0xff)
                            .arg((CTP2PSet[addrIndex].IPAdd.sin_addr.s_addr>>8)&0xff)
                            .arg((CTP2PSet[addrIndex].IPAdd.sin_addr.s_addr>>16)&0xff)
                            .arg((CTP2PSet[addrIndex].IPAdd.sin_addr.s_addr>>24)&0xff);
            memcpy(BufferSend+7, CTP2PSet[addrIndex].DID, 4);
            theSendSocket.SendTo(BufferSend, sendLength, CTP2PSet[addrIndex].PortReceive, pAddStr.toAscii());
        }//每个地址逐一发送
    }
    //组播发送
    else
    {
        for(int addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
        {
            QString pAddStr = QString("%1.%2.%3.%4")
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr)&0xff)
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr>>8)&0xff)
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr>>16)&0xff)
                            .arg((CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr>>24)&0xff);
            memcpy(BufferSend+7, CTMulSetSe[addrIndex].DID, 4);//更改DID
            theSendSocket.SendTo(BufferSend, sendLength, CTMulSetSe[addrIndex].PortReceive, pAddStr.toAscii());
        }//每个地址逐一发送
    }

    pBufferSendedLength = sendLength;
//d.通知窗口更新显示??????????????????????????????????????????
    memcpy(BufferSended_Passed, BufferSend, MACRO_BUFFER_SIZE);
    //memcpy(BufferSended_Passed, BufferSendtemp, MACRO_BUFFER_SIZE);
    emit WM_USER_SENDED_CT(WayNO, sendLength);//消息通知，WayNO用于表明消息的来源

//e.数据存盘
    //输出文件
    SYSTEMTIME curTime;
    QString startMessage;
    QString tempMessage;
    QString iPstr;
    unsigned   char   *pIP;
    curTime = GetTimeMilli(TimeSource);//采用通用时间
    startMessage=startMessage.sprintf("%.2d:%.2d:%.2d::%.3d : LOCAL => ",curTime.tm_hour, curTime.tm_min,
                                      curTime.tm_sec,curTime.tm_msec);

    for(int byteCounter=0; byteCounter<sendLength; byteCounter++)
    {
        int temp_Char = (BYTE)(BufferSendtemp[byteCounter]);
        tempMessage=tempMessage.sprintf("%.2x", temp_Char);
        startMessage = startMessage + tempMessage;
        if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
        {
            startMessage = startMessage + " ";
        }
    }

    DWORD pp1 = 0;
    //单播
    if(SendSocketTP == Socket_Udp)
    {
        if(CTP2PNum>0)
            pIP = (unsigned   char*)&(CTP2PSet[0].IPAdd.sin_addr.s_addr);
        else
            pIP = (unsigned   char*)&pp1;
    }
    //组播
    else
    {
        if(CTMulNumSe>0)
            pIP = (unsigned   char*)&(CTMulSetSe[0].IPAdd.sin_addr.s_addr);
        else
            pIP = (unsigned   char*)&pp1;
    }
    iPstr=iPstr.sprintf("%.3u.%.3u.%.3u.%.3u", *pIP, *(pIP+1), *(pIP+2), *(pIP+3));
    startMessage = startMessage + " => " + iPstr + "\n";
    ::write(SendFile,startMessage.toAscii(),strlen(startMessage.toAscii()));
    OctSwitch(0, startMessage, &tempMessage);
    ::write(SendFileOct,tempMessage.toAscii(),strlen(tempMessage.toAscii()));
    //输出文件结束

    //记录该型数据的总数
    switch(type)
    {
    case 1:
    case 5:
        {
            MeasureCOUNT++;
            if(MeasureCOUNT>(256*256*256*255))
                MeasureCOUNT = 0;
            break;
        }
    case 2:
        {
            LinkSendCOUNT++;
            if(LinkSendCOUNT>(256*256*256*255))
                LinkSendCOUNT = 0;
            break;
        }
    case 3:
    case 4:
        {
            TimeExamSendCOUNT++;
            if(TimeExamSendCOUNT>(256*256*256*255))
                TimeExamSendCOUNT = 0;
            break;
        }
    }

    return true;
}

/************************************************************************/
/* 发送数据，数据转换在这里进行
参数	sendDataBuffer:数据区
        sendDataBufferLength:数据区长度
        type:1=实算数据;2=常时;3=时延测试发起;4=时延测试响应       */
/************************************************************************/
bool CNetCommuCT::SendData(BYTE* sendDataBuffer, int sendDataBufferLength, SocketSetting DestSet, int type)
{
    if(!SocketEnable)
        return false;
    if(!KeepConnecting)
        return false;
    else
    {
        QString pAddStr = QString("%1.%2.%3.%4")
                        .arg((DestSet.IPAdd.sin_addr.s_addr)&0xff)
                        .arg((DestSet.IPAdd.sin_addr.s_addr>>8)&0xff)
                        .arg((DestSet.IPAdd.sin_addr.s_addr>>16)&0xff)
                        .arg((DestSet.IPAdd.sin_addr.s_addr>>24)&0xff);
        theSendSocket.SendTo(sendDataBuffer, sendDataBufferLength, DestSet.PortReceive, pAddStr.toAscii());
    }

    ZKSendCOUNT++;
    if(ZKSendCOUNT>(256*256*256*255))
        ZKSendCOUNT = 0;

    FZSendCOUNT++;
    if(FZSendCOUNT>(256*256*256*255))
        FZSendCOUNT = 0;

    return true;
}

/************************************************************************/
/* 关闭连接                              */
/************************************************************************/
bool CNetCommuCT::CloseConnect( )
{
    KeepConnecting = false;

    //退出组
    int addrIndex = 0;
    int addrIndex2 = 0;
    if(SocketEnable)
    {
        if(RecvSocketTP == Socket_Multicast_ASM)//组播收
        {
            for(addrIndex=0; addrIndex<CTMulNumRe; addrIndex++)
            {
                QString pAddStr;
                pAddStr=pAddStr.sprintf("%d.%d.%d.%d",
                    QString(CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr).mid(0,3).toInt(),
                     QString(CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr).mid(3,3).toInt(),
                     QString(CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr).mid(6,3).toInt(),
                     QString(CTMulSetRe[addrIndex].IPAdd.sin_addr.s_addr).mid(9,3).toInt());
                theRecvSocket.DropBroadCastGroup(pAddStr.toAscii());
            }
        }
        else if(RecvSocketTP == Socket_Multicast_SSM)
        {
            for(addrIndex=0; addrIndex<CTSrcNum; addrIndex++)
            {
                for(addrIndex2=0; addrIndex2<CTMulNumRe; addrIndex2++)
                {
                    QString pAddStr1;
                    pAddStr1=pAddStr1.sprintf("%d.%d.%d.%d",
                        QString(CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr).mid(0,3).toInt(),
                         QString(CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr).mid(3,3).toInt(),
                         QString(CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr).mid(6,3).toInt(),
                         QString(CTMulSetRe[addrIndex2].IPAdd.sin_addr.s_addr).mid(9,3).toInt());
                    QString pAddStr2;
                    pAddStr2=pAddStr2.sprintf("%d.%d.%d.%d", CTSrcSet[addrIndex]/256/256/256,
                        CTSrcSet[addrIndex]/256/256%256,
                        CTSrcSet[addrIndex]/256%256,
                        CTSrcSet[addrIndex]%256);
                    theRecvSocket.DropSSMBroadCastGroup(pAddStr1.toAscii(), pAddStr2.toAscii());//指定源的组播则需要加入源地址
                }
            }
        }

        if(SendSocketTP == Socket_Multicast_ASM)//组播发
        {
            for(addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
            {
                QString pAddStr;
                pAddStr=pAddStr.sprintf("%d.%d.%d.%d",
                    QString(CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr).mid(0,3).toInt(),
                     QString(CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr).mid(3,3).toInt(),
                     QString(CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr).mid(6,3).toInt(),
                     QString(CTMulSetSe[addrIndex].IPAdd.sin_addr.s_addr).mid(9,3).toInt());
                theSendSocket.DropBroadCastGroup(pAddStr.toAscii());
            }
        }
        else if(SendSocketTP == Socket_Multicast_SSM)
        {
            for(addrIndex=0; addrIndex<CTSrcNum; addrIndex++)
            {
                for(addrIndex2=0; addrIndex2<CTMulNumSe; addrIndex2++)
                {
                    QString pAddStr1;
                    pAddStr1=pAddStr1.sprintf("%d.%d.%d.%d",
                        QString(CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr).mid(0,3).toInt(),
                         QString(CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr).mid(3,3).toInt(),
                         QString(CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr).mid(6,3).toInt(),
                         QString(CTMulSetSe[addrIndex2].IPAdd.sin_addr.s_addr).mid(9,3).toInt());
                    QString pAddStr2;
                    pAddStr2=pAddStr2.sprintf("%d.%d.%d.%d", CTSrcSet[addrIndex]/256/256/256,
                        CTSrcSet[addrIndex]/256/256%256,
                        CTSrcSet[addrIndex]/256%256,
                        CTSrcSet[addrIndex]%256);
                    theSendSocket.DropSSMBroadCastGroup(pAddStr1.toAscii(), pAddStr2.toAscii());//指定源的组播则需要加入源地址
                }
            }
        }
    }

    //一些数据清零
    for(addrIndex=0; addrIndex<CTP2PNum; addrIndex++)
    {
        memset(&(CTP2PSet[addrIndex]), 0, sizeof(AddStruct));
    }
    CTP2PSet.clear();
    CTP2PNum = 0;

    for(addrIndex=0; addrIndex<CTMulNumRe; addrIndex++)
    {
        memset(&(CTMulSetRe[addrIndex]), 0, sizeof(AddStruct));
    }
    CTMulSetRe.clear();
    CTMulNumRe = 0;

    for(addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
    {
        memset(&(CTMulSetSe[addrIndex]), 0, sizeof(AddStruct));
    }
    CTMulSetSe.clear();
    CTMulNumSe = 0;

    CTSrcSet.clear();
    CTSrcNum = 0;

    memset(&LocalSet, 0, sizeof(SocketSetting));
    memset(&DataSource, 0, sizeof(SocketSetting));

    theRecvSocket.CloseConnect();
    theSendSocket.CloseConnect();

    if(::close(SendFile)==-1)
    {
        //AfxMessageBox("file close error");
    }
    if(::close(RecvFile)==-1)
    {
        //AfxMessageBox("file close error");
    }
    if(::close(SendFileOct)==-1)
    {
        //AfxMessageBox("file close error");
    }
    if(::close(RecvFileOct)==-1)
    {
        //AfxMessageBox("file close error");
    }
    return true;
}

/************************************************************************/
/* 接收到数据的通知，此时需要做数据处理
1.准备状态：BufferRecv具有数据，数据可能是T0数据、外部说明数据、时延测试、常时
            注意要保证互斥性

  本函数将原始的数据 BufferRecv 通知窗口进行显示更新，同时记录到文件中，
同时还要通知窗口进行显示更新
a.复制
b.通知窗口更新显示
c.数据存盘
                             */
/************************************************************************/
bool CNetCommuCT::Receive()
{
    if(WayNO == 0)
        WayNO = WayNO;

    if(!SocketEnable)
    {
        return false;
    }
    if(!KeepConnecting)
    {
        return false;
    }

//a.复制
    memcpy(&DataSource, &(theRecvSocket.DataSource), sizeof(SocketSetting));//保存来源

    pBufferRecvLength = theRecvSocket.pBufferLength;						//保存长度

    int ts=errno;
    if(SOCKET_ERROR==pBufferRecvLength)
    {
        TRACE("接受数据出错 ErroCode=%d\n", ts);
        return false;
    }
    else
    {
        TRACE("接受\n");
    }

    memset(BufferRecv_Passed, 0, MACRO_BUFFER_SIZE);
    memset(BufferRecvtemp, 0, MACRO_BUFFER_SIZE);
    memcpy(BufferRecv_Passed, BufferRecv, pBufferRecvLength);	//来路明了的数据方予处理
    memcpy(BufferRecvtemp, BufferRecv, pBufferRecvLength);		//来路明了的数据方予处理

//b.通知窗口更新显示
    DWORD RecvDate;
    DWORD RecvTime;

    memcpy(&BIDTest, BufferRecv+11, 4);			//得到当前帧的BID

    int temp_FL = false;
    for(int tem_I=0; tem_I<30; tem_I++)
    {
        if(BIDTest == BIDWYD[tem_I])
        {
            temp_FL = true;
            break;
        }
    }
    if(temp_FL)		//为外部说明数据，仅对外部说明数据进行数据重复性校验
    {
        RecvDate=0;
        RecvTime=0;
        memcpy(&RecvDate, BufferRecv+24, 2);//数据包具有日期，所以一并复制
        memcpy(&RecvTime, BufferRecv+32, 4);//数据包具有时间，所以一并复制
//        RecvDate=(RecvDate&0xff)<<8+(RecvDate&0xff00)>>8;
//        RecvTime=(RecvTime&0xff)<<24+
//		TRACE("RecentTime=%d, RecvTime=%d, RecentDate=%d, ")
        if((RecvTime > RecentTime)||(RecvDate > RecentDate))//时间长或日期长,代表新数据
        {
            RecentTime = RecvTime;
            RecentDate = RecvDate;
            emit WM_USER_RECEIVED_CT(WayNO, 1);//通知窗口来取值,第2个参数表明该数据为新鲜有效的数据，应该转发
        }
        else
        {
            emit WM_USER_RECEIVED_CT(WayNO, 0); //通知窗口来取值,第2个参数表明该数据为重复数据，不应该转发
        }

    }
    else
    {
            emit WM_USER_RECEIVED_CT(WayNO, 1); //通知窗口来取值,第2个参数表明该数据为新鲜有效的数据，应该转发
    }

//c.数据存盘
    //输出文件
    SYSTEMTIME curTime;
    QString startMessage;
    QString tempMessage;
    QString iPstr;
    unsigned   char   *pIP;
    curTime = GetTimeMilli(TimeSource);//采用通用时间

    //单播
    if(RecvSocketTP == Socket_Udp)
    {
        pIP = (unsigned   char*)&(DataSource.IPAdd.sin_addr.s_addr);
    }
    //组播
    else
    {
        pIP = (unsigned   char*)&(DataSource.IPAdd.sin_addr.s_addr);
    }
    iPstr=iPstr.sprintf("%.3u.%.3u.%.3u.%.3u", *pIP, *(pIP+1), *(pIP+2), *(pIP+3));
    startMessage=startMessage.sprintf("%.2d:%.2d:%.2d::%.3d : ", curTime.tm_hour, curTime.tm_min,
        curTime.tm_sec, curTime.tm_msec);
    startMessage = startMessage + iPstr + " => ";

    for(int byteCounter=0; byteCounter<pBufferRecvLength; byteCounter++)
    {
        int temp_Char = (BYTE)(BufferRecvtemp[byteCounter]);
        tempMessage=tempMessage.sprintf("%.2x", temp_Char);
        startMessage = startMessage + tempMessage;
        if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
        {
            startMessage = startMessage + " ";
        }
    }
    startMessage = startMessage + " => LOCAL" + "\n";

    ::write(RecvFile,startMessage.toAscii(),strlen(startMessage.toAscii()));
    OctSwitch(1, startMessage,  &tempMessage);
    ::write(RecvFileOct,tempMessage.toAscii(),strlen(tempMessage.toAscii()));

    //输出文件结束
    return true;
}

/************************************************************************/
/* 读取配置文件
必须读取到的:
    网卡的IP，收发端口
    网卡的IP，收发端口；
    监控机的IP、路由；
    包头固定信息；
    各个数据区长度
(发射点信息依据坐标系是否需要转换而定)
                             */
/************************************************************************/
bool CNetCommuCT::ReadIniFile()
{
    char tempPathString_a[256];
    getcwd(tempPathString_a,256);
    QString tempPathString;
    tempPathString = tempPathString_a;
    tempPathString = tempPathString+ "/settest.ini";

    CBaseFile iniFile;
    QString sectionName;
    QString secContent;
    int secValue = 0;
    BYTE ip1, ip2, ip3, ip4;
    QString tempName;
    QString tempDID;
    QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
    DWORD tempValue;
    int tempCTCounter=0;

//IP设置
    sectionName = "网络配置";
    if(WayNO==0)//对本对象与哪一个网卡对应
    {
        ip1 = iniFile.GetIniInt(sectionName, "本地第一路由IP1", tempPathString);
        ip2 = iniFile.GetIniInt(sectionName, "本地第一路由IP2", tempPathString);
        ip3 = iniFile.GetIniInt(sectionName, "本地第一路由IP3", tempPathString);
        ip4 = iniFile.GetIniInt(sectionName, "本地第一路由IP4", tempPathString);
        LocalSet.WayChose = 0;
    }
    else
    {
        ip1 = iniFile.GetIniInt(sectionName, "本地第二路由IP1", tempPathString);
        ip2 = iniFile.GetIniInt(sectionName, "本地第二路由IP2", tempPathString);
        ip3 = iniFile.GetIniInt(sectionName, "本地第二路由IP3", tempPathString);
        ip4 = iniFile.GetIniInt(sectionName, "本地第二路由IP4", tempPathString);
        LocalSet.WayChose = 1;
    }
    LocalSet.IPAdd.sin_addr.s_addr= htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);
    LocalSet.PortReceive = iniFile.GetIniInt(sectionName, "监控机接收端口", tempPathString);	//24584
    LocalSet.PortSend = iniFile.GetIniInt(sectionName, "监控机发送端口", tempPathString);		//24576


//单播
    sectionName = "单播网络配置";
    int tempCTP2PNum = iniFile.GetIniInt(sectionName, "远端数目", tempPathString);//远端数目
    int tempThisWayNum = 0;
    for(tempCTCounter=0; tempCTCounter<tempCTP2PNum; tempCTCounter++)//第一次循环统计本路由的数目
    {
        valueItem9=valueItem9.sprintf("远端%d_路由",		tempCTCounter+1);
        secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        if(secValue == LocalSet.WayChose)//本路由的地址便保存的数组中
        {
            tempThisWayNum++;
        }
        else
        {
            continue;
        }
    }
    CTP2PNum = tempThisWayNum;
    CTP2PSet.resize(tempThisWayNum);
    int t_1=0;
    for(tempCTCounter=0; tempCTCounter<tempCTP2PNum; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1=valueItem1.sprintf("远端%d_IP1",			tempCTCounter+1);
        valueItem2=valueItem2.sprintf("远端%d_IP2",			tempCTCounter+1);
        valueItem3=valueItem3.sprintf("远端%d_IP3",			tempCTCounter+1);
        valueItem4=valueItem4.sprintf("远端%d_IP4",			tempCTCounter+1);
        valueItem7=valueItem7.sprintf("远端%d_DID",			tempCTCounter+1);
        valueItem8=valueItem8.sprintf("远端%d_地址名称",	tempCTCounter+1);
        valueItem9=valueItem9.sprintf("远端%d_路由",		tempCTCounter+1);
        secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        if(secValue == LocalSet.WayChose)//本路由的地址便保存数组中
        {
            ip1 = iniFile.GetIniInt(sectionName, valueItem1, tempPathString);
            ip2 = iniFile.GetIniInt(sectionName, valueItem2, tempPathString);
            ip3 = iniFile.GetIniInt(sectionName, valueItem3, tempPathString);
            ip4 = iniFile.GetIniInt(sectionName, valueItem4, tempPathString);
            CTP2PSet[t_1].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
            CTP2PSet[t_1].PortReceive = LocalSet.PortReceive;
            CTP2PSet[t_1].PortSend = LocalSet.PortSend;
            tempDID = iniFile.GetIniStr(sectionName, valueItem7, tempPathString);
            tempValue = 0;
            tempValue = CharToHex(tempDID);
            memcpy(CTP2PSet[t_1].DID, &tempValue, 4);
            tempName = iniFile.GetIniStr(sectionName, valueItem8, tempPathString);
            memcpy(CTP2PSet[t_1].Name, (LPCSTR)(tempName.toAscii()), 40);
            CTP2PSet[t_1].WayChose = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
            t_1++;
        }
        else
        {
            continue;
        }
    }//此时，将所有的单播网络远端都读入了


//组播
    sectionName = "组播网络配置";
    //接收远端数目
    int tempCTMulNum = iniFile.GetIniInt(sectionName, "接收远端数目", tempPathString);//远端数目
    tempThisWayNum = 0;
    for(tempCTCounter=0; tempCTCounter<tempCTMulNum; tempCTCounter++)//第一次循环统计本路由的数目
    {
        valueItem9=valueItem9.sprintf("接收远端%d_路由",		tempCTCounter+1);
        secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        if(secValue == LocalSet.WayChose)//本路由的地址便保存的数组中
        {
            tempThisWayNum++;
        }
        else
        {
            continue;
        }
    }
    CTMulNumRe = tempThisWayNum;
    CTMulSetRe.resize(CTMulNumRe);
    int t_2=0;
    for(tempCTCounter=0; tempCTCounter<tempCTMulNum; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1=valueItem1.sprintf("接收远端%d_IP1",			tempCTCounter+1);
        valueItem2=valueItem2.sprintf("接收远端%d_IP2",			tempCTCounter+1);
        valueItem3=valueItem3.sprintf("接收远端%d_IP3",			tempCTCounter+1);
        valueItem4=valueItem4.sprintf("接收远端%d_IP4",			tempCTCounter+1);
        valueItem7=valueItem7.sprintf("接收远端%d_DID",			tempCTCounter+1);
        valueItem8=valueItem8.sprintf("接收远端%d_地址名称",	tempCTCounter+1);
        valueItem9=valueItem9.sprintf("接收远端%d_路由",		tempCTCounter+1);
        secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        if(secValue == LocalSet.WayChose)//本路由的地址便保存数组中
        {
            ip1 = iniFile.GetIniInt(sectionName, valueItem1, tempPathString);
            ip2 = iniFile.GetIniInt(sectionName, valueItem2, tempPathString);
            ip3 = iniFile.GetIniInt(sectionName, valueItem3, tempPathString);
            ip4 = iniFile.GetIniInt(sectionName, valueItem4, tempPathString);
            CTMulSetRe[t_2].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
            CTMulSetRe[t_2].PortReceive = LocalSet.PortReceive;
            CTMulSetRe[t_2].PortSend	= LocalSet.PortSend;;
            tempDID = iniFile.GetIniStr(sectionName, valueItem7, tempPathString);
            tempValue = 0;
            tempValue = CharToHex(tempDID);
            memcpy(CTMulSetRe[t_2].DID, &tempValue, 4);
            tempName = iniFile.GetIniStr(sectionName, valueItem8, tempPathString);
            memcpy(CTMulSetRe[t_2].Name, (LPCSTR)(tempName.toAscii()), 40);
            CTMulSetRe[t_2].WayChose = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
            t_2++;
        }
        else
        {
            continue;
        }
    }

    //发送远端数目
    tempCTMulNum = iniFile.GetIniInt(sectionName, "发送远端数目", tempPathString);//远端数目
    tempThisWayNum = 0;
    for(tempCTCounter=0; tempCTCounter<tempCTMulNum; tempCTCounter++)//第一次循环统计本路由的数目
    {
        valueItem9=valueItem9.sprintf("接收远端%d_路由",		tempCTCounter+1);
        secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        if(secValue == LocalSet.WayChose)//本路由的地址便保存的数组中
        {
            tempThisWayNum++;
        }
        else
        {
            continue;
        }
    }
    CTMulNumSe = tempThisWayNum;
    CTMulSetSe.resize(CTMulNumSe);
    t_2=0;
    for(tempCTCounter=0; tempCTCounter<tempCTMulNum; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1=valueItem1.sprintf("接收远端%d_IP1",			tempCTCounter+1);
        valueItem2=valueItem2.sprintf("接收远端%d_IP2",			tempCTCounter+1);
        valueItem3=valueItem3.sprintf("接收远端%d_IP3",			tempCTCounter+1);
        valueItem4=valueItem4.sprintf("接收远端%d_IP4",			tempCTCounter+1);
        valueItem7=valueItem7.sprintf("接收远端%d_DID",			tempCTCounter+1);
        valueItem8=valueItem8.sprintf("接收远端%d_地址名称",	tempCTCounter+1);
        valueItem9=valueItem9.sprintf("接收远端%d_路由",		tempCTCounter+1);
        secValue = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
        if(secValue == LocalSet.WayChose)//本路由的地址便保存数组中
        {
            ip1 = iniFile.GetIniInt(sectionName, valueItem1, tempPathString);
            ip2 = iniFile.GetIniInt(sectionName, valueItem2, tempPathString);
            ip3 = iniFile.GetIniInt(sectionName, valueItem3, tempPathString);
            ip4 = iniFile.GetIniInt(sectionName, valueItem4, tempPathString);
            CTMulSetSe[t_2].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
            CTMulSetSe[t_2].PortReceive = LocalSet.PortReceive;
            CTMulSetSe[t_2].PortSend	= LocalSet.PortSend;;
            tempDID = iniFile.GetIniStr(sectionName, valueItem7, tempPathString);
            tempValue = 0;
            tempValue = CharToHex(tempDID);
            memcpy(CTMulSetSe[t_2].DID, &tempValue, 4);
            tempName = iniFile.GetIniStr(sectionName, valueItem8, tempPathString);
            memcpy(CTMulSetSe[t_2].Name, (LPCSTR)(tempName.toAscii()), 40);
            CTMulSetSe[t_2].WayChose = iniFile.GetIniInt(sectionName, valueItem9, tempPathString);
            t_2++;
        }
        else
        {
            continue;
        }
    }//此时，将所有的组播网络远端都读入了

    //组播源数目
    CTSrcNum = iniFile.GetIniInt(sectionName, "组播源数目", tempPathString);//远端数目
    CTSrcSet.resize(CTSrcNum);
    for(tempCTCounter=0; tempCTCounter<CTSrcNum; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1=valueItem1.sprintf("接收远端%d_IP1",			tempCTCounter+1);
        valueItem2=valueItem2.sprintf("接收远端%d_IP2",			tempCTCounter+1);
        valueItem3=valueItem3.sprintf("接收远端%d_IP3",			tempCTCounter+1);
        valueItem4=valueItem4.sprintf("接收远端%d_IP4",			tempCTCounter+1);
        ip1 = iniFile.GetIniInt(sectionName, valueItem1, tempPathString);
        ip2 = iniFile.GetIniInt(sectionName, valueItem2, tempPathString);
        ip3 = iniFile.GetIniInt(sectionName, valueItem3, tempPathString);
        ip4 = iniFile.GetIniInt(sectionName, valueItem4, tempPathString);
        CTSrcSet[tempCTCounter] = ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4;//使用PortReceive来保存port，不用IPAdd.sin_port
    }


//协议设置
    sectionName = "协议设置";
    INI_DATALENGTH_MEASURE = iniFile.GetIniInt	(sectionName, "实算数据区长度", tempPathString);
    INI_DATALENGTH_THEORY = iniFile.GetIniInt	(sectionName, "引入数据区长度", tempPathString);
    INI_DATALENGTH_EXAM = iniFile.GetIniInt		(sectionName, "时延测试数据区长度", tempPathString);
    INI_DATALENGTH_T0 = iniFile.GetIniInt		(sectionName, "T0数据区长度", tempPathString);
    INI_REVERSE_DATALENGTH = iniFile.GetIniInt	(sectionName, "填充区长度", tempPathString); //Jerry 20110629++
    INI_REVERSE_DATACONTENT = iniFile.GetIniStr	(sectionName, "填充区内容", tempPathString);//Jerry 20110629++
    INI_DATALENGTH_ZK = iniFile.GetIniInt	(sectionName, "主控数据长度", tempPathString);


//HEADER固定值
    HEADERStruct tempHEADER;
    memset(&tempHEADER, 0, sizeof(HEADERStruct));

    sectionName = "包头数据";
    secContent = iniFile.GetIniStr(sectionName, "VER", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(&(tempHEADER.v_Version), &tempValue, 1);

    secContent = iniFile.GetIniStr(sectionName, "FLAG", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(&(tempHEADER.v_Flag), &tempValue, 1);

    secContent = iniFile.GetIniStr(sectionName, "REVERSE", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(&(tempHEADER.v_Reserve), &tempValue, 4);

    //以上为共有的信息，下面只处理BID和MID
    secContent = iniFile.GetIniStr(sectionName, "MID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

//Time 发常时信息
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID_T", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID常时", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);

    tempHEADER.v_Length[0] = 04;
    tempHEADER.v_Length[1] = 0;

    memcpy(&TimerSendHEADER, &tempHEADER, sizeof(HEADERStruct));


//Time 收常时信息 注意SID和DID要颠倒
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID_T", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID常时", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);

    tempHEADER.v_Length[0] = 04;
    tempHEADER.v_Length[1] = 0;

    memcpy(&TimerRecvHEADER, &tempHEADER, sizeof(HEADERStruct));


//实算
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID实算数据", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);

    tempHEADER.v_Length[0] = INI_DATALENGTH_MEASURE;
    tempHEADER.v_Length[1] = 0;

    memcpy(&MeasureHEADER, &tempHEADER, sizeof(HEADERStruct));


//时延测试	发
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "BID时延测试", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

    tempHEADER.v_Length[0] = INI_DATALENGTH_EXAM;
    tempHEADER.v_Length[1] = 0;

    memcpy(&ExamSendHEADER, &tempHEADER, sizeof(HEADERStruct));


//时延测试	收
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "BID时延测试", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

    tempHEADER.v_Length[0] = INI_DATALENGTH_EXAM;
    tempHEADER.v_Length[1] = 0;

    memcpy(&ExamRecvHEADER, &tempHEADER, sizeof(HEADERStruct));


//T0
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "BID绝对时T0", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

    tempHEADER.v_Length[0] = INI_DATALENGTH_T0;
    tempHEADER.v_Length[1] = 0;

    memcpy(&T0HEADER, &tempHEADER, sizeof(HEADERStruct));


//外部说明
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    for(int tem_I=0; tem_I<30; tem_I++)
    {
        QString temp_DD;
        temp_DD=temp_DD.sprintf("BID引入%d", tem_I+1);
        secContent = iniFile.GetIniStr(sectionName, temp_DD, tempPathString);
        tempValue =CharToHex(secContent);//不得超过4byte
        memcpy(tempHEADER.v_SP4, &tempValue, 4);
        tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
        tempHEADER.v_Length[1] = 0;
        memcpy(WYDHEADER+tem_I, &tempHEADER, sizeof(HEADERStruct));
    }


    sectionName = "程序配置";
//发射点的大地直角坐标系坐标
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标B", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosB = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标L", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosL = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标H", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosH = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射角", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectAngle = atof(secContent.toAscii());
//	secContent	= iniFile.GetIniStr(sectionName, "发射点坐标X", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
//	EjectPosX = atof(secContent);
//	secContent	= iniFile.GetIniStr(sectionName, "发射点坐标Y", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
//	EjectPosY = atof(secContent);
//	secContent	= iniFile.GetIniStr(sectionName, "发射点坐标Z", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
//	EjectPosZ = atof(secContent);
//发射点的大地直角坐标系坐标

    for(int tem_I=0; tem_I<30; tem_I++)
    {
        memcpy(BIDWYD+tem_I, WYDHEADER[tem_I].v_SP4, 4);			//复制标准
    }

    memcpy(&BIDT0, T0HEADER.v_SP4, 4);			//复制标准
    memcpy(&BIDExam, ExamSendHEADER.v_SP4, 4);	//复制标准
    memcpy(&BIDTimer, TimerSendHEADER.v_SP4, 4);	//复制标准
    memcpy(&BIDMeasure, MeasureHEADER.v_SP4, 4);	//复制标准

    sectionName = "程序配置";
    //发射点的大地直角坐标系坐标
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标B", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosB = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标L", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosL = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标H", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosH = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射角", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectAngle = atof(secContent.toAscii());
    //发射点的大地直角坐标系坐标

    for(int tem_I=0; tem_I<30; tem_I++)
    {
        memcpy(BIDWYD+tem_I, WYDHEADER[tem_I].v_SP4, 4);			//复制标准
    }

    memcpy(&BIDT0, T0HEADER.v_SP4, 4);			//复制标准
    memcpy(&BIDExam, ExamSendHEADER.v_SP4, 4);	//复制标准
    memcpy(&BIDTimer, TimerSendHEADER.v_SP4, 4);	//复制标准
    memcpy(&BIDMeasure, MeasureHEADER.v_SP4, 4);	//复制标准

    unsigned short diffDay;
    diffDay = GetDate();
    memcpy(MeasureHEADER.v_Date, &diffDay, 2);
    memcpy(TimerSendHEADER.v_Date, &diffDay, 2);
    memcpy(TimerRecvHEADER.v_Date, &diffDay, 2);
    memcpy(ExamSendHEADER.v_Date, &diffDay, 2);
    memcpy(ExamRecvHEADER.v_Date, &diffDay, 2);
    memcpy(T0HEADER.v_Date, &diffDay, 2);
    for(int tem_I=0; tem_I<30; tem_I++)
    {
        memcpy(WYDHEADER[tem_I].v_Date, &diffDay, 2);				//在程序开启时得到日期
    }

    return true;
}

/************************************************************************/
/* 设置系统时间
参数 MSend 为毫秒                       */
/************************************************************************/
//bool CNetCommuCT::SetSystemT( DWORD MSend )
//{
//	SYSTEMTIME pRecvTime;
//	GetSystemTime(&pRecvTime);
//	pRecvTime.wHour = MSend/1000/60/60;
//	pRecvTime.wMinute = (MSend/1000/60)%60;
//	pRecvTime.wSecond =	(MSend/1000)%60;
//	pRecvTime.wMilliseconds = (MSend%1000)/10;
//	if(!SetSystemTime(&pRecvTime))
//	{
//		TRACE("Set Time Error");
//	}
//	return true;
//}

/************************************************************************/
/*
主要的！！！！！！！！！
数据转换（编解码）；该函数需要继承时重构，以满足不同设备
参数：
1.源数据
2.源数据的最长长度（实际长度不需传入，函数内可根据协议自行截取）
3.结果数据
4.结果数据的最长长度（实际长度不需传入，函数内可根据协议自行截取）
5.type:用于当源数据无法在本函数内辨识类型时，由此从外面指定数据类型。
        当type=-1,则用户自输入的HEADER数据中提取BID作判断（这只针对
        实算数据和时延测试有效，对其他数据类型，则必须强制指定）
        暂时包括1实算数据、2常时（此时不需要pSource）、3主动与4被动时延、
        5调试数据

返回值:
转换后pDest的有效长度
*/
/************************************************************************/
int CNetCommuCT::TransZK2CT(BYTE* pSource, int pSourceLength, BYTE* pDest, int pDestLength, int type)//转换函数
{
    int ret = 0;
    if(type==-1)//表示类型识别在TransZK2CT进行，不指定（此情况）.则
    {
    }
    if(type == 1)//实算数据
    {
        memcpy(pDest+sizeof(HEADERStruct), pSource+sizeof(HEADERStruct), 100);

        if(MeasurePackIndex>=(pow((float)2, 32)-1))
            MeasurePackIndex = 0;
        else
            MeasurePackIndex++;
        memcpy(MeasureHEADER.v_No, &MeasurePackIndex, 4);

        DWORD milSecondCount = 0;
        milSecondCount = GetTime(TimeSource);
        memcpy(MeasureHEADER.v_Time, &milSecondCount, 4);

        if(milSecondCount<10000)//当在每天最初的10秒时，需要重新判断日期
        {
            unsigned short diffDay = GetDate();
            memcpy(MeasureHEADER.v_Date, &diffDay, 2);
        }
        memcpy(pDest, &MeasureHEADER, sizeof(HEADERStruct));

        if(pDest[45] == 1)
        {
            ret = sizeof(HEADERStruct) + INI_DATALENGTH_MEASURE;
        }
        else if(pDest[45] == 2)
        {
            ret = sizeof(HEADERStruct) + INI_DATALENGTH_MEASURE + 18;
        }

        else if(pDest[45] == 3)
        {
            ret = sizeof(HEADERStruct) + INI_DATALENGTH_MEASURE + 36;
        }
        else
        {
            ret = sizeof(HEADERStruct) + INI_DATALENGTH_MEASURE;
        }
    }

    if(type == 2)//常时 , 不需要pSource
    {
        if(TimerPackIndex>=(pow((float)2, 32) -1))
            TimerPackIndex=0;
        else
            TimerPackIndex++;
        memcpy(TimerSendHEADER.v_No, &TimerPackIndex, 4);

        DWORD milSecondCount =0;

        milSecondCount=GetTime(TimeSource);
        memcpy(TimerSendHEADER.v_Time,&milSecondCount,4);

        if(milSecondCount<10000)
        {
            unsigned short diffDay=GetDate();
            memcpy(TimerSendHEADER.v_Date,&diffDay,2);
        }

        memcpy(pDest,&TimerSendHEADER,sizeof(HEADERStruct));
        memcpy(pDest+sizeof(HEADERStruct),TimerSendHEADER.v_Time,4);

        ret=sizeof(HEADERStruct)+4;
    }

    if(type == 3)//主动时延测试 //不用pSource
    {
        memset(pDest, 0, pDestLength);
        if(ExamPackIndex>=(pow((float)2, 32)-1))
            ExamPackIndex = 0;
        else
            ExamPackIndex++;
        memcpy(ExamSendHEADER.v_No, &ExamPackIndex, 4);

        DWORD milSecondCount = 0;
        milSecondCount = GetTime(TimeSource);
        memcpy(ExamSendHEADER.v_Time, &milSecondCount, 4);

        if(milSecondCount<10000)//当在每天最初的10秒时，需要重新判断日期
        {
            unsigned short diffDay = GetDate();
            memcpy(ExamSendHEADER.v_Date, &diffDay, 2);
        }

        memcpy(pDest, &ExamSendHEADER, sizeof(HEADERStruct));

        memcpy(pDest+sizeof(HEADERStruct), ExamSendHEADER.v_Time, 4);//复制时间

        milSecondCount = 0xffffffff;
        memcpy(pDest+sizeof(HEADERStruct)+4, &milSecondCount, 4);//初始值为全1
        memcpy(pDest+sizeof(HEADERStruct)+8, &milSecondCount, 4);//初始值为全1
        memcpy(pDest+sizeof(HEADERStruct)+12, &milSecondCount, 4);//初始值为全1
        ret = sizeof(HEADERStruct) + INI_DATALENGTH_EXAM;
    }

    if(type == 4)//响应时延测试
    {
        memset(pDest, 0, pDestLength);
        if(ExamPackIndex>=(pow((float)2, 32)-1))
            ExamPackIndex = 0;
        else
            ExamPackIndex++;
        memcpy(ExamSendHEADER.v_No, &ExamPackIndex, 4);

        DWORD milSecondCount = 0;
        milSecondCount = GetTime(TimeSource);
        memcpy(ExamSendHEADER.v_Time, &milSecondCount, 4);

        if(milSecondCount<10000)//当在每天最初的10秒时，需要重新判断日期
        {
            unsigned short diffDay = GetDate();
            memcpy(ExamSendHEADER.v_Date, &diffDay, 2);
        }

        memcpy(pDest, &ExamSendHEADER, sizeof(HEADERStruct));

        memcpy(pDest+sizeof(HEADERStruct), pSource+sizeof(HEADERStruct), 4);	//复制发起端的时间
        memcpy(pDest+sizeof(HEADERStruct)+4, ExamSendHEADER.v_Time, 4);			//复制当前的时间
        memcpy(pDest+sizeof(HEADERStruct)+8, ExamSendHEADER.v_Time, 4);			//复制当前的时间

        milSecondCount = 0xffffffff;
        memcpy(pDest+sizeof(HEADERStruct)+12, &milSecondCount, 4);//初始值为全1
        ret = sizeof(HEADERStruct) + INI_DATALENGTH_EXAM;
    }

    if(type == 5)//发送调试数据
    {
        memset(pDest, 0, pDestLength);
        memcpy(pDest+sizeof(HEADERStruct), pSource+sizeof(HEADERStruct), INI_DATALENGTH_MEASURE);
        memcpy(&DebugHEADER, pSource, sizeof(HEADERStruct));

        if(DebugPackIndex>=(pow((float)2, 32)-1))
            DebugPackIndex = 0;
        else
            DebugPackIndex++;
        memcpy(DebugHEADER.v_No, &DebugPackIndex, 4);

        DWORD milSecondCount = 0;
        milSecondCount = GetTime(TimeSource);
        memcpy(DebugHEADER.v_Time, &milSecondCount, 4);

        if(milSecondCount<10000)//当在每天最初的10秒时，需要重新判断日期
        {
            unsigned short diffDay = GetDate();
            memcpy(DebugHEADER.v_Date, &diffDay, 2);
        }

        memcpy(pDest, &DebugHEADER, sizeof(HEADERStruct));

        memcpy(pDest+sizeof(HEADERStruct), pSource+sizeof(HEADERStruct), INI_DATALENGTH_MEASURE);	//复制发起端的时间

        ret = sizeof(HEADERStruct) + INI_DATALENGTH_MEASURE;
    }

    return ret;
}

/************************************************************************/
/* 保存到文件中                              */
/************************************************************************/
bool CNetCommuCT::SaveFile( )
{
    GetSystemTime(&EndTime);

    QString saveFileName_Send;
    QString startMessage;
    int pout_SendData;
    saveFileName_Send=saveFileName_Send.sprintf("/发送中心%d年%d月%d日%d时%d分%d秒.txt", EndTime.tm_year, EndTime.tm_mon,
        EndTime.tm_mday, EndTime.tm_hour, EndTime.tm_min,EndTime.tm_sec);
    startMessage=startMessage.sprintf("%d年%d月%d日%d时%d分%d秒 开始记录: \n", EndTime.tm_year, EndTime.tm_mon,
                                      EndTime.tm_mday, EndTime.tm_hour, EndTime.tm_min,EndTime.tm_sec);
    saveFileName_Send = BufferSaveFilePath_Send + saveFileName_Send;

    pout_SendData=::open(saveFileName_Send.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    ::write(pout_SendData,startMessage.toAscii(),strlen(startMessage.toAscii()));
    ::close(pout_SendData);

    QString saveFileName_Recv;
    int pout_RecvData;
    saveFileName_Recv=saveFileName_Recv.sprintf("/接收中心%d年%d月%d日%d时%d分%d秒.txt", EndTime.tm_year, EndTime.tm_mon,
                                                EndTime.tm_mday, EndTime.tm_hour, EndTime.tm_min,EndTime.tm_sec);
    startMessage=startMessage.sprintf("%d年%d月%d日%d时%d分%d秒 开始记录: \n", StartTime.tm_year, StartTime.tm_mon,
                        StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    saveFileName_Recv = BufferSaveFilePath_Recv + saveFileName_Recv;

    pout_RecvData=::open(saveFileName_Recv.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    ::write(pout_RecvData,startMessage.toAscii(),strlen(startMessage.toAscii()));
    ::close(pout_RecvData);

    usleep(100000);
    FormatOctFile( saveFileName_Send, saveFileName_Recv );

    return true;
}

/************************************************************************/
/* 将原始数据进行解码之后保存到文件中                              */
/************************************************************************/
/************************************************************************/
/*
生成10进制可视化文件
2个参数：
SaveFileName_Send：发送数据文件路径
SaveFileName_Recv：接收数据文件路径
*/
/************************************************************************/
bool CNetCommuCT::FormatOctFile( QString SaveFileName_Send, QString SaveFileName_Recv )
{
    QString TempOutput;
    QString OctFilePath;
    QString ReadContent;//上一行内容
    QString TempString;//填充内容
    DWORD OriI=0;//读取的行号
    DWORD DesI=0;//保存的行号
    int tempValue = 0;//LONG tempValue = 0;
    DWORD tempValue_D = 0;
    int type=0; //数据类别：1.T0; 2.外引导; 3.时延测试; 4.测量数据; 5.链监
    int LengthThreshold = 110;
    QString SourceIPstr;
    QString Timestr;

//发送中心++ 要注意不同的地址在源文件中实际上只保存了一组（第一个中心）1.测量数据 2.时延测试
    DesI=0;
    FILE *InputFile=fopen(SaveFileName_Send.toAscii(),"r");;//输入的十进制文件
    if(InputFile==NULL )
    {
        TRACE("打开失败");
        return false;
    }
    OctFilePath = SaveFileName_Send.left(SaveFileName_Send.lastIndexOf('.')) + "解码.txt";
    FILE *fptmp=fopen(OctFilePath.toAscii(),"wb+");
    if(fptmp!=NULL) {   fclose(fptmp);   }
    FILE *OctFile=fopen(OctFilePath.toAscii(),"ab+");
    if(OctFile==NULL )
    {
        TRACE("打开失败");
        return false;
    }
    TempOutput.sprintf("发送中心数据\n序号    本地时间    时间    类别    方位角A(度)    俯仰角E(度)    伺服模式    目标数目    脱靶量X(秒)    脱靶量Y(秒)    时延发起    时延收到    时延返回    \n");
    fwrite(TempOutput.toAscii(),sizeof(char),strlen(TempOutput.toAscii()),OctFile);//写入标题
    for(OriI=0; OriI<(65535*60000); OriI++)
    {
        TempOutput = "";
        SourceIPstr = "";
        TempString = "";

        char tmpContent[MAX_COL_SIZE];
        memset(tmpContent,0,MAX_COL_SIZE);
        if(fgets(tmpContent,MAX_COL_SIZE,InputFile)==NULL)
            break;
        ReadContent=QString(tmpContent);
        if(ReadContent.length()<LengthThreshold)//判断是否为无效的标题行
            continue;

        Timestr = ReadContent.left(ReadContent.indexOf(" : "));//将本地时间保存
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf("LOCAL => ") - 9);
        ReadContent = ReadContent.left(ReadContent.indexOf(" => "));
        ReadContent.remove(' ');//连续数值
        tempValue_D =CharToUnsignedHexReverse(ReadContent.mid(11*2, 4*2));
        if(tempValue_D == BIDMeasure)
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type = 4;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            TempOutput = TempOutput + "测量数据" + "  ";											//type
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1)*2, 4*2));					//A 1@
            TempString.	sprintf("%.4f", ((double)tempValue)*360/pow((float)2,31));
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4)*2, 4*2));					//E 1@
            TempString.	sprintf("%.4f", ((double)tempValue)*360/pow((float)2,31));
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4)*2, 2));						//Status
            TempString.	sprintf("%.2d", tempValue);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4)*2, 1*2));				//NUM
            TempString. sprintf("%.1d", tempValue);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4+1)*2, 4*2));				//x 1S
            TempString. sprintf("%.1f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4+1+4)*2, 4*2));			//y 1S
            TempString. sprintf("%.1f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        else if(tempValue_D == BIDExam)
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type = 3;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(22*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";		//T
            TempOutput = TempOutput + "时延测试" + "  ";		//Type
            TempOutput = TempOutput + "*******" + "  ";			//A
            TempOutput = TempOutput + "*******" + "  ";			//E
            TempOutput = TempOutput + "*******" + "  ";			//Status
            TempOutput = TempOutput + "*******" + "  ";			//Num
            TempOutput = TempOutput + "*******" + "  ";			//x
            TempOutput = TempOutput + "*******" + "  ";			//y
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));			//Tf
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4)*2, 4*2));		//Ts
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4+4)*2, 4*2));		//Tz
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        else if(tempValue_D == BIDTimer)//链监
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type =5;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";											//T
            TempOutput = TempOutput + "链监信息" + "  \n";											//Type
        }

        fwrite(TempOutput.toAscii(),sizeof(char),strlen(TempOutput.toAscii()),OctFile);//文件写入
    }
    fclose(InputFile);
    fclose(OctFile);
//发送中心--


//接收中心++ 要注意不同的地址在源文件中多组，因此需要标示哪个中心 1.引导数据 2.时延测试 3.T0
    DesI=0;
    InputFile=fopen(SaveFileName_Recv.toAscii(),"r");;//输入的十进制文件
    if(InputFile==NULL )
    {
        TRACE("打开失败");
        return false;
    }
    OctFilePath = SaveFileName_Recv.left(SaveFileName_Recv.lastIndexOf('.')) + "解码.txt";
    fptmp=fopen(OctFilePath.toAscii(),"wb+");
    if(fptmp!=NULL) {   fclose(fptmp);   }
    OctFile=fopen(OctFilePath.toAscii(),"ab+");
    if(OctFile==NULL )
    {
        TRACE("打开失败");
        return false;
    }
    TempOutput.sprintf("接收中心数据\n序号    本地时间    时间    源地址IP    类别    大地坐标X(米)    大地坐标Y(米)    大地坐标Z(米)    速度X(米/秒)    速度Y(米/秒)    速度Z(米/秒)    起飞时刻    时延发起    时延收到    时延返回    \n");
    fwrite(TempOutput.toAscii(),sizeof(char),strlen(TempOutput.toAscii()),OctFile);//写入标题
    for(OriI=0; OriI<(65535*60000); OriI++)
    {
        TempOutput = "";
        SourceIPstr = "";
        TempString = "";

        char tmpContent[MAX_COL_SIZE];
        memset(tmpContent,0,MAX_COL_SIZE);
        if(fgets(tmpContent,MAX_COL_SIZE,InputFile)==NULL)
            break;
        ReadContent=QString(tmpContent);
        if(ReadContent.length()<LengthThreshold)//判断是否为无效的标题行
            continue;

        Timestr = ReadContent.left(ReadContent.indexOf(" : "));//将本地时间保存
        ReadContent = ReadContent.left(ReadContent.indexOf(" => LOCAL"));
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf(" : ") - 3);//暂保留IP地址
        SourceIPstr = ReadContent.left(ReadContent.indexOf(" => "));
//		SourceIP = inet_addr((LPCSTR)SourceIPstr);//得到地址
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf(" => ") - 4);
        ReadContent.remove(' ');//连续数值
        tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(11*2, 4*2));	//Bid

        if(tempValue_D == BIDT0)
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type = 1;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(22*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "起飞时刻" + "  ";											//type
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//起飞时刻
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        int temp_FL = false;
        for(int tem_I=0; tem_I<30; tem_I++)
        {
            if(tempValue_D == BIDWYD[tem_I])
            {
                temp_FL = true;
                break;
            }
        }
        if(temp_FL)		//为引导数据，仅对引导数据进行数据重复性校验
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type = 2;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "引导数据" + "  ";											//type
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4)*2, 4*2));						//大地坐标
            TempString. sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4)*2, 4*2));					//大地坐标
            TempString. sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4)*2, 4*2));					//大地坐标
            TempString. sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4+4)*2, 4*2));				//速度
            TempString. sprintf("%.2f", ((double)tempValue)/100);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4+4+4)*2, 4*2));				//速度
            TempString. sprintf("%.2f", ((double)tempValue)/100);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4+4+4+4)*2, 4*2));			//速度
            TempString. sprintf("%.2f", ((double)tempValue)/100);
            TempOutput = TempOutput + TempString + "  \n";
        }
        if(tempValue_D == BIDExam)
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type = 3;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(22*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";											//T
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "时延测试" + "  ";											//Type
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//T0
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//Tf
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4)*2, 4*2));					//Ts
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4+4)*2, 4*2));				//Tz
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        else if(tempValue_D == BIDTimer)//链监
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type =5;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";											//T
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "链监信息" + "  \n";											//Type
        }
        fwrite(TempOutput.toAscii(),sizeof(char),strlen(TempOutput.toAscii()),OctFile);//文件写入
    }
    fclose(InputFile);
    fclose(OctFile);
//接收中心--

    return true;
}

/************************************************************************/
/*
生成10进制可视化字符串
3个参数：
    type:0代表发送字符串；1代表接收字符串
    输入字符串
    输出字符串
*/
/************************************************************************/
void CNetCommuCT::OctSwitch( int Type, QString InputString,  QString* OutputString )
{
    QString ReadContent;
    QString TempString;//填充内容
    QString TempOutput;
    QString Timestr;
    BOOL re;
    DWORD LineIndex=0;
    int tempValue = 0;//LONG tempValue = 0;
    int tempValue_D = 0;//DWORD tempValue_D = 0;
    int type=0; //数据类别：1.T0; 2.外引导; 3.时延测试; 4.测量数据; 5.链监
    int LengthThreshold = 110;
    QString SourceIPstr;

    ReadContent = InputString;
    TempOutput = "";
    SourceIPstr = "";
    TempString = "";
    *OutputString = "";

    if(ReadContent.length()<LengthThreshold)//判断是否为无效的标题行
    {
        *OutputString = "";
        return;
    }

    if(Type==0)
    {
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf("LOCAL => ") - 9);
        ReadContent = ReadContent.left(ReadContent.indexOf(" => "));
        ReadContent.remove(' ');//连续数值
        tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(11*2, 4*2));
        if(tempValue_D == BIDMeasure)
        {
            DesI++;
            TempOutput.sprintf("%.5d  ", DesI);														//序号
            type = 4;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            TempOutput = TempOutput + "测量数据" + "  ";											//type
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1)*2, 4*2));					//A 1@
            TempString.sprintf("%.4f", ((double)tempValue)*360/pow((float)2,31));
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4)*2, 4*2));					//E 1@
            TempString.sprintf("%.4f", ((double)tempValue)*360/pow((float)2,31));
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4)*2, 2));						//Status
            TempString.sprintf("%.2d", tempValue);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4)*2, 1*2));				//NUM
            TempString.sprintf("%.1d", tempValue);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4+1)*2, 4*2));				//x 1S
            TempString.sprintf("%.1f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4+1+4)*2, 4*2));			//y 1S
            TempString.sprintf("%.1f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        else if(tempValue_D == BIDExam)
        {
            DesI++;
            TempOutput.sprintf("%.5d  ", DesI);														//序号
            type = 3;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            //tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(22*2, 4*2));						//T (必须乘以2)
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(26*2, 4*2));						//T (必须乘以2)
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";		//T
            TempOutput = TempOutput + "时延测试" + "  ";		//Type
            TempOutput = TempOutput + "*******" + "  ";			//A
            TempOutput = TempOutput + "*******" + "  ";			//E
            TempOutput = TempOutput + "*******" + "  ";			//Status
            TempOutput = TempOutput + "*******" + "  ";			//Num
            TempOutput = TempOutput + "*******" + "  ";			//x
            TempOutput = TempOutput + "*******" + "  ";			//y
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));			//Tf
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4)*2, 4*2));		//Ts
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4+4)*2, 4*2));		//Tz
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        else if(tempValue_D == BIDTimer)//链监
        {
            DesI++;
            TempOutput.sprintf("%.5d  ", DesI);														//序号
            type =5;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";											//T
            TempOutput = TempOutput + "链监信息" + "  \n";											//Type
        }
        *OutputString = TempOutput;
    }
    else
    {
        Timestr = ReadContent.left(ReadContent.indexOf(" : "));//将本地时间保存
        ReadContent = ReadContent.left(ReadContent.indexOf(" => LOCAL"));
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf(" : ") - 3);//暂保留IP地址
        SourceIPstr = ReadContent.left(ReadContent.indexOf(" => "));
        //		SourceIP = inet_addr((LPCSTR)SourceIPstr);//得到地址
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf(" => ") - 4);
        ReadContent.remove(' ');//连续数值
        tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(11*2, 4*2));	//Bid

        if(tempValue_D == BIDT0)
        {
            DesI++;
            TempOutput.sprintf("%.5d  ", DesI);														//序号
            type = 1;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            //tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(22*2, 4*2));						//T (必须乘以2)
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(26*2, 4*2));						//T (必须乘以2)
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "起飞时刻" + "  ";											//type
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//起飞时刻
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        int temp_FL = false;
        for(int tem_I=0; tem_I<30; tem_I++)
        {
            if(tempValue_D == BIDWYD[tem_I])
            {
                temp_FL = true;
                break;
            }
        }
        if(temp_FL)		//为引导数据，仅对引导数据进行数据重复性校验
        {
            DesI++;
            TempOutput.sprintf("%.5d  ", DesI);														//序号
            type = 2;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "引导数据" + "  ";											//type
            tempValue =(int) CharToSignedHexReverse(ReadContent.mid((32+4)*2, 4*2));						//大地坐标
            TempString.sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue =(int) CharToSignedHexReverse(ReadContent.mid((32+4+4)*2, 4*2));					//大地坐标
            TempString. sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue =(int) CharToSignedHexReverse(ReadContent.mid((32+4+4+4)*2, 4*2));					//大地坐标
            TempString. sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4+4)*2, 4*2));				//速度
            TempString. sprintf("%.2f", ((double)tempValue)/100);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4+4+4)*2, 4*2));				//速度
            TempString. sprintf("%.2f", ((double)tempValue)/100);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4+4+4+4)*2, 4*2));			//速度
            TempString. sprintf("%.2f", ((double)tempValue)/100);
            TempOutput = TempOutput + TempString + "  \n";
        }
        else if(tempValue_D == BIDExam)
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type = 3;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            //tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(22*2, 4*2));						//T (必须乘以2)
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(26*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";											//T
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "时延测试" + "  ";											//Type
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//速度
            TempOutput = TempOutput + "*******" + "  ";												//T0
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//Tf
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4)*2, 4*2));					//Ts
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid((32+4+4)*2, 4*2));				//Tz
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        else if(tempValue_D == BIDTimer)//链监
        {
            DesI++;
            TempOutput.	sprintf("%.5d  ", DesI);														//序号
            type =5;
            TempOutput = TempOutput + Timestr + "  ";												//本地时间
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString. sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
            TempOutput = TempOutput + TempString + "  ";											//T
            TempOutput = TempOutput + SourceIPstr + "  ";											//IP
            TempOutput = TempOutput + "链监信息" + "  \n";											//Type
        }
        *OutputString = TempOutput;
    }
    return;
}
