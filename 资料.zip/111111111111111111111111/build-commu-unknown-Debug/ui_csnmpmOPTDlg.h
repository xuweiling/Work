/********************************************************************************
** Form generated from reading UI file 'csnmpmOPTDlg.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CSNMPMOPTDLG_H
#define UI_CSNMPMOPTDLG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_CSnmpmOPTDlg
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *reset;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *startagent;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *stopagent;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *pushButton_4;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *verticalSpacer_3;

    void setupUi(QDialog *CSnmpmOPTDlg)
    {
        if (CSnmpmOPTDlg->objectName().isEmpty())
            CSnmpmOPTDlg->setObjectName(QString::fromUtf8("CSnmpmOPTDlg"));
        CSnmpmOPTDlg->resize(764, 488);
        verticalLayout_2 = new QVBoxLayout(CSnmpmOPTDlg);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer = new QSpacerItem(20, 138, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(108, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        reset = new QPushButton(CSnmpmOPTDlg);
        reset->setObjectName(QString::fromUtf8("reset"));
        reset->setEnabled(false);

        horizontalLayout->addWidget(reset);

        horizontalSpacer_2 = new QSpacerItem(98, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        startagent = new QPushButton(CSnmpmOPTDlg);
        startagent->setObjectName(QString::fromUtf8("startagent"));

        horizontalLayout->addWidget(startagent);

        horizontalSpacer_3 = new QSpacerItem(128, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        stopagent = new QPushButton(CSnmpmOPTDlg);
        stopagent->setObjectName(QString::fromUtf8("stopagent"));
        stopagent->setEnabled(false);

        horizontalLayout->addWidget(stopagent);

        horizontalSpacer_4 = new QSpacerItem(108, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer_2 = new QSpacerItem(20, 138, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_5 = new QSpacerItem(298, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);

        pushButton_4 = new QPushButton(CSnmpmOPTDlg);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setEnabled(false);

        horizontalLayout_2->addWidget(pushButton_4);

        horizontalSpacer_6 = new QSpacerItem(358, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_6);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer_3 = new QSpacerItem(20, 138, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(CSnmpmOPTDlg);

        QMetaObject::connectSlotsByName(CSnmpmOPTDlg);
    } // setupUi

    void retranslateUi(QDialog *CSnmpmOPTDlg)
    {
        CSnmpmOPTDlg->setWindowTitle(QApplication::translate("CSnmpmOPTDlg", "Dialog", 0, QApplication::UnicodeUTF8));
        reset->setText(QApplication::translate("CSnmpmOPTDlg", "\345\220\257\345\212\250\350\277\220\347\256\241\346\233\264\346\226\260", 0, QApplication::UnicodeUTF8));
        startagent->setText(QApplication::translate("CSnmpmOPTDlg", "\345\220\257\345\212\250\346\234\215\345\212\241", 0, QApplication::UnicodeUTF8));
        stopagent->setText(QApplication::translate("CSnmpmOPTDlg", "\347\273\210\346\255\242\346\234\215\345\212\241", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("CSnmpmOPTDlg", "TRAP\346\265\213\350\257\225", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CSnmpmOPTDlg: public Ui_CSnmpmOPTDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CSNMPMOPTDLG_H
