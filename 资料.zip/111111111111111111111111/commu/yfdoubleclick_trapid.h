#ifndef YFDOUBLECLICK_TRAPID_H
#define YFDOUBLECLICK_TRAPID_H

#include <QDialog>
#define ADDBUTTON    1
#define MODIFYBUTTON  2
#define DELETEBUTTON  3

namespace Ui {
class YFDoubleClick_TrapID;
}

class YFDoubleClick_TrapID : public QDialog
{
    Q_OBJECT

public:
    explicit YFDoubleClick_TrapID(QWidget *parent = 0);
    ~YFDoubleClick_TrapID();

    QString text;
    int other;

private slots:
    void on_addButton_clicked();

    void on_ModifyButton_clicked();

    void on_deleteButton_clicked();

private:
    Ui::YFDoubleClick_TrapID *ui;
};

#endif // YFDOUBLECLICK_TRAPID_H
