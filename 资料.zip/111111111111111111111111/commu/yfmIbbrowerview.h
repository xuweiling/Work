#ifndef _MIBBROWERVIEW_H__
#define _MIBBROWERVIEW_H__

#include <string>
#include <QString>
using namespace std;
#include <vector>
 //treeview item;
struct MibNode
{
   string PSnytax;   //保存SNMP变量数据类型信息
   string PAccess;   //保存SNMP变量访问权限信息
   string PStatus;   //保存SNMP变量状态信息
   string PDescr;    //保存SNMP变量文字描述信息
   string PIndex;    //保存表辅助节点的索引信息
   string POid;      //保存节点OID信息
   string PSValue;
   int    PIValue;
   vector<string> *PInteger;   //保存数据类型为枚举型整数时的信息，其他类型时指针为0
};
//MibNode YFMibdata;

struct TreeNode
{
	string  Currentname;
	MibNode Mibdata;
	struct TreeNode *LChildren;
	struct TreeNode *RChildren;
};

struct QMibNode
{
   QString PSnytax;   //保存SNMP变量数据类型信息
   QString PAccess;   //保存SNMP变量访问权限信息
   QString PStatus;   //保存SNMP变量状态信息
   QString PDescr;    //保存SNMP变量文字描述信息
   QString PIndex;    //保存表辅助节点的索引信息
   QString POid;      //保存节点OID信息
   QString PSValue;
   int    PIValue;
   QVector<QString> *PInteger;   //保存数据类型为枚举型整数时的信息，其他类型时指针为0
   QString  Currentname;
   QString isTrap;
};
//MibNode YFMibdata;

struct QTreeNode
{
    QMibNode QMibdata;
    struct QTreeNode *LChildren;
    struct QTreeNode *RChildren;
};

//treeview data;
//CStringList TopOid;  //保存顶端节点
//CStdioFile MibFile;


//加载MIB
int LoadMid(void);
int YFQLoadMId(void);
void DeleteTree(TreeNode *hSubRoot);
void SearchNodeFromOID(TreeNode *hSubRoot,TreeNode *&SubRootconst, string &text);
void FindNode(TreeNode *hSubRoot,TreeNode *&SubRootconst, string &text);
#endif
