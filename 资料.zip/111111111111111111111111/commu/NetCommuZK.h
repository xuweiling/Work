﻿// NetCommuZK.h: interface for the CNetCommuZK class.
//
//////////////////////////////////////////////////////////////////////

/************************************************************************/
/*
注意:
    本类负责数据收发和编解码,什么时候发送数据由调用者调用Send即可，
数据的互斥由调用者保证（只要BufferSend_Passed保证不冲突即可）
接收的数据直接由BufferRecv_Passed采集即可（通过消息通知调用者来
收集数据）
一张网卡对应一个实例(本类只有一张网卡，故只有1个实例)

  使用:
  a.初始化    1.实例化；2.StartConnect; 3.设置PDlg、CurrentMode、TimeSource、DebugHEADER、
                        BufferSaveFilePath_Send、BufferSaveFilePath_Recv
                        至此初始化完毕
  b.当接收到WM_USER_RECEIVED_CT消息时，可从BufferRecv_Passed中取数据；
                从pBufferRecvLength中得到数据长度，从DataSource中得到数据源
                值得注意的是:BufferRecv_Passed数据是原始代码，即符合原分站的发送格式(实算数据)
  c.当需要发送数据时，只要设置了BufferSend_Passed的内容、pBufferSendLength数据长度，之后调用
                SendData(1)即可。如有时时修改的需要，还要设置CurrentMode、TimeSource和DebugHEADER。
                发送完毕后，自BufferSended_Passed可得到重新编码后的数据,
                自pBufferSendedLength得到该数据的长度
                值得注意的是:BufferSend_Passed数据是原始代码，即符合HEADER协议的外部说明、T0、
                如果需要发送主控台直接来的数据，这只能用SendData(1,2,3)这个重构的函数
  d.关闭：CloseConnect、SaveFile即可
                                                                      */
/************************************************************************/

#if !defined(AFX_NETCOMMUZK_H__3A59D6E7_67DF_4D2C_B962_6E4E417BC3EF__INCLUDED_)
#define AFX_NETCOMMUZK_H__3A59D6E7_67DF_4D2C_B962_6E4E417BC3EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "NetCommu.h"
#include "ZKSocket.h"
#include <QObject>

class CNetCommuZK : public QObject,public CNetCommu
{
    Q_OBJECT
public:
    explicit CNetCommuZK(QObject *parent = 0);
        virtual ~CNetCommuZK();

        bool StartConnect();							//网络启动，线程启动
        bool SendData(int type);								//发送数据
        bool SendData(BYTE* sendDataBuffer, int sendDataBufferLength, int type);//发送数据
        bool CloseConnect( );							//关闭连接
        bool Receive( );								//由窗口调用，通知处理

        int TransCT2ZK(BYTE* pSource, int pSourceLength, BYTE* pDest, int pDestLength, int type);//转换函数

        static  QString	BufferSaveFilePath_Send;			//将要保存的发送数据文件路径
        static QString BufferSaveFilePath_Recv;			//将要保存的接收数据文件路径
        static bool SaveFile();							//保存到文件中
        static bool FormatOctFile( QString SaveFileName_Send, QString SaveFileName_Recv );					//保存到文件中
    //	static BYTE BufferSave_Send[MACRO_FILE_SIZE];	//将要保存到文件中的发送数据
    //	static BYTE BufferSave_Recv[MACRO_FILE_SIZE];	//将要保存到文件中的接收数据
        static int BufferSave_SendLength;				//将要保存到文件中的发送数据长度
        static int BufferSave_RecvLength;				//将要保存到文件中的接收数据长度 使用static,这样所有的数据都保存在一个文件中
        static SYSTEMTIME	StartTime;						//起始时刻
        static SYSTEMTIME	EndTime;						//保存时刻

        double		EjectPosB;							//发射点的大地直角坐标系坐标 Jerry 20110707++
        double		EjectPosL;							//发射点的大地直角坐标系坐标 Jerry 20110707++
        double		EjectPosH;							//发射点的大地直角坐标系坐标 Jerry 20110707++
        double		EjectAngle;							//发射点的发射角 Jerry 20110907++

        LONG Prepost_X[5];
        LONG Prepost_Y[5];
        LONG Prepost_Z[5];//预推的样本与结果
        BYTE PrepostCount;//连续预推的数目
        BYTE PrepostDataLength;//预推样本的数目
        bool PrepostValid;//是否允许预推
        bool IsLeadExist;//是否正在接收外引导(即本周期内是否接受到外引导)
        float PrepostThreshold_X;
        float PrepostThreshold_Y;
        float PrepostThreshold_Z;//判断是否为跳点的阈值
        BYTE PrepostBuff[60];
        void PrepostSend();

protected:
    CZKSocket theSocket;							//通信端口
    SocketSetting LocalSet;							//Socket配置（本地）
    SocketSetting ZKSet;							//Socket配置（主控）
    bool		SocketEnable;						//本通信类是否使用，这决定于Socket是否成功绑定

    bool ReadIniFile( );							//读取配置内容：文件名为"\\配置.ini"(MACRO_INI_FILEPATH)
//继承时必须读取到的:网卡的IP，收发端口；主控机的IP；(发射点信息依据坐标系是否需要转换而定)
    bool SetSystemT( DWORD MSend );					//设置系统时间，参数为毫秒

    void SendMib(char* pSendData, int pSendDataLength, QString WindowName) ;

    bool FirstSetSystemTime;						//首次收到主控

    int			INI_DATALENGTH_ZK;					//分站主控发送的数据长度
    int			INI_DATALENGTH_MEASURE;				//实算数据中数据区有效长度 = 32, 22+10
    int			INI_DATALENGTH_THEORY;				//引入数据中数据区有效长度 = 28
    int			INI_DATALENGTH_EXAM;				//时延测试数据区长度
    int			INI_DATALENGTH_T0;					//T0数据区长度
    int			INI_REVERSE_DATALENGTH;				//正式实算数据中最后保留的数据长度		Jerry 20110629
    QString		INI_REVERSE_DATACONTENT;			//正式实算数据中最后保留的数据内容	Jerry 20110629

//下面为临时变量
    DWORD BIDTest;									//用来测试BID
    DWORD DebugPackIndex;							//用来测试BID

    DWORD LastT0;									//离本时刻最近的T0(毫秒)
    DWORD ReceivedNo;								//接收到的主控数据个数

    QString SaveFileName_Send;
    QString SaveFileName_Recv;
    QString OctFileName_Send;
    QString OctFileName_Recv;
    int SendFile;
    int RecvFile;
    int SendFileOct;
    int RecvFileOct;
    DWORD DesI;
    void OctSwitch( int type, QString InputString,  QString* OutputString );

signals:
        void  WM_USER_SENDED_ZK(unsigned int wParam,long lParam);
        void  WM_USER_RECEIVED_ZK(unsigned int wParam,long lParam);
        void   WM_TRANSDATA(const char*);

public slots:

};

#endif // !defined(AFX_NETCOMMUZK_H__3A59D6E7_67DF_4D2C_B962_6E4E417BC3EF__INCLUDED_)
