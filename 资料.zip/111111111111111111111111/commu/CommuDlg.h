﻿#ifndef COMMUDLG_H
#define COMMUDLG_H

#define WPARAM unsigned int
#define  LPARAM  long
#define  LRESULT  long

#include <QWidget>
#include <QFont>
#include "CDlg_MsgDisplay.h"
//#include "TestDialog.h"
#include "commu.h"
#include "Dlg_Debug.h"
//#include "MyTabWnd.h"
#include "NetCommuCT.h"
#include "NetCommuZK.h"
//#include "afxwin.h"
#include"TestDialog.h"
#include"CWinThread1.h"
#include"CWinThread2.h"
#include "yfmainwindow.h"

// CCommuDlg dialog

/************************************************************************/
/* 本类是一个调度类，本身不具备数据存储，所有的数据都存储在各个分页及各个
    通信类内。
    完成的功能：
    1.收到数据后对数据的调度。
    2.自身构成数据（指调试数据和分站/主控台之间的数据）
    3.显示刷新

重用时应注意:
1.类似于TransZK2CT/TransCT2ZK这样的编解码内容(其中的很多内容在CDlg_MsgDisplay中)
2.作为特例，这里使用了坐标变换（发射系与地心系）。
3.作为特例，这里增加了分站与中心站（主控台）之间数据通信的功能

对于
1正常状态的接收T0、外引导，并转发主控，
2接收中心站的数据并转发主控
3接收时延测试并回应
4接收常时
这4种功能在ReceivedCT中实现，
对于
1主动发送时延测试
需要在按钮响应中实现
对于
1发送常时
2与监控机发送调试数据
3与主控发送调试数据
这3种功能需要在定时器中实现
对于
1接收主控的实算数据
需要在ReceivedZK中实现

 另外SendedZK/SendedCT则只处理显示更新
                                                                     */
/************************************************************************/

namespace Ui {
class CCommuDlg;
}

class CCommuDlg : public QWidget
{
    Q_OBJECT

public:
    explicit CCommuDlg(QWidget *parent = 0);
    ~CCommuDlg();
    //   CMyTabWnd m_DialogTab;//一个定义的类对象

    CDlg_MsgDisplay *Dialog_MsgDisplay;//本工程中自定义的类
    CTestDialog *pTe;//本工程中自定义的类
    commu *Dialog_Setup;//本工程中自定义的类
    Dlg_Debug *Dialog_Debug;//本工程中自定义的类
    YFMainWindow *Dialog_Snmp;//本工程中自定义的类???????????????????????????????????????????????????????????????????/??????????????????????????????

    CNetCommuCT CTC_1;//NetCommuCT.h中定义的类
    CNetCommuCT CTC_2;//NetCommuCT.h中定义的类
    CNetCommuZK ZKC;//NetCommuCT.h中定义的类

    //CBCGPStatic	m_TitleBmp;

    // virtual BOOL PreTranslateMessage(MSG* pMsg);//????????????????????????????????????????????????
    //CWnd::PreTranslateMessage
    //virtual BOOL PreTranslateMessage( MSG* pMsg );
    //返回值：
    //如果消息被转换但是不会被分派，则返回非零值；如果消息没有被转换并且要被分派，则返回0。
    //参数： pMsg 指向一个MSG结构，其中包含了要处理的消息。
    //说明：
    //CWinApp类使用这个函数以在消息被分派到Windows的TranslateMessage和DispatchMessage函数之前进行转换。
protected:
    void closeEvent(QCloseEvent *event);
    //以下东西，都是与CNetCommu内容重叠，仅用于从文件中读出，显示在界面上。
    SocketSetting*	ZKSock;							//主控计算机网卡设置
    SocketSetting*	LocalCTSock_1;					//本地网卡设置
    SocketSetting*	LocalCTSock_2;					//本地网卡设置
    SocketSetting*	LocalZKSock;					//本地网卡设置
    Sockettp*		SendSocketTP;					//发送网络属性
    Sockettp*		RecvSocketTP;					//接收网络属性

    int*		INI_DATALENGTH_MEASURE;				//实算数据中数据区有效长度 = 32, 22+10
    int*		INI_DATALENGTH_THEORY;				//引入数据中数据区有效长度 = 28
    int*		INI_DATALENGTH_EXAM;				//时延测试数据区长度
    int*		INI_DATALENGTH_T0;					//T0数据区长度
    int*		INI_REVERSE_DATALENGTH;				//正式实算数据中最后保留的数据长度		Jerry 20110629
    QString*	INI_REVERSE_DATACONTENT;			//正式实算数据中最后保留的数据内容	Jerry 20110629
    bool*		Is_ZhuKongTai;						//分站与主控台之间是否通信
    int*		INI_DATALENGTH_ZK;					//分站主控发送的数据长度
    int*		INI_DATALENGTH_ZXZ;					//中心站主控发送的数据长度

    HEADERStruct*	MeasureHEADER;						//实算数据帧头信息
    HEADERStruct*	TimerSendHEADER;						//常时数据帧头信息(发送)
    HEADERStruct*	TimerRecvHEADER;						//常时数据帧头信息(接收)
    HEADERStruct*	ExamSendHEADER;						//时延测试帧头信息(发送)
    HEADERStruct*	ExamRecvHEADER;						//时延测试帧头信息(接收)
    HEADERStruct*	T0HEADER;								//T0数据帧头信息
    HEADERStruct*	WYDHEADER;							//外部说明数据帧头信息

    HEADERStruct*	DebugHEADER_Measure;					//调试实算数据帧头信息 ，调试模式下，主要是调试实算数据。
    HEADERStruct*	DebugHEADER_Timer;					//调试常时时数据帧头信息

    double*		EjectPosB;							//发射点坐标
    double*		EjectPosL;
    double*		EjectPosH;
    double*		EjectAngle;							//发射角
    QString*	DataSavePath;						//数据保存路径
    TimeSourceType  TimeSource;						//时统来源

    Runtp Global_CurrentMode;						//软件状态  runtp在Globaldefine.h中定义
    bool*	IsHandleWay;							//是否手工指定数据源路由
    int*	SourceWayNO;							//手工选择的路由 1->路由1 <> 2->路由2

    //HICON m_hIcon;  //?????????????????????????????????????????????????????????????????
    QFont PFont;// QFont代替
    //CFont类封装了一个Windows图形设备接口（GDI）字体并提供管理字体的成员函数。
    // 为使用一个CFont对象，可构造一个CFont对象并用CreatFont，CreateFontIndirect，CreatePointFont或CreatePointFontIndirect将一个Windows字体附加给它，然后用对象的成员函数操纵字体。

    QFont* def_font;

    BYTE 	BufferRecv[2][MACRO_BUFFER_SIZE];	//用于通信的接收数据区-对应CTC_1和CTC_2
    BYTE 	BufferSend[2][MACRO_BUFFER_SIZE];	//用于通信的将要发送数据区-对应CTC_1和CTC_2
    BYTE 	BufferRecv3[MACRO_BUFFER_SIZE];		//用于通信的接收数据区-对应ZKT
    BYTE	    BufferSend3[MACRO_BUFFER_SIZE];		//用于通信的将要发送数据区-对应ZKT
    DWORD	LastT0;								//最近的T0
    DWORD Counter20Hz;							//20Hz信号计数器
    bool IsExamSending;							//是否正在按频率发送主动常时
    int  ExamSendFreq;							//发送主动常时的频率
    int  ExamCount;								//发送主动常时的次数
    ExamResult ExamSet1[MACRO_MAXEXAM];			//测试结果
    ExamResult ExamSet2[MACRO_MAXEXAM];			//测试结果
    int ExamSetNum1;								//测试结果长度
    int ExamSetNum2;								//测试结果长度

    void InitDataMember();     //本类自定义的方法

    DWORD HandleTimeExam(int wayNO);//本类自定义的方法

    CWinThread1* Thread20HzHWND;					//20线程句柄
    CWinThread2* Thread1HzHWND;					//20线程句柄


    int T0_WYD_LAG;								//表示T0与外引导数据之间发送的延时（即T0发送之后需要多久秒再发送外引导）


    QTimer *Timer1SecondHWND;//整秒定时器 //UINT Timer1SecondHWND;
    QTimer *Timer1Hz;


    // afx_msg void OnPaint();  //qt不需要移植过去??????????????????？？？？？？？？？？？？？？？？？？
    //当Windows或应用程序请求重画应用程序窗口的一部分时，框架调用这个成员函数。
    // afx_msg HCURSOR OnQueryDragIcon();//?????????????????????????????????????????????????????????????
    //afx_msg HCURSOR OnQueryDragIcon( );
    //返回值：
    //一个双字值，它在低位字中包含了光标或图标的句柄。光标和图标必须与显示器的分辨率匹配。如果应用程序返回NULL，则系统将显示缺省的光标。缺省的返回值是NULL。
    //说明：
    //框架为不具有为类图标的最小化（图标化）窗口调用这个成员函数。系统调用这个函数以在用户拖拉最小化窗口的时候显示光标。
    //如果应用程序返回图标或光标的句柄，系统将它转换为黑与白。
    //如果应用程序返回一个句柄，则这个句柄必须标识与显示设备分辨率相兼容的单色光标或图标。应用程序可以调用CWinApp::LoadCursor或CWinApp::LoadIcon成员

public:
    // 显示状态提示
    // CBCGPStatic m_Tooltip;

    double MulRate1;
    double MulRate2;
    double LostRate1;
    double LostRate2;

    bool isCloseClicked;

public slots:
    void OnButtonConnect();
    void OnCoCancel();
    void OnButtonSendExam();
    void OnCheckStatusSwitch();
    void OnCheckStatusswitch2();
    void OnSysCommand(unsigned int nID, long lParam);//定义qt中的公共槽？？？？？？？？?????????????????????????????????????
    void OnTimer();
    long ReceivedCT(unsigned int wParam, long lParam);
    long SendedCT(unsigned int wParam, long lParam);
    long ReceivedZK(unsigned int wParam, long lParam);
    long SendedZK(unsigned int  wParam, long  lParam);
    void ParamApply();
    long OnTimer20Hz(unsigned int  wParam, long lParam);
    void  OnTimer1Hz();
    long OnStartLostExam(unsigned int wParam, long lParam);
    long OnCheckSend1(unsigned int  wParam,long lParam);
    long OnCheckSend2(unsigned int wParam, long  lParam);
    void ChangeIshandleway(bool HandleWay,int WayNO);
signals:
    //void WM_USER_20Hz(unsigned int ,long );
    void  WM_USER_1Hz(unsigned int,long);
private:
    Ui::CCommuDlg *ui;
    Ui::commu *commuui;
    Ui::Dlg_Debug *debugui;
    Ui::CDlg_MsgDisplay *msgdisplayui;
};



//UINT Thread20Hz(LPVOID pParam);//????????????????????????????????????????????
//UINT Thread1Hz(LPVOID pParam);//????????????????????????????????????????????
#endif // COMMUDLG_H
