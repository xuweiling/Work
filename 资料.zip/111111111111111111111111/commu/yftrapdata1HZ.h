#ifndef TRAPDATA_H
#define TRAPDATA_H

#include <qtimer.h>
#include <QObject>

class trapdata : public QObject
{
    Q_OBJECT
public:
    explicit trapdata(QObject *parent = 0);

    QTimer *timer;

signals:

public slots:
    void uptrapdata();

private:
    void isuptrapdata();
};

#endif // TRAPDATA_H
