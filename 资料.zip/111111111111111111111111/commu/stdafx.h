// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__680BA513_B298_4050_B0AE_1F41134731F3__INCLUDED_)
#define AFX_STDAFX_H__680BA513_B298_4050_B0AE_1F41134731F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#define WINVER 0x0501

#ifdef LINUXQT
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxadv.h>
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include "winsock2.h"		//Jerry 20101223
#include "Ws2tcpip.h"		//Jerry 20101223
#include <afxsock.h>		// MFC socket extensions
#include "tcrclib.h"

#include <fstream>
#include <winioctl.h>
#include"winsnmp.h"

#include <BCGCBProInc.h>			// BCGControlBar Pro
#endif

#define User_Control 20086								
#define ID_USER_Tab		User_Control+1				//Tab的ID
#define ID_USER_DLG1	 User_Control+2				//实时显示窗的ID

#define MACRO_BUFFER_SIZE	2048
#define MACRO_FILE_SIZE		256*1024*1024
#define MACRO_INI_FILEPATH  "\\配置.ini"
#define MACRO_24Hour		864000000//24小时的最大时间码

#define BUFFER_LENGTH		1024
#define WM_USER_FRESHEDITZK	2500
#define WM_USER_FRESHEDITCT	2501
#define WM_USER_FRESHRADIO  2502
#define WM_USER_UPDATEMSGDLG	2503
#define WM_USER_UPDATEMSGDLGSEND 2504
#define WM_USER_SendExamResult	2505

//#define WM_USER_RECEIVED_CT		WM_USER+105
//#define WM_USER_SENDED_CT		WM_USER+106
//#define WM_USER_RECEIVED_ZK		WM_USER+107
//#define WM_USER_SENDED_ZK		WM_USER+108
//#define WM_USER_APPLY			WM_USER+109
//#define WM_USER_20Hz			WM_USER+110
//#define WM_USER_STARTLOST		WM_USER+111
//#define WM_USER_CHECK_SEND1		WM_USER+112
//#define WM_USER_CHECK_SEND2		WM_USER+113
//#define WM_USER_1Hz				WM_USER+114

#define USER_TYPE 1//代表是分站程序

#define REOCRDFILE "D:\\网络记录文件\\"
#define THEORYFILE "D:\\引入.txt"
#define MEASUREFILE "D:\\实算数据.txt"
//#define INIFILE "C:\\工作\\1307\\网络改造\\正式版本\\分站版本\\Commu_多IP23\\分站Commu新.ini"
#define INIFILE "D:\\配置.ini"
#define MACRO_MAXEXAM 6000

#define WM_USER_TESTW 2505

//#define WM_YGMSG WM_USER+200
#define STATELEN 255
#define  WM_SNMP WM_USER+1000

//#define CardType 1//定义了此宏代表PIO，没定义此宏代表tcrc
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__680BA513_B298_4050_B0AE_1F41134731F3__INCLUDED_)
