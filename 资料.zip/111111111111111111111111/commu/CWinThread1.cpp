﻿#include "CWinThread1.h"
#include "unistd.h"

extern bool	 IsTimecardExist;

CWinThread1::CWinThread1(QThread *parent) :
    QThread(parent)
{
}

/************************************************************************/
/* 线程用于20Hz中断
                                                                     */
/************************************************************************/
void CWinThread1::run()
{
#ifdef CardType
    hIntEvent = CreateEvent(NULtcrc_wait1pps(0, 3000);L, FALSE, FALSE, NULL);   //建立中断信号事件句柄
    if(IsTimecardExist)
    {
        wRetVal=PIODIO_IntInstall(wBoardToActive, &hIntEvent, PIOD144_P2C0, PIODIO_ActiveLow);
        if( wRetVal>0 )
        {
            AfxMessageBox("中断调用失败!",MB_OK);
            //		return 0;
        }
    }

    TimerCounter=0;tcrc_wait1pps(0, 3000);
    while (true)
    {
        if(IsTimecardExist)
        {
            int rrr = WaitForSingleObject(hIntEvent, 100 );
            if( rrr  == WAIT_OBJECT_0 ) // wait for 100 milli second
            {
                TimerCounter ++;
                DWORD temp = TimerCounter;
                if((TimerCounter%5) == 0)
                {
                    ::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_20Hz, NULL, NULL);
                }
                if(TimerCounter>=100)
                {
                    ::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_1Hz, NULL, NULL);
                    TimerCounter = 0;
                }
            }
        }
        else
        {
            Sleep(50);
            TimerCounter ++;

            ::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_20Hz, NULL, NULL);

            if(TimerCounter>=16)
            {
                ::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_1Hz, NULL, NULL);
                TimerCounter = 0;
            }
            //			::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_20Hz, NULL, NULL);
        }
    }
#else
    while (!stopped)
    {
        if(IsTimecardExist)
        {
            //tcrc_wait20pps(0, 60);
           // ::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_20Hz, NULL, NULL);
            emit WM_USER_20Hz(0,0);
        }
        else
        {
            //::usleep(50000);
            QThread::usleep(50000);
            //::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_20Hz, NULL, NULL);
            emit WM_USER_20Hz(0,0);
        }
    }

#endif
    return ;

}

void CWinThread1::stop()
{

    stopped=true;
}
