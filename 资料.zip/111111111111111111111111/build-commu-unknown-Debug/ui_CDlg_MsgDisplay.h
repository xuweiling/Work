/********************************************************************************
** Form generated from reading UI file 'CDlg_MsgDisplay.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CDLG_MSGDISPLAY_H
#define UI_CDLG_MSGDISPLAY_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_CDlg_MsgDisplay
{
public:
    QHBoxLayout *horizontalLayout_6;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout;
    QLabel *IDC_STATIC1_TEXT;
    QComboBox *m_DisplayAdd1;
    QLabel *m_StType1;
    QSpacerItem *horizontalSpacer;
    QCheckBox *m_SetWayAutoHandle;
    QLabel *m_WayChosen;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *IDC_STATIC2_TEXT;
    QLineEdit *m_Recv_1_1;
    QHBoxLayout *horizontalLayout_3;
    QLabel *IDC_STATIC3_TEXT;
    QLineEdit *m_Recv_1_2;
    QPushButton *m_Select_1;
    QLabel *m_NetStatus1;
    QHBoxLayout *horizontalLayout_5;
    QLabel *IDC_STATIC3_TEXT_3;
    QComboBox *m_DisplayAdd2;
    QLabel *m_StType2;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_2;
    QLabel *label;
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_7;
    QLabel *IDC_STATIC4_TEXT;
    QLineEdit *m_Recv_2_1;
    QHBoxLayout *horizontalLayout_8;
    QLabel *IDC_STATIC5_TEXT;
    QLineEdit *m_Recv_2_2;
    QPushButton *m_Select_2;
    QLabel *m_NetStatus2;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_10;
    QLabel *IDC_STATIC6_TEXT;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_11;
    QLabel *IDC_STATIC7_TEXT;
    QLineEdit *m_Send_1;
    QPushButton *m_ChkSend1;
    QHBoxLayout *horizontalLayout_12;
    QLabel *IDC_STATIC8_TEXT;
    QLineEdit *m_Send_2;
    QPushButton *m_ChkSend2;
    QVBoxLayout *verticalLayout_6;
    QLabel *m_StIndexInfo;
    QLabel *m_BuffetLeftLength;
    QLabel *m_LagTime;
    QHBoxLayout *horizontalLayout_28;
    QGroupBox *IDC_STATIC16_Group_box;
    QVBoxLayout *verticalLayout_8;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_13;
    QLabel *IDC_STATIC17_TEXT;
    QLabel *m_Recv_Time_1_1;
    QLabel *IDC_STATIC18_TEXT;
    QLabel *m_Recv_Time_1_2;
    QHBoxLayout *horizontalLayout_14;
    QLabel *IDC_STATIC19_TEXT;
    QLabel *m_RecvT0_1;
    QLabel *IDC_STATIC23_TEXT;
    QLabel *m_RecvMID_1;
    QHBoxLayout *horizontalLayout_15;
    QLabel *IDC_STATIC20_TEXT;
    QLabel *m_Recv_X_1;
    QLabel *IDC_STATIC24_TEXT;
    QLabel *m_RecvSID_1;
    QHBoxLayout *horizontalLayout_16;
    QLabel *IDC_STATIC21_TEXT;
    QLabel *m_Recv_Y_1;
    QLabel *IDC_STATIC25_TEXT;
    QLabel *m_RecvDID_1;
    QHBoxLayout *horizontalLayout_17;
    QLabel *IDC_STATIC22_TEXT;
    QLabel *m_Recv_Z_1;
    QLabel *IDC_STATIC26_TEXT;
    QLabel *m_PackCount1;
    QGroupBox *IDC_STATIC37_Group_box;
    QVBoxLayout *verticalLayout_10;
    QVBoxLayout *verticalLayout_9;
    QHBoxLayout *horizontalLayout_18;
    QLabel *IDC_STATIC38_TEXT;
    QLabel *m_Recv_Time_2_1;
    QLabel *IDC_STATIC39_TEXT;
    QLabel *m_Recv_Time_2_2;
    QHBoxLayout *horizontalLayout_19;
    QLabel *IDC_STATIC40_TEXT;
    QLabel *m_RecvT0_2;
    QLabel *IDC_STATIC44_TEXT;
    QLabel *m_RecvMID_2;
    QHBoxLayout *horizontalLayout_20;
    QLabel *IDC_STATIC41_TEXT;
    QLabel *m_Recv_X_2;
    QLabel *IDC_STATIC45_TEXT;
    QLabel *m_RecvSID_2;
    QHBoxLayout *horizontalLayout_21;
    QLabel *IDC_STATIC42_TEXT;
    QLabel *m_Recv_Y_2;
    QLabel *IDC_STATIC46_TEXT;
    QLabel *m_RecvDID_2;
    QHBoxLayout *horizontalLayout_22;
    QLabel *IDC_STATIC43_TEXT;
    QLabel *m_Recv_Z_2;
    QLabel *IDC_STATIC47_TEXT;
    QLabel *m_PackCount2;
    QGroupBox *IDC_STATIC58_Group_box_2;
    QVBoxLayout *verticalLayout_12;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_23;
    QLabel *IDC_STATIC59_TEXT;
    QLabel *m_Send_Time_1;
    QLabel *IDC_STATIC60_TEXT;
    QLabel *m_Send_Time_2;
    QHBoxLayout *horizontalLayout_24;
    QLabel *IDC_STATIC61_TEXT;
    QLabel *m_Send_A;
    QLabel *IDC_STATIC65_TEXT;
    QLabel *m_SendMID;
    QHBoxLayout *horizontalLayout_25;
    QLabel *IDC_STATIC62_TEXT;
    QLabel *m_Send_E;
    QLabel *IDC_STATIC66_TEXT;
    QLabel *m_SendSID;
    QHBoxLayout *horizontalLayout_26;
    QLabel *IDC_STATIC63_TEXT;
    QLabel *m_Send_Mode;
    QLabel *IDC_STATIC67_TEXT;
    QLabel *m_SendDID;
    QHBoxLayout *horizontalLayout_27;
    QLabel *IDC_STATIC64_TEXT;
    QLabel *m_Send_Offset;
    QLabel *IDC_STATIC68_TEXT;
    QLabel *m_PackCount3;
    QFrame *line1_2;
    QFrame *line1_3;

    void setupUi(QDialog *CDlg_MsgDisplay)
    {
        if (CDlg_MsgDisplay->objectName().isEmpty())
            CDlg_MsgDisplay->setObjectName(QString::fromUtf8("CDlg_MsgDisplay"));
        CDlg_MsgDisplay->resize(1177, 771);
        horizontalLayout_6 = new QHBoxLayout(CDlg_MsgDisplay);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        IDC_STATIC1_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC1_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC1_TEXT"));
        IDC_STATIC1_TEXT->setEnabled(true);

        horizontalLayout->addWidget(IDC_STATIC1_TEXT);

        m_DisplayAdd1 = new QComboBox(CDlg_MsgDisplay);
        m_DisplayAdd1->setObjectName(QString::fromUtf8("m_DisplayAdd1"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_DisplayAdd1->sizePolicy().hasHeightForWidth());
        m_DisplayAdd1->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(m_DisplayAdd1);

        m_StType1 = new QLabel(CDlg_MsgDisplay);
        m_StType1->setObjectName(QString::fromUtf8("m_StType1"));
        m_StType1->setEnabled(true);

        horizontalLayout->addWidget(m_StType1);

        horizontalSpacer = new QSpacerItem(378, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        m_SetWayAutoHandle = new QCheckBox(CDlg_MsgDisplay);
        m_SetWayAutoHandle->setObjectName(QString::fromUtf8("m_SetWayAutoHandle"));

        horizontalLayout->addWidget(m_SetWayAutoHandle);

        m_WayChosen = new QLabel(CDlg_MsgDisplay);
        m_WayChosen->setObjectName(QString::fromUtf8("m_WayChosen"));
        m_WayChosen->setEnabled(true);

        horizontalLayout->addWidget(m_WayChosen);

        horizontalLayout->setStretch(0, 200);
        horizontalLayout->setStretch(1, 1000);
        horizontalLayout->setStretch(2, 50);
        horizontalLayout->setStretch(3, 1000);
        horizontalLayout->setStretch(4, 100);
        horizontalLayout->setStretch(5, 100);

        verticalLayout_4->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        IDC_STATIC2_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC2_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC2_TEXT"));
        IDC_STATIC2_TEXT->setEnabled(true);

        horizontalLayout_2->addWidget(IDC_STATIC2_TEXT);

        m_Recv_1_1 = new QLineEdit(CDlg_MsgDisplay);
        m_Recv_1_1->setObjectName(QString::fromUtf8("m_Recv_1_1"));

        horizontalLayout_2->addWidget(m_Recv_1_1);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(10);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        IDC_STATIC3_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC3_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC3_TEXT"));
        IDC_STATIC3_TEXT->setEnabled(true);

        horizontalLayout_3->addWidget(IDC_STATIC3_TEXT);

        m_Recv_1_2 = new QLineEdit(CDlg_MsgDisplay);
        m_Recv_1_2->setObjectName(QString::fromUtf8("m_Recv_1_2"));

        horizontalLayout_3->addWidget(m_Recv_1_2);

        m_Select_1 = new QPushButton(CDlg_MsgDisplay);
        m_Select_1->setObjectName(QString::fromUtf8("m_Select_1"));

        horizontalLayout_3->addWidget(m_Select_1);


        verticalLayout->addLayout(horizontalLayout_3);


        horizontalLayout_4->addLayout(verticalLayout);

        m_NetStatus1 = new QLabel(CDlg_MsgDisplay);
        m_NetStatus1->setObjectName(QString::fromUtf8("m_NetStatus1"));

        horizontalLayout_4->addWidget(m_NetStatus1);


        verticalLayout_4->addLayout(horizontalLayout_4);


        verticalLayout_3->addLayout(verticalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        IDC_STATIC3_TEXT_3 = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC3_TEXT_3->setObjectName(QString::fromUtf8("IDC_STATIC3_TEXT_3"));
        IDC_STATIC3_TEXT_3->setEnabled(true);
        sizePolicy.setHeightForWidth(IDC_STATIC3_TEXT_3->sizePolicy().hasHeightForWidth());
        IDC_STATIC3_TEXT_3->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(IDC_STATIC3_TEXT_3);

        m_DisplayAdd2 = new QComboBox(CDlg_MsgDisplay);
        m_DisplayAdd2->setObjectName(QString::fromUtf8("m_DisplayAdd2"));
        sizePolicy.setHeightForWidth(m_DisplayAdd2->sizePolicy().hasHeightForWidth());
        m_DisplayAdd2->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(m_DisplayAdd2);

        m_StType2 = new QLabel(CDlg_MsgDisplay);
        m_StType2->setObjectName(QString::fromUtf8("m_StType2"));
        m_StType2->setEnabled(true);

        horizontalLayout_5->addWidget(m_StType2);

        horizontalSpacer_2 = new QSpacerItem(458, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_2);

        label_2 = new QLabel(CDlg_MsgDisplay);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(label_2);

        label = new QLabel(CDlg_MsgDisplay);
        label->setObjectName(QString::fromUtf8("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(label);

        horizontalLayout_5->setStretch(0, 200);
        horizontalLayout_5->setStretch(1, 1000);
        horizontalLayout_5->setStretch(2, 50);
        horizontalLayout_5->setStretch(3, 1000);
        horizontalLayout_5->setStretch(4, 500);
        horizontalLayout_5->setStretch(5, 300);

        verticalLayout_3->addLayout(horizontalLayout_5);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        IDC_STATIC4_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC4_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC4_TEXT"));
        IDC_STATIC4_TEXT->setEnabled(true);

        horizontalLayout_7->addWidget(IDC_STATIC4_TEXT);

        m_Recv_2_1 = new QLineEdit(CDlg_MsgDisplay);
        m_Recv_2_1->setObjectName(QString::fromUtf8("m_Recv_2_1"));

        horizontalLayout_7->addWidget(m_Recv_2_1);


        verticalLayout_2->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(9);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        IDC_STATIC5_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC5_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC5_TEXT"));
        IDC_STATIC5_TEXT->setEnabled(true);

        horizontalLayout_8->addWidget(IDC_STATIC5_TEXT);

        m_Recv_2_2 = new QLineEdit(CDlg_MsgDisplay);
        m_Recv_2_2->setObjectName(QString::fromUtf8("m_Recv_2_2"));

        horizontalLayout_8->addWidget(m_Recv_2_2);

        m_Select_2 = new QPushButton(CDlg_MsgDisplay);
        m_Select_2->setObjectName(QString::fromUtf8("m_Select_2"));

        horizontalLayout_8->addWidget(m_Select_2);


        verticalLayout_2->addLayout(horizontalLayout_8);


        horizontalLayout_9->addLayout(verticalLayout_2);

        m_NetStatus2 = new QLabel(CDlg_MsgDisplay);
        m_NetStatus2->setObjectName(QString::fromUtf8("m_NetStatus2"));

        horizontalLayout_9->addWidget(m_NetStatus2);


        verticalLayout_3->addLayout(horizontalLayout_9);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        IDC_STATIC6_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC6_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC6_TEXT"));
        IDC_STATIC6_TEXT->setEnabled(true);

        horizontalLayout_10->addWidget(IDC_STATIC6_TEXT);

        horizontalSpacer_4 = new QSpacerItem(968, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_4);


        verticalLayout_5->addLayout(horizontalLayout_10);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        IDC_STATIC7_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC7_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC7_TEXT"));
        IDC_STATIC7_TEXT->setEnabled(true);

        horizontalLayout_11->addWidget(IDC_STATIC7_TEXT);

        m_Send_1 = new QLineEdit(CDlg_MsgDisplay);
        m_Send_1->setObjectName(QString::fromUtf8("m_Send_1"));

        horizontalLayout_11->addWidget(m_Send_1);

        m_ChkSend1 = new QPushButton(CDlg_MsgDisplay);
        m_ChkSend1->setObjectName(QString::fromUtf8("m_ChkSend1"));

        horizontalLayout_11->addWidget(m_ChkSend1);


        verticalLayout_5->addLayout(horizontalLayout_11);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        IDC_STATIC8_TEXT = new QLabel(CDlg_MsgDisplay);
        IDC_STATIC8_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC8_TEXT"));
        IDC_STATIC8_TEXT->setEnabled(true);

        horizontalLayout_12->addWidget(IDC_STATIC8_TEXT);

        m_Send_2 = new QLineEdit(CDlg_MsgDisplay);
        m_Send_2->setObjectName(QString::fromUtf8("m_Send_2"));

        horizontalLayout_12->addWidget(m_Send_2);

        m_ChkSend2 = new QPushButton(CDlg_MsgDisplay);
        m_ChkSend2->setObjectName(QString::fromUtf8("m_ChkSend2"));

        horizontalLayout_12->addWidget(m_ChkSend2);


        verticalLayout_5->addLayout(horizontalLayout_12);


        verticalLayout_3->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        m_StIndexInfo = new QLabel(CDlg_MsgDisplay);
        m_StIndexInfo->setObjectName(QString::fromUtf8("m_StIndexInfo"));
        m_StIndexInfo->setContextMenuPolicy(Qt::DefaultContextMenu);
        m_StIndexInfo->setFrameShape(QFrame::Panel);

        verticalLayout_6->addWidget(m_StIndexInfo);

        m_BuffetLeftLength = new QLabel(CDlg_MsgDisplay);
        m_BuffetLeftLength->setObjectName(QString::fromUtf8("m_BuffetLeftLength"));
        m_BuffetLeftLength->setEnabled(true);
        m_BuffetLeftLength->setFrameShape(QFrame::Panel);

        verticalLayout_6->addWidget(m_BuffetLeftLength);

        m_LagTime = new QLabel(CDlg_MsgDisplay);
        m_LagTime->setObjectName(QString::fromUtf8("m_LagTime"));
        m_LagTime->setEnabled(true);
        m_LagTime->setFrameShape(QFrame::Panel);

        verticalLayout_6->addWidget(m_LagTime);


        verticalLayout_3->addLayout(verticalLayout_6);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        IDC_STATIC16_Group_box = new QGroupBox(CDlg_MsgDisplay);
        IDC_STATIC16_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC16_Group_box"));
        IDC_STATIC16_Group_box->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        verticalLayout_8 = new QVBoxLayout(IDC_STATIC16_Group_box);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(2);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        IDC_STATIC17_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC17_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC17_TEXT"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(IDC_STATIC17_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC17_TEXT->setSizePolicy(sizePolicy1);
        QFont font;
        font.setBold(false);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        IDC_STATIC17_TEXT->setFont(font);
        IDC_STATIC17_TEXT->setMouseTracking(false);
        IDC_STATIC17_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC17_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_13->addWidget(IDC_STATIC17_TEXT);

        m_Recv_Time_1_1 = new QLabel(IDC_STATIC16_Group_box);
        m_Recv_Time_1_1->setObjectName(QString::fromUtf8("m_Recv_Time_1_1"));
        sizePolicy1.setHeightForWidth(m_Recv_Time_1_1->sizePolicy().hasHeightForWidth());
        m_Recv_Time_1_1->setSizePolicy(sizePolicy1);
        m_Recv_Time_1_1->setFont(font);
        m_Recv_Time_1_1->setMouseTracking(false);
        m_Recv_Time_1_1->setFrameShape(QFrame::StyledPanel);
        m_Recv_Time_1_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_13->addWidget(m_Recv_Time_1_1);

        IDC_STATIC18_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC18_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC18_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC18_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC18_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC18_TEXT->setFont(font);
        IDC_STATIC18_TEXT->setMouseTracking(false);
        IDC_STATIC18_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC18_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_13->addWidget(IDC_STATIC18_TEXT);

        m_Recv_Time_1_2 = new QLabel(IDC_STATIC16_Group_box);
        m_Recv_Time_1_2->setObjectName(QString::fromUtf8("m_Recv_Time_1_2"));
        sizePolicy1.setHeightForWidth(m_Recv_Time_1_2->sizePolicy().hasHeightForWidth());
        m_Recv_Time_1_2->setSizePolicy(sizePolicy1);
        m_Recv_Time_1_2->setFont(font);
        m_Recv_Time_1_2->setMouseTracking(false);
        m_Recv_Time_1_2->setFrameShape(QFrame::StyledPanel);
        m_Recv_Time_1_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_13->addWidget(m_Recv_Time_1_2);

        horizontalLayout_13->setStretch(0, 100);
        horizontalLayout_13->setStretch(1, 400);
        horizontalLayout_13->setStretch(2, 100);
        horizontalLayout_13->setStretch(3, 400);

        verticalLayout_7->addLayout(horizontalLayout_13);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(14);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        IDC_STATIC19_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC19_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC19_TEXT"));
        IDC_STATIC19_TEXT->setFont(font);
        IDC_STATIC19_TEXT->setMouseTracking(false);
        IDC_STATIC19_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC19_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_14->addWidget(IDC_STATIC19_TEXT);

        m_RecvT0_1 = new QLabel(IDC_STATIC16_Group_box);
        m_RecvT0_1->setObjectName(QString::fromUtf8("m_RecvT0_1"));
        sizePolicy1.setHeightForWidth(m_RecvT0_1->sizePolicy().hasHeightForWidth());
        m_RecvT0_1->setSizePolicy(sizePolicy1);
        m_RecvT0_1->setFont(font);
        m_RecvT0_1->setMouseTracking(false);
        m_RecvT0_1->setFrameShape(QFrame::StyledPanel);
        m_RecvT0_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_14->addWidget(m_RecvT0_1);

        IDC_STATIC23_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC23_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC23_TEXT"));
        IDC_STATIC23_TEXT->setFont(font);
        IDC_STATIC23_TEXT->setMouseTracking(false);
        IDC_STATIC23_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC23_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_14->addWidget(IDC_STATIC23_TEXT);

        m_RecvMID_1 = new QLabel(IDC_STATIC16_Group_box);
        m_RecvMID_1->setObjectName(QString::fromUtf8("m_RecvMID_1"));
        sizePolicy1.setHeightForWidth(m_RecvMID_1->sizePolicy().hasHeightForWidth());
        m_RecvMID_1->setSizePolicy(sizePolicy1);
        m_RecvMID_1->setFont(font);
        m_RecvMID_1->setMouseTracking(false);
        m_RecvMID_1->setFrameShape(QFrame::StyledPanel);
        m_RecvMID_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_14->addWidget(m_RecvMID_1);

        horizontalLayout_14->setStretch(0, 100);
        horizontalLayout_14->setStretch(1, 300);
        horizontalLayout_14->setStretch(2, 100);
        horizontalLayout_14->setStretch(3, 300);

        verticalLayout_7->addLayout(horizontalLayout_14);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        IDC_STATIC20_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC20_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC20_TEXT"));
        IDC_STATIC20_TEXT->setFont(font);
        IDC_STATIC20_TEXT->setMouseTracking(false);
        IDC_STATIC20_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC20_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC20_TEXT->setWordWrap(true);

        horizontalLayout_15->addWidget(IDC_STATIC20_TEXT);

        m_Recv_X_1 = new QLabel(IDC_STATIC16_Group_box);
        m_Recv_X_1->setObjectName(QString::fromUtf8("m_Recv_X_1"));
        sizePolicy1.setHeightForWidth(m_Recv_X_1->sizePolicy().hasHeightForWidth());
        m_Recv_X_1->setSizePolicy(sizePolicy1);
        m_Recv_X_1->setFont(font);
        m_Recv_X_1->setMouseTracking(false);
        m_Recv_X_1->setFrameShape(QFrame::StyledPanel);
        m_Recv_X_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_15->addWidget(m_Recv_X_1);

        IDC_STATIC24_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC24_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC24_TEXT"));
        IDC_STATIC24_TEXT->setFont(font);
        IDC_STATIC24_TEXT->setMouseTracking(false);
        IDC_STATIC24_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC24_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_15->addWidget(IDC_STATIC24_TEXT);

        m_RecvSID_1 = new QLabel(IDC_STATIC16_Group_box);
        m_RecvSID_1->setObjectName(QString::fromUtf8("m_RecvSID_1"));
        sizePolicy1.setHeightForWidth(m_RecvSID_1->sizePolicy().hasHeightForWidth());
        m_RecvSID_1->setSizePolicy(sizePolicy1);
        m_RecvSID_1->setFont(font);
        m_RecvSID_1->setMouseTracking(false);
        m_RecvSID_1->setFrameShape(QFrame::StyledPanel);
        m_RecvSID_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_15->addWidget(m_RecvSID_1);

        horizontalLayout_15->setStretch(0, 200);
        horizontalLayout_15->setStretch(1, 400);
        horizontalLayout_15->setStretch(2, 200);
        horizontalLayout_15->setStretch(3, 400);

        verticalLayout_7->addLayout(horizontalLayout_15);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        IDC_STATIC21_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC21_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC21_TEXT"));
        IDC_STATIC21_TEXT->setFont(font);
        IDC_STATIC21_TEXT->setMouseTracking(false);
        IDC_STATIC21_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC21_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC21_TEXT->setWordWrap(true);

        horizontalLayout_16->addWidget(IDC_STATIC21_TEXT);

        m_Recv_Y_1 = new QLabel(IDC_STATIC16_Group_box);
        m_Recv_Y_1->setObjectName(QString::fromUtf8("m_Recv_Y_1"));
        sizePolicy1.setHeightForWidth(m_Recv_Y_1->sizePolicy().hasHeightForWidth());
        m_Recv_Y_1->setSizePolicy(sizePolicy1);
        m_Recv_Y_1->setFont(font);
        m_Recv_Y_1->setMouseTracking(false);
        m_Recv_Y_1->setFrameShape(QFrame::StyledPanel);
        m_Recv_Y_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_16->addWidget(m_Recv_Y_1);

        IDC_STATIC25_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC25_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC25_TEXT"));
        IDC_STATIC25_TEXT->setFont(font);
        IDC_STATIC25_TEXT->setMouseTracking(false);
        IDC_STATIC25_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC25_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_16->addWidget(IDC_STATIC25_TEXT);

        m_RecvDID_1 = new QLabel(IDC_STATIC16_Group_box);
        m_RecvDID_1->setObjectName(QString::fromUtf8("m_RecvDID_1"));
        sizePolicy1.setHeightForWidth(m_RecvDID_1->sizePolicy().hasHeightForWidth());
        m_RecvDID_1->setSizePolicy(sizePolicy1);
        m_RecvDID_1->setFont(font);
        m_RecvDID_1->setMouseTracking(false);
        m_RecvDID_1->setFrameShape(QFrame::StyledPanel);
        m_RecvDID_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_16->addWidget(m_RecvDID_1);

        horizontalLayout_16->setStretch(0, 200);
        horizontalLayout_16->setStretch(1, 400);
        horizontalLayout_16->setStretch(2, 200);
        horizontalLayout_16->setStretch(3, 400);

        verticalLayout_7->addLayout(horizontalLayout_16);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        IDC_STATIC22_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC22_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC22_TEXT"));
        IDC_STATIC22_TEXT->setFont(font);
        IDC_STATIC22_TEXT->setMouseTracking(false);
        IDC_STATIC22_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC22_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC22_TEXT->setWordWrap(true);

        horizontalLayout_17->addWidget(IDC_STATIC22_TEXT);

        m_Recv_Z_1 = new QLabel(IDC_STATIC16_Group_box);
        m_Recv_Z_1->setObjectName(QString::fromUtf8("m_Recv_Z_1"));
        sizePolicy1.setHeightForWidth(m_Recv_Z_1->sizePolicy().hasHeightForWidth());
        m_Recv_Z_1->setSizePolicy(sizePolicy1);
        m_Recv_Z_1->setFont(font);
        m_Recv_Z_1->setMouseTracking(false);
        m_Recv_Z_1->setFrameShape(QFrame::StyledPanel);
        m_Recv_Z_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_17->addWidget(m_Recv_Z_1);

        IDC_STATIC26_TEXT = new QLabel(IDC_STATIC16_Group_box);
        IDC_STATIC26_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC26_TEXT"));
        IDC_STATIC26_TEXT->setFont(font);
        IDC_STATIC26_TEXT->setMouseTracking(false);
        IDC_STATIC26_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC26_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_17->addWidget(IDC_STATIC26_TEXT);

        m_PackCount1 = new QLabel(IDC_STATIC16_Group_box);
        m_PackCount1->setObjectName(QString::fromUtf8("m_PackCount1"));
        sizePolicy1.setHeightForWidth(m_PackCount1->sizePolicy().hasHeightForWidth());
        m_PackCount1->setSizePolicy(sizePolicy1);
        m_PackCount1->setFont(font);
        m_PackCount1->setMouseTracking(false);
        m_PackCount1->setFrameShape(QFrame::StyledPanel);
        m_PackCount1->setFrameShadow(QFrame::Plain);

        horizontalLayout_17->addWidget(m_PackCount1);

        horizontalLayout_17->setStretch(0, 200);
        horizontalLayout_17->setStretch(1, 400);
        horizontalLayout_17->setStretch(2, 200);
        horizontalLayout_17->setStretch(3, 400);

        verticalLayout_7->addLayout(horizontalLayout_17);


        verticalLayout_8->addLayout(verticalLayout_7);


        horizontalLayout_28->addWidget(IDC_STATIC16_Group_box);

        IDC_STATIC37_Group_box = new QGroupBox(CDlg_MsgDisplay);
        IDC_STATIC37_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC37_Group_box"));
        verticalLayout_10 = new QVBoxLayout(IDC_STATIC37_Group_box);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(2);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        IDC_STATIC38_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC38_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC38_TEXT"));
        IDC_STATIC38_TEXT->setFont(font);
        IDC_STATIC38_TEXT->setMouseTracking(false);
        IDC_STATIC38_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC38_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_18->addWidget(IDC_STATIC38_TEXT);

        m_Recv_Time_2_1 = new QLabel(IDC_STATIC37_Group_box);
        m_Recv_Time_2_1->setObjectName(QString::fromUtf8("m_Recv_Time_2_1"));
        sizePolicy1.setHeightForWidth(m_Recv_Time_2_1->sizePolicy().hasHeightForWidth());
        m_Recv_Time_2_1->setSizePolicy(sizePolicy1);
        m_Recv_Time_2_1->setFont(font);
        m_Recv_Time_2_1->setMouseTracking(false);
        m_Recv_Time_2_1->setFrameShape(QFrame::StyledPanel);
        m_Recv_Time_2_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_18->addWidget(m_Recv_Time_2_1);

        IDC_STATIC39_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC39_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC39_TEXT"));
        IDC_STATIC39_TEXT->setFont(font);
        IDC_STATIC39_TEXT->setMouseTracking(false);
        IDC_STATIC39_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC39_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_18->addWidget(IDC_STATIC39_TEXT);

        m_Recv_Time_2_2 = new QLabel(IDC_STATIC37_Group_box);
        m_Recv_Time_2_2->setObjectName(QString::fromUtf8("m_Recv_Time_2_2"));
        sizePolicy1.setHeightForWidth(m_Recv_Time_2_2->sizePolicy().hasHeightForWidth());
        m_Recv_Time_2_2->setSizePolicy(sizePolicy1);
        m_Recv_Time_2_2->setFont(font);
        m_Recv_Time_2_2->setMouseTracking(false);
        m_Recv_Time_2_2->setFrameShape(QFrame::StyledPanel);
        m_Recv_Time_2_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_18->addWidget(m_Recv_Time_2_2);

        horizontalLayout_18->setStretch(0, 100);
        horizontalLayout_18->setStretch(1, 400);
        horizontalLayout_18->setStretch(2, 100);
        horizontalLayout_18->setStretch(3, 400);

        verticalLayout_9->addLayout(horizontalLayout_18);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(14);
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        IDC_STATIC40_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC40_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC40_TEXT"));
        IDC_STATIC40_TEXT->setFont(font);
        IDC_STATIC40_TEXT->setMouseTracking(false);
        IDC_STATIC40_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC40_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_19->addWidget(IDC_STATIC40_TEXT);

        m_RecvT0_2 = new QLabel(IDC_STATIC37_Group_box);
        m_RecvT0_2->setObjectName(QString::fromUtf8("m_RecvT0_2"));
        sizePolicy1.setHeightForWidth(m_RecvT0_2->sizePolicy().hasHeightForWidth());
        m_RecvT0_2->setSizePolicy(sizePolicy1);
        m_RecvT0_2->setFont(font);
        m_RecvT0_2->setMouseTracking(false);
        m_RecvT0_2->setFrameShape(QFrame::StyledPanel);
        m_RecvT0_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_19->addWidget(m_RecvT0_2);

        IDC_STATIC44_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC44_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC44_TEXT"));
        IDC_STATIC44_TEXT->setFont(font);
        IDC_STATIC44_TEXT->setMouseTracking(false);
        IDC_STATIC44_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC44_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_19->addWidget(IDC_STATIC44_TEXT);

        m_RecvMID_2 = new QLabel(IDC_STATIC37_Group_box);
        m_RecvMID_2->setObjectName(QString::fromUtf8("m_RecvMID_2"));
        sizePolicy1.setHeightForWidth(m_RecvMID_2->sizePolicy().hasHeightForWidth());
        m_RecvMID_2->setSizePolicy(sizePolicy1);
        m_RecvMID_2->setFont(font);
        m_RecvMID_2->setMouseTracking(false);
        m_RecvMID_2->setFrameShape(QFrame::StyledPanel);
        m_RecvMID_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_19->addWidget(m_RecvMID_2);

        horizontalLayout_19->setStretch(0, 100);
        horizontalLayout_19->setStretch(1, 300);
        horizontalLayout_19->setStretch(2, 100);
        horizontalLayout_19->setStretch(3, 300);

        verticalLayout_9->addLayout(horizontalLayout_19);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));
        IDC_STATIC41_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC41_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC41_TEXT"));
        IDC_STATIC41_TEXT->setFont(font);
        IDC_STATIC41_TEXT->setMouseTracking(false);
        IDC_STATIC41_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC41_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC41_TEXT->setWordWrap(true);

        horizontalLayout_20->addWidget(IDC_STATIC41_TEXT);

        m_Recv_X_2 = new QLabel(IDC_STATIC37_Group_box);
        m_Recv_X_2->setObjectName(QString::fromUtf8("m_Recv_X_2"));
        sizePolicy1.setHeightForWidth(m_Recv_X_2->sizePolicy().hasHeightForWidth());
        m_Recv_X_2->setSizePolicy(sizePolicy1);
        m_Recv_X_2->setFont(font);
        m_Recv_X_2->setMouseTracking(false);
        m_Recv_X_2->setFrameShape(QFrame::StyledPanel);
        m_Recv_X_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_20->addWidget(m_Recv_X_2);

        IDC_STATIC45_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC45_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC45_TEXT"));
        IDC_STATIC45_TEXT->setFont(font);
        IDC_STATIC45_TEXT->setMouseTracking(false);
        IDC_STATIC45_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC45_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_20->addWidget(IDC_STATIC45_TEXT);

        m_RecvSID_2 = new QLabel(IDC_STATIC37_Group_box);
        m_RecvSID_2->setObjectName(QString::fromUtf8("m_RecvSID_2"));
        sizePolicy1.setHeightForWidth(m_RecvSID_2->sizePolicy().hasHeightForWidth());
        m_RecvSID_2->setSizePolicy(sizePolicy1);
        m_RecvSID_2->setFont(font);
        m_RecvSID_2->setMouseTracking(false);
        m_RecvSID_2->setFrameShape(QFrame::StyledPanel);
        m_RecvSID_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_20->addWidget(m_RecvSID_2);

        horizontalLayout_20->setStretch(0, 200);
        horizontalLayout_20->setStretch(1, 400);
        horizontalLayout_20->setStretch(2, 200);
        horizontalLayout_20->setStretch(3, 400);

        verticalLayout_9->addLayout(horizontalLayout_20);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        IDC_STATIC42_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC42_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC42_TEXT"));
        IDC_STATIC42_TEXT->setFont(font);
        IDC_STATIC42_TEXT->setMouseTracking(false);
        IDC_STATIC42_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC42_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC42_TEXT->setWordWrap(true);

        horizontalLayout_21->addWidget(IDC_STATIC42_TEXT);

        m_Recv_Y_2 = new QLabel(IDC_STATIC37_Group_box);
        m_Recv_Y_2->setObjectName(QString::fromUtf8("m_Recv_Y_2"));
        sizePolicy1.setHeightForWidth(m_Recv_Y_2->sizePolicy().hasHeightForWidth());
        m_Recv_Y_2->setSizePolicy(sizePolicy1);
        m_Recv_Y_2->setFont(font);
        m_Recv_Y_2->setMouseTracking(false);
        m_Recv_Y_2->setFrameShape(QFrame::StyledPanel);
        m_Recv_Y_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_21->addWidget(m_Recv_Y_2);

        IDC_STATIC46_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC46_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC46_TEXT"));
        IDC_STATIC46_TEXT->setFont(font);
        IDC_STATIC46_TEXT->setMouseTracking(false);
        IDC_STATIC46_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC46_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_21->addWidget(IDC_STATIC46_TEXT);

        m_RecvDID_2 = new QLabel(IDC_STATIC37_Group_box);
        m_RecvDID_2->setObjectName(QString::fromUtf8("m_RecvDID_2"));
        sizePolicy1.setHeightForWidth(m_RecvDID_2->sizePolicy().hasHeightForWidth());
        m_RecvDID_2->setSizePolicy(sizePolicy1);
        m_RecvDID_2->setFont(font);
        m_RecvDID_2->setMouseTracking(false);
        m_RecvDID_2->setFrameShape(QFrame::StyledPanel);
        m_RecvDID_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_21->addWidget(m_RecvDID_2);

        horizontalLayout_21->setStretch(0, 200);
        horizontalLayout_21->setStretch(1, 400);
        horizontalLayout_21->setStretch(2, 200);
        horizontalLayout_21->setStretch(3, 400);

        verticalLayout_9->addLayout(horizontalLayout_21);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        IDC_STATIC43_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC43_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC43_TEXT"));
        IDC_STATIC43_TEXT->setFont(font);
        IDC_STATIC43_TEXT->setMouseTracking(false);
        IDC_STATIC43_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC43_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC43_TEXT->setWordWrap(true);

        horizontalLayout_22->addWidget(IDC_STATIC43_TEXT);

        m_Recv_Z_2 = new QLabel(IDC_STATIC37_Group_box);
        m_Recv_Z_2->setObjectName(QString::fromUtf8("m_Recv_Z_2"));
        sizePolicy1.setHeightForWidth(m_Recv_Z_2->sizePolicy().hasHeightForWidth());
        m_Recv_Z_2->setSizePolicy(sizePolicy1);
        m_Recv_Z_2->setFont(font);
        m_Recv_Z_2->setMouseTracking(false);
        m_Recv_Z_2->setFrameShape(QFrame::StyledPanel);
        m_Recv_Z_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_22->addWidget(m_Recv_Z_2);

        IDC_STATIC47_TEXT = new QLabel(IDC_STATIC37_Group_box);
        IDC_STATIC47_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC47_TEXT"));
        IDC_STATIC47_TEXT->setFont(font);
        IDC_STATIC47_TEXT->setMouseTracking(false);
        IDC_STATIC47_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC47_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_22->addWidget(IDC_STATIC47_TEXT);

        m_PackCount2 = new QLabel(IDC_STATIC37_Group_box);
        m_PackCount2->setObjectName(QString::fromUtf8("m_PackCount2"));
        sizePolicy1.setHeightForWidth(m_PackCount2->sizePolicy().hasHeightForWidth());
        m_PackCount2->setSizePolicy(sizePolicy1);
        m_PackCount2->setFont(font);
        m_PackCount2->setMouseTracking(false);
        m_PackCount2->setFrameShape(QFrame::StyledPanel);
        m_PackCount2->setFrameShadow(QFrame::Plain);

        horizontalLayout_22->addWidget(m_PackCount2);

        horizontalLayout_22->setStretch(0, 200);
        horizontalLayout_22->setStretch(1, 400);
        horizontalLayout_22->setStretch(2, 200);
        horizontalLayout_22->setStretch(3, 400);

        verticalLayout_9->addLayout(horizontalLayout_22);


        verticalLayout_10->addLayout(verticalLayout_9);


        horizontalLayout_28->addWidget(IDC_STATIC37_Group_box);

        IDC_STATIC58_Group_box_2 = new QGroupBox(CDlg_MsgDisplay);
        IDC_STATIC58_Group_box_2->setObjectName(QString::fromUtf8("IDC_STATIC58_Group_box_2"));
        verticalLayout_12 = new QVBoxLayout(IDC_STATIC58_Group_box_2);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        IDC_STATIC59_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC59_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC59_TEXT"));
        IDC_STATIC59_TEXT->setFont(font);
        IDC_STATIC59_TEXT->setMouseTracking(false);
        IDC_STATIC59_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC59_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_23->addWidget(IDC_STATIC59_TEXT);

        m_Send_Time_1 = new QLabel(IDC_STATIC58_Group_box_2);
        m_Send_Time_1->setObjectName(QString::fromUtf8("m_Send_Time_1"));
        sizePolicy1.setHeightForWidth(m_Send_Time_1->sizePolicy().hasHeightForWidth());
        m_Send_Time_1->setSizePolicy(sizePolicy1);
        m_Send_Time_1->setFont(font);
        m_Send_Time_1->setMouseTracking(false);
        m_Send_Time_1->setFrameShape(QFrame::StyledPanel);
        m_Send_Time_1->setFrameShadow(QFrame::Plain);

        horizontalLayout_23->addWidget(m_Send_Time_1);

        IDC_STATIC60_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC60_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC60_TEXT"));
        IDC_STATIC60_TEXT->setFont(font);
        IDC_STATIC60_TEXT->setMouseTracking(false);
        IDC_STATIC60_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC60_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_23->addWidget(IDC_STATIC60_TEXT);

        m_Send_Time_2 = new QLabel(IDC_STATIC58_Group_box_2);
        m_Send_Time_2->setObjectName(QString::fromUtf8("m_Send_Time_2"));
        sizePolicy1.setHeightForWidth(m_Send_Time_2->sizePolicy().hasHeightForWidth());
        m_Send_Time_2->setSizePolicy(sizePolicy1);
        m_Send_Time_2->setFont(font);
        m_Send_Time_2->setMouseTracking(false);
        m_Send_Time_2->setFrameShape(QFrame::StyledPanel);
        m_Send_Time_2->setFrameShadow(QFrame::Plain);

        horizontalLayout_23->addWidget(m_Send_Time_2);

        horizontalLayout_23->setStretch(0, 100);
        horizontalLayout_23->setStretch(1, 200);
        horizontalLayout_23->setStretch(2, 100);
        horizontalLayout_23->setStretch(3, 200);

        verticalLayout_11->addLayout(horizontalLayout_23);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        IDC_STATIC61_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC61_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC61_TEXT"));
        IDC_STATIC61_TEXT->setFont(font);
        IDC_STATIC61_TEXT->setMouseTracking(false);
        IDC_STATIC61_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC61_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_24->addWidget(IDC_STATIC61_TEXT);

        m_Send_A = new QLabel(IDC_STATIC58_Group_box_2);
        m_Send_A->setObjectName(QString::fromUtf8("m_Send_A"));
        sizePolicy1.setHeightForWidth(m_Send_A->sizePolicy().hasHeightForWidth());
        m_Send_A->setSizePolicy(sizePolicy1);
        m_Send_A->setFont(font);
        m_Send_A->setMouseTracking(false);
        m_Send_A->setFrameShape(QFrame::StyledPanel);
        m_Send_A->setFrameShadow(QFrame::Plain);

        horizontalLayout_24->addWidget(m_Send_A);

        IDC_STATIC65_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC65_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC65_TEXT"));
        IDC_STATIC65_TEXT->setFont(font);
        IDC_STATIC65_TEXT->setMouseTracking(false);
        IDC_STATIC65_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC65_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_24->addWidget(IDC_STATIC65_TEXT);

        m_SendMID = new QLabel(IDC_STATIC58_Group_box_2);
        m_SendMID->setObjectName(QString::fromUtf8("m_SendMID"));
        sizePolicy1.setHeightForWidth(m_SendMID->sizePolicy().hasHeightForWidth());
        m_SendMID->setSizePolicy(sizePolicy1);
        m_SendMID->setFont(font);
        m_SendMID->setMouseTracking(false);
        m_SendMID->setFrameShape(QFrame::StyledPanel);
        m_SendMID->setFrameShadow(QFrame::Plain);

        horizontalLayout_24->addWidget(m_SendMID);

        horizontalLayout_24->setStretch(0, 100);
        horizontalLayout_24->setStretch(1, 200);
        horizontalLayout_24->setStretch(2, 100);
        horizontalLayout_24->setStretch(3, 200);

        verticalLayout_11->addLayout(horizontalLayout_24);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        IDC_STATIC62_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC62_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC62_TEXT"));
        IDC_STATIC62_TEXT->setFont(font);
        IDC_STATIC62_TEXT->setMouseTracking(false);
        IDC_STATIC62_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC62_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC62_TEXT->setWordWrap(true);

        horizontalLayout_25->addWidget(IDC_STATIC62_TEXT);

        m_Send_E = new QLabel(IDC_STATIC58_Group_box_2);
        m_Send_E->setObjectName(QString::fromUtf8("m_Send_E"));
        sizePolicy1.setHeightForWidth(m_Send_E->sizePolicy().hasHeightForWidth());
        m_Send_E->setSizePolicy(sizePolicy1);
        m_Send_E->setFont(font);
        m_Send_E->setMouseTracking(false);
        m_Send_E->setFrameShape(QFrame::StyledPanel);
        m_Send_E->setFrameShadow(QFrame::Plain);

        horizontalLayout_25->addWidget(m_Send_E);

        IDC_STATIC66_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC66_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC66_TEXT"));
        IDC_STATIC66_TEXT->setFont(font);
        IDC_STATIC66_TEXT->setMouseTracking(false);
        IDC_STATIC66_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC66_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_25->addWidget(IDC_STATIC66_TEXT);

        m_SendSID = new QLabel(IDC_STATIC58_Group_box_2);
        m_SendSID->setObjectName(QString::fromUtf8("m_SendSID"));
        sizePolicy1.setHeightForWidth(m_SendSID->sizePolicy().hasHeightForWidth());
        m_SendSID->setSizePolicy(sizePolicy1);
        m_SendSID->setFont(font);
        m_SendSID->setMouseTracking(false);
        m_SendSID->setFrameShape(QFrame::StyledPanel);
        m_SendSID->setFrameShadow(QFrame::Plain);

        horizontalLayout_25->addWidget(m_SendSID);

        horizontalLayout_25->setStretch(0, 100);
        horizontalLayout_25->setStretch(1, 200);
        horizontalLayout_25->setStretch(2, 100);
        horizontalLayout_25->setStretch(3, 200);

        verticalLayout_11->addLayout(horizontalLayout_25);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        IDC_STATIC63_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC63_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC63_TEXT"));
        IDC_STATIC63_TEXT->setFont(font);
        IDC_STATIC63_TEXT->setMouseTracking(false);
        IDC_STATIC63_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC63_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC63_TEXT->setWordWrap(true);

        horizontalLayout_26->addWidget(IDC_STATIC63_TEXT);

        m_Send_Mode = new QLabel(IDC_STATIC58_Group_box_2);
        m_Send_Mode->setObjectName(QString::fromUtf8("m_Send_Mode"));
        sizePolicy1.setHeightForWidth(m_Send_Mode->sizePolicy().hasHeightForWidth());
        m_Send_Mode->setSizePolicy(sizePolicy1);
        m_Send_Mode->setFont(font);
        m_Send_Mode->setMouseTracking(false);
        m_Send_Mode->setFrameShape(QFrame::StyledPanel);
        m_Send_Mode->setFrameShadow(QFrame::Plain);

        horizontalLayout_26->addWidget(m_Send_Mode);

        IDC_STATIC67_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC67_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC67_TEXT"));
        IDC_STATIC67_TEXT->setFont(font);
        IDC_STATIC67_TEXT->setMouseTracking(false);
        IDC_STATIC67_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC67_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_26->addWidget(IDC_STATIC67_TEXT);

        m_SendDID = new QLabel(IDC_STATIC58_Group_box_2);
        m_SendDID->setObjectName(QString::fromUtf8("m_SendDID"));
        sizePolicy1.setHeightForWidth(m_SendDID->sizePolicy().hasHeightForWidth());
        m_SendDID->setSizePolicy(sizePolicy1);
        m_SendDID->setFont(font);
        m_SendDID->setMouseTracking(false);
        m_SendDID->setFrameShape(QFrame::StyledPanel);
        m_SendDID->setFrameShadow(QFrame::Plain);

        horizontalLayout_26->addWidget(m_SendDID);

        horizontalLayout_26->setStretch(0, 100);
        horizontalLayout_26->setStretch(1, 200);
        horizontalLayout_26->setStretch(2, 100);
        horizontalLayout_26->setStretch(3, 200);

        verticalLayout_11->addLayout(horizontalLayout_26);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        IDC_STATIC64_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC64_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC64_TEXT"));
        IDC_STATIC64_TEXT->setFont(font);
        IDC_STATIC64_TEXT->setMouseTracking(false);
        IDC_STATIC64_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC64_TEXT->setFrameShadow(QFrame::Plain);
        IDC_STATIC64_TEXT->setWordWrap(true);

        horizontalLayout_27->addWidget(IDC_STATIC64_TEXT);

        m_Send_Offset = new QLabel(IDC_STATIC58_Group_box_2);
        m_Send_Offset->setObjectName(QString::fromUtf8("m_Send_Offset"));
        sizePolicy1.setHeightForWidth(m_Send_Offset->sizePolicy().hasHeightForWidth());
        m_Send_Offset->setSizePolicy(sizePolicy1);
        m_Send_Offset->setFont(font);
        m_Send_Offset->setMouseTracking(false);
        m_Send_Offset->setFrameShape(QFrame::StyledPanel);
        m_Send_Offset->setFrameShadow(QFrame::Plain);

        horizontalLayout_27->addWidget(m_Send_Offset);

        IDC_STATIC68_TEXT = new QLabel(IDC_STATIC58_Group_box_2);
        IDC_STATIC68_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC68_TEXT"));
        IDC_STATIC68_TEXT->setFont(font);
        IDC_STATIC68_TEXT->setMouseTracking(false);
        IDC_STATIC68_TEXT->setFrameShape(QFrame::NoFrame);
        IDC_STATIC68_TEXT->setFrameShadow(QFrame::Plain);

        horizontalLayout_27->addWidget(IDC_STATIC68_TEXT);

        m_PackCount3 = new QLabel(IDC_STATIC58_Group_box_2);
        m_PackCount3->setObjectName(QString::fromUtf8("m_PackCount3"));
        sizePolicy1.setHeightForWidth(m_PackCount3->sizePolicy().hasHeightForWidth());
        m_PackCount3->setSizePolicy(sizePolicy1);
        m_PackCount3->setFont(font);
        m_PackCount3->setMouseTracking(false);
        m_PackCount3->setFrameShape(QFrame::StyledPanel);
        m_PackCount3->setFrameShadow(QFrame::Plain);

        horizontalLayout_27->addWidget(m_PackCount3);

        horizontalLayout_27->setStretch(0, 100);
        horizontalLayout_27->setStretch(1, 200);
        horizontalLayout_27->setStretch(2, 100);
        horizontalLayout_27->setStretch(3, 200);

        verticalLayout_11->addLayout(horizontalLayout_27);


        verticalLayout_12->addLayout(verticalLayout_11);


        horizontalLayout_28->addWidget(IDC_STATIC58_Group_box_2);


        verticalLayout_3->addLayout(horizontalLayout_28);


        horizontalLayout_6->addLayout(verticalLayout_3);

        line1_2 = new QFrame(CDlg_MsgDisplay);
        line1_2->setObjectName(QString::fromUtf8("line1_2"));
        line1_2->setFrameShape(QFrame::HLine);
        line1_2->setFrameShadow(QFrame::Sunken);

        horizontalLayout_6->addWidget(line1_2);

        line1_3 = new QFrame(CDlg_MsgDisplay);
        line1_3->setObjectName(QString::fromUtf8("line1_3"));
        line1_3->setFrameShape(QFrame::HLine);
        line1_3->setFrameShadow(QFrame::Sunken);

        horizontalLayout_6->addWidget(line1_3);


        retranslateUi(CDlg_MsgDisplay);

        QMetaObject::connectSlotsByName(CDlg_MsgDisplay);
    } // setupUi

    void retranslateUi(QDialog *CDlg_MsgDisplay)
    {
        CDlg_MsgDisplay->setWindowTitle(QApplication::translate("CDlg_MsgDisplay", "Dialog", 0, QApplication::UnicodeUTF8));
        IDC_STATIC1_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\216\245\346\224\266\345\214\2721\357\274\232 ", 0, QApplication::UnicodeUTF8));
        m_StType1->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\347\261\273\345\236\213 ", 0, QApplication::UnicodeUTF8));
        m_SetWayAutoHandle->setText(QApplication::translate("CDlg_MsgDisplay", "\346\230\257\345\220\246\346\211\213\345\267\245\351\200\211\346\213\251\350\267\257\347\224\261", 0, QApplication::UnicodeUTF8));
        m_WayChosen->setText(QApplication::translate("CDlg_MsgDisplay", "\345\273\272\350\256\256\344\275\277\347\224\250\350\207\252\345\212\250\346\226\271\345\274\217", 0, QApplication::UnicodeUTF8));
        IDC_STATIC2_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256 ", 0, QApplication::UnicodeUTF8));
        IDC_STATIC3_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221", 0, QApplication::UnicodeUTF8));
        m_Select_1->setText(QApplication::translate("CDlg_MsgDisplay", "\351\200\211\346\213\251\346\234\254\350\267\257\346\225\260\346\215\256", 0, QApplication::UnicodeUTF8));
        m_NetStatus1->setText(QApplication::translate("CDlg_MsgDisplay", "<html><head/><body><p><img src=\":/myImage/Images/Netstatus1.bmp\"/></p></body></html>", 0, QApplication::UnicodeUTF8));
        IDC_STATIC3_TEXT_3->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\216\245\346\224\266\345\214\2722\357\274\232", 0, QApplication::UnicodeUTF8));
        m_StType2->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\347\261\273\345\236\213 ", 0, QApplication::UnicodeUTF8));
        label_2->setText(QString());
        label->setText(QString());
        IDC_STATIC4_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256 ", 0, QApplication::UnicodeUTF8));
        IDC_STATIC5_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221", 0, QApplication::UnicodeUTF8));
        m_Select_2->setText(QApplication::translate("CDlg_MsgDisplay", "\351\200\211\346\213\251\346\234\254\350\267\257\346\225\260\346\215\256", 0, QApplication::UnicodeUTF8));
        m_NetStatus2->setText(QApplication::translate("CDlg_MsgDisplay", "<html><head/><body><p><img src=\":/myImage/Images/Netstatus1.bmp\"/></p></body></html>", 0, QApplication::UnicodeUTF8));
        IDC_STATIC6_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\345\217\221\351\200\201\345\214\272\357\274\232", 0, QApplication::UnicodeUTF8));
        IDC_STATIC7_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256 ", 0, QApplication::UnicodeUTF8));
        m_ChkSend1->setText(QApplication::translate("CDlg_MsgDisplay", "\350\267\257\347\224\2611\345\217\221\351\200\201\344\270\255", 0, QApplication::UnicodeUTF8));
        IDC_STATIC8_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221", 0, QApplication::UnicodeUTF8));
        m_ChkSend2->setText(QApplication::translate("CDlg_MsgDisplay", "\350\267\257\347\224\2612\345\217\221\351\200\201\344\270\255", 0, QApplication::UnicodeUTF8));
        m_StIndexInfo->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\200\273\351\207\217\346\217\220\347\244\272", 0, QApplication::UnicodeUTF8));
        m_BuffetLeftLength->setText(QApplication::translate("CDlg_MsgDisplay", "\347\274\223\345\206\262\345\214\272\346\217\220\347\244\272", 0, QApplication::UnicodeUTF8));
        m_LagTime->setText(QApplication::translate("CDlg_MsgDisplay", "\346\227\266\345\273\266", 0, QApplication::UnicodeUTF8));
        IDC_STATIC16_Group_box->setTitle(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\216\245\346\224\266\345\214\272", 0, QApplication::UnicodeUTF8));
        IDC_STATIC17_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\216\245\346\224\266\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        m_Recv_Time_1_1->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        IDC_STATIC18_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        m_Recv_Time_1_2->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        IDC_STATIC19_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "T0\346\227\266\345\210\273", 0, QApplication::UnicodeUTF8));
        m_RecvT0_1->setText(QApplication::translate("CDlg_MsgDisplay", "T0", 0, QApplication::UnicodeUTF8));
        IDC_STATIC23_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "MID", 0, QApplication::UnicodeUTF8));
        m_RecvMID_1->setText(QApplication::translate("CDlg_MsgDisplay", "MID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC20_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\274\225\345\257\274\345\234\260\345\277\203X", 0, QApplication::UnicodeUTF8));
        m_Recv_X_1->setText(QApplication::translate("CDlg_MsgDisplay", "X", 0, QApplication::UnicodeUTF8));
        IDC_STATIC24_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "SID", 0, QApplication::UnicodeUTF8));
        m_RecvSID_1->setText(QApplication::translate("CDlg_MsgDisplay", "SID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC21_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\274\225\345\257\274\345\234\260\345\277\203Y", 0, QApplication::UnicodeUTF8));
        m_Recv_Y_1->setText(QApplication::translate("CDlg_MsgDisplay", "Y", 0, QApplication::UnicodeUTF8));
        IDC_STATIC25_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "DID", 0, QApplication::UnicodeUTF8));
        m_RecvDID_1->setText(QApplication::translate("CDlg_MsgDisplay", "DID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC22_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\274\225\345\257\274\345\234\260\345\277\203Y", 0, QApplication::UnicodeUTF8));
        m_Recv_Z_1->setText(QApplication::translate("CDlg_MsgDisplay", "Z", 0, QApplication::UnicodeUTF8));
        IDC_STATIC26_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\216\245\345\217\227\347\273\237\350\256\241", 0, QApplication::UnicodeUTF8));
        m_PackCount1->setText(QApplication::translate("CDlg_MsgDisplay", "\345\214\205\346\225\260\351\207\217", 0, QApplication::UnicodeUTF8));
        IDC_STATIC37_Group_box->setTitle(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\216\245\346\224\266\345\214\272", 0, QApplication::UnicodeUTF8));
        IDC_STATIC38_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\216\245\346\224\266\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        m_Recv_Time_2_1->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        IDC_STATIC39_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        m_Recv_Time_2_2->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        IDC_STATIC40_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "T0\346\227\266\345\210\273", 0, QApplication::UnicodeUTF8));
        m_RecvT0_2->setText(QApplication::translate("CDlg_MsgDisplay", "T0", 0, QApplication::UnicodeUTF8));
        IDC_STATIC44_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "MID", 0, QApplication::UnicodeUTF8));
        m_RecvMID_2->setText(QApplication::translate("CDlg_MsgDisplay", "MID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC41_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\274\225\345\257\274\345\234\260\345\277\203X", 0, QApplication::UnicodeUTF8));
        m_Recv_X_2->setText(QApplication::translate("CDlg_MsgDisplay", "X", 0, QApplication::UnicodeUTF8));
        IDC_STATIC45_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "SID", 0, QApplication::UnicodeUTF8));
        m_RecvSID_2->setText(QApplication::translate("CDlg_MsgDisplay", "SID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC42_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\274\225\345\257\274\345\234\260\345\277\203Y", 0, QApplication::UnicodeUTF8));
        m_Recv_Y_2->setText(QApplication::translate("CDlg_MsgDisplay", "Y", 0, QApplication::UnicodeUTF8));
        IDC_STATIC46_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "DID", 0, QApplication::UnicodeUTF8));
        m_RecvDID_2->setText(QApplication::translate("CDlg_MsgDisplay", "DID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC43_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\274\225\345\257\274\345\234\260\345\277\203Y", 0, QApplication::UnicodeUTF8));
        m_Recv_Z_2->setText(QApplication::translate("CDlg_MsgDisplay", "Z", 0, QApplication::UnicodeUTF8));
        IDC_STATIC47_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\216\245\345\217\227\347\273\237\350\256\241", 0, QApplication::UnicodeUTF8));
        m_PackCount2->setText(QApplication::translate("CDlg_MsgDisplay", "\345\214\205\346\225\260\351\207\217", 0, QApplication::UnicodeUTF8));
        IDC_STATIC58_Group_box_2->setTitle(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\345\217\221\351\200\201\345\214\272", 0, QApplication::UnicodeUTF8));
        IDC_STATIC59_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\217\221\351\200\201\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        m_Send_Time_1->setText(QApplication::translate("CDlg_MsgDisplay", "\346\225\260\346\215\256\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        IDC_STATIC60_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        m_Send_Time_2->setText(QApplication::translate("CDlg_MsgDisplay", " \351\223\276\347\233\221\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        IDC_STATIC61_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\346\226\271\344\275\215\350\247\222", 0, QApplication::UnicodeUTF8));
        m_Send_A->setText(QApplication::translate("CDlg_MsgDisplay", "A", 0, QApplication::UnicodeUTF8));
        IDC_STATIC65_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "MID", 0, QApplication::UnicodeUTF8));
        m_SendMID->setText(QApplication::translate("CDlg_MsgDisplay", "MID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC62_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\344\277\257\344\273\260\350\247\222", 0, QApplication::UnicodeUTF8));
        m_Send_E->setText(QApplication::translate("CDlg_MsgDisplay", "E", 0, QApplication::UnicodeUTF8));
        IDC_STATIC66_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "SID", 0, QApplication::UnicodeUTF8));
        m_SendSID->setText(QApplication::translate("CDlg_MsgDisplay", "SID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC63_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\344\274\272\346\234\215\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
        m_Send_Mode->setText(QApplication::translate("CDlg_MsgDisplay", "mode", 0, QApplication::UnicodeUTF8));
        IDC_STATIC67_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "DID", 0, QApplication::UnicodeUTF8));
        m_SendDID->setText(QApplication::translate("CDlg_MsgDisplay", "DID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC64_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\350\204\261\351\235\266\351\207\217\357\274\210\347\247\222\357\274\211", 0, QApplication::UnicodeUTF8));
        m_Send_Offset->setText(QApplication::translate("CDlg_MsgDisplay", "offset", 0, QApplication::UnicodeUTF8));
        IDC_STATIC68_TEXT->setText(QApplication::translate("CDlg_MsgDisplay", "\345\217\221\351\200\201\347\273\237\350\256\241", 0, QApplication::UnicodeUTF8));
        m_PackCount3->setText(QApplication::translate("CDlg_MsgDisplay", "\345\214\205\346\225\260\351\207\217", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CDlg_MsgDisplay: public Ui_CDlg_MsgDisplay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CDLG_MSGDISPLAY_H
