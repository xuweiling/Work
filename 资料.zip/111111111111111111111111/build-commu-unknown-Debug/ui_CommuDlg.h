/********************************************************************************
** Form generated from reading UI file 'CommuDlg.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COMMUDLG_H
#define UI_COMMUDLG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CCommuDlg
{
public:
    QVBoxLayout *verticalLayout_8;
    QVBoxLayout *verticalLayout_7;
    QTabWidget *tabWidget;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *m_Connect;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout_4;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *m_Cancel;
    QSpacerItem *horizontalSpacer_3;
    QVBoxLayout *verticalLayout;
    QCheckBox *m_StatusSwitch;
    QCheckBox *m_StatusSwitch2;
    QVBoxLayout *verticalLayout_5;
    QPushButton *m_SendExam;
    QHBoxLayout *horizontalLayout_3;
    QLabel *IDC_STATIC2_TEXT;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *horizontalSpacer_5;
    QVBoxLayout *verticalLayout_2;
    QLabel *m_ExamResult;
    QLabel *STATIC_SLIDER23_TEXT;
    QHBoxLayout *horizontalLayout_5;
    QLabel *m_Tooltip;
    QSpacerItem *horizontalSpacer_6;

    void setupUi(QWidget *CCommuDlg)
    {
        if (CCommuDlg->objectName().isEmpty())
            CCommuDlg->setObjectName(QString::fromUtf8("CCommuDlg"));
        CCommuDlg->resize(1198, 904);
        verticalLayout_8 = new QVBoxLayout(CCommuDlg);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        tabWidget = new QTabWidget(CCommuDlg);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));

        verticalLayout_7->addWidget(tabWidget);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalSpacer = new QSpacerItem(168, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_3->addItem(horizontalSpacer);

        horizontalSpacer_8 = new QSpacerItem(168, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_3->addItem(horizontalSpacer_8);


        horizontalLayout->addLayout(verticalLayout_3);

        m_Connect = new QPushButton(CCommuDlg);
        m_Connect->setObjectName(QString::fromUtf8("m_Connect"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_Connect->sizePolicy().hasHeightForWidth());
        m_Connect->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(m_Connect);

        horizontalLayout->setStretch(0, 60);
        horizontalLayout->setStretch(1, 61);

        horizontalLayout_4->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalSpacer_2 = new QSpacerItem(98, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_4->addItem(horizontalSpacer_2);

        horizontalSpacer_9 = new QSpacerItem(98, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_4->addItem(horizontalSpacer_9);


        horizontalLayout_2->addLayout(verticalLayout_4);

        m_Cancel = new QPushButton(CCommuDlg);
        m_Cancel->setObjectName(QString::fromUtf8("m_Cancel"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_Cancel->sizePolicy().hasHeightForWidth());
        m_Cancel->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(m_Cancel);

        horizontalLayout_2->setStretch(0, 1);
        horizontalLayout_2->setStretch(1, 2);

        horizontalLayout_4->addLayout(horizontalLayout_2);

        horizontalSpacer_3 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        m_StatusSwitch = new QCheckBox(CCommuDlg);
        m_StatusSwitch->setObjectName(QString::fromUtf8("m_StatusSwitch"));

        verticalLayout->addWidget(m_StatusSwitch);

        m_StatusSwitch2 = new QCheckBox(CCommuDlg);
        m_StatusSwitch2->setObjectName(QString::fromUtf8("m_StatusSwitch2"));

        verticalLayout->addWidget(m_StatusSwitch2);


        horizontalLayout_4->addLayout(verticalLayout);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        m_SendExam = new QPushButton(CCommuDlg);
        m_SendExam->setObjectName(QString::fromUtf8("m_SendExam"));

        verticalLayout_5->addWidget(m_SendExam);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        IDC_STATIC2_TEXT = new QLabel(CCommuDlg);
        IDC_STATIC2_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC2_TEXT"));
        IDC_STATIC2_TEXT->setFrameShape(QFrame::StyledPanel);

        horizontalLayout_3->addWidget(IDC_STATIC2_TEXT);

        horizontalSpacer_4 = new QSpacerItem(98, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);


        verticalLayout_5->addLayout(horizontalLayout_3);


        horizontalLayout_4->addLayout(verticalLayout_5);

        horizontalSpacer_5 = new QSpacerItem(178, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_5);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        m_ExamResult = new QLabel(CCommuDlg);
        m_ExamResult->setObjectName(QString::fromUtf8("m_ExamResult"));
        m_ExamResult->setFrameShape(QFrame::StyledPanel);

        verticalLayout_2->addWidget(m_ExamResult);

        STATIC_SLIDER23_TEXT = new QLabel(CCommuDlg);
        STATIC_SLIDER23_TEXT->setObjectName(QString::fromUtf8("STATIC_SLIDER23_TEXT"));
        STATIC_SLIDER23_TEXT->setFrameShape(QFrame::StyledPanel);

        verticalLayout_2->addWidget(STATIC_SLIDER23_TEXT);


        horizontalLayout_4->addLayout(verticalLayout_2);


        verticalLayout_6->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        m_Tooltip = new QLabel(CCommuDlg);
        m_Tooltip->setObjectName(QString::fromUtf8("m_Tooltip"));
        m_Tooltip->setFrameShape(QFrame::StyledPanel);

        horizontalLayout_5->addWidget(m_Tooltip);

        horizontalSpacer_6 = new QSpacerItem(118, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_6);

        horizontalLayout_5->setStretch(0, 2);
        horizontalLayout_5->setStretch(1, 1);

        verticalLayout_6->addLayout(horizontalLayout_5);


        verticalLayout_7->addLayout(verticalLayout_6);

        verticalLayout_7->setStretch(0, 100);
        verticalLayout_7->setStretch(1, 1);

        verticalLayout_8->addLayout(verticalLayout_7);

        IDC_STATIC2_TEXT->raise();
        tabWidget->raise();
        m_Tooltip->raise();
        m_StatusSwitch->raise();
        m_StatusSwitch2->raise();
        m_Connect->raise();
        m_Cancel->raise();
        m_SendExam->raise();
        m_ExamResult->raise();
        STATIC_SLIDER23_TEXT->raise();
        m_Tooltip->raise();

        retranslateUi(CCommuDlg);

        tabWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(CCommuDlg);
    } // setupUi

    void retranslateUi(QWidget *CCommuDlg)
    {
        CCommuDlg->setWindowTitle(QApplication::translate("CCommuDlg", "\347\275\221\347\273\234\351\200\232\344\277\241", 0, QApplication::UnicodeUTF8));
        m_Connect->setText(QApplication::translate("CCommuDlg", "\350\277\236\346\216\245", 0, QApplication::UnicodeUTF8));
        m_Cancel->setText(QApplication::translate("CCommuDlg", "\345\205\263\351\227\255", 0, QApplication::UnicodeUTF8));
        m_StatusSwitch->setText(QApplication::translate("CCommuDlg", "\344\270\216\347\233\221\346\216\247\346\234\272\345\210\207\346\215\242\344\270\272\350\260\203\350\257\225\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
        m_StatusSwitch2->setText(QApplication::translate("CCommuDlg", "\344\270\216\346\234\254\345\234\260\345\210\207\346\215\242\344\270\272\350\260\203\350\257\225\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
        m_SendExam->setText(QApplication::translate("CCommuDlg", "\344\270\273\345\212\250\345\217\221\350\265\267\346\227\266\345\273\266\346\265\213\350\257\225", 0, QApplication::UnicodeUTF8));
        IDC_STATIC2_TEXT->setText(QApplication::translate("CCommuDlg", "J", 0, QApplication::UnicodeUTF8));
        m_ExamResult->setText(QApplication::translate("CCommuDlg", "\346\227\266\345\273\266\346\265\213\350\257\225\347\273\223\346\236\234", 0, QApplication::UnicodeUTF8));
        STATIC_SLIDER23_TEXT->setText(QApplication::translate("CCommuDlg", "V3.0", 0, QApplication::UnicodeUTF8));
        m_Tooltip->setText(QApplication::translate("CCommuDlg", "TODO\357\274\232\347\255\211\345\276\205\345\220\257\345\212\250", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CCommuDlg: public Ui_CCommuDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COMMUDLG_H
