/********************************************************************************
** Form generated from reading UI file 'commu.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COMMU_H
#define UI_COMMU_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_commu
{
public:
    QVBoxLayout *verticalLayout_15;
    QHBoxLayout *horizontalLayout_28;
    QGroupBox *IDC_STATIC13_Group_box;
    QVBoxLayout *verticalLayout_14;
    QVBoxLayout *verticalLayout_9;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QPushButton *IDC_BUTTON_SETSOURCE;
    QTableWidget *m_AddList1;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *IDC_STATIC15_TEXT;
    QLabel *IDC_STATIC44_TEXT;
    QLabel *IDC_STATIC45_TEXT;
    QHBoxLayout *horizontalLayout_3;
    QTableWidget *m_Addlist2_1;
    QTableWidget *m_Addlist2_2;
    QHBoxLayout *horizontalLayout_26;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *IDC_STATIC7_TEXT;
    QLineEdit *m_NewIP1;
    QHBoxLayout *horizontalLayout_5;
    QLabel *IDC_STATIC5_TEXT;
    QLineEdit *IDC_EDIT_NPRECEIVE1;
    QLabel *IDC_STATIC4_TEXT;
    QLineEdit *IDC_EDIT_NPSEND1;
    QHBoxLayout *horizontalLayout_6;
    QLabel *IDC_STATIC8_TEXT;
    QLineEdit *m_NewDID1;
    QGroupBox *IDC_STATIC22_TEXT;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_7;
    QRadioButton *m_WayNo1;
    QRadioButton *m_WayNo1_2;
    QHBoxLayout *horizontalLayout_8;
    QLabel *IDC_STATIC9_TEXT;
    QLineEdit *m_NewName1;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_27;
    QLabel *IDC_STATIC18;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_14;
    QLabel *IDC_STATIC19_TEXT;
    QLineEdit *m_NewIP2;
    QHBoxLayout *horizontalLayout_15;
    QLabel *IDC_STATIC17_TEXT;
    QLineEdit *IDC_EDIT_NPRECEIVE2;
    QLabel *IDC_STATIC16_TEXT;
    QLineEdit *IDC_EDIT_NPSEND2;
    QHBoxLayout *horizontalLayout_16;
    QLabel *IDC_STATIC20_TEXT;
    QLineEdit *m_NewDID2;
    QGroupBox *IDC_STATIC23_TEXT;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_17;
    QRadioButton *m_WayNo2;
    QRadioButton *m_WayNo2_2;
    QHBoxLayout *horizontalLayout_18;
    QLabel *IDC_STATIC21_TEXT;
    QLineEdit *m_NewName2;
    QHBoxLayout *horizontalLayout_25;
    QVBoxLayout *verticalLayout_12;
    QSpacerItem *horizontalSpacer_2;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_22;
    QLabel *IDC_STATIC10_TEXT;
    QHBoxLayout *horizontalLayout_24;
    QPushButton *ADD_NEWADD1;
    QPushButton *ADD_DELADD1;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_20;
    QLabel *IDC_STATIC46_TEXT;
    QPushButton *ADD_NEWADD2_1;
    QPushButton *ADD_DELADD2_1;
    QHBoxLayout *horizontalLayout_21;
    QLabel *IDC_STATIC47_TEXT;
    QPushButton *ADD_NEWADD2_2;
    QPushButton *ADD_DELADD2_2;
    QPushButton *MULTICASTSOURCE;
    QVBoxLayout *verticalLayout_24;
    QGroupBox *IDC_STATIC88_Group_box;
    QVBoxLayout *verticalLayout_19;
    QVBoxLayout *verticalLayout_17;
    QHBoxLayout *horizontalLayout_9;
    QLabel *IDC_STATIC24_TEXT;
    QLineEdit *m_LocaltoCT_IP1;
    QLabel *IDC_STATIC12_TEXT;
    QLineEdit *m_RecvCTPort;
    QHBoxLayout *horizontalLayout_38;
    QLabel *IDC_STATIC25_TEXT;
    QLineEdit *m_LocaltoCT_IP2;
    QLabel *IDC_STATIC11_TEXT;
    QLineEdit *m_SendCTPort;
    QGroupBox *IDC_STATIC68_Group_box;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_11;
    QRadioButton *m_SendSocketTP;
    QRadioButton *m_SendSocketTP2;
    QRadioButton *m_SendSocketTP3;
    QGroupBox *IDC_STATIC99_Group_box;
    QVBoxLayout *verticalLayout_16;
    QHBoxLayout *horizontalLayout_12;
    QRadioButton *m_RecvSocketTP;
    QRadioButton *m_RecvSocketTP2;
    QRadioButton *m_RecvSocketTP3;
    QHBoxLayout *horizontalLayout_13;
    QLabel *IDC_STATIC1_TEXT;
    QLineEdit *m_ZKIP;
    QLabel *IDC_STATIC3_TEXT;
    QLineEdit *m_ZKPort;
    QHBoxLayout *horizontalLayout_23;
    QLabel *IDC_STATIC14_TEXT;
    QLineEdit *m_LocaltoZK_IP;
    QLabel *IDC_STATIC3_TEXT_4;
    QLabel *IDC_STATIC3_TEXT_5;
    QGroupBox *IDC_STATIC39_Group_box;
    QVBoxLayout *verticalLayout_23;
    QVBoxLayout *verticalLayout_20;
    QGroupBox *IDC_STATIC26_Group_box;
    QVBoxLayout *verticalLayout_22;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_29;
    QLabel *IDC_STATIC27_TEXT;
    QLineEdit *m_stVersion;
    QLabel *IDC_STATIC28_TEXT;
    QLineEdit *m__stMID;
    QLabel *IDC_STATIC41_TEXT;
    QLineEdit *m_stMID_T;
    QHBoxLayout *horizontalLayout_30;
    QLabel *IDC_STATIC29_TEXT;
    QLineEdit *m_stSID;
    QLabel *IDC_STATIC33_TEXT;
    QLineEdit *m_stBIDMeasure;
    QLabel *IDC_STATIC34_TEXT;
    QLineEdit *m_stBIDTimer;
    QHBoxLayout *horizontalLayout_31;
    QLabel *IDC_STATIC35_TEXT;
    QLineEdit *m__stBIDExam;
    QLabel *IDC_STATIC31_TEXT;
    QLineEdit *m__stBIDTO;
    QLabel *IDC_STATIC30_TEXT;
    QLineEdit *m_stDID;
    QHBoxLayout *horizontalLayout_32;
    QLabel *IDC_STATIC32_TEXT;
    QLineEdit *m_stBIDWyd1;
    QLineEdit *m_stBIDWyd2;
    QLineEdit *m_stBIDWyd3;
    QLineEdit *m_stBIDWyd4;
    QLineEdit *m_stBIDWyd5;
    QHBoxLayout *horizontalLayout_33;
    QLabel *IDC_STATIC32_TEXT_2;
    QPushButton *Setup_TIP;
    QLineEdit *m_stBIDWyd6;
    QLineEdit *m_stBIDWyd7;
    QLineEdit *m_stBIDWyd8;
    QLineEdit *m_stBIDWyd9;
    QGroupBox *IDC_STATIC36_Group_box;
    QVBoxLayout *verticalLayout_21;
    QVBoxLayout *verticalLayout_13;
    QHBoxLayout *horizontalLayout_34;
    QLabel *IDC_STATIC37_TEXT;
    QComboBox *m_DataSavePath;
    QPushButton *SETSAVEPATH;
    QHBoxLayout *horizontalLayout_35;
    QLabel *IDC_STATIC38_TEXT;
    QRadioButton *m_TimeSource;
    QRadioButton *m_TimeSource2;
    QRadioButton *m_TimeSource3;
    QHBoxLayout *horizontalLayout_36;
    QLabel *label_3;
    QCheckBox *m_WYDEnable_va;
    QCheckBox *m_TOEnable_va;
    QCheckBox *m_MeasureEnable_va;
    QPushButton *SETUP_INNER;
    QHBoxLayout *horizontalLayout_37;
    QPushButton *SETUP_SAVE;
    QPushButton *SETUP_APPLY;
    QPushButton *SETUP_CANCEL;

    void setupUi(QDialog *commu)
    {
        if (commu->objectName().isEmpty())
            commu->setObjectName(QString::fromUtf8("commu"));
        commu->resize(1177, 771);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(commu->sizePolicy().hasHeightForWidth());
        commu->setSizePolicy(sizePolicy);
        verticalLayout_15 = new QVBoxLayout(commu);
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setContentsMargins(11, 11, 11, 11);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setSpacing(6);
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        IDC_STATIC13_Group_box = new QGroupBox(commu);
        IDC_STATIC13_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC13_Group_box"));
        verticalLayout_14 = new QVBoxLayout(IDC_STATIC13_Group_box);
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setContentsMargins(11, 11, 11, 11);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(IDC_STATIC13_Group_box);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setAutoFillBackground(false);
        label->setTextFormat(Qt::AutoText);
        label->setScaledContents(false);
        label->setMargin(0);
        label->setIndent(0);
        label->setOpenExternalLinks(false);

        horizontalLayout->addWidget(label);

        IDC_BUTTON_SETSOURCE = new QPushButton(IDC_STATIC13_Group_box);
        IDC_BUTTON_SETSOURCE->setObjectName(QString::fromUtf8("IDC_BUTTON_SETSOURCE"));
        sizePolicy1.setHeightForWidth(IDC_BUTTON_SETSOURCE->sizePolicy().hasHeightForWidth());
        IDC_BUTTON_SETSOURCE->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(IDC_BUTTON_SETSOURCE);


        verticalLayout_2->addLayout(horizontalLayout);

        m_AddList1 = new QTableWidget(IDC_STATIC13_Group_box);
        m_AddList1->setObjectName(QString::fromUtf8("m_AddList1"));

        verticalLayout_2->addWidget(m_AddList1);


        verticalLayout_9->addLayout(verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        IDC_STATIC15_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC15_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC15_TEXT"));
        IDC_STATIC15_TEXT->setEnabled(true);
        sizePolicy1.setHeightForWidth(IDC_STATIC15_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC15_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC15_TEXT->setAutoFillBackground(false);
        IDC_STATIC15_TEXT->setTextFormat(Qt::AutoText);
        IDC_STATIC15_TEXT->setScaledContents(false);
        IDC_STATIC15_TEXT->setMargin(0);
        IDC_STATIC15_TEXT->setIndent(0);
        IDC_STATIC15_TEXT->setOpenExternalLinks(false);

        horizontalLayout_2->addWidget(IDC_STATIC15_TEXT);

        IDC_STATIC44_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC44_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC44_TEXT"));
        IDC_STATIC44_TEXT->setEnabled(true);
        sizePolicy1.setHeightForWidth(IDC_STATIC44_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC44_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC44_TEXT->setAutoFillBackground(false);
        IDC_STATIC44_TEXT->setTextFormat(Qt::AutoText);
        IDC_STATIC44_TEXT->setScaledContents(false);
        IDC_STATIC44_TEXT->setMargin(0);
        IDC_STATIC44_TEXT->setIndent(0);
        IDC_STATIC44_TEXT->setOpenExternalLinks(false);

        horizontalLayout_2->addWidget(IDC_STATIC44_TEXT);

        IDC_STATIC45_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC45_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC45_TEXT"));
        IDC_STATIC45_TEXT->setEnabled(true);
        sizePolicy1.setHeightForWidth(IDC_STATIC45_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC45_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC45_TEXT->setAutoFillBackground(false);
        IDC_STATIC45_TEXT->setTextFormat(Qt::AutoText);
        IDC_STATIC45_TEXT->setScaledContents(false);
        IDC_STATIC45_TEXT->setMargin(0);
        IDC_STATIC45_TEXT->setIndent(0);
        IDC_STATIC45_TEXT->setOpenExternalLinks(false);

        horizontalLayout_2->addWidget(IDC_STATIC45_TEXT);


        verticalLayout_3->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        m_Addlist2_1 = new QTableWidget(IDC_STATIC13_Group_box);
        m_Addlist2_1->setObjectName(QString::fromUtf8("m_Addlist2_1"));

        horizontalLayout_3->addWidget(m_Addlist2_1);

        m_Addlist2_2 = new QTableWidget(IDC_STATIC13_Group_box);
        m_Addlist2_2->setObjectName(QString::fromUtf8("m_Addlist2_2"));

        horizontalLayout_3->addWidget(m_Addlist2_2);


        verticalLayout_3->addLayout(horizontalLayout_3);


        verticalLayout_9->addLayout(verticalLayout_3);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setSpacing(6);
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        label_2 = new QLabel(IDC_STATIC13_Group_box);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_19->addWidget(label_2);

        horizontalSpacer_3 = new QSpacerItem(38, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_3);


        verticalLayout_5->addLayout(horizontalLayout_19);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        IDC_STATIC7_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC7_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC7_TEXT"));

        horizontalLayout_4->addWidget(IDC_STATIC7_TEXT);

        m_NewIP1 = new QLineEdit(IDC_STATIC13_Group_box);
        m_NewIP1->setObjectName(QString::fromUtf8("m_NewIP1"));

        horizontalLayout_4->addWidget(m_NewIP1);


        verticalLayout_5->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        IDC_STATIC5_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC5_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC5_TEXT"));

        horizontalLayout_5->addWidget(IDC_STATIC5_TEXT);

        IDC_EDIT_NPRECEIVE1 = new QLineEdit(IDC_STATIC13_Group_box);
        IDC_EDIT_NPRECEIVE1->setObjectName(QString::fromUtf8("IDC_EDIT_NPRECEIVE1"));

        horizontalLayout_5->addWidget(IDC_EDIT_NPRECEIVE1);

        IDC_STATIC4_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC4_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC4_TEXT"));

        horizontalLayout_5->addWidget(IDC_STATIC4_TEXT);

        IDC_EDIT_NPSEND1 = new QLineEdit(IDC_STATIC13_Group_box);
        IDC_EDIT_NPSEND1->setObjectName(QString::fromUtf8("IDC_EDIT_NPSEND1"));

        horizontalLayout_5->addWidget(IDC_EDIT_NPSEND1);


        verticalLayout_5->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        IDC_STATIC8_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC8_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC8_TEXT"));

        horizontalLayout_6->addWidget(IDC_STATIC8_TEXT);

        m_NewDID1 = new QLineEdit(IDC_STATIC13_Group_box);
        m_NewDID1->setObjectName(QString::fromUtf8("m_NewDID1"));
        m_NewDID1->setMaxLength(8);

        horizontalLayout_6->addWidget(m_NewDID1);


        verticalLayout_5->addLayout(horizontalLayout_6);

        IDC_STATIC22_TEXT = new QGroupBox(IDC_STATIC13_Group_box);
        IDC_STATIC22_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC22_TEXT"));
        verticalLayout_4 = new QVBoxLayout(IDC_STATIC22_TEXT);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        m_WayNo1 = new QRadioButton(IDC_STATIC22_TEXT);
        m_WayNo1->setObjectName(QString::fromUtf8("m_WayNo1"));

        horizontalLayout_7->addWidget(m_WayNo1);

        m_WayNo1_2 = new QRadioButton(IDC_STATIC22_TEXT);
        m_WayNo1_2->setObjectName(QString::fromUtf8("m_WayNo1_2"));

        horizontalLayout_7->addWidget(m_WayNo1_2);


        verticalLayout_4->addLayout(horizontalLayout_7);


        verticalLayout_5->addWidget(IDC_STATIC22_TEXT);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        IDC_STATIC9_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC9_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC9_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC9_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC9_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC9_TEXT->setAlignment(Qt::AlignCenter);

        horizontalLayout_8->addWidget(IDC_STATIC9_TEXT);

        m_NewName1 = new QLineEdit(IDC_STATIC13_Group_box);
        m_NewName1->setObjectName(QString::fromUtf8("m_NewName1"));
        m_NewName1->setMaxLength(20);

        horizontalLayout_8->addWidget(m_NewName1);


        verticalLayout_5->addLayout(horizontalLayout_8);


        horizontalLayout_26->addLayout(verticalLayout_5);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setSpacing(6);
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        IDC_STATIC18 = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC18->setObjectName(QString::fromUtf8("IDC_STATIC18"));

        horizontalLayout_27->addWidget(IDC_STATIC18);

        horizontalSpacer_4 = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_27->addItem(horizontalSpacer_4);


        verticalLayout_8->addLayout(horizontalLayout_27);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        IDC_STATIC19_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC19_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC19_TEXT"));

        horizontalLayout_14->addWidget(IDC_STATIC19_TEXT);

        m_NewIP2 = new QLineEdit(IDC_STATIC13_Group_box);
        m_NewIP2->setObjectName(QString::fromUtf8("m_NewIP2"));

        horizontalLayout_14->addWidget(m_NewIP2);


        verticalLayout_8->addLayout(horizontalLayout_14);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        IDC_STATIC17_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC17_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC17_TEXT"));

        horizontalLayout_15->addWidget(IDC_STATIC17_TEXT);

        IDC_EDIT_NPRECEIVE2 = new QLineEdit(IDC_STATIC13_Group_box);
        IDC_EDIT_NPRECEIVE2->setObjectName(QString::fromUtf8("IDC_EDIT_NPRECEIVE2"));

        horizontalLayout_15->addWidget(IDC_EDIT_NPRECEIVE2);

        IDC_STATIC16_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC16_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC16_TEXT"));

        horizontalLayout_15->addWidget(IDC_STATIC16_TEXT);

        IDC_EDIT_NPSEND2 = new QLineEdit(IDC_STATIC13_Group_box);
        IDC_EDIT_NPSEND2->setObjectName(QString::fromUtf8("IDC_EDIT_NPSEND2"));

        horizontalLayout_15->addWidget(IDC_EDIT_NPSEND2);


        verticalLayout_8->addLayout(horizontalLayout_15);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        IDC_STATIC20_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC20_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC20_TEXT"));

        horizontalLayout_16->addWidget(IDC_STATIC20_TEXT);

        m_NewDID2 = new QLineEdit(IDC_STATIC13_Group_box);
        m_NewDID2->setObjectName(QString::fromUtf8("m_NewDID2"));
        m_NewDID2->setMaxLength(8);

        horizontalLayout_16->addWidget(m_NewDID2);


        verticalLayout_8->addLayout(horizontalLayout_16);

        IDC_STATIC23_TEXT = new QGroupBox(IDC_STATIC13_Group_box);
        IDC_STATIC23_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC23_TEXT"));
        verticalLayout_7 = new QVBoxLayout(IDC_STATIC23_TEXT);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        m_WayNo2 = new QRadioButton(IDC_STATIC23_TEXT);
        m_WayNo2->setObjectName(QString::fromUtf8("m_WayNo2"));

        horizontalLayout_17->addWidget(m_WayNo2);

        m_WayNo2_2 = new QRadioButton(IDC_STATIC23_TEXT);
        m_WayNo2_2->setObjectName(QString::fromUtf8("m_WayNo2_2"));

        horizontalLayout_17->addWidget(m_WayNo2_2);


        verticalLayout_7->addLayout(horizontalLayout_17);


        verticalLayout_8->addWidget(IDC_STATIC23_TEXT);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        IDC_STATIC21_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC21_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC21_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC21_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC21_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC21_TEXT->setAlignment(Qt::AlignCenter);

        horizontalLayout_18->addWidget(IDC_STATIC21_TEXT);

        m_NewName2 = new QLineEdit(IDC_STATIC13_Group_box);
        m_NewName2->setObjectName(QString::fromUtf8("m_NewName2"));
        m_NewName2->setMaxLength(20);

        horizontalLayout_18->addWidget(m_NewName2);


        verticalLayout_8->addLayout(horizontalLayout_18);


        horizontalLayout_26->addLayout(verticalLayout_8);


        verticalLayout_9->addLayout(horizontalLayout_26);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        horizontalSpacer_2 = new QSpacerItem(178, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        verticalLayout_12->addItem(horizontalSpacer_2);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(13);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        IDC_STATIC10_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC10_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC10_TEXT"));
        IDC_STATIC10_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC10_TEXT->setWordWrap(true);

        horizontalLayout_22->addWidget(IDC_STATIC10_TEXT);


        verticalLayout_11->addLayout(horizontalLayout_22);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        ADD_NEWADD1 = new QPushButton(IDC_STATIC13_Group_box);
        ADD_NEWADD1->setObjectName(QString::fromUtf8("ADD_NEWADD1"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(ADD_NEWADD1->sizePolicy().hasHeightForWidth());
        ADD_NEWADD1->setSizePolicy(sizePolicy2);

        horizontalLayout_24->addWidget(ADD_NEWADD1);

        ADD_DELADD1 = new QPushButton(IDC_STATIC13_Group_box);
        ADD_DELADD1->setObjectName(QString::fromUtf8("ADD_DELADD1"));
        sizePolicy2.setHeightForWidth(ADD_DELADD1->sizePolicy().hasHeightForWidth());
        ADD_DELADD1->setSizePolicy(sizePolicy2);

        horizontalLayout_24->addWidget(ADD_DELADD1);


        verticalLayout_11->addLayout(horizontalLayout_24);


        verticalLayout_12->addLayout(verticalLayout_11);


        horizontalLayout_25->addLayout(verticalLayout_12);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));
        IDC_STATIC46_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC46_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC46_TEXT"));

        horizontalLayout_20->addWidget(IDC_STATIC46_TEXT);

        ADD_NEWADD2_1 = new QPushButton(IDC_STATIC13_Group_box);
        ADD_NEWADD2_1->setObjectName(QString::fromUtf8("ADD_NEWADD2_1"));
        sizePolicy1.setHeightForWidth(ADD_NEWADD2_1->sizePolicy().hasHeightForWidth());
        ADD_NEWADD2_1->setSizePolicy(sizePolicy1);

        horizontalLayout_20->addWidget(ADD_NEWADD2_1);

        ADD_DELADD2_1 = new QPushButton(IDC_STATIC13_Group_box);
        ADD_DELADD2_1->setObjectName(QString::fromUtf8("ADD_DELADD2_1"));
        sizePolicy1.setHeightForWidth(ADD_DELADD2_1->sizePolicy().hasHeightForWidth());
        ADD_DELADD2_1->setSizePolicy(sizePolicy1);

        horizontalLayout_20->addWidget(ADD_DELADD2_1);


        verticalLayout_10->addLayout(horizontalLayout_20);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));
        IDC_STATIC47_TEXT = new QLabel(IDC_STATIC13_Group_box);
        IDC_STATIC47_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC47_TEXT"));

        horizontalLayout_21->addWidget(IDC_STATIC47_TEXT);

        ADD_NEWADD2_2 = new QPushButton(IDC_STATIC13_Group_box);
        ADD_NEWADD2_2->setObjectName(QString::fromUtf8("ADD_NEWADD2_2"));
        sizePolicy1.setHeightForWidth(ADD_NEWADD2_2->sizePolicy().hasHeightForWidth());
        ADD_NEWADD2_2->setSizePolicy(sizePolicy1);

        horizontalLayout_21->addWidget(ADD_NEWADD2_2);

        ADD_DELADD2_2 = new QPushButton(IDC_STATIC13_Group_box);
        ADD_DELADD2_2->setObjectName(QString::fromUtf8("ADD_DELADD2_2"));
        sizePolicy1.setHeightForWidth(ADD_DELADD2_2->sizePolicy().hasHeightForWidth());
        ADD_DELADD2_2->setSizePolicy(sizePolicy1);

        horizontalLayout_21->addWidget(ADD_DELADD2_2);


        verticalLayout_10->addLayout(horizontalLayout_21);

        MULTICASTSOURCE = new QPushButton(IDC_STATIC13_Group_box);
        MULTICASTSOURCE->setObjectName(QString::fromUtf8("MULTICASTSOURCE"));
        MULTICASTSOURCE->setEnabled(true);
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(MULTICASTSOURCE->sizePolicy().hasHeightForWidth());
        MULTICASTSOURCE->setSizePolicy(sizePolicy3);

        verticalLayout_10->addWidget(MULTICASTSOURCE);


        horizontalLayout_25->addLayout(verticalLayout_10);


        verticalLayout_9->addLayout(horizontalLayout_25);


        verticalLayout_14->addLayout(verticalLayout_9);


        horizontalLayout_28->addWidget(IDC_STATIC13_Group_box);

        verticalLayout_24 = new QVBoxLayout();
        verticalLayout_24->setSpacing(6);
        verticalLayout_24->setObjectName(QString::fromUtf8("verticalLayout_24"));
        IDC_STATIC88_Group_box = new QGroupBox(commu);
        IDC_STATIC88_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC88_Group_box"));
        verticalLayout_19 = new QVBoxLayout(IDC_STATIC88_Group_box);
        verticalLayout_19->setSpacing(6);
        verticalLayout_19->setContentsMargins(11, 11, 11, 11);
        verticalLayout_19->setObjectName(QString::fromUtf8("verticalLayout_19"));
        verticalLayout_17 = new QVBoxLayout();
        verticalLayout_17->setSpacing(6);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        IDC_STATIC24_TEXT = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC24_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC24_TEXT"));

        horizontalLayout_9->addWidget(IDC_STATIC24_TEXT);

        m_LocaltoCT_IP1 = new QLineEdit(IDC_STATIC88_Group_box);
        m_LocaltoCT_IP1->setObjectName(QString::fromUtf8("m_LocaltoCT_IP1"));

        horizontalLayout_9->addWidget(m_LocaltoCT_IP1);

        IDC_STATIC12_TEXT = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC12_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC12_TEXT"));

        horizontalLayout_9->addWidget(IDC_STATIC12_TEXT);

        m_RecvCTPort = new QLineEdit(IDC_STATIC88_Group_box);
        m_RecvCTPort->setObjectName(QString::fromUtf8("m_RecvCTPort"));

        horizontalLayout_9->addWidget(m_RecvCTPort);

        horizontalLayout_9->setStretch(0, 70);
        horizontalLayout_9->setStretch(1, 100);
        horizontalLayout_9->setStretch(2, 50);
        horizontalLayout_9->setStretch(3, 90);

        verticalLayout_17->addLayout(horizontalLayout_9);

        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setSpacing(6);
        horizontalLayout_38->setObjectName(QString::fromUtf8("horizontalLayout_38"));
        IDC_STATIC25_TEXT = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC25_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC25_TEXT"));

        horizontalLayout_38->addWidget(IDC_STATIC25_TEXT);

        m_LocaltoCT_IP2 = new QLineEdit(IDC_STATIC88_Group_box);
        m_LocaltoCT_IP2->setObjectName(QString::fromUtf8("m_LocaltoCT_IP2"));

        horizontalLayout_38->addWidget(m_LocaltoCT_IP2);

        IDC_STATIC11_TEXT = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC11_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC11_TEXT"));

        horizontalLayout_38->addWidget(IDC_STATIC11_TEXT);

        m_SendCTPort = new QLineEdit(IDC_STATIC88_Group_box);
        m_SendCTPort->setObjectName(QString::fromUtf8("m_SendCTPort"));

        horizontalLayout_38->addWidget(m_SendCTPort);

        horizontalLayout_38->setStretch(0, 70);
        horizontalLayout_38->setStretch(1, 100);
        horizontalLayout_38->setStretch(2, 50);
        horizontalLayout_38->setStretch(3, 90);

        verticalLayout_17->addLayout(horizontalLayout_38);

        IDC_STATIC68_Group_box = new QGroupBox(IDC_STATIC88_Group_box);
        IDC_STATIC68_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC68_Group_box"));
        verticalLayout = new QVBoxLayout(IDC_STATIC68_Group_box);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        m_SendSocketTP = new QRadioButton(IDC_STATIC68_Group_box);
        m_SendSocketTP->setObjectName(QString::fromUtf8("m_SendSocketTP"));

        horizontalLayout_11->addWidget(m_SendSocketTP);

        m_SendSocketTP2 = new QRadioButton(IDC_STATIC68_Group_box);
        m_SendSocketTP2->setObjectName(QString::fromUtf8("m_SendSocketTP2"));

        horizontalLayout_11->addWidget(m_SendSocketTP2);

        m_SendSocketTP3 = new QRadioButton(IDC_STATIC68_Group_box);
        m_SendSocketTP3->setObjectName(QString::fromUtf8("m_SendSocketTP3"));

        horizontalLayout_11->addWidget(m_SendSocketTP3);


        verticalLayout->addLayout(horizontalLayout_11);


        verticalLayout_17->addWidget(IDC_STATIC68_Group_box);

        IDC_STATIC99_Group_box = new QGroupBox(IDC_STATIC88_Group_box);
        IDC_STATIC99_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC99_Group_box"));
        verticalLayout_16 = new QVBoxLayout(IDC_STATIC99_Group_box);
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setContentsMargins(11, 11, 11, 11);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        m_RecvSocketTP = new QRadioButton(IDC_STATIC99_Group_box);
        m_RecvSocketTP->setObjectName(QString::fromUtf8("m_RecvSocketTP"));

        horizontalLayout_12->addWidget(m_RecvSocketTP);

        m_RecvSocketTP2 = new QRadioButton(IDC_STATIC99_Group_box);
        m_RecvSocketTP2->setObjectName(QString::fromUtf8("m_RecvSocketTP2"));

        horizontalLayout_12->addWidget(m_RecvSocketTP2);

        m_RecvSocketTP3 = new QRadioButton(IDC_STATIC99_Group_box);
        m_RecvSocketTP3->setObjectName(QString::fromUtf8("m_RecvSocketTP3"));

        horizontalLayout_12->addWidget(m_RecvSocketTP3);


        verticalLayout_16->addLayout(horizontalLayout_12);


        verticalLayout_17->addWidget(IDC_STATIC99_Group_box);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        IDC_STATIC1_TEXT = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC1_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC1_TEXT"));

        horizontalLayout_13->addWidget(IDC_STATIC1_TEXT);

        m_ZKIP = new QLineEdit(IDC_STATIC88_Group_box);
        m_ZKIP->setObjectName(QString::fromUtf8("m_ZKIP"));

        horizontalLayout_13->addWidget(m_ZKIP);

        IDC_STATIC3_TEXT = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC3_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC3_TEXT"));

        horizontalLayout_13->addWidget(IDC_STATIC3_TEXT);

        m_ZKPort = new QLineEdit(IDC_STATIC88_Group_box);
        m_ZKPort->setObjectName(QString::fromUtf8("m_ZKPort"));

        horizontalLayout_13->addWidget(m_ZKPort);

        horizontalLayout_13->setStretch(0, 100);
        horizontalLayout_13->setStretch(1, 100);
        horizontalLayout_13->setStretch(2, 20);
        horizontalLayout_13->setStretch(3, 100);

        verticalLayout_17->addLayout(horizontalLayout_13);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));
        IDC_STATIC14_TEXT = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC14_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC14_TEXT"));

        horizontalLayout_23->addWidget(IDC_STATIC14_TEXT);

        m_LocaltoZK_IP = new QLineEdit(IDC_STATIC88_Group_box);
        m_LocaltoZK_IP->setObjectName(QString::fromUtf8("m_LocaltoZK_IP"));

        horizontalLayout_23->addWidget(m_LocaltoZK_IP);

        IDC_STATIC3_TEXT_4 = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC3_TEXT_4->setObjectName(QString::fromUtf8("IDC_STATIC3_TEXT_4"));

        horizontalLayout_23->addWidget(IDC_STATIC3_TEXT_4);

        IDC_STATIC3_TEXT_5 = new QLabel(IDC_STATIC88_Group_box);
        IDC_STATIC3_TEXT_5->setObjectName(QString::fromUtf8("IDC_STATIC3_TEXT_5"));

        horizontalLayout_23->addWidget(IDC_STATIC3_TEXT_5);

        horizontalLayout_23->setStretch(0, 100);
        horizontalLayout_23->setStretch(1, 100);
        horizontalLayout_23->setStretch(2, 20);
        horizontalLayout_23->setStretch(3, 100);

        verticalLayout_17->addLayout(horizontalLayout_23);


        verticalLayout_19->addLayout(verticalLayout_17);


        verticalLayout_24->addWidget(IDC_STATIC88_Group_box);

        IDC_STATIC39_Group_box = new QGroupBox(commu);
        IDC_STATIC39_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC39_Group_box"));
        sizePolicy1.setHeightForWidth(IDC_STATIC39_Group_box->sizePolicy().hasHeightForWidth());
        IDC_STATIC39_Group_box->setSizePolicy(sizePolicy1);
        QFont font;
        font.setPointSize(11);
        IDC_STATIC39_Group_box->setFont(font);
        IDC_STATIC39_Group_box->setAutoFillBackground(false);
        verticalLayout_23 = new QVBoxLayout(IDC_STATIC39_Group_box);
        verticalLayout_23->setSpacing(6);
        verticalLayout_23->setContentsMargins(11, 11, 11, 11);
        verticalLayout_23->setObjectName(QString::fromUtf8("verticalLayout_23"));
        verticalLayout_20 = new QVBoxLayout();
        verticalLayout_20->setSpacing(6);
        verticalLayout_20->setObjectName(QString::fromUtf8("verticalLayout_20"));
        IDC_STATIC26_Group_box = new QGroupBox(IDC_STATIC39_Group_box);
        IDC_STATIC26_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC26_Group_box"));
        sizePolicy1.setHeightForWidth(IDC_STATIC26_Group_box->sizePolicy().hasHeightForWidth());
        IDC_STATIC26_Group_box->setSizePolicy(sizePolicy1);
        verticalLayout_22 = new QVBoxLayout(IDC_STATIC26_Group_box);
        verticalLayout_22->setSpacing(6);
        verticalLayout_22->setContentsMargins(11, 11, 11, 11);
        verticalLayout_22->setObjectName(QString::fromUtf8("verticalLayout_22"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setSpacing(6);
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));
        IDC_STATIC27_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC27_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC27_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC27_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC27_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC27_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC27_TEXT->setWordWrap(false);

        horizontalLayout_29->addWidget(IDC_STATIC27_TEXT);

        m_stVersion = new QLineEdit(IDC_STATIC26_Group_box);
        m_stVersion->setObjectName(QString::fromUtf8("m_stVersion"));
        m_stVersion->setMaxLength(8);

        horizontalLayout_29->addWidget(m_stVersion);

        IDC_STATIC28_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC28_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC28_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC28_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC28_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC28_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC28_TEXT->setWordWrap(false);

        horizontalLayout_29->addWidget(IDC_STATIC28_TEXT);

        m__stMID = new QLineEdit(IDC_STATIC26_Group_box);
        m__stMID->setObjectName(QString::fromUtf8("m__stMID"));
        m__stMID->setMaxLength(4);

        horizontalLayout_29->addWidget(m__stMID);

        IDC_STATIC41_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC41_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC41_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC41_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC41_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC41_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC41_TEXT->setWordWrap(false);

        horizontalLayout_29->addWidget(IDC_STATIC41_TEXT);

        m_stMID_T = new QLineEdit(IDC_STATIC26_Group_box);
        m_stMID_T->setObjectName(QString::fromUtf8("m_stMID_T"));
        m_stMID_T->setMaxLength(4);

        horizontalLayout_29->addWidget(m_stMID_T);

        horizontalLayout_29->setStretch(0, 65);
        horizontalLayout_29->setStretch(1, 200);
        horizontalLayout_29->setStretch(2, 115);
        horizontalLayout_29->setStretch(3, 200);
        horizontalLayout_29->setStretch(4, 60);
        horizontalLayout_29->setStretch(5, 200);

        verticalLayout_6->addLayout(horizontalLayout_29);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setSpacing(6);
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        IDC_STATIC29_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC29_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC29_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC29_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC29_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC29_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC29_TEXT->setWordWrap(false);

        horizontalLayout_30->addWidget(IDC_STATIC29_TEXT);

        m_stSID = new QLineEdit(IDC_STATIC26_Group_box);
        m_stSID->setObjectName(QString::fromUtf8("m_stSID"));
        m_stSID->setMaxLength(8);

        horizontalLayout_30->addWidget(m_stSID);

        IDC_STATIC33_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC33_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC33_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC33_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC33_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC33_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC33_TEXT->setWordWrap(false);

        horizontalLayout_30->addWidget(IDC_STATIC33_TEXT);

        m_stBIDMeasure = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDMeasure->setObjectName(QString::fromUtf8("m_stBIDMeasure"));

        horizontalLayout_30->addWidget(m_stBIDMeasure);

        IDC_STATIC34_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC34_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC34_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC34_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC34_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC34_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC34_TEXT->setWordWrap(false);

        horizontalLayout_30->addWidget(IDC_STATIC34_TEXT);

        m_stBIDTimer = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDTimer->setObjectName(QString::fromUtf8("m_stBIDTimer"));

        horizontalLayout_30->addWidget(m_stBIDTimer);

        horizontalLayout_30->setStretch(0, 50);
        horizontalLayout_30->setStretch(1, 200);
        horizontalLayout_30->setStretch(2, 52);
        horizontalLayout_30->setStretch(3, 200);
        horizontalLayout_30->setStretch(4, 55);
        horizontalLayout_30->setStretch(5, 200);

        verticalLayout_6->addLayout(horizontalLayout_30);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setSpacing(6);
        horizontalLayout_31->setObjectName(QString::fromUtf8("horizontalLayout_31"));
        IDC_STATIC35_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC35_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC35_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC35_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC35_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC35_TEXT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC35_TEXT->setWordWrap(true);

        horizontalLayout_31->addWidget(IDC_STATIC35_TEXT);

        m__stBIDExam = new QLineEdit(IDC_STATIC26_Group_box);
        m__stBIDExam->setObjectName(QString::fromUtf8("m__stBIDExam"));

        horizontalLayout_31->addWidget(m__stBIDExam);

        IDC_STATIC31_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC31_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC31_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC31_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC31_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC31_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC31_TEXT->setWordWrap(false);

        horizontalLayout_31->addWidget(IDC_STATIC31_TEXT);

        m__stBIDTO = new QLineEdit(IDC_STATIC26_Group_box);
        m__stBIDTO->setObjectName(QString::fromUtf8("m__stBIDTO"));

        horizontalLayout_31->addWidget(m__stBIDTO);

        IDC_STATIC30_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC30_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC30_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC30_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC30_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC30_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC30_TEXT->setWordWrap(false);

        horizontalLayout_31->addWidget(IDC_STATIC30_TEXT);

        m_stDID = new QLineEdit(IDC_STATIC26_Group_box);
        m_stDID->setObjectName(QString::fromUtf8("m_stDID"));

        horizontalLayout_31->addWidget(m_stDID);

        horizontalLayout_31->setStretch(0, 100);
        horizontalLayout_31->setStretch(1, 100);
        horizontalLayout_31->setStretch(2, 50);
        horizontalLayout_31->setStretch(3, 100);
        horizontalLayout_31->setStretch(4, 20);
        horizontalLayout_31->setStretch(5, 100);

        verticalLayout_6->addLayout(horizontalLayout_31);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setSpacing(6);
        horizontalLayout_32->setObjectName(QString::fromUtf8("horizontalLayout_32"));
        IDC_STATIC32_TEXT = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC32_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC32_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC32_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC32_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC32_TEXT->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC32_TEXT->setWordWrap(true);

        horizontalLayout_32->addWidget(IDC_STATIC32_TEXT);

        m_stBIDWyd1 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd1->setObjectName(QString::fromUtf8("m_stBIDWyd1"));
        m_stBIDWyd1->setMaxLength(8);

        horizontalLayout_32->addWidget(m_stBIDWyd1);

        m_stBIDWyd2 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd2->setObjectName(QString::fromUtf8("m_stBIDWyd2"));
        m_stBIDWyd2->setMaxLength(8);

        horizontalLayout_32->addWidget(m_stBIDWyd2);

        m_stBIDWyd3 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd3->setObjectName(QString::fromUtf8("m_stBIDWyd3"));
        m_stBIDWyd3->setMaxLength(8);

        horizontalLayout_32->addWidget(m_stBIDWyd3);

        m_stBIDWyd4 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd4->setObjectName(QString::fromUtf8("m_stBIDWyd4"));
        m_stBIDWyd4->setMaxLength(8);

        horizontalLayout_32->addWidget(m_stBIDWyd4);

        m_stBIDWyd5 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd5->setObjectName(QString::fromUtf8("m_stBIDWyd5"));
        m_stBIDWyd5->setMaxLength(8);

        horizontalLayout_32->addWidget(m_stBIDWyd5);

        horizontalLayout_32->setStretch(0, 130);
        horizontalLayout_32->setStretch(1, 100);
        horizontalLayout_32->setStretch(2, 100);
        horizontalLayout_32->setStretch(3, 100);
        horizontalLayout_32->setStretch(4, 100);
        horizontalLayout_32->setStretch(5, 100);

        verticalLayout_6->addLayout(horizontalLayout_32);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setSpacing(6);
        horizontalLayout_33->setObjectName(QString::fromUtf8("horizontalLayout_33"));
        IDC_STATIC32_TEXT_2 = new QLabel(IDC_STATIC26_Group_box);
        IDC_STATIC32_TEXT_2->setObjectName(QString::fromUtf8("IDC_STATIC32_TEXT_2"));
        sizePolicy1.setHeightForWidth(IDC_STATIC32_TEXT_2->sizePolicy().hasHeightForWidth());
        IDC_STATIC32_TEXT_2->setSizePolicy(sizePolicy1);
        IDC_STATIC32_TEXT_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC32_TEXT_2->setWordWrap(true);

        horizontalLayout_33->addWidget(IDC_STATIC32_TEXT_2);

        Setup_TIP = new QPushButton(IDC_STATIC26_Group_box);
        Setup_TIP->setObjectName(QString::fromUtf8("Setup_TIP"));
        sizePolicy1.setHeightForWidth(Setup_TIP->sizePolicy().hasHeightForWidth());
        Setup_TIP->setSizePolicy(sizePolicy1);

        horizontalLayout_33->addWidget(Setup_TIP);

        m_stBIDWyd6 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd6->setObjectName(QString::fromUtf8("m_stBIDWyd6"));
        m_stBIDWyd6->setMaxLength(8);

        horizontalLayout_33->addWidget(m_stBIDWyd6);

        m_stBIDWyd7 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd7->setObjectName(QString::fromUtf8("m_stBIDWyd7"));
        m_stBIDWyd7->setMaxLength(8);

        horizontalLayout_33->addWidget(m_stBIDWyd7);

        m_stBIDWyd8 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd8->setObjectName(QString::fromUtf8("m_stBIDWyd8"));
        m_stBIDWyd8->setMaxLength(8);

        horizontalLayout_33->addWidget(m_stBIDWyd8);

        m_stBIDWyd9 = new QLineEdit(IDC_STATIC26_Group_box);
        m_stBIDWyd9->setObjectName(QString::fromUtf8("m_stBIDWyd9"));
        m_stBIDWyd9->setMaxLength(8);

        horizontalLayout_33->addWidget(m_stBIDWyd9);

        horizontalLayout_33->setStretch(0, 130);
        horizontalLayout_33->setStretch(1, 100);
        horizontalLayout_33->setStretch(2, 100);
        horizontalLayout_33->setStretch(3, 100);
        horizontalLayout_33->setStretch(4, 100);
        horizontalLayout_33->setStretch(5, 100);

        verticalLayout_6->addLayout(horizontalLayout_33);


        verticalLayout_22->addLayout(verticalLayout_6);


        verticalLayout_20->addWidget(IDC_STATIC26_Group_box);

        IDC_STATIC36_Group_box = new QGroupBox(IDC_STATIC39_Group_box);
        IDC_STATIC36_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC36_Group_box"));
        verticalLayout_21 = new QVBoxLayout(IDC_STATIC36_Group_box);
        verticalLayout_21->setSpacing(6);
        verticalLayout_21->setContentsMargins(11, 11, 11, 11);
        verticalLayout_21->setObjectName(QString::fromUtf8("verticalLayout_21"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        horizontalLayout_34 = new QHBoxLayout();
        horizontalLayout_34->setSpacing(6);
        horizontalLayout_34->setObjectName(QString::fromUtf8("horizontalLayout_34"));
        IDC_STATIC37_TEXT = new QLabel(IDC_STATIC36_Group_box);
        IDC_STATIC37_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC37_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC37_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC37_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC37_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC37_TEXT->setWordWrap(false);

        horizontalLayout_34->addWidget(IDC_STATIC37_TEXT);

        m_DataSavePath = new QComboBox(IDC_STATIC36_Group_box);
        m_DataSavePath->setObjectName(QString::fromUtf8("m_DataSavePath"));

        horizontalLayout_34->addWidget(m_DataSavePath);

        SETSAVEPATH = new QPushButton(IDC_STATIC36_Group_box);
        SETSAVEPATH->setObjectName(QString::fromUtf8("SETSAVEPATH"));
        sizePolicy1.setHeightForWidth(SETSAVEPATH->sizePolicy().hasHeightForWidth());
        SETSAVEPATH->setSizePolicy(sizePolicy1);

        horizontalLayout_34->addWidget(SETSAVEPATH);

        horizontalLayout_34->setStretch(0, 1);
        horizontalLayout_34->setStretch(1, 3);
        horizontalLayout_34->setStretch(2, 1);

        verticalLayout_13->addLayout(horizontalLayout_34);

        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setSpacing(84);
        horizontalLayout_35->setObjectName(QString::fromUtf8("horizontalLayout_35"));
        IDC_STATIC38_TEXT = new QLabel(IDC_STATIC36_Group_box);
        IDC_STATIC38_TEXT->setObjectName(QString::fromUtf8("IDC_STATIC38_TEXT"));
        sizePolicy1.setHeightForWidth(IDC_STATIC38_TEXT->sizePolicy().hasHeightForWidth());
        IDC_STATIC38_TEXT->setSizePolicy(sizePolicy1);
        IDC_STATIC38_TEXT->setAlignment(Qt::AlignCenter);
        IDC_STATIC38_TEXT->setWordWrap(false);

        horizontalLayout_35->addWidget(IDC_STATIC38_TEXT);

        m_TimeSource = new QRadioButton(IDC_STATIC36_Group_box);
        m_TimeSource->setObjectName(QString::fromUtf8("m_TimeSource"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(m_TimeSource->sizePolicy().hasHeightForWidth());
        m_TimeSource->setSizePolicy(sizePolicy4);

        horizontalLayout_35->addWidget(m_TimeSource);

        m_TimeSource2 = new QRadioButton(IDC_STATIC36_Group_box);
        m_TimeSource2->setObjectName(QString::fromUtf8("m_TimeSource2"));

        horizontalLayout_35->addWidget(m_TimeSource2);

        m_TimeSource3 = new QRadioButton(IDC_STATIC36_Group_box);
        m_TimeSource3->setObjectName(QString::fromUtf8("m_TimeSource3"));

        horizontalLayout_35->addWidget(m_TimeSource3);


        verticalLayout_13->addLayout(horizontalLayout_35);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setSpacing(6);
        horizontalLayout_36->setObjectName(QString::fromUtf8("horizontalLayout_36"));
        label_3 = new QLabel(IDC_STATIC36_Group_box);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_36->addWidget(label_3);

        m_WYDEnable_va = new QCheckBox(IDC_STATIC36_Group_box);
        m_WYDEnable_va->setObjectName(QString::fromUtf8("m_WYDEnable_va"));

        horizontalLayout_36->addWidget(m_WYDEnable_va);

        m_TOEnable_va = new QCheckBox(IDC_STATIC36_Group_box);
        m_TOEnable_va->setObjectName(QString::fromUtf8("m_TOEnable_va"));

        horizontalLayout_36->addWidget(m_TOEnable_va);

        m_MeasureEnable_va = new QCheckBox(IDC_STATIC36_Group_box);
        m_MeasureEnable_va->setObjectName(QString::fromUtf8("m_MeasureEnable_va"));

        horizontalLayout_36->addWidget(m_MeasureEnable_va);

        SETUP_INNER = new QPushButton(IDC_STATIC36_Group_box);
        SETUP_INNER->setObjectName(QString::fromUtf8("SETUP_INNER"));
        sizePolicy1.setHeightForWidth(SETUP_INNER->sizePolicy().hasHeightForWidth());
        SETUP_INNER->setSizePolicy(sizePolicy1);

        horizontalLayout_36->addWidget(SETUP_INNER);


        verticalLayout_13->addLayout(horizontalLayout_36);


        verticalLayout_21->addLayout(verticalLayout_13);


        verticalLayout_20->addWidget(IDC_STATIC36_Group_box);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setSpacing(0);
        horizontalLayout_37->setObjectName(QString::fromUtf8("horizontalLayout_37"));
        horizontalLayout_37->setContentsMargins(0, -1, -1, 0);
        SETUP_SAVE = new QPushButton(IDC_STATIC39_Group_box);
        SETUP_SAVE->setObjectName(QString::fromUtf8("SETUP_SAVE"));
        sizePolicy2.setHeightForWidth(SETUP_SAVE->sizePolicy().hasHeightForWidth());
        SETUP_SAVE->setSizePolicy(sizePolicy2);

        horizontalLayout_37->addWidget(SETUP_SAVE);

        SETUP_APPLY = new QPushButton(IDC_STATIC39_Group_box);
        SETUP_APPLY->setObjectName(QString::fromUtf8("SETUP_APPLY"));
        sizePolicy2.setHeightForWidth(SETUP_APPLY->sizePolicy().hasHeightForWidth());
        SETUP_APPLY->setSizePolicy(sizePolicy2);

        horizontalLayout_37->addWidget(SETUP_APPLY);

        SETUP_CANCEL = new QPushButton(IDC_STATIC39_Group_box);
        SETUP_CANCEL->setObjectName(QString::fromUtf8("SETUP_CANCEL"));
        sizePolicy2.setHeightForWidth(SETUP_CANCEL->sizePolicy().hasHeightForWidth());
        SETUP_CANCEL->setSizePolicy(sizePolicy2);

        horizontalLayout_37->addWidget(SETUP_CANCEL);


        verticalLayout_20->addLayout(horizontalLayout_37);


        verticalLayout_23->addLayout(verticalLayout_20);


        verticalLayout_24->addWidget(IDC_STATIC39_Group_box);


        horizontalLayout_28->addLayout(verticalLayout_24);


        verticalLayout_15->addLayout(horizontalLayout_28);


        retranslateUi(commu);

        QMetaObject::connectSlotsByName(commu);
    } // setupUi

    void retranslateUi(QDialog *commu)
    {
        commu->setWindowTitle(QApplication::translate("commu", "commu", 0, QApplication::UnicodeUTF8));
        IDC_STATIC13_Group_box->setTitle(QApplication::translate("commu", "\347\233\221\346\216\247\346\234\272\351\205\215\347\275\256", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("commu", "\350\277\234\347\253\257\350\256\241\347\256\227\346\234\272IP\345\234\260\345\235\200\344\270\216\347\253\257\345\217\243(\345\215\225\346\222\255)", 0, QApplication::UnicodeUTF8));
        IDC_BUTTON_SETSOURCE->setText(QApplication::translate("commu", "\344\273\245\346\211\200\351\200\211\345\234\260\345\235\200\344\270\272\346\216\245\345\217\227\346\272\220", 0, QApplication::UnicodeUTF8));
        IDC_STATIC15_TEXT->setText(QApplication::translate("commu", "\350\277\234\347\253\257\350\256\241\347\256\227\346\234\272IP\345\234\260\345\235\200\344\270\216\347\253\257\345\217\243(\347\273\204\346\222\255)", 0, QApplication::UnicodeUTF8));
        IDC_STATIC44_TEXT->setText(QApplication::translate("commu", "\346\216\245\345\217\227", 0, QApplication::UnicodeUTF8));
        IDC_STATIC45_TEXT->setText(QApplication::translate("commu", "\345\217\221\351\200\201", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("commu", "\346\226\260\345\212\240\345\205\245\347\232\204\345\215\225\346\222\255\350\277\234\347\253\257\345\234\260\345\235\200", 0, QApplication::UnicodeUTF8));
        IDC_STATIC7_TEXT->setText(QApplication::translate("commu", "IP", 0, QApplication::UnicodeUTF8));
        IDC_STATIC5_TEXT->setText(QApplication::translate("commu", "\346\224\266\357\274\232", 0, QApplication::UnicodeUTF8));
        IDC_STATIC4_TEXT->setText(QApplication::translate("commu", "\345\217\221\357\274\232", 0, QApplication::UnicodeUTF8));
        IDC_STATIC8_TEXT->setText(QApplication::translate("commu", "DID\347\240\201", 0, QApplication::UnicodeUTF8));
        IDC_STATIC22_TEXT->setTitle(QApplication::translate("commu", "\350\267\257\347\224\261\351\200\211\346\213\251", 0, QApplication::UnicodeUTF8));
        m_WayNo1->setText(QApplication::translate("commu", "\347\254\254\344\270\200\350\267\257\347\224\261", 0, QApplication::UnicodeUTF8));
        m_WayNo1_2->setText(QApplication::translate("commu", "\347\254\254\344\272\214\350\267\257\347\224\261", 0, QApplication::UnicodeUTF8));
        IDC_STATIC9_TEXT->setText(QApplication::translate("commu", "\345\221\275\345\220\215", 0, QApplication::UnicodeUTF8));
        IDC_STATIC18->setText(QApplication::translate("commu", "\346\226\260\345\212\240\345\205\245\347\232\204\345\215\225\346\222\255\350\277\234\347\253\257\345\234\260\345\235\200", 0, QApplication::UnicodeUTF8));
        IDC_STATIC19_TEXT->setText(QApplication::translate("commu", "IP", 0, QApplication::UnicodeUTF8));
        IDC_STATIC17_TEXT->setText(QApplication::translate("commu", "\346\224\266\357\274\232", 0, QApplication::UnicodeUTF8));
        IDC_STATIC16_TEXT->setText(QApplication::translate("commu", "\345\217\221\357\274\232", 0, QApplication::UnicodeUTF8));
        IDC_STATIC20_TEXT->setText(QApplication::translate("commu", "DID\347\240\201", 0, QApplication::UnicodeUTF8));
        IDC_STATIC23_TEXT->setTitle(QApplication::translate("commu", "\350\267\257\347\224\261\351\200\211\346\213\251", 0, QApplication::UnicodeUTF8));
        m_WayNo2->setText(QApplication::translate("commu", "\347\254\254\344\270\200\350\267\257\347\224\261", 0, QApplication::UnicodeUTF8));
        m_WayNo2_2->setText(QApplication::translate("commu", "\347\254\254\344\272\214\350\267\257\347\224\261", 0, QApplication::UnicodeUTF8));
        IDC_STATIC21_TEXT->setText(QApplication::translate("commu", "\345\221\275\345\220\215", 0, QApplication::UnicodeUTF8));
        IDC_STATIC10_TEXT->setText(QApplication::translate("commu", "\346\234\254\346\234\272\345\257\271\350\277\234\347\253\257\344\275\277\347\224\250\344\272\2062\344\270\252\347\275\221\345\215\241\357\274\214\350\257\267\346\263\250\346\204\217\351\200\211\346\213\251\350\267\257\347\224\261", 0, QApplication::UnicodeUTF8));
        ADD_NEWADD1->setText(QApplication::translate("commu", "\346\267\273\345\212\240\345\210\260\345\215\225\346\222\255", 0, QApplication::UnicodeUTF8));
        ADD_DELADD1->setText(QApplication::translate("commu", "\344\273\216\345\215\225\346\222\255\345\210\227\350\241\250\344\270\255\345\210\240\351\231\244", 0, QApplication::UnicodeUTF8));
        IDC_STATIC46_TEXT->setText(QApplication::translate("commu", "\346\224\266\357\274\232", 0, QApplication::UnicodeUTF8));
        ADD_NEWADD2_1->setText(QApplication::translate("commu", "\346\267\273\345\212\240\345\210\260\347\273\204\346\222\255", 0, QApplication::UnicodeUTF8));
        ADD_DELADD2_1->setText(QApplication::translate("commu", "\344\273\216\347\273\204\346\222\255\345\210\227\350\241\250\344\270\255\345\210\240\351\231\244", 0, QApplication::UnicodeUTF8));
        IDC_STATIC47_TEXT->setText(QApplication::translate("commu", "\345\217\221\357\274\232", 0, QApplication::UnicodeUTF8));
        ADD_NEWADD2_2->setText(QApplication::translate("commu", "\346\267\273\345\212\240\345\210\260\347\273\204\346\222\255", 0, QApplication::UnicodeUTF8));
        ADD_DELADD2_2->setText(QApplication::translate("commu", "\344\273\216\347\273\204\346\222\255\345\210\227\350\241\250\344\270\255\345\210\240\351\231\244", 0, QApplication::UnicodeUTF8));
        MULTICASTSOURCE->setText(QApplication::translate("commu", "\350\256\276\347\275\256\347\273\204\346\222\255\346\272\220", 0, QApplication::UnicodeUTF8));
        IDC_STATIC88_Group_box->setTitle(QApplication::translate("commu", "\346\234\254\346\234\272\347\275\221\347\273\234\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        IDC_STATIC24_TEXT->setText(QApplication::translate("commu", "\346\234\254\346\234\272\347\254\254\344\270\200\350\267\257\347\224\261\345\234\260\345\235\200", 0, QApplication::UnicodeUTF8));
        m_LocaltoCT_IP1->setText(QString());
        IDC_STATIC12_TEXT->setText(QApplication::translate("commu", "\346\216\245\345\217\227\350\277\234\347\253\257\347\253\257\345\217\243", 0, QApplication::UnicodeUTF8));
        IDC_STATIC25_TEXT->setText(QApplication::translate("commu", "\346\234\254\346\234\272\347\254\254\344\272\214\350\267\257\347\224\261\345\234\260\345\235\200", 0, QApplication::UnicodeUTF8));
        m_LocaltoCT_IP2->setText(QString());
        IDC_STATIC11_TEXT->setText(QApplication::translate("commu", "\345\217\221\351\200\201\350\277\234\347\253\257\347\253\257\345\217\243", 0, QApplication::UnicodeUTF8));
        IDC_STATIC68_Group_box->setTitle(QApplication::translate("commu", "\344\270\216\347\233\221\346\216\247\346\234\272\345\217\221\351\200\201\347\275\221\347\273\234\347\261\273\345\236\213", 0, QApplication::UnicodeUTF8));
        m_SendSocketTP->setText(QApplication::translate("commu", "\345\215\225\346\222\255", 0, QApplication::UnicodeUTF8));
        m_SendSocketTP2->setText(QApplication::translate("commu", "\347\273\204\346\222\255ASM", 0, QApplication::UnicodeUTF8));
        m_SendSocketTP3->setText(QApplication::translate("commu", "\347\273\204\346\222\255SSM", 0, QApplication::UnicodeUTF8));
        IDC_STATIC99_Group_box->setTitle(QApplication::translate("commu", "\344\270\216\347\233\221\346\216\247\346\234\272\346\216\245\346\224\266\347\275\221\347\273\234\347\261\273\345\236\213", 0, QApplication::UnicodeUTF8));
        m_RecvSocketTP->setText(QApplication::translate("commu", "\345\215\225\346\222\255", 0, QApplication::UnicodeUTF8));
        m_RecvSocketTP2->setText(QApplication::translate("commu", "\347\273\204\346\222\255ASM", 0, QApplication::UnicodeUTF8));
        m_RecvSocketTP3->setText(QApplication::translate("commu", "\347\273\204\346\222\255SSM", 0, QApplication::UnicodeUTF8));
        IDC_STATIC1_TEXT->setText(QApplication::translate("commu", "\344\270\273\346\216\247\350\256\241\347\256\227\346\234\272IP\345\234\260\345\235\200\344\270\216\347\253\257\345\217\243", 0, QApplication::UnicodeUTF8));
        m_ZKIP->setText(QString());
        IDC_STATIC3_TEXT->setText(QApplication::translate("commu", "\347\253\257\345\217\243", 0, QApplication::UnicodeUTF8));
        IDC_STATIC14_TEXT->setText(QApplication::translate("commu", "\346\234\254\346\234\272\345\257\271\344\270\273\346\216\247IP\345\234\260\345\235\200\344\270\216\347\253\257\345\217\243", 0, QApplication::UnicodeUTF8));
        m_LocaltoZK_IP->setText(QString());
        IDC_STATIC3_TEXT_4->setText(QString());
        IDC_STATIC3_TEXT_5->setText(QString());
        IDC_STATIC39_Group_box->setTitle(QApplication::translate("commu", "\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        IDC_STATIC26_Group_box->setTitle(QApplication::translate("commu", "\346\225\260\346\215\256\351\205\215\347\275\256", 0, QApplication::UnicodeUTF8));
        IDC_STATIC27_TEXT->setText(QApplication::translate("commu", "VER ", 0, QApplication::UnicodeUTF8));
        IDC_STATIC28_TEXT->setText(QApplication::translate("commu", "  MID ", 0, QApplication::UnicodeUTF8));
        IDC_STATIC41_TEXT->setText(QApplication::translate("commu", "MID\345\270\270\346\227\266", 0, QApplication::UnicodeUTF8));
        IDC_STATIC29_TEXT->setText(QApplication::translate("commu", "SID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC33_TEXT->setText(QApplication::translate("commu", "BID\345\256\236\347\256\227", 0, QApplication::UnicodeUTF8));
        IDC_STATIC34_TEXT->setText(QApplication::translate("commu", "BID\345\270\270\346\227\266", 0, QApplication::UnicodeUTF8));
        IDC_STATIC35_TEXT->setText(QApplication::translate("commu", "BID\346\227\266\345\273\266\346\265\213\350\257\225", 0, QApplication::UnicodeUTF8));
        IDC_STATIC31_TEXT->setText(QApplication::translate("commu", "BID TO", 0, QApplication::UnicodeUTF8));
        IDC_STATIC30_TEXT->setText(QApplication::translate("commu", "DID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC32_TEXT->setText(QApplication::translate("commu", "BID\345\244\226\351\203\250\350\257\264\346\230\216", 0, QApplication::UnicodeUTF8));
        IDC_STATIC32_TEXT_2->setText(QString());
        Setup_TIP->setText(QApplication::translate("commu", "\346\233\264\345\244\232", 0, QApplication::UnicodeUTF8));
        IDC_STATIC36_Group_box->setTitle(QApplication::translate("commu", "\346\234\254\346\234\272\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        IDC_STATIC37_TEXT->setText(QApplication::translate("commu", "\350\256\260\345\275\225\344\277\235\345\255\230\350\267\257\345\276\204", 0, QApplication::UnicodeUTF8));
        SETSAVEPATH->setText(QApplication::translate("commu", "\346\265\217\350\247\210", 0, QApplication::UnicodeUTF8));
        IDC_STATIC38_TEXT->setText(QApplication::translate("commu", "\346\227\266\351\222\237\346\272\220\351\200\211\346\213\251", 0, QApplication::UnicodeUTF8));
        m_TimeSource->setText(QApplication::translate("commu", "GPS", 0, QApplication::UnicodeUTF8));
        m_TimeSource2->setText(QApplication::translate("commu", "AC", 0, QApplication::UnicodeUTF8));
        m_TimeSource3->setText(QApplication::translate("commu", "\346\234\254\346\234\272", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("commu", "\345\210\206\347\253\231\345\257\271\347\233\221\346\216\247\346\234\272", 0, QApplication::UnicodeUTF8));
        m_WYDEnable_va->setText(QApplication::translate("commu", "\346\216\245\345\217\227\345\244\226\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8));
        m_TOEnable_va->setText(QApplication::translate("commu", "\346\216\245\345\217\227TO", 0, QApplication::UnicodeUTF8));
        m_MeasureEnable_va->setText(QApplication::translate("commu", "\345\217\221\351\200\201\345\256\236\347\256\227\346\225\260\346\215\256", 0, QApplication::UnicodeUTF8));
        SETUP_INNER->setText(QApplication::translate("commu", "\346\233\264\345\244\232\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        SETUP_SAVE->setText(QApplication::translate("commu", "\344\277\235\345\255\230\345\271\266\345\272\224\347\224\250", 0, QApplication::UnicodeUTF8));
        SETUP_APPLY->setText(QApplication::translate("commu", "\345\272\224\347\224\250", 0, QApplication::UnicodeUTF8));
        SETUP_CANCEL->setText(QApplication::translate("commu", "\345\217\226\346\266\210", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class commu: public Ui_commu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COMMU_H
