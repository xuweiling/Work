﻿/*LX//////////////////////////////////////////////////////////////////////
// udpSocket.cpp: interface for the udpSocket class.
// author: chenyanan
// date: 2014-12-13
//LX*/

#include "udpSocket.h"

/*************************************************
*udpSocket()构造函数：初始化套接字，并进行绑定
*Parameters:
*  buff_size: 默认值MACRO_BUFFER_SIZE
*return:
*/     
udpSocket::udpSocket():buffer(NULL),buff_size(MACRO_BUFFER_SIZE)
{
    buffer=new unsigned char[buff_size];
    /*清空缓冲区*/
    if (NULL != buffer)
    {
    	memset(buffer, 0, buff_size);  
    }                 
    
    bzero(&myAddress,sizeof(myAddress));
    bzero(&toAddress,sizeof(toAddress));
    bzero(&recvAddress,sizeof(recvAddress));
        
//    /*create and name a udp socket*/
//    sockfd=socket(AF_INET, SOCK_DGRAM, 0);

    bzero(&myAddress,sizeof(myAddress));
    myAddress.sin_family =AF_INET;
    myAddress.sin_port = htons(0);//htons:host to network,short  atoi:ASCII to integer
    myAddress.sin_addr.s_addr=htonl(INADDR_ANY); //htonl:host to network,long   in address any  
    
    //bind(sockfd, (struct sockaddr *)&myAddress, sizeof(myAddress) );
}


/*************************************************
*udpSocket()析构函数：释放buffer，关闭套接字
*Parameters:
*return:
*/ 
udpSocket::~udpSocket()
{
    close(sockfd);
    delete [] buffer;
}

/*************************************************
*udpSocket()构造函数（重载）：初始化套接字
*Parameters:
*  port：监听端口（默认为任意端口）
*  bind: 是否将套接字与本地端口绑定（默认绑定）
*  addr: 监听地址（默认为任意地址）
*  buff_length:缓冲区大小（默认为MACRO_BUFFER_SIZE）
*return:
*/ 
udpSocket::udpSocket(unsigned short int port, bool isbind, const char *addr, int buff_length):buffer(NULL)
{
    buff_size=buff_length;
    buffer=new unsigned char[buff_size];
    /*清空缓冲区*/
    if (NULL != buffer)
    {
    	memset(buffer, 0, buff_size);  
    }               

    bzero(&myAddress,sizeof(myAddress));
    bzero(&toAddress,sizeof(toAddress));
    bzero(&recvAddress,sizeof(recvAddress));
    
//    /*create and name a udp socket*/
//    sockfd=socket(AF_INET, SOCK_DGRAM, 0);
    
    bzero(&myAddress,sizeof(myAddress));
    myAddress.sin_family =AF_INET;
    myAddress.sin_port = htons(port);//htons:host to network,short  atoi:ASCII to integer
    myAddress.sin_addr.s_addr=inet_addr(addr); /* ip转换为4字节整形，使用时需要根据服务端ip进行更改 */  
    
//    if(isbind)
//    {
//    	bind(sockfd, (struct sockaddr *)&myAddress, sizeof(myAddress) );
//    }
}


/*************************************************
*get_sockfd()：返回套接字的索引
*Parameters:
*return:
*  返回套接字的索引
*/ 
int udpSocket::get_sockfd()
{ 
   return sockfd;
}

/*************************************************
*create()：命名套接字
*Parameters:
*  port：监听端口（默认为任意端口）
*  addr: 监听地址（默认为任意地址）
*return:
*  调用成功时返回0,否则返回错误代码
*/
int udpSocket::create(unsigned short int port, const char *addr)
{
    bzero(&myAddress,sizeof(myAddress));
    myAddress.sin_family =AF_INET;
    myAddress.sin_port = htons(port);//htons:host to network,short  atoi:ASCII to integer
    myAddress.sin_addr.s_addr=inet_addr(addr); /* ip转换为4字节整形，使用时需要根据服务端ip进行更改 */  
    
    return ( bind(sockfd, (struct sockaddr *)&myAddress, sizeof(myAddress)) );
}

/*************************************************
*create()：命名套接字
*Parameters:
*  port：监听端口（默认为任意端口）
*  addr: 监听地址
*return:
*  调用成功时返回0,否则返回错误代码
*/


int udpSocket::create(unsigned short int port, unsigned long int addr,bool isbind)
{
    /*create and name a udp socket*/
    sockfd=socket(AF_INET, SOCK_DGRAM, 0);

    /*select init*/
    FD_ZERO(&recvfds);
    FD_SET(sockfd,&recvfds);

    bzero(&myAddress,sizeof(myAddress));
    myAddress.sin_family =AF_INET;
    myAddress.sin_port = htons(port);//htons:host to network,short  atoi:ASCII to integer
    myAddress.sin_addr.s_addr=addr; /* ip转换为4字节整形，使用时需要根据服务端ip进行更改 */

    if(isbind)
    {
        return ( bind(sockfd, (struct sockaddr *)&myAddress, sizeof(myAddress)) );
    }
    else
    {
        return 0;
    }
}

/*************************************************
*set_toAddress()：设置接收方的端口和地址
*Parameters:
*  port：端口（默认为任意端口）
*  addr: 地址（默认为任意地址）
*return:
*/ 
void udpSocket::set_toAddress(unsigned short int port, const char *addr)
{
    bzero(&toAddress,sizeof(toAddress));   
    /*construct the address for use with sendto...*/
    toAddress.sin_family = AF_INET;
    toAddress.sin_port = htons(port);
    toAddress.sin_addr.s_addr=inet_addr(addr); /* ip转换为4字节整形，使用时需要根据服务端ip进行更改 */
}

/*************************************************
*udpsendto()：向指定地址和端口发送消息
*Parameters:
*  msg :消息内容
*  port：端口（默认为任意端口）
*  addr: 地址（默认为任意地址）
*return:
*  调用成功时返回0,否则返回错误代码
*/ 
int udpSocket::udpsendto(const void*msg, int sendLength, unsigned short int port, const char *addr)
{
    bzero(&toAddress,sizeof(toAddress));    
    /*construct the address for use with sendto...*/
    toAddress.sin_family = AF_INET;
    toAddress.sin_port = htons(port);
    toAddress.sin_addr.s_addr=inet_addr(addr); /* ip转换为4字节整形，使用时需要根据服务端ip进行更改 */ 
    
    return ( sendto(sockfd, msg, sendLength, 0, (struct sockaddr *)&toAddress, sizeof(toAddress)) );
}

/***********************************************************
*udpsend():向toAddress发送消息
*Parameters:
*  msg :消息内容
*return:
*  调用成功时返回0,否则返回错误代码
*/
int udpSocket::udpsend(const void *msg)
{  
    return ( sendto(sockfd, msg, strlen((const char*)msg), 0, (struct sockaddr *)&toAddress, sizeof(toAddress)) );
}

/*************************************************
*set_recvAddress()：设置本机所接收消息的发送端的端口和地址
*Parameters:
*  port：端口（默认为任意端口）
*  addr: 地址（默认为任意地址）
*return:
*/ 
void udpSocket::set_recvAddress(unsigned short int port, const char *addr)
{
    bzero(&recvAddress,sizeof(recvAddress));   
    /*construct the address for use with sendto...*/
    recvAddress.sin_family = AF_INET;
    recvAddress.sin_port = htons(port);
    recvAddress.sin_addr.s_addr=inet_addr(addr); /* ip转换为4字节整形，使用时需要根据服务端ip进行更改 */ 
}

/**************************************×××××××××××××××××××××××××××××××××××××××××××××××××××××××
*udprecvfrom():从指定接收地址（默认为任意地址）和接收端口（默认位任意端口），
*	       接收指定个数（buff_len）个字符存入buff。
*Parameters:
*	buff:接收到的消息存入buff
*	buff_len:接收指定字节数
*	set_toAddr:设为1时，在接收完成后将自动设定toAdress位recvAddress(默认不自动设定)。
*	port：从该端口接收（默认为任意端口）
*       addr: 从该地址接收（默认为任意地址）
*return:
*	返回实际接收到的字节数
*/
int udpSocket::udprecvfrom(unsigned char *buff, int buff_len, bool set_toAddr, unsigned short int port, const char *addr)
{
    assert(buff_len<=buff_size);

    testfds=recvfds;
    timeout.tv_sec =3; //seconds
    timeout.tv_usec=1; //micro seconds
    int result = select(FD_SETSIZE,&testfds, (fd_set *)0, (fd_set *)0, &timeout);  //timeout: result=0
    buff_len=0;
    if(result>0)
    {
        if(FD_ISSET(sockfd,&testfds))
        {
               /*清空缓冲区*/
               if (NULL != buffer)
               {
                   memset(buffer, 0, buff_size);
               }
               bzero(&recvAddress,sizeof(recvAddress));
               /*construct the address for use with recvfrom...*/
               recvAddress.sin_family = AF_INET;
               recvAddress.sin_port = htons(port);
               recvAddress.sin_addr.s_addr=inet_addr(addr); /* ip转换为4字节整形，使用时需要根据服务端ip进行更改 */
               int len = sizeof(recvAddress);
               buff_len=recvfrom(sockfd, buffer, buff_size, 0, (struct sockaddr *)&recvAddress,(socklen_t *)&len);
               if(set_toAddr)
               {
                   toAddress.sin_port = recvAddress.sin_port;
                   toAddress.sin_addr.s_addr=recvAddress.sin_addr.s_addr;
               }
               if(buff_len>0)
               {
                   //strncpy(buff,buffer,buff_len);
                   memcpy(buff,buffer,buff_len);
                   buff[buff_len]='\0';
               }
        }
    }
    
    return buff_len;
}

/**************************************×××××××××××××××××××××××××××××××××××××××××××××××××××××××
*udprecv():从recvAddress接收指定个数（buff_len）个字符存入buff。
*Parameters:
*	buff:接收到的消息存入buff
*	buff_len:接收指定字节数
*return:
*	返回实际接收到的字节数
*/
int udpSocket::udprecv(char * buff, int buff_len)
{
    assert(buff_len<=buff_size);
    
    /*清空缓冲区*/
    if (NULL != buffer)
    {
    	memset(buffer, 0, buff_size);  
    }
    
    int len = sizeof(recvAddress); 
    buff_len=recvfrom(sockfd, buffer, buff_size, 0, (struct sockaddr *)&recvAddress, (socklen_t *)&len);
    
    if(buff_len>0)
    {
        //strncpy(buff,buffer,buff_len);
        memcpy(buff,buffer,buff_len);
        buff[buff_len]='\0';
    }
    return buff_len;
}

/**************************************×××××××××××××××××××××××××××××××××××××××××××××××××××××××
*get_recvAddress():获得接收到的消息的发送端的地址
*Parameters:
*return:
*	返回接收到的消息的发送端的地址
*/
uint32_t udpSocket::get_recvAddress()
{
    /*
     * Grab the UDP packet sent by the client.  From that we can extract the
     * client's address, and then use that information to bind the remote side
     * of the socket to the client.
     */
     struct in_addr in;
     in.s_addr=recvAddress.sin_addr.s_addr;
     char *addr=inet_ntoa(in);//将unsigned long int 转换为点分十进制表示的字符串形式的网络地址
     
     return recvAddress.sin_addr.s_addr;
}

/*************************************************************************************
*addMcastGroup():加入组播组
*Parameters:
*	mcastAddr:组播组地址
*  interface:本网卡的地址信息
*	loop:是否设置回环，即是否接收本机发送的消息（默认接收）
*	ttl:设置ttl（存活时间），默认为1
*	reuse:是否允许重用本机（默认允许）
*	iaddr:设置本机网卡（默认由系统自己指定活动网卡）
*return:
*/
void udpSocket::addMcastGroup(const char *mcastAddr, uint32_t interface, int loop, int ttl, int reuse, const char *iaddr)
{
    //设置回环许可or禁止
    setsockopt(sockfd,IPPROTO_IP, IP_MULTICAST_LOOP,&loop, sizeof(loop));

    // Set multicast packet TTL; default TTL is 1
    setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl,sizeof(unsigned char));
    setsockopt(sockfd, IPPROTO_IP, IP_TTL, &ttl,sizeof(unsigned char));

    // Enable SO_REUSEADDR to allow multiple instances of this application to receive copies of the multicast datagrams. 
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse)); 

    //Set socket buffer size
    setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &buffer, sizeof(buff_size));
    setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, &buffer, sizeof(buff_size));

    // Set the outgoing interface to DEFAULT(多网卡)
    moreAddr.s_addr=inet_addr(iaddr);
    setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_IF, &moreAddr,sizeof(struct in_addr));
 
    bzero(&group, sizeof(struct ip_mreq));  
    group.imr_multiaddr.s_addr= inet_addr(mcastAddr);        //设置要加入组播的地址 
    group.imr_interface.s_addr = interface;        // 设置发送组播消息的源主机的地址信息
    //把本机加入组播地址，即本机网卡作为组播成员，只有加入组才能收到组播消息 
    if (setsockopt(sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &group,sizeof(struct ip_mreq)) ==-1)
    {
        perror("setsockopt() ADD failed");
        exit(1);
    } 
}

/*************************************************************************************
*addSourceMcastGroup():加入组播组
*Parameters:
*	mcastAddr:组播组地址
*  interface:本网卡的地址信息
*	sourceAddr:仅接收指定地址的消息
*	loop:是否设置回环，即是否接收本机发送的消息（默认接收）
*	ttl:设置ttl（存活时间），默认为1
*	reuse:是否允许重用本机（默认允许）
*	iaddr:设置本机网卡（默认由系统自己指定活动网卡）
*return:
*/
void udpSocket::addSourceMcastGroup(const char *mcastAddr, const char *sourceAddr, uint32_t interface, int loop, int ttl, int reuse, const char *iaddr)
{
    //设置回环许可or禁止
    setsockopt(sockfd,IPPROTO_IP, IP_MULTICAST_LOOP,&loop, sizeof(loop));

    // Set multicast packet TTL; default TTL is 1
    setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl,sizeof(unsigned char));
    setsockopt(sockfd, IPPROTO_IP, IP_TTL, &ttl,sizeof(unsigned char));

    // Enable SO_REUSEADDR to allow multiple instances of this application to receive copies of the multicast datagrams.
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse));

    //Set socket buffer size
    setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &buffer, sizeof(buff_size));
    setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, &buffer, sizeof(buff_size));

    // Set the outgoing interface to DEFAULT(多网卡)
    moreAddr.s_addr=inet_addr(iaddr);
    setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_IF, &moreAddr,sizeof(struct in_addr));

    //把本机加入组播地址，即本机网卡作为组播成员，只有加入组才能收到组播消息
    struct ip_mreq_source groupSource;
    groupSource.imr_interface.s_addr = interface;// 设置发送组播消息的源主机的地址信息
    groupSource.imr_multiaddr.s_addr = inet_addr(mcastAddr);//设置要加入组播的地址
    groupSource.imr_sourceaddr.s_addr = inet_addr(sourceAddr);//设置仅接收指定源的组播信息
    if (setsockopt(sockfd, IPPROTO_IP, IP_ADD_SOURCE_MEMBERSHIP, &groupSource,sizeof(struct ip_mreq_source)) ==-1)
    {
        perror("setsockopt() ADD_SOURCE failed");
        exit(1);
    }
}

/*************************************************************************************
*addMcastGroup():离开组播组
*Parameters:
*return:
*/
void udpSocket::dropMcastGroup()
{
    /* send a DROP MEMBERSHIP message via setsockopt */
    if ((setsockopt(sockfd, IPPROTO_IP, IP_DROP_MEMBERSHIP, (void*) &group, sizeof(group))) < 0)
    {
        perror("setsockopt() DROP failed");
        exit(1);
    }
}

/*************************************************************************************
*addMcastGroup():离开组播组
*Parameters:
* 	mcastAddr:组播组地址
*  interface:本网卡的地址信息
*return:
*/
void udpSocket::dropMcastGroup(const char *mcastAddr, uint32_t interface)
{
    struct ip_mreq groupMess;
    groupMess.imr_multiaddr.s_addr= inet_addr(mcastAddr);        //设置要加入组播的地址
    groupMess.imr_interface.s_addr = interface;        // 设置发送组播消息的源主机的地址信息
    /* send a DROP MEMBERSHIP message via setsockopt */
    if ((setsockopt(sockfd, IPPROTO_IP, IP_DROP_MEMBERSHIP, (void*) &groupMess, sizeof(groupMess))) < 0)
    {
    	perror("setsockopt() DROP failed");
    	exit(1);
    }
}

/*************************************************************************************
*addMcastGroup():离开组播组
*Parameters:
* 	mcastAddr:组播组地址
*  interface:本网卡的地址信息
*	sourceAddr:指定地址的消息
*return:
*/
void udpSocket::dropSourceMcastGroup(const char *mcastAddr, const char *sourceAddr, uint32_t interface)
{
    struct ip_mreq_source groupSource;
    groupSource.imr_interface.s_addr = interface;// 设置发送组播消息的源主机的地址信息
    groupSource.imr_multiaddr.s_addr = inet_addr(mcastAddr);//设置要加入组播的地址
    groupSource.imr_sourceaddr.s_addr = inet_addr(sourceAddr);//设置仅接收指定源的组播信息
    /* send a DROP MEMBERSHIP message via setsockopt */
    if ((setsockopt(sockfd, IPPROTO_IP, IP_DROP_SOURCE_MEMBERSHIP, (void*) &groupSource, sizeof(groupSource))) < 0)
    {
        perror("setsockopt() DROP_SOURCE failed");
        exit(1);
    }
}

/*************************************************
*close()析：释放buffer，关闭套接字
*Parameters:
*return:
*/
bool udpSocket::udpClose()
{
    //delete [] buffer;
    close(sockfd);
    return true;
}
