﻿#include "modifyoid.h"
#include "ui_modifyoid.h"
#include "string"
using namespace std;
QString CurrentOID;

ModifyOID::ModifyOID(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ModifyOID)
{
    ui->setupUi(this);
    ui->lineEdit->setText(CurrentOID);
    OneLine2ModifyOId();
}

ModifyOID::~ModifyOID()
{
    delete ui;
}

void ModifyOID::on_buttonBox_accepted()
{
    ModifyOId2OneLine();
//    CurrentOID = ui->lineEdit->text();

}

void ModifyOID::ModifyOId2OneLine()
{
    CurrentOID = "";
    CurrentOID += "POid:";
    CurrentOID += ui->OID->text();
    CurrentOID += ",Name:";
    CurrentOID += ui->Name->text();
    CurrentOID += ",PSnytax:";
    CurrentOID += ui->Snytax->text();
    CurrentOID += ",PValue:";
    CurrentOID += ui->Value->text();
    CurrentOID += ",PAccess:";
    CurrentOID += ui->Access->text();
    CurrentOID += ",PIsTrap:";
    CurrentOID += ui->isTrap->text();
    CurrentOID += ",";
    CurrentOID += "\n";
}

void ModifyOID::OneLine2ModifyOId()
{
    int n1,n2;
    string Line = CurrentOID.toStdString();
    if(strcmp(Line.c_str()," ") == 0) return;//空行，直接读入下一行
    if (Line.find("--")==0) return;    //注释行直接读下一行
    n1 = Line.find("--");
    if (n1 > 0)           //去掉行后边注释部分
        Line=Line.substr(0,Line.find("--")+1);
    n1 = Line.find_first_not_of(" ");
    n2 = Line.length()-n1;
    if(n1 == -1)
        n1 = 0;
    Line = Line.substr(n1,n2);
    n2 = Line.find_last_not_of(" ");
    Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
    n1 = Line.find_first_not_of("\t");
    n2 = Line.length()-n1;
    if(n1 == -1)
        n1 = 0;
    Line = Line.substr(n1,n2);
    if(Line == "\r") return;
    //辅助节点定义行，从该行中可以读得的信息有：辅助节点的名字，该辅助节点的父节点名字，
    //该辅助节点在兄弟节点中的位置。这些信息被传递给函数Tree control中添加辅助节点的函数
    //AddPlaceHolder。有该函数完成Tree Control中增加行应的节点
//		while(!Line.length())
    {
        n1 = Line.find("Name:");
        if(n1 != string::npos)
        {
            n2 = Line.find_first_of(',',Line.find("Name:"));
            ui->Name->setText(Line.substr(n1+5,n2-n1-5).c_str());
        }
        n1 = Line.find("PSnytax:");
        if(n1 != string::npos)
        {
            n2 = Line.find_first_of(',',Line.find("PSnytax:"));
            ui->Snytax->setText(Line.substr(n1+8,n2-n1-8).c_str());
        }

        n1 = Line.find("PValue:");
        if(n1 != string::npos)
        {
            n2 = Line.find_first_of(',',Line.find("PValue:"));
            ui->Value->setText((Line.substr(n1+7,n2-n1-7).c_str()));
            QString a = Line.substr(n1+7,n2-n1-7).c_str();
            a = a;
        }

        n1 = Line.find("PAccess:");
        if(n1 != string::npos)
        {
            n2 = Line.find_first_of(',',Line.find("PAccess:"));
            ui->Access->setText(Line.substr(n1+8,n2-n1-8).c_str());
        }
        n1 = Line.find("POid:");
        if(n1 != string::npos)
        {
            n2 = Line.find_first_of(',',Line.find("POid:"));
            ui->OID->setText(Line.substr((n1+5),(n2-n1-5)).c_str());
        }
        n1 = Line.find("PIsTrap:");
        if(n1 != string::npos)
        {
            n2 = Line.find_first_of(',',Line.find("PIsTrap:"));
            ui->isTrap->setText(Line.substr(n1+8,n2-n1-8).c_str());
        }
    }
}
