/****************************************************************************
*                                                                           *
* windef.h -- Basic Windows Type Definitions                                *
*                                                                           *
* Copyright (c) Microsoft Corporation. All rights reserved.                 *
*                                                                           *
****************************************************************************/


#ifndef _WINDEF_
#define _WINDEF_

 #include <QMessageBox>

typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef float               FLOAT;
typedef FLOAT               *PFLOAT;


typedef int                 INT;
typedef unsigned int        UINT;
typedef unsigned int        *PUINT;

typedef long  LONG;
typedef const char *LPCSTR;
typedef int HANDLE;
typedef const char*LPCTSTR;

#define SOCKET_ERROR  -1

#ifdef _DEBUG
#define TRACE (void)
#else
#define TRACE qDebug
#endif

#define AfxMessageBox(pMessage)		    QMessageBox::information(0, QString("Message"),\
                                                                    pMessage,\
                                                                   QMessageBox::Ok,\
                                                                   QMessageBox::Ok);


#endif /* _WINDEF_ */


