/*
 * notify.h
 *
 *  Created on: Dec 19, 2014
 *      Author: feng
 */

#ifndef NOTIFY_H_
#define NOTIFY_H_



class AGENTPP_DECL YFNotificationOriginator: public NotificationOriginator
{

public :
	void YF_configuration_notify(void);
	int YF_send_notify(NotificationOriginatorParams& nop,int notify);

	int YF_notify(const OctetStr& context,
					   const Oidx& oid,
					   Vbx* vbs, int sz,
					   unsigned int timestamp);
	int YF_generate(Vbx* vbs, int size, const Oidx& id,
					     unsigned int timestamp,
					     const Oidx& enterprise,
					     const OctetStr& contextName);

	boolean YF_check_access(ListCursor<MibTableRow>& cur,
			NotificationOriginatorParams& nop);
};



#endif /* NOTIFY_H_ */
