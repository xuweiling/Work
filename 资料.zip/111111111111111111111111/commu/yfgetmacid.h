#ifndef GETMACID_H
#define GETMACID_H
#include <QString>

QString GetLocalMac();

#endif // GETMACID_H
