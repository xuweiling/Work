/********************************************************************************
** Form generated from reading UI file 'Dlg_SetInner.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DLG_SETINNER_H
#define UI_DLG_SETINNER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_CDlg_SetInner
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QCheckBox *m_Is_ZhuKongTai;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QSpacerItem *horizontalSpacer_2;
    QTableWidget *FZtable;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_2;
    QLineEdit *m_CT_IP1;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_6;
    QLabel *label_3;
    QLineEdit *m_CT_IP2;
    QSpacerItem *horizontalSpacer_7;
    QSpacerItem *verticalSpacer;
    QPushButton *ipAdd;
    QPushButton *ipDelete;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *okButton;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *CancleButton;
    QSpacerItem *horizontalSpacer_10;

    void setupUi(QDialog *CDlg_SetInner)
    {
        if (CDlg_SetInner->objectName().isEmpty())
            CDlg_SetInner->setObjectName(QString::fromUtf8("CDlg_SetInner"));
        CDlg_SetInner->setEnabled(true);
        CDlg_SetInner->resize(423, 481);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(CDlg_SetInner->sizePolicy().hasHeightForWidth());
        CDlg_SetInner->setSizePolicy(sizePolicy);
        CDlg_SetInner->setSizeGripEnabled(false);
        CDlg_SetInner->setModal(false);
        verticalLayout_2 = new QVBoxLayout(CDlg_SetInner);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        m_Is_ZhuKongTai = new QCheckBox(CDlg_SetInner);
        m_Is_ZhuKongTai->setObjectName(QString::fromUtf8("m_Is_ZhuKongTai"));

        horizontalLayout->addWidget(m_Is_ZhuKongTai);

        horizontalSpacer = new QSpacerItem(218, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_3 = new QSpacerItem(13, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label = new QLabel(CDlg_SetInner);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        horizontalSpacer_2 = new QSpacerItem(238, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        horizontalLayout_3->addLayout(horizontalLayout_2);


        verticalLayout->addLayout(horizontalLayout_3);

        FZtable = new QTableWidget(CDlg_SetInner);
        if (FZtable->columnCount() < 2)
            FZtable->setColumnCount(2);
        FZtable->setObjectName(QString::fromUtf8("FZtable"));
        FZtable->setColumnCount(2);
        FZtable->horizontalHeader()->setDefaultSectionSize(200);

        verticalLayout->addWidget(FZtable);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_4 = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_4);

        label_2 = new QLabel(CDlg_SetInner);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_4->addWidget(label_2);

        m_CT_IP1 = new QLineEdit(CDlg_SetInner);
        m_CT_IP1->setObjectName(QString::fromUtf8("m_CT_IP1"));

        horizontalLayout_4->addWidget(m_CT_IP1);

        horizontalSpacer_5 = new QSpacerItem(118, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_5);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_6 = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_6);

        label_3 = new QLabel(CDlg_SetInner);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_5->addWidget(label_3);

        m_CT_IP2 = new QLineEdit(CDlg_SetInner);
        m_CT_IP2->setObjectName(QString::fromUtf8("m_CT_IP2"));

        horizontalLayout_5->addWidget(m_CT_IP2);

        horizontalSpacer_7 = new QSpacerItem(118, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_7);


        verticalLayout->addLayout(horizontalLayout_5);

        verticalSpacer = new QSpacerItem(368, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        ipAdd = new QPushButton(CDlg_SetInner);
        ipAdd->setObjectName(QString::fromUtf8("ipAdd"));

        verticalLayout->addWidget(ipAdd);

        ipDelete = new QPushButton(CDlg_SetInner);
        ipDelete->setObjectName(QString::fromUtf8("ipDelete"));

        verticalLayout->addWidget(ipDelete);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer_9 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_9);

        okButton = new QPushButton(CDlg_SetInner);
        okButton->setObjectName(QString::fromUtf8("okButton"));

        horizontalLayout_6->addWidget(okButton);

        horizontalSpacer_8 = new QSpacerItem(98, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_8);

        CancleButton = new QPushButton(CDlg_SetInner);
        CancleButton->setObjectName(QString::fromUtf8("CancleButton"));

        horizontalLayout_6->addWidget(CancleButton);

        horizontalSpacer_10 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_10);


        verticalLayout->addLayout(horizontalLayout_6);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(CDlg_SetInner);

        QMetaObject::connectSlotsByName(CDlg_SetInner);
    } // setupUi

    void retranslateUi(QDialog *CDlg_SetInner)
    {
        CDlg_SetInner->setWindowTitle(QApplication::translate("CDlg_SetInner", "SETINNER", 0, QApplication::UnicodeUTF8));
        m_Is_ZhuKongTai->setText(QApplication::translate("CDlg_SetInner", "\346\230\257\345\220\246\344\270\216\350\200\201\350\264\242\347\253\231\351\200\232\344\277\241", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CDlg_SetInner", "\350\257\267\350\256\276\347\275\256\350\200\201\350\264\242\347\253\231\345\234\260\345\235\200", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("CDlg_SetInner", "\350\267\257\347\224\2611", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("CDlg_SetInner", "\350\267\257\347\224\2612", 0, QApplication::UnicodeUTF8));
        ipAdd->setText(QApplication::translate("CDlg_SetInner", "\346\267\273\345\212\240", 0, QApplication::UnicodeUTF8));
        ipDelete->setText(QApplication::translate("CDlg_SetInner", "\345\210\240\351\231\244", 0, QApplication::UnicodeUTF8));
        okButton->setText(QApplication::translate("CDlg_SetInner", "OK", 0, QApplication::UnicodeUTF8));
        CancleButton->setText(QApplication::translate("CDlg_SetInner", "Cancle", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CDlg_SetInner: public Ui_CDlg_SetInner {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DLG_SETINNER_H
