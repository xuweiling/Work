#include "yfmodifyOID.h"
#include <QFile>

int YFModifyOID(void)
{
    QFile file("MyMib.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return 0;

    while (!file.atEnd()) {
        QString line = file.readLine();

     }
    return 1;
}
