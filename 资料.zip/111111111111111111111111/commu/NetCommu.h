﻿// NetCommu.h: interface for the NetCommu class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NETCOMMU_H__26A59E62_20BB_4579_8683_83394ABA53FD__INCLUDED_)
#define AFX_NETCOMMU_H__26A59E62_20BB_4579_8683_83394ABA53FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"
#include "GlabalDefine.h"
#include "tcrclib.h"

class CNetCommu
{
public:
	CNetCommu();
	virtual ~CNetCommu();

	BYTE		BufferRecv_Passed[MACRO_BUFFER_SIZE];	//用于通信的接收数据区
	BYTE		BufferSend_Passed[MACRO_BUFFER_SIZE];	//用于通信的将要发送数据区
	BYTE		BufferSended_Passed[MACRO_BUFFER_SIZE];	//用于通信的已经发送数据区
	int			pBufferRecvLength;						//接收到的数据长度
	int			pBufferSendLength;						//将要发送的数据长度
	int			pBufferSendedLength;					//发送过的数据长度
	TimeSourceType TimeSource;							//时统来源

	Runtp CurrentMode;									//软件状态
    QWidget* PDlg;											//用于与调用者通信

	virtual bool StartConnect();						//网络启动，线程启动
	virtual bool SendData(int type);					//发送数据
	virtual bool SendData(BYTE* sendDataBuffer, int sendDataBufferLength, int type);//发送数据
	virtual bool Receive( );							//由窗口调用，通知处理
	virtual bool CloseConnect( );						//关闭连接

//	DWORD GetTimeFromTcrc();							//自时统卡得到时间,属于集中处理的函数，外界也可直接调用，得到时间
//	unsigned short GetDate();							//自本机得到日期
	void SetTimeSource(TimeSourceType timeSource);//转换函数

	HEADERStruct	DebugHEADER;								//测试用的实算数据帧头信息

protected:
	BYTE		BufferRecv[MACRO_BUFFER_SIZE];			//接收数据区
	BYTE		BufferSend[MACRO_BUFFER_SIZE];			//发送数据区

	bool		KeepConnecting;							//是否持续连接（用于关闭线程）


	HEADERStruct	MeasureHEADER;							//实算数据帧头信息
	HEADERStruct	TimerSendHEADER;							//常时数据帧头信息(发送)
	HEADERStruct	TimerRecvHEADER;							//常时数据帧头信息(接收)
	HEADERStruct	ExamSendHEADER;							//时延测试帧头信息(发送)
	HEADERStruct	ExamRecvHEADER;							//时延测试帧头信息(接收)
	HEADERStruct	T0HEADER;									//T0数据帧头信息
	HEADERStruct	WYDHEADER[30];						//外部说明数据帧头信息

//下面为一些临时变量
	BYTE		BufferRecvtemp[MACRO_BUFFER_SIZE];		//临时数据
	BYTE		BufferSendtemp[MACRO_BUFFER_SIZE];		//临时数据

	static DWORD	BIDMeasure;							//实算数据帧BID(仅供SaveFile使用)
	static DWORD	BIDTimer;							//常时数据帧BID(仅供SaveFile使用)
	static DWORD	BIDExam;							//时延测试帧BID(仅供SaveFile使用)
	static DWORD	BIDT0;								//T0数据帧BID(仅供SaveFile使用)
	static DWORD	BIDWYD[30];								//外部说明数据帧头信息(仅供SaveFile使用)

};


#endif // !defined(AFX_NETCOMMU_H__26A59E62_20BB_4579_8683_83394ABA53FD__INCLUDED_)
