/********************************************************************************
** Form generated from reading UI file 'Dlg_Debug.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DLG_DEBUG_H
#define UI_DLG_DEBUG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_Dlg_Debug
{
public:
    QVBoxLayout *verticalLayout_15;
    QHBoxLayout *horizontalLayout_26;
    QHBoxLayout *horizontalLayout_25;
    QHBoxLayout *horizontalLayout_24;
    QHBoxLayout *horizontalLayout_23;
    QHBoxLayout *horizontalLayout_22;
    QVBoxLayout *verticalLayout_6;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_21;
    QHBoxLayout *horizontalLayout_20;
    QHBoxLayout *horizontalLayout_16;
    QHBoxLayout *horizontalLayout_30;
    QVBoxLayout *verticalLayout_10;
    QGroupBox *IDC_STATIC1_Group_box;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *IDC_STATIC_STATIC_VER4;
    QLineEdit *m_Ver;
    QLabel *IDC_STATIC_DEBUG_MID5;
    QLineEdit *m_MID;
    QHBoxLayout *horizontalLayout_2;
    QLabel *IDC_STATIC_DEBUG_SID6;
    QLineEdit *m_SID;
    QLabel *IDC_STATIC_DEBUG_DID7;
    QLineEdit *m_DID;
    QHBoxLayout *horizontalLayout_3;
    QLabel *IDC_STATIC_DEBUG_BIDLINKER11;
    QLineEdit *m_BID_Timer;
    QLabel *IDC_STATIC_DEBUG_BIDME9;
    QLineEdit *m_BID_Measure;
    QHBoxLayout *horizontalLayout_4;
    QLabel *IDC_STATIC_DEBUG_A13;
    QLineEdit *m_A;
    QLabel *IDC_STATIC_DEBUG_E14;
    QLineEdit *m_E;
    QHBoxLayout *horizontalLayout_5;
    QLabel *IDC_STATIC_DEBUG_TAR17;
    QCheckBox *m_IsTarget;
    QLabel *IDC_STATIC_DEBUG_CONTROL18;
    QComboBox *m_ServerMode;
    QHBoxLayout *horizontalLayout_6;
    QLabel *IDC_STATIC_DEBUG_X15;
    QLineEdit *m_OffsetX;
    QLabel *IDC_STATIC_DEBUG_Y16;
    QLineEdit *m_OffsetY;
    QGroupBox *IDC_STATIC19_Group_box;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_7;
    QLabel *IDC_STATIC_DEBUG_DX20;
    QLineEdit *m_Wyd_X;
    QLabel *IDC_STATIC_DEBUG_DY21;
    QLineEdit *m_Wyd_Y;
    QHBoxLayout *horizontalLayout_8;
    QLabel *IDC_STATIC_DEBUG_DZ22;
    QLineEdit *m_Wyd_Z;
    QLabel *IDC_STATIC_DEBUG_DY21_2;
    QLabel *IDC_STATIC_DEBUG_DY21_3;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *DEBUG_SENDTO;
    QPushButton *DEBUG_STOPTO;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_10;
    QPushButton *DEBUG_APPLY;
    QPushButton *DEBUG_SAVE;
    QPushButton *DEBUG_CANCEL;
    QPushButton *DEBUG_STARTLOST;
    QHBoxLayout *horizontalLayout_11;
    QPushButton *DEBUG_CHECK_STATUSSWITCH;
    QPushButton *DEBUG_CHECK_STATUSSWITCH2;
    QPushButton *DEBUG_SENDEXAM;
    QVBoxLayout *verticalLayout_14;
    QGroupBox *IDC_STATICEXTRA_Group_box;
    QVBoxLayout *verticalLayout_13;
    QVBoxLayout *verticalLayout_12;
    QHBoxLayout *horizontalLayout_27;
    QLabel *IDC_STATIC12_DEBUG;
    QLineEdit *m_BID_Exam;
    QLabel *IDC_STATIC8_DEBUG;
    QLineEdit *m_BID_TO;
    QHBoxLayout *horizontalLayout_29;
    QLabel *IDC_STATIC10_DEBUG;
    QSpacerItem *horizontalSpacer;
    QLineEdit *m_BID_Wyd;
    QLabel *m_ModeBmp;
    QLabel *STATIC_DEBUG_MODE3;
    QVBoxLayout *verticalLayout_11;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *IDC_STATIC23_Group_box;
    QVBoxLayout *verticalLayout_8;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_15;
    QLabel *IDC_STATIC66_DEBUG;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_12;
    QLabel *IDC_STATIC27_DEBUG;
    QLabel *IDC_STATIC66_DEBUG_3;
    QLineEdit *m_ExamMax1;
    QLabel *IDC_STATIC30_DEBUG;
    QLineEdit *m_ExamMin1;
    QLabel *IDC_STATIC33_DEBUG;
    QLineEdit *m_ExamAve1;
    QHBoxLayout *horizontalLayout_13;
    QLabel *IDC_STATIC25_DEBUG;
    QLabel *IDC_STATIC28_DEBUG;
    QLineEdit *m_ExamMax2;
    QLabel *IDC_STATIC31_DEBUG;
    QLineEdit *m_ExamMin2;
    QLabel *IDC_STATIC34_DEBUG;
    QLineEdit *m_ExamAve2;
    QHBoxLayout *horizontalLayout_14;
    QLabel *IDC_STATIC26_DEBUG;
    QLabel *IDC_STATIC29_DEBUG;
    QLineEdit *m_ExamMax3;
    QLabel *IDC_STATIC32_DEBUG;
    QLineEdit *m_ExamMin3;
    QLabel *IDC_STATIC35_DEBUG;
    QLineEdit *m_ExamAve3;
    QHBoxLayout *horizontalLayout_28;
    QLabel *IDC_STATIC66_DEBUG_5;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_17;
    QLabel *IDC_STATIC45_DEBUG;
    QLabel *IDC_STATIC66_DEBUG_4;
    QLineEdit *m_ExamMax4;
    QLabel *IDC_STATIC51_DEBUG;
    QLineEdit *m_ExamMin4;
    QLabel *IDC_STATIC54_DEBUG;
    QLineEdit *m_ExamAve4;
    QHBoxLayout *horizontalLayout_18;
    QLabel *IDC_STATIC46_DEBUG;
    QLabel *IDC_STATIC49_DEBUG;
    QLineEdit *m_ExamMax5;
    QLabel *IDC_STATIC52_DEBUG;
    QLineEdit *m_ExamMin5;
    QLabel *IDC_STATIC55_DEBUG;
    QLineEdit *m_ExamAve5;
    QHBoxLayout *horizontalLayout_19;
    QLabel *IDC_STATIC47_DEBUG;
    QLabel *IDC_STATIC50_DEBUG;
    QLineEdit *m_ExamMax6;
    QLabel *IDC_STATIC53_DEBUG;
    QLineEdit *m_ExamMin6;
    QLabel *IDC_STATIC56_DEBUG;
    QLineEdit *m_ExamAve6;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_9;
    QLabel *m_StLost1;
    QLabel *m_StLost2;

    void setupUi(QDialog *Dlg_Debug)
    {
        if (Dlg_Debug->objectName().isEmpty())
            Dlg_Debug->setObjectName(QString::fromUtf8("Dlg_Debug"));
        Dlg_Debug->resize(1003, 630);
        verticalLayout_15 = new QVBoxLayout(Dlg_Debug);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QString::fromUtf8("horizontalLayout_26"));

        verticalLayout_15->addLayout(horizontalLayout_26);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));

        verticalLayout_15->addLayout(horizontalLayout_25);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));

        verticalLayout_15->addLayout(horizontalLayout_24);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setObjectName(QString::fromUtf8("horizontalLayout_23"));

        verticalLayout_15->addLayout(horizontalLayout_23);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));

        verticalLayout_15->addLayout(horizontalLayout_22);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));

        verticalLayout_15->addLayout(verticalLayout_6);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));

        verticalLayout_15->addLayout(verticalLayout_5);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QString::fromUtf8("horizontalLayout_21"));

        verticalLayout_15->addLayout(horizontalLayout_21);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QString::fromUtf8("horizontalLayout_20"));

        verticalLayout_15->addLayout(horizontalLayout_20);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));

        verticalLayout_15->addLayout(horizontalLayout_16);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setObjectName(QString::fromUtf8("horizontalLayout_30"));
        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        IDC_STATIC1_Group_box = new QGroupBox(Dlg_Debug);
        IDC_STATIC1_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC1_Group_box"));
        verticalLayout_2 = new QVBoxLayout(IDC_STATIC1_Group_box);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(5, -1, -1, -1);
        IDC_STATIC_STATIC_VER4 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_STATIC_VER4->setObjectName(QString::fromUtf8("IDC_STATIC_STATIC_VER4"));
        IDC_STATIC_STATIC_VER4->setAlignment(Qt::AlignCenter);
        IDC_STATIC_STATIC_VER4->setWordWrap(true);

        horizontalLayout->addWidget(IDC_STATIC_STATIC_VER4);

        m_Ver = new QLineEdit(IDC_STATIC1_Group_box);
        m_Ver->setObjectName(QString::fromUtf8("m_Ver"));
        m_Ver->setMaxLength(2);

        horizontalLayout->addWidget(m_Ver);

        IDC_STATIC_DEBUG_MID5 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_MID5->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_MID5"));
        IDC_STATIC_DEBUG_MID5->setAlignment(Qt::AlignCenter);
        IDC_STATIC_DEBUG_MID5->setWordWrap(true);

        horizontalLayout->addWidget(IDC_STATIC_DEBUG_MID5);

        m_MID = new QLineEdit(IDC_STATIC1_Group_box);
        m_MID->setObjectName(QString::fromUtf8("m_MID"));
        m_MID->setMaxLength(4);

        horizontalLayout->addWidget(m_MID);

        horizontalLayout->setStretch(0, 50);
        horizontalLayout->setStretch(1, 200);
        horizontalLayout->setStretch(2, 50);
        horizontalLayout->setStretch(3, 200);

        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        IDC_STATIC_DEBUG_SID6 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_SID6->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_SID6"));
        IDC_STATIC_DEBUG_SID6->setAlignment(Qt::AlignCenter);
        IDC_STATIC_DEBUG_SID6->setWordWrap(true);

        horizontalLayout_2->addWidget(IDC_STATIC_DEBUG_SID6);

        m_SID = new QLineEdit(IDC_STATIC1_Group_box);
        m_SID->setObjectName(QString::fromUtf8("m_SID"));
        m_SID->setMaxLength(8);

        horizontalLayout_2->addWidget(m_SID);

        IDC_STATIC_DEBUG_DID7 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_DID7->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_DID7"));
        IDC_STATIC_DEBUG_DID7->setAlignment(Qt::AlignCenter);
        IDC_STATIC_DEBUG_DID7->setWordWrap(true);

        horizontalLayout_2->addWidget(IDC_STATIC_DEBUG_DID7);

        m_DID = new QLineEdit(IDC_STATIC1_Group_box);
        m_DID->setObjectName(QString::fromUtf8("m_DID"));
        m_DID->setMaxLength(8);

        horizontalLayout_2->addWidget(m_DID);

        horizontalLayout_2->setStretch(0, 50);
        horizontalLayout_2->setStretch(1, 200);
        horizontalLayout_2->setStretch(2, 50);
        horizontalLayout_2->setStretch(3, 200);

        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        IDC_STATIC_DEBUG_BIDLINKER11 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_BIDLINKER11->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_BIDLINKER11"));
        IDC_STATIC_DEBUG_BIDLINKER11->setAlignment(Qt::AlignCenter);
        IDC_STATIC_DEBUG_BIDLINKER11->setWordWrap(true);

        horizontalLayout_3->addWidget(IDC_STATIC_DEBUG_BIDLINKER11);

        m_BID_Timer = new QLineEdit(IDC_STATIC1_Group_box);
        m_BID_Timer->setObjectName(QString::fromUtf8("m_BID_Timer"));
        m_BID_Timer->setMaxLength(8);

        horizontalLayout_3->addWidget(m_BID_Timer);

        IDC_STATIC_DEBUG_BIDME9 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_BIDME9->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_BIDME9"));
        IDC_STATIC_DEBUG_BIDME9->setAlignment(Qt::AlignCenter);
        IDC_STATIC_DEBUG_BIDME9->setWordWrap(true);

        horizontalLayout_3->addWidget(IDC_STATIC_DEBUG_BIDME9);

        m_BID_Measure = new QLineEdit(IDC_STATIC1_Group_box);
        m_BID_Measure->setObjectName(QString::fromUtf8("m_BID_Measure"));
        m_BID_Measure->setMaxLength(8);

        horizontalLayout_3->addWidget(m_BID_Measure);

        horizontalLayout_3->setStretch(0, 50);
        horizontalLayout_3->setStretch(1, 200);
        horizontalLayout_3->setStretch(2, 50);
        horizontalLayout_3->setStretch(3, 200);

        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        IDC_STATIC_DEBUG_A13 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_A13->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_A13"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Ignored);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(IDC_STATIC_DEBUG_A13->sizePolicy().hasHeightForWidth());
        IDC_STATIC_DEBUG_A13->setSizePolicy(sizePolicy);
        IDC_STATIC_DEBUG_A13->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_A13->setWordWrap(true);

        horizontalLayout_4->addWidget(IDC_STATIC_DEBUG_A13);

        m_A = new QLineEdit(IDC_STATIC1_Group_box);
        m_A->setObjectName(QString::fromUtf8("m_A"));
        m_A->setMaxLength(8);

        horizontalLayout_4->addWidget(m_A);

        IDC_STATIC_DEBUG_E14 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_E14->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_E14"));
        IDC_STATIC_DEBUG_E14->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_E14->setWordWrap(true);

        horizontalLayout_4->addWidget(IDC_STATIC_DEBUG_E14);

        m_E = new QLineEdit(IDC_STATIC1_Group_box);
        m_E->setObjectName(QString::fromUtf8("m_E"));
        m_E->setMaxLength(8);

        horizontalLayout_4->addWidget(m_E);

        horizontalLayout_4->setStretch(0, 50);
        horizontalLayout_4->setStretch(1, 200);
        horizontalLayout_4->setStretch(2, 50);
        horizontalLayout_4->setStretch(3, 200);

        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        IDC_STATIC_DEBUG_TAR17 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_TAR17->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_TAR17"));
        IDC_STATIC_DEBUG_TAR17->setAlignment(Qt::AlignCenter);
        IDC_STATIC_DEBUG_TAR17->setWordWrap(true);

        horizontalLayout_5->addWidget(IDC_STATIC_DEBUG_TAR17);

        m_IsTarget = new QCheckBox(IDC_STATIC1_Group_box);
        m_IsTarget->setObjectName(QString::fromUtf8("m_IsTarget"));

        horizontalLayout_5->addWidget(m_IsTarget);

        IDC_STATIC_DEBUG_CONTROL18 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_CONTROL18->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_CONTROL18"));
        IDC_STATIC_DEBUG_CONTROL18->setAlignment(Qt::AlignCenter);
        IDC_STATIC_DEBUG_CONTROL18->setWordWrap(true);

        horizontalLayout_5->addWidget(IDC_STATIC_DEBUG_CONTROL18);

        m_ServerMode = new QComboBox(IDC_STATIC1_Group_box);
        m_ServerMode->setObjectName(QString::fromUtf8("m_ServerMode"));

        horizontalLayout_5->addWidget(m_ServerMode);

        horizontalLayout_5->setStretch(0, 100);
        horizontalLayout_5->setStretch(1, 150);
        horizontalLayout_5->setStretch(2, 100);
        horizontalLayout_5->setStretch(3, 200);

        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        IDC_STATIC_DEBUG_X15 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_X15->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_X15"));
        sizePolicy.setHeightForWidth(IDC_STATIC_DEBUG_X15->sizePolicy().hasHeightForWidth());
        IDC_STATIC_DEBUG_X15->setSizePolicy(sizePolicy);
        IDC_STATIC_DEBUG_X15->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_X15->setWordWrap(true);

        horizontalLayout_6->addWidget(IDC_STATIC_DEBUG_X15);

        m_OffsetX = new QLineEdit(IDC_STATIC1_Group_box);
        m_OffsetX->setObjectName(QString::fromUtf8("m_OffsetX"));
        m_OffsetX->setMaxLength(8);

        horizontalLayout_6->addWidget(m_OffsetX);

        IDC_STATIC_DEBUG_Y16 = new QLabel(IDC_STATIC1_Group_box);
        IDC_STATIC_DEBUG_Y16->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_Y16"));
        IDC_STATIC_DEBUG_Y16->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_Y16->setWordWrap(true);

        horizontalLayout_6->addWidget(IDC_STATIC_DEBUG_Y16);

        m_OffsetY = new QLineEdit(IDC_STATIC1_Group_box);
        m_OffsetY->setObjectName(QString::fromUtf8("m_OffsetY"));
        m_OffsetY->setMaxLength(8);

        horizontalLayout_6->addWidget(m_OffsetY);

        horizontalLayout_6->setStretch(0, 50);
        horizontalLayout_6->setStretch(1, 200);
        horizontalLayout_6->setStretch(2, 50);
        horizontalLayout_6->setStretch(3, 200);

        verticalLayout->addLayout(horizontalLayout_6);


        verticalLayout_2->addLayout(verticalLayout);


        verticalLayout_10->addWidget(IDC_STATIC1_Group_box);

        IDC_STATIC19_Group_box = new QGroupBox(Dlg_Debug);
        IDC_STATIC19_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC19_Group_box"));
        verticalLayout_4 = new QVBoxLayout(IDC_STATIC19_Group_box);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        IDC_STATIC_DEBUG_DX20 = new QLabel(IDC_STATIC19_Group_box);
        IDC_STATIC_DEBUG_DX20->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_DX20"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(IDC_STATIC_DEBUG_DX20->sizePolicy().hasHeightForWidth());
        IDC_STATIC_DEBUG_DX20->setSizePolicy(sizePolicy1);
        IDC_STATIC_DEBUG_DX20->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_DX20->setWordWrap(true);

        horizontalLayout_7->addWidget(IDC_STATIC_DEBUG_DX20);

        m_Wyd_X = new QLineEdit(IDC_STATIC19_Group_box);
        m_Wyd_X->setObjectName(QString::fromUtf8("m_Wyd_X"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(m_Wyd_X->sizePolicy().hasHeightForWidth());
        m_Wyd_X->setSizePolicy(sizePolicy2);
        m_Wyd_X->setMaxLength(8);

        horizontalLayout_7->addWidget(m_Wyd_X);

        IDC_STATIC_DEBUG_DY21 = new QLabel(IDC_STATIC19_Group_box);
        IDC_STATIC_DEBUG_DY21->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_DY21"));
        sizePolicy1.setHeightForWidth(IDC_STATIC_DEBUG_DY21->sizePolicy().hasHeightForWidth());
        IDC_STATIC_DEBUG_DY21->setSizePolicy(sizePolicy1);
        IDC_STATIC_DEBUG_DY21->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_DY21->setWordWrap(true);

        horizontalLayout_7->addWidget(IDC_STATIC_DEBUG_DY21);

        m_Wyd_Y = new QLineEdit(IDC_STATIC19_Group_box);
        m_Wyd_Y->setObjectName(QString::fromUtf8("m_Wyd_Y"));
        sizePolicy2.setHeightForWidth(m_Wyd_Y->sizePolicy().hasHeightForWidth());
        m_Wyd_Y->setSizePolicy(sizePolicy2);
        m_Wyd_Y->setMaxLength(8);

        horizontalLayout_7->addWidget(m_Wyd_Y);

        horizontalLayout_7->setStretch(0, 50);
        horizontalLayout_7->setStretch(1, 200);
        horizontalLayout_7->setStretch(2, 50);
        horizontalLayout_7->setStretch(3, 200);

        verticalLayout_3->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        IDC_STATIC_DEBUG_DZ22 = new QLabel(IDC_STATIC19_Group_box);
        IDC_STATIC_DEBUG_DZ22->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_DZ22"));
        sizePolicy.setHeightForWidth(IDC_STATIC_DEBUG_DZ22->sizePolicy().hasHeightForWidth());
        IDC_STATIC_DEBUG_DZ22->setSizePolicy(sizePolicy);
        IDC_STATIC_DEBUG_DZ22->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_DZ22->setWordWrap(true);

        horizontalLayout_8->addWidget(IDC_STATIC_DEBUG_DZ22);

        m_Wyd_Z = new QLineEdit(IDC_STATIC19_Group_box);
        m_Wyd_Z->setObjectName(QString::fromUtf8("m_Wyd_Z"));
        sizePolicy2.setHeightForWidth(m_Wyd_Z->sizePolicy().hasHeightForWidth());
        m_Wyd_Z->setSizePolicy(sizePolicy2);
        m_Wyd_Z->setMaxLength(8);

        horizontalLayout_8->addWidget(m_Wyd_Z);

        IDC_STATIC_DEBUG_DY21_2 = new QLabel(IDC_STATIC19_Group_box);
        IDC_STATIC_DEBUG_DY21_2->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_DY21_2"));
        sizePolicy1.setHeightForWidth(IDC_STATIC_DEBUG_DY21_2->sizePolicy().hasHeightForWidth());
        IDC_STATIC_DEBUG_DY21_2->setSizePolicy(sizePolicy1);
        IDC_STATIC_DEBUG_DY21_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_DY21_2->setWordWrap(true);

        horizontalLayout_8->addWidget(IDC_STATIC_DEBUG_DY21_2);

        IDC_STATIC_DEBUG_DY21_3 = new QLabel(IDC_STATIC19_Group_box);
        IDC_STATIC_DEBUG_DY21_3->setObjectName(QString::fromUtf8("IDC_STATIC_DEBUG_DY21_3"));
        sizePolicy1.setHeightForWidth(IDC_STATIC_DEBUG_DY21_3->sizePolicy().hasHeightForWidth());
        IDC_STATIC_DEBUG_DY21_3->setSizePolicy(sizePolicy1);
        IDC_STATIC_DEBUG_DY21_3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC_DEBUG_DY21_3->setWordWrap(true);

        horizontalLayout_8->addWidget(IDC_STATIC_DEBUG_DY21_3);

        horizontalLayout_8->setStretch(0, 50);
        horizontalLayout_8->setStretch(1, 200);
        horizontalLayout_8->setStretch(2, 50);
        horizontalLayout_8->setStretch(3, 90);

        verticalLayout_3->addLayout(horizontalLayout_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(5);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        DEBUG_SENDTO = new QPushButton(IDC_STATIC19_Group_box);
        DEBUG_SENDTO->setObjectName(QString::fromUtf8("DEBUG_SENDTO"));
        sizePolicy2.setHeightForWidth(DEBUG_SENDTO->sizePolicy().hasHeightForWidth());
        DEBUG_SENDTO->setSizePolicy(sizePolicy2);

        horizontalLayout_9->addWidget(DEBUG_SENDTO);

        DEBUG_STOPTO = new QPushButton(IDC_STATIC19_Group_box);
        DEBUG_STOPTO->setObjectName(QString::fromUtf8("DEBUG_STOPTO"));
        sizePolicy2.setHeightForWidth(DEBUG_STOPTO->sizePolicy().hasHeightForWidth());
        DEBUG_STOPTO->setSizePolicy(sizePolicy2);

        horizontalLayout_9->addWidget(DEBUG_STOPTO);

        horizontalSpacer_2 = new QSpacerItem(98, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_2);


        verticalLayout_3->addLayout(horizontalLayout_9);


        verticalLayout_4->addLayout(verticalLayout_3);


        verticalLayout_10->addWidget(IDC_STATIC19_Group_box);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        DEBUG_APPLY = new QPushButton(Dlg_Debug);
        DEBUG_APPLY->setObjectName(QString::fromUtf8("DEBUG_APPLY"));
        sizePolicy2.setHeightForWidth(DEBUG_APPLY->sizePolicy().hasHeightForWidth());
        DEBUG_APPLY->setSizePolicy(sizePolicy2);

        horizontalLayout_10->addWidget(DEBUG_APPLY);

        DEBUG_SAVE = new QPushButton(Dlg_Debug);
        DEBUG_SAVE->setObjectName(QString::fromUtf8("DEBUG_SAVE"));

        horizontalLayout_10->addWidget(DEBUG_SAVE);

        DEBUG_CANCEL = new QPushButton(Dlg_Debug);
        DEBUG_CANCEL->setObjectName(QString::fromUtf8("DEBUG_CANCEL"));

        horizontalLayout_10->addWidget(DEBUG_CANCEL);

        DEBUG_STARTLOST = new QPushButton(Dlg_Debug);
        DEBUG_STARTLOST->setObjectName(QString::fromUtf8("DEBUG_STARTLOST"));

        horizontalLayout_10->addWidget(DEBUG_STARTLOST);


        verticalLayout_10->addLayout(horizontalLayout_10);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        DEBUG_CHECK_STATUSSWITCH = new QPushButton(Dlg_Debug);
        DEBUG_CHECK_STATUSSWITCH->setObjectName(QString::fromUtf8("DEBUG_CHECK_STATUSSWITCH"));

        horizontalLayout_11->addWidget(DEBUG_CHECK_STATUSSWITCH);

        DEBUG_CHECK_STATUSSWITCH2 = new QPushButton(Dlg_Debug);
        DEBUG_CHECK_STATUSSWITCH2->setObjectName(QString::fromUtf8("DEBUG_CHECK_STATUSSWITCH2"));

        horizontalLayout_11->addWidget(DEBUG_CHECK_STATUSSWITCH2);

        DEBUG_SENDEXAM = new QPushButton(Dlg_Debug);
        DEBUG_SENDEXAM->setObjectName(QString::fromUtf8("DEBUG_SENDEXAM"));

        horizontalLayout_11->addWidget(DEBUG_SENDEXAM);


        verticalLayout_10->addLayout(horizontalLayout_11);


        horizontalLayout_30->addLayout(verticalLayout_10);

        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        IDC_STATICEXTRA_Group_box = new QGroupBox(Dlg_Debug);
        IDC_STATICEXTRA_Group_box->setObjectName(QString::fromUtf8("IDC_STATICEXTRA_Group_box"));
        verticalLayout_13 = new QVBoxLayout(IDC_STATICEXTRA_Group_box);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QString::fromUtf8("horizontalLayout_27"));
        IDC_STATIC12_DEBUG = new QLabel(IDC_STATICEXTRA_Group_box);
        IDC_STATIC12_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC12_DEBUG"));
        sizePolicy.setHeightForWidth(IDC_STATIC12_DEBUG->sizePolicy().hasHeightForWidth());
        IDC_STATIC12_DEBUG->setSizePolicy(sizePolicy);
        IDC_STATIC12_DEBUG->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC12_DEBUG->setWordWrap(true);

        horizontalLayout_27->addWidget(IDC_STATIC12_DEBUG);

        m_BID_Exam = new QLineEdit(IDC_STATICEXTRA_Group_box);
        m_BID_Exam->setObjectName(QString::fromUtf8("m_BID_Exam"));
        m_BID_Exam->setMaxLength(8);

        horizontalLayout_27->addWidget(m_BID_Exam);

        IDC_STATIC8_DEBUG = new QLabel(IDC_STATICEXTRA_Group_box);
        IDC_STATIC8_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC8_DEBUG"));
        IDC_STATIC8_DEBUG->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC8_DEBUG->setWordWrap(true);

        horizontalLayout_27->addWidget(IDC_STATIC8_DEBUG);

        m_BID_TO = new QLineEdit(IDC_STATICEXTRA_Group_box);
        m_BID_TO->setObjectName(QString::fromUtf8("m_BID_TO"));
        m_BID_TO->setMaxLength(8);

        horizontalLayout_27->addWidget(m_BID_TO);

        horizontalLayout_27->setStretch(0, 120);
        horizontalLayout_27->setStretch(1, 150);
        horizontalLayout_27->setStretch(2, 50);
        horizontalLayout_27->setStretch(3, 150);

        verticalLayout_12->addLayout(horizontalLayout_27);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setSpacing(17);
        horizontalLayout_29->setObjectName(QString::fromUtf8("horizontalLayout_29"));
        IDC_STATIC10_DEBUG = new QLabel(IDC_STATICEXTRA_Group_box);
        IDC_STATIC10_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC10_DEBUG"));
        sizePolicy2.setHeightForWidth(IDC_STATIC10_DEBUG->sizePolicy().hasHeightForWidth());
        IDC_STATIC10_DEBUG->setSizePolicy(sizePolicy2);
        IDC_STATIC10_DEBUG->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        IDC_STATIC10_DEBUG->setWordWrap(true);

        horizontalLayout_29->addWidget(IDC_STATIC10_DEBUG);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_29->addItem(horizontalSpacer);

        m_BID_Wyd = new QLineEdit(IDC_STATICEXTRA_Group_box);
        m_BID_Wyd->setObjectName(QString::fromUtf8("m_BID_Wyd"));
        sizePolicy2.setHeightForWidth(m_BID_Wyd->sizePolicy().hasHeightForWidth());
        m_BID_Wyd->setSizePolicy(sizePolicy2);
        m_BID_Wyd->setMaxLength(8);

        horizontalLayout_29->addWidget(m_BID_Wyd);

        m_ModeBmp = new QLabel(IDC_STATICEXTRA_Group_box);
        m_ModeBmp->setObjectName(QString::fromUtf8("m_ModeBmp"));

        horizontalLayout_29->addWidget(m_ModeBmp);

        STATIC_DEBUG_MODE3 = new QLabel(IDC_STATICEXTRA_Group_box);
        STATIC_DEBUG_MODE3->setObjectName(QString::fromUtf8("STATIC_DEBUG_MODE3"));

        horizontalLayout_29->addWidget(STATIC_DEBUG_MODE3);

        horizontalLayout_29->setStretch(0, 120);
        horizontalLayout_29->setStretch(1, 20);
        horizontalLayout_29->setStretch(2, 150);
        horizontalLayout_29->setStretch(3, 10);
        horizontalLayout_29->setStretch(4, 100);

        verticalLayout_12->addLayout(horizontalLayout_29);


        verticalLayout_13->addLayout(verticalLayout_12);


        verticalLayout_14->addWidget(IDC_STATICEXTRA_Group_box);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_11->addItem(verticalSpacer_2);

        IDC_STATIC23_Group_box = new QGroupBox(Dlg_Debug);
        IDC_STATIC23_Group_box->setObjectName(QString::fromUtf8("IDC_STATIC23_Group_box"));
        verticalLayout_8 = new QVBoxLayout(IDC_STATIC23_Group_box);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        IDC_STATIC66_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC66_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC66_DEBUG"));
        IDC_STATIC66_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC66_DEBUG->setWordWrap(true);

        horizontalLayout_15->addWidget(IDC_STATIC66_DEBUG);

        horizontalSpacer_3 = new QSpacerItem(371, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_3);


        verticalLayout_7->addLayout(horizontalLayout_15);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(11, -1, -1, -1);
        IDC_STATIC27_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC27_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC27_DEBUG"));
        IDC_STATIC27_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC27_DEBUG->setWordWrap(true);

        horizontalLayout_12->addWidget(IDC_STATIC27_DEBUG);

        IDC_STATIC66_DEBUG_3 = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC66_DEBUG_3->setObjectName(QString::fromUtf8("IDC_STATIC66_DEBUG_3"));
        IDC_STATIC66_DEBUG_3->setAlignment(Qt::AlignCenter);
        IDC_STATIC66_DEBUG_3->setWordWrap(true);

        horizontalLayout_12->addWidget(IDC_STATIC66_DEBUG_3);

        m_ExamMax1 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMax1->setObjectName(QString::fromUtf8("m_ExamMax1"));
        m_ExamMax1->setMaxLength(8);

        horizontalLayout_12->addWidget(m_ExamMax1);

        IDC_STATIC30_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC30_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC30_DEBUG"));
        IDC_STATIC30_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC30_DEBUG->setWordWrap(true);

        horizontalLayout_12->addWidget(IDC_STATIC30_DEBUG);

        m_ExamMin1 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMin1->setObjectName(QString::fromUtf8("m_ExamMin1"));
        m_ExamMin1->setMaxLength(8);

        horizontalLayout_12->addWidget(m_ExamMin1);

        IDC_STATIC33_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC33_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC33_DEBUG"));
        IDC_STATIC33_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC33_DEBUG->setWordWrap(true);

        horizontalLayout_12->addWidget(IDC_STATIC33_DEBUG);

        m_ExamAve1 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamAve1->setObjectName(QString::fromUtf8("m_ExamAve1"));
        m_ExamAve1->setMaxLength(8);

        horizontalLayout_12->addWidget(m_ExamAve1);

        horizontalLayout_12->setStretch(0, 100);
        horizontalLayout_12->setStretch(1, 100);
        horizontalLayout_12->setStretch(2, 300);
        horizontalLayout_12->setStretch(3, 100);
        horizontalLayout_12->setStretch(4, 300);
        horizontalLayout_12->setStretch(5, 100);
        horizontalLayout_12->setStretch(6, 300);

        verticalLayout_7->addLayout(horizontalLayout_12);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalLayout_13->setContentsMargins(11, -1, -1, -1);
        IDC_STATIC25_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC25_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC25_DEBUG"));
        IDC_STATIC25_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC25_DEBUG->setWordWrap(true);

        horizontalLayout_13->addWidget(IDC_STATIC25_DEBUG);

        IDC_STATIC28_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC28_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC28_DEBUG"));
        IDC_STATIC28_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC28_DEBUG->setWordWrap(true);

        horizontalLayout_13->addWidget(IDC_STATIC28_DEBUG);

        m_ExamMax2 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMax2->setObjectName(QString::fromUtf8("m_ExamMax2"));
        m_ExamMax2->setMaxLength(8);

        horizontalLayout_13->addWidget(m_ExamMax2);

        IDC_STATIC31_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC31_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC31_DEBUG"));
        IDC_STATIC31_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC31_DEBUG->setWordWrap(true);

        horizontalLayout_13->addWidget(IDC_STATIC31_DEBUG);

        m_ExamMin2 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMin2->setObjectName(QString::fromUtf8("m_ExamMin2"));
        m_ExamMin2->setMaxLength(8);

        horizontalLayout_13->addWidget(m_ExamMin2);

        IDC_STATIC34_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC34_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC34_DEBUG"));
        IDC_STATIC34_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC34_DEBUG->setWordWrap(true);

        horizontalLayout_13->addWidget(IDC_STATIC34_DEBUG);

        m_ExamAve2 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamAve2->setObjectName(QString::fromUtf8("m_ExamAve2"));
        m_ExamAve2->setMaxLength(8);

        horizontalLayout_13->addWidget(m_ExamAve2);

        horizontalLayout_13->setStretch(0, 100);
        horizontalLayout_13->setStretch(1, 100);
        horizontalLayout_13->setStretch(2, 300);
        horizontalLayout_13->setStretch(3, 100);
        horizontalLayout_13->setStretch(4, 300);
        horizontalLayout_13->setStretch(5, 100);
        horizontalLayout_13->setStretch(6, 300);

        verticalLayout_7->addLayout(horizontalLayout_13);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(11, -1, -1, -1);
        IDC_STATIC26_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC26_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC26_DEBUG"));
        IDC_STATIC26_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC26_DEBUG->setWordWrap(true);

        horizontalLayout_14->addWidget(IDC_STATIC26_DEBUG);

        IDC_STATIC29_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC29_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC29_DEBUG"));
        IDC_STATIC29_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC29_DEBUG->setWordWrap(true);

        horizontalLayout_14->addWidget(IDC_STATIC29_DEBUG);

        m_ExamMax3 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMax3->setObjectName(QString::fromUtf8("m_ExamMax3"));
        m_ExamMax3->setMaxLength(8);

        horizontalLayout_14->addWidget(m_ExamMax3);

        IDC_STATIC32_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC32_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC32_DEBUG"));
        IDC_STATIC32_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC32_DEBUG->setWordWrap(true);

        horizontalLayout_14->addWidget(IDC_STATIC32_DEBUG);

        m_ExamMin3 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMin3->setObjectName(QString::fromUtf8("m_ExamMin3"));
        m_ExamMin3->setMaxLength(8);

        horizontalLayout_14->addWidget(m_ExamMin3);

        IDC_STATIC35_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC35_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC35_DEBUG"));
        IDC_STATIC35_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC35_DEBUG->setWordWrap(true);

        horizontalLayout_14->addWidget(IDC_STATIC35_DEBUG);

        m_ExamAve3 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamAve3->setObjectName(QString::fromUtf8("m_ExamAve3"));
        m_ExamAve3->setMaxLength(8);

        horizontalLayout_14->addWidget(m_ExamAve3);

        horizontalLayout_14->setStretch(0, 100);
        horizontalLayout_14->setStretch(1, 100);
        horizontalLayout_14->setStretch(2, 300);
        horizontalLayout_14->setStretch(3, 100);
        horizontalLayout_14->setStretch(4, 300);
        horizontalLayout_14->setStretch(5, 100);
        horizontalLayout_14->setStretch(6, 300);

        verticalLayout_7->addLayout(horizontalLayout_14);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QString::fromUtf8("horizontalLayout_28"));
        IDC_STATIC66_DEBUG_5 = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC66_DEBUG_5->setObjectName(QString::fromUtf8("IDC_STATIC66_DEBUG_5"));
        IDC_STATIC66_DEBUG_5->setAlignment(Qt::AlignCenter);
        IDC_STATIC66_DEBUG_5->setWordWrap(true);

        horizontalLayout_28->addWidget(IDC_STATIC66_DEBUG_5);

        horizontalSpacer_5 = new QSpacerItem(370, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_28->addItem(horizontalSpacer_5);


        verticalLayout_7->addLayout(horizontalLayout_28);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        horizontalLayout_17->setContentsMargins(11, -1, -1, -1);
        IDC_STATIC45_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC45_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC45_DEBUG"));
        IDC_STATIC45_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC45_DEBUG->setWordWrap(true);

        horizontalLayout_17->addWidget(IDC_STATIC45_DEBUG);

        IDC_STATIC66_DEBUG_4 = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC66_DEBUG_4->setObjectName(QString::fromUtf8("IDC_STATIC66_DEBUG_4"));
        IDC_STATIC66_DEBUG_4->setAlignment(Qt::AlignCenter);
        IDC_STATIC66_DEBUG_4->setWordWrap(true);

        horizontalLayout_17->addWidget(IDC_STATIC66_DEBUG_4);

        m_ExamMax4 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMax4->setObjectName(QString::fromUtf8("m_ExamMax4"));
        m_ExamMax4->setMaxLength(8);

        horizontalLayout_17->addWidget(m_ExamMax4);

        IDC_STATIC51_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC51_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC51_DEBUG"));
        IDC_STATIC51_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC51_DEBUG->setWordWrap(true);

        horizontalLayout_17->addWidget(IDC_STATIC51_DEBUG);

        m_ExamMin4 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMin4->setObjectName(QString::fromUtf8("m_ExamMin4"));
        m_ExamMin4->setMaxLength(8);

        horizontalLayout_17->addWidget(m_ExamMin4);

        IDC_STATIC54_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC54_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC54_DEBUG"));
        IDC_STATIC54_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC54_DEBUG->setWordWrap(true);

        horizontalLayout_17->addWidget(IDC_STATIC54_DEBUG);

        m_ExamAve4 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamAve4->setObjectName(QString::fromUtf8("m_ExamAve4"));
        m_ExamAve4->setMaxLength(8);

        horizontalLayout_17->addWidget(m_ExamAve4);

        horizontalLayout_17->setStretch(0, 100);
        horizontalLayout_17->setStretch(1, 100);
        horizontalLayout_17->setStretch(2, 300);
        horizontalLayout_17->setStretch(3, 100);
        horizontalLayout_17->setStretch(4, 300);
        horizontalLayout_17->setStretch(5, 100);
        horizontalLayout_17->setStretch(6, 300);

        verticalLayout_7->addLayout(horizontalLayout_17);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        horizontalLayout_18->setContentsMargins(11, -1, -1, -1);
        IDC_STATIC46_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC46_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC46_DEBUG"));
        IDC_STATIC46_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC46_DEBUG->setWordWrap(true);

        horizontalLayout_18->addWidget(IDC_STATIC46_DEBUG);

        IDC_STATIC49_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC49_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC49_DEBUG"));
        IDC_STATIC49_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC49_DEBUG->setWordWrap(true);

        horizontalLayout_18->addWidget(IDC_STATIC49_DEBUG);

        m_ExamMax5 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMax5->setObjectName(QString::fromUtf8("m_ExamMax5"));
        m_ExamMax5->setMaxLength(8);

        horizontalLayout_18->addWidget(m_ExamMax5);

        IDC_STATIC52_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC52_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC52_DEBUG"));
        IDC_STATIC52_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC52_DEBUG->setWordWrap(true);

        horizontalLayout_18->addWidget(IDC_STATIC52_DEBUG);

        m_ExamMin5 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMin5->setObjectName(QString::fromUtf8("m_ExamMin5"));
        m_ExamMin5->setMaxLength(8);

        horizontalLayout_18->addWidget(m_ExamMin5);

        IDC_STATIC55_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC55_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC55_DEBUG"));
        IDC_STATIC55_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC55_DEBUG->setWordWrap(true);

        horizontalLayout_18->addWidget(IDC_STATIC55_DEBUG);

        m_ExamAve5 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamAve5->setObjectName(QString::fromUtf8("m_ExamAve5"));
        m_ExamAve5->setMaxLength(8);

        horizontalLayout_18->addWidget(m_ExamAve5);

        horizontalLayout_18->setStretch(0, 100);
        horizontalLayout_18->setStretch(1, 100);
        horizontalLayout_18->setStretch(2, 300);
        horizontalLayout_18->setStretch(3, 100);
        horizontalLayout_18->setStretch(4, 300);
        horizontalLayout_18->setStretch(5, 100);
        horizontalLayout_18->setStretch(6, 300);

        verticalLayout_7->addLayout(horizontalLayout_18);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        horizontalLayout_19->setContentsMargins(11, -1, -1, -1);
        IDC_STATIC47_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC47_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC47_DEBUG"));
        IDC_STATIC47_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC47_DEBUG->setWordWrap(true);

        horizontalLayout_19->addWidget(IDC_STATIC47_DEBUG);

        IDC_STATIC50_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC50_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC50_DEBUG"));
        IDC_STATIC50_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC50_DEBUG->setWordWrap(true);

        horizontalLayout_19->addWidget(IDC_STATIC50_DEBUG);

        m_ExamMax6 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMax6->setObjectName(QString::fromUtf8("m_ExamMax6"));
        m_ExamMax6->setMaxLength(8);

        horizontalLayout_19->addWidget(m_ExamMax6);

        IDC_STATIC53_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC53_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC53_DEBUG"));
        IDC_STATIC53_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC53_DEBUG->setWordWrap(true);

        horizontalLayout_19->addWidget(IDC_STATIC53_DEBUG);

        m_ExamMin6 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamMin6->setObjectName(QString::fromUtf8("m_ExamMin6"));
        m_ExamMin6->setMaxLength(8);

        horizontalLayout_19->addWidget(m_ExamMin6);

        IDC_STATIC56_DEBUG = new QLabel(IDC_STATIC23_Group_box);
        IDC_STATIC56_DEBUG->setObjectName(QString::fromUtf8("IDC_STATIC56_DEBUG"));
        IDC_STATIC56_DEBUG->setAlignment(Qt::AlignCenter);
        IDC_STATIC56_DEBUG->setWordWrap(true);

        horizontalLayout_19->addWidget(IDC_STATIC56_DEBUG);

        m_ExamAve6 = new QLineEdit(IDC_STATIC23_Group_box);
        m_ExamAve6->setObjectName(QString::fromUtf8("m_ExamAve6"));
        m_ExamAve6->setMaxLength(8);

        horizontalLayout_19->addWidget(m_ExamAve6);

        horizontalLayout_19->setStretch(0, 100);
        horizontalLayout_19->setStretch(1, 100);
        horizontalLayout_19->setStretch(2, 300);
        horizontalLayout_19->setStretch(3, 100);
        horizontalLayout_19->setStretch(4, 300);
        horizontalLayout_19->setStretch(5, 100);
        horizontalLayout_19->setStretch(6, 300);

        verticalLayout_7->addLayout(horizontalLayout_19);


        verticalLayout_8->addLayout(verticalLayout_7);


        verticalLayout_11->addWidget(IDC_STATIC23_Group_box);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_11->addItem(verticalSpacer);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        m_StLost1 = new QLabel(Dlg_Debug);
        m_StLost1->setObjectName(QString::fromUtf8("m_StLost1"));

        verticalLayout_9->addWidget(m_StLost1);

        m_StLost2 = new QLabel(Dlg_Debug);
        m_StLost2->setObjectName(QString::fromUtf8("m_StLost2"));

        verticalLayout_9->addWidget(m_StLost2);


        verticalLayout_11->addLayout(verticalLayout_9);

        verticalLayout_11->setStretch(1, 1);

        verticalLayout_14->addLayout(verticalLayout_11);

        verticalLayout_14->setStretch(1, 1);

        horizontalLayout_30->addLayout(verticalLayout_14);


        verticalLayout_15->addLayout(horizontalLayout_30);


        retranslateUi(Dlg_Debug);

        QMetaObject::connectSlotsByName(Dlg_Debug);
    } // setupUi

    void retranslateUi(QDialog *Dlg_Debug)
    {
        Dlg_Debug->setWindowTitle(QApplication::translate("Dlg_Debug", "Dialog", 0, QApplication::UnicodeUTF8));
        IDC_STATIC1_Group_box->setTitle(QApplication::translate("Dlg_Debug", "\347\233\221\346\216\247\346\234\272\350\260\203\350\257\225\346\225\260\346\215\256", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_STATIC_VER4->setText(QApplication::translate("Dlg_Debug", "VER", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_MID5->setText(QApplication::translate("Dlg_Debug", "MID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_SID6->setText(QApplication::translate("Dlg_Debug", "SID", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_DID7->setText(QApplication::translate("Dlg_Debug", "Did", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_BIDLINKER11->setText(QApplication::translate("Dlg_Debug", "BID\345\270\270\346\227\266", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_BIDME9->setText(QApplication::translate("Dlg_Debug", "BID\345\256\236\347\256\227", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_A13->setText(QApplication::translate("Dlg_Debug", "\346\226\271\344\275\215\350\247\222   A\357\274\210\345\272\246\357\274\211", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_E14->setText(QApplication::translate("Dlg_Debug", "\344\277\257\344\273\260\350\247\222E\357\274\210\345\272\246\357\274\211", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_TAR17->setText(QApplication::translate("Dlg_Debug", "\345\205\267\346\234\211\347\233\256\346\240\207", 0, QApplication::UnicodeUTF8));
        m_IsTarget->setText(QApplication::translate("Dlg_Debug", "\345\267\262\350\267\237\350\270\252\344\270\212\347\233\256\346\240\207", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_CONTROL18->setText(QApplication::translate("Dlg_Debug", "\344\274\272\346\234\215\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
        m_ServerMode->clear();
        m_ServerMode->insertItems(0, QStringList()
         << QApplication::translate("Dlg_Debug", "\345\215\225\346\235\206", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dlg_Debug", "\347\250\213\345\272\217\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dlg_Debug", "\345\244\226\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dlg_Debug", "\347\224\265\350\247\206\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dlg_Debug", "\346\255\243\345\274\246\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dlg_Debug", "\347\255\211\351\200\237\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dlg_Debug", "\345\256\232\344\275\215", 0, QApplication::UnicodeUTF8)
        );
        IDC_STATIC_DEBUG_X15->setText(QApplication::translate("Dlg_Debug", "\350\204\261\351\235\266\350\247\222X\357\274\210\347\247\222\357\274\211", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_Y16->setText(QApplication::translate("Dlg_Debug", "\350\204\261\351\235\266\350\247\222Y\357\274\210\347\247\222\357\274\211", 0, QApplication::UnicodeUTF8));
        IDC_STATIC19_Group_box->setTitle(QApplication::translate("Dlg_Debug", "\344\270\216\344\270\273\346\216\247\350\201\224\350\260\203", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_DX20->setText(QApplication::translate("Dlg_Debug", "\345\244\226\351\203\250\350\257\264\346\230\216\345\244\247\345\234\260", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_DY21->setText(QApplication::translate("Dlg_Debug", "\345\244\226\351\203\250\350\257\264\346\230\216\345\244\247\345\234\260", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_DZ22->setText(QApplication::translate("Dlg_Debug", "\345\244\226\351\203\250\350\257\264\346\230\216\345\244\247\345\234\260", 0, QApplication::UnicodeUTF8));
        IDC_STATIC_DEBUG_DY21_2->setText(QString());
        IDC_STATIC_DEBUG_DY21_3->setText(QString());
        DEBUG_SENDTO->setText(QApplication::translate("Dlg_Debug", "\345\274\200\345\247\213\345\217\221\351\200\201TO\345\222\214\345\244\226\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8));
        DEBUG_STOPTO->setText(QApplication::translate("Dlg_Debug", "\345\201\234\346\255\242\345\217\221\351\200\201\346\225\260\346\215\256", 0, QApplication::UnicodeUTF8));
        DEBUG_APPLY->setText(QApplication::translate("Dlg_Debug", "\345\272\224\347\224\250", 0, QApplication::UnicodeUTF8));
        DEBUG_SAVE->setText(QApplication::translate("Dlg_Debug", "\345\272\224\347\224\250\345\271\266\344\277\235\345\255\230", 0, QApplication::UnicodeUTF8));
        DEBUG_CANCEL->setText(QApplication::translate("Dlg_Debug", "\345\217\226\346\266\210", 0, QApplication::UnicodeUTF8));
        DEBUG_STARTLOST->setText(QApplication::translate("Dlg_Debug", "\345\274\200\345\247\213\344\271\261\345\272\217\347\273\237\350\256\241", 0, QApplication::UnicodeUTF8));
        DEBUG_CHECK_STATUSSWITCH->setText(QApplication::translate("Dlg_Debug", "\344\270\216\347\233\221\346\216\247\346\234\272\345\210\207\346\215\242\344\270\272\350\260\203\350\257\225\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
        DEBUG_CHECK_STATUSSWITCH2->setText(QApplication::translate("Dlg_Debug", "\344\270\216\346\234\254\345\234\260\345\210\207\346\215\242\344\270\272\350\260\203\350\257\225\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
        DEBUG_SENDEXAM->setText(QApplication::translate("Dlg_Debug", "\344\270\273\345\212\250\345\217\221\350\265\267\346\227\266\345\273\266\346\265\213\350\257\225", 0, QApplication::UnicodeUTF8));
        IDC_STATICEXTRA_Group_box->setTitle(QString());
        IDC_STATIC12_DEBUG->setText(QApplication::translate("Dlg_Debug", "BID\346\227\266\345\273\266\346\265\213\350\257\225", 0, QApplication::UnicodeUTF8));
        IDC_STATIC8_DEBUG->setText(QApplication::translate("Dlg_Debug", "BID    TO", 0, QApplication::UnicodeUTF8));
        IDC_STATIC10_DEBUG->setText(QApplication::translate("Dlg_Debug", "BID\345\244\226\351\203\250\350\257\264\346\230\216", 0, QApplication::UnicodeUTF8));
        m_ModeBmp->setText(QApplication::translate("Dlg_Debug", "<html><head/><body><p><img src=\":/myImage/Images/normal.bmp\"/></p></body></html>", 0, QApplication::UnicodeUTF8));
        STATIC_DEBUG_MODE3->setText(QApplication::translate("Dlg_Debug", "\345\275\223\345\211\215\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        IDC_STATIC23_Group_box->setTitle(QApplication::translate("Dlg_Debug", "\346\227\266\345\273\266\346\265\213\350\257\225\347\273\223\346\236\234\357\274\210\346\257\253\347\247\222\357\274\211", 0, QApplication::UnicodeUTF8));
        IDC_STATIC66_DEBUG->setText(QApplication::translate("Dlg_Debug", "\350\267\257\347\224\2611", 0, QApplication::UnicodeUTF8));
        IDC_STATIC27_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\216\273\347\250\213", 0, QApplication::UnicodeUTF8));
        IDC_STATIC66_DEBUG_3->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\244\247", 0, QApplication::UnicodeUTF8));
        m_ExamMax1->setText(QString());
        IDC_STATIC30_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\260\217", 0, QApplication::UnicodeUTF8));
        m_ExamMin1->setText(QString());
        IDC_STATIC33_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\271\263\345\235\207", 0, QApplication::UnicodeUTF8));
        m_ExamAve1->setText(QString());
        IDC_STATIC25_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\233\236\347\250\213", 0, QApplication::UnicodeUTF8));
        IDC_STATIC28_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\244\247", 0, QApplication::UnicodeUTF8));
        m_ExamMax2->setText(QString());
        IDC_STATIC31_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\260\217", 0, QApplication::UnicodeUTF8));
        m_ExamMin2->setText(QString());
        IDC_STATIC34_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\271\263\345\235\207", 0, QApplication::UnicodeUTF8));
        m_ExamAve2->setText(QString());
        IDC_STATIC26_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\205\250\347\250\213", 0, QApplication::UnicodeUTF8));
        IDC_STATIC29_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\244\247", 0, QApplication::UnicodeUTF8));
        m_ExamMax3->setText(QString());
        IDC_STATIC32_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\260\217", 0, QApplication::UnicodeUTF8));
        m_ExamMin3->setText(QString());
        IDC_STATIC35_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\271\263\345\235\207", 0, QApplication::UnicodeUTF8));
        m_ExamAve3->setText(QString());
        IDC_STATIC66_DEBUG_5->setText(QApplication::translate("Dlg_Debug", "\350\267\257\347\224\2612", 0, QApplication::UnicodeUTF8));
        IDC_STATIC45_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\216\273\347\250\213", 0, QApplication::UnicodeUTF8));
        IDC_STATIC66_DEBUG_4->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\244\247", 0, QApplication::UnicodeUTF8));
        m_ExamMax4->setText(QString());
        IDC_STATIC51_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\260\217", 0, QApplication::UnicodeUTF8));
        m_ExamMin4->setText(QString());
        IDC_STATIC54_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\271\263\345\235\207", 0, QApplication::UnicodeUTF8));
        m_ExamAve4->setText(QString());
        IDC_STATIC46_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\233\236\347\250\213", 0, QApplication::UnicodeUTF8));
        IDC_STATIC49_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\244\247", 0, QApplication::UnicodeUTF8));
        m_ExamMax5->setText(QString());
        IDC_STATIC52_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\260\217", 0, QApplication::UnicodeUTF8));
        m_ExamMin5->setText(QString());
        IDC_STATIC55_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\271\263\345\235\207", 0, QApplication::UnicodeUTF8));
        m_ExamAve5->setText(QString());
        IDC_STATIC47_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\205\250\347\250\213", 0, QApplication::UnicodeUTF8));
        IDC_STATIC50_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\244\247", 0, QApplication::UnicodeUTF8));
        m_ExamMax6->setText(QString());
        IDC_STATIC53_DEBUG->setText(QApplication::translate("Dlg_Debug", "\346\234\200\345\260\217", 0, QApplication::UnicodeUTF8));
        m_ExamMin6->setText(QString());
        IDC_STATIC56_DEBUG->setText(QApplication::translate("Dlg_Debug", "\345\271\263\345\235\207", 0, QApplication::UnicodeUTF8));
        m_ExamAve6->setText(QString());
        m_StLost1->setText(QApplication::translate("Dlg_Debug", "static", 0, QApplication::UnicodeUTF8));
        m_StLost2->setText(QApplication::translate("Dlg_Debug", "static", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dlg_Debug: public Ui_Dlg_Debug {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DLG_DEBUG_H
