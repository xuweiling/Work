﻿#include "yfthread.h"
#include "yfagent.h"
#include "yfmainwindow.h"
#include <string>

using namespace std;

#define coldStartOid "1.3.6.1.6.3.1.1.5.1"
#define warmStartOid "1.3.6.1.6.3.1.1.5.2"
#define linkDownOid "1.3.6.1.6.3.1.1.5.3"
#define linkUpOid "1.3.6.1.6.3.1.1.5.4"
#define authenticationFailureOid "1.3.6.1.6.3.1.1.5.5"
#define egpNeighborLossOid "1.3.6.1.6.3.1.1.5.6"

extern QString YFtrapID[YFAGENTPARNUM];
extern int     YFtrapIDNum;
extern YFSnmpAgent yfsnmpagent;

YFThread::YFThread(int flag,QObject *parent) :
    QThread(parent)
{
    stopped = false;

    threadFalg = flag;
}

void YFThread::run()
{
    if(threadFalg == 1)
    {
        int argc = 0;
        char argvSub[10];
        char *argv[1];
        argv[0] = argvSub;

        QString *YFaddString;
        YFaddString = YFtrapID;

        int YFargc = YFtrapIDNum;
        yfsnmpagent.agentmain(argc,argv,YFaddString,YFargc);
    }
    else if(threadFalg == 2)
    {
        yfsnmpagent.trapto("1.3.6.1.4.1.1.1.0");
    }
    else if(threadFalg == 3)
    {
        while(!stopped)
        {
            //OnTimer1HzThread();
            OnReceiveThread();
        }


    }

    stopped = false;
}

void YFThread::stop()
{
    stopped = true;
}

long  YFThread::OnTimer1HzThread()
{

}

void YFThread::OnReceiveThread()
{

}
