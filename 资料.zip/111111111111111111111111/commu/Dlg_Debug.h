﻿#ifndef DLG_DEBUG_H
#define DLG_DEBUG_H

#include "GlabalDefine.h"
#include <QDialog>







typedef unsigned int        UINT;
typedef unsigned long  DWORD;
typedef unsigned char  BYTE;
typedef unsigned short WORD;






namespace Ui {
class Dlg_Debug;
}

class Dlg_Debug : public QDialog
{
    Q_OBJECT

public:
    explicit Dlg_Debug(QWidget *parent = 0);
    ~Dlg_Debug();

public:
    void InitDebugData();
    void UnInitDebugData();

    HEADERStruct	DebugHEADER_Measure;					//调试实算数据帧头信息 ，调试模式下，主要是调试实算数据。
    HEADERStruct	DebugHEADER_Timer;						//调试常时时数据帧头信息
//	HEADERStruct	DebugHEADER_WYD;						//调试常时时数据帧头信息
    int			INI_DATALENGTH_MEASURE;				//实算数据中数据区有效长度 = 32, 22+10
    double		A;									//中心调试数据A
    double		E;									//中心调试数据E
    double		OffsetX;							//中心调试数据X
    double		OffsetY;							//中心调试数据Y
    double		WydX;								//主控调试数据X
    double		WydY;								//主控调试数据Y
    double		WydZ;								//主控调试数据Z
    QString		ServerMode;							//主控调试数据伺服模式

    int			ZKStatus;							//是否开始向主控机发送T0和外引导 0:没有发送、1:发送T0、2:发送WYD
    UINT		ZKDebugIndex;						//向主控机发送T0的包数
    DWORD		CTDebugIndex;						//向监控机发送的包数
    DWORD		ZKT0;								//主控发送的T0时刻（0.1毫秒）

    bool IsLostExaming;					//是否正在丢包乱序测试中

signals:
    void WM_USER_STARTLOST(unsigned int , long);
    void WM_COMMANDStatus();
    void WM_COMMANDStatus2();
    void  WM_COMMANDSendexam();



 private slots:
    void OnButtonSendZK();
    void OnButtonStopTO();
    void OnButtonApply();
    void OnButtonSave();
    void OnDebugCancel();

 public slots:
    void OnBnClickedDebugStartlost();
    void OnBnClickedDebugCheckStatusswitch();
    void OnBnClickedDebugCheckStatusswitch2();
    void OnBnClickedButtonDebugSendexam();

public:
    Ui::Dlg_Debug *getui(){return ui;}
    Ui::Dlg_Debug *ui;
};

#endif // DLG_DEBUG_H
