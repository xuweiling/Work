// Matrix.cpp: implementation of the CMatrix class.
//
//////////////////////////////////////////////////////////////////////

//l/#include "stdafx.h"
#include "Matrix.h"
#include <memory.h> 
//l/#include <WINDOWS.H>
#include <stdio.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMatrix::CMatrix()
{
	cols=0;
	rows=0;
	buffer=NULL;
	M_temp=NULL;
}

CMatrix::CMatrix(CMatrix & m1)
{

		buffer=NULL;
		M_temp=NULL;
		cols=m1.cols;
		rows=m1.rows;
	
		buffer=new double [rows*cols];
		memcpy(buffer,m1.buffer,sizeof(double)*rows*cols);
}
/*
CMatrix::CMatrix(double data,...)
{
	buffer=NULL;
	M_temp=NULL;

	rows=0;cols=0;
	printf("this is a sample for () assignment!");
}*/

CMatrix::CMatrix(int row,int col)
{
	cols=col;
	rows=row;
	buffer=new double [row*col];
	ZeroMemory(buffer,sizeof(double)*rows*cols);
	M_temp=NULL;
}
CMatrix::~CMatrix()
{
	if(buffer!=NULL)
		delete [] buffer;
	if(M_temp!=NULL)
		delete M_temp;


}
void CMatrix::SetAt(int row,int col,double value)
{
	//if(row<=rows && row>0 && col >0 && col <=cols)
	row=row>rows?rows:row;
	row=row<1?1:row;
	col=col>cols?cols:col;
	col=col<1?1:col;

	buffer[(col-1)*rows+row-1]=value;
}
double CMatrix::GetAt(int row,int col)
{
	//if(row<=rows && row>0 && col >0 && col <=cols)
	row=row>rows?rows:row;
	row=row<1?1:row;
	col=col>cols?cols:col;
	col=col<1?1:col;
	
	return buffer[(col-1)*rows+row-1];
}
void CMatrix::reshape(int row,int col)
{

	if(buffer!=NULL)
		delete [] buffer;
	rows=row;
	cols=col;
	buffer=new double [rows*cols];
	ZeroMemory(buffer,sizeof(double)*rows*cols);
}

CMatrix& CMatrix::operator * (const CMatrix & m1)
{
	if(M_temp==NULL)
		M_temp=new CMatrix;
	M_temp->MatrixMultil(*this,m1);
	return *M_temp;
}
CMatrix& CMatrix::operator+( CMatrix & m1)
{
	if(rows==m1.rows && cols==m1.cols )
	{	
		if(M_temp==NULL)
			M_temp=new CMatrix;
		M_temp->reshape(rows,cols);
		for(int i=1;i<=rows;i++)
		for(int j=1;j<=cols;j++)
			M_temp->SetAt(i,j,GetAt(i,j)+m1.GetAt(i,j));
	}
	else
	{
		if(M_temp!=NULL)
		{	delete M_temp;
			M_temp=NULL;
		}
	}
	return * M_temp;
		
}
CMatrix& CMatrix::operator-( CMatrix & m1)
{
	if(rows==m1.rows && cols==m1.cols )
	{	
		if(M_temp==NULL)
			M_temp=new CMatrix;
		M_temp->reshape(rows,cols);
		for(int i=1;i<=rows;i++)
		for(int j=1;j<=cols;j++)
			M_temp->SetAt(i,j,GetAt(i,j)-m1.GetAt(i,j));
	}
	else
	{
		if(M_temp!=NULL)
		{	delete M_temp;
			M_temp=NULL;
		}
	}
	return * M_temp;
}
CMatrix & CMatrix::operator=( const CMatrix & m1)
{
	cols=m1.cols;
	rows=m1.rows;
	if(buffer!=NULL)
		delete [] buffer;
			
	buffer=new double [rows*cols];
	memcpy(buffer,m1.buffer,sizeof(double)*rows*cols);
	return *this;
}

double& CMatrix::operator()( int row,int col)
{
	double * point=NULL;
	row=row>rows?rows:row;
	row=row<1?1:row;
	col=col>cols?cols:col;
	col=col<1?1:col;
	

//	if(row<=rows && row>0 && col >0 && col<cols)	   
	   point=buffer+(col-1)*rows+row-1;
		return *point;
}

CMatrix& CMatrix::MatrixMultil(const CMatrix & m1,const CMatrix & m2)
{
	//CMatrix ret;

	if(m1.rows*m1.cols*m2.rows*m2.cols!=0)
	{
			if(m1.cols!=m2.rows)
				error=1;//行列错误！
			else 
				{
					rows=m1.rows;
					cols=m2.cols;
					if(buffer!=NULL)
						delete [] buffer;
					buffer=new double [rows*cols];
						for(int n=0;n<m1.rows;n++)	
							for(int j=0;j<m2.cols;j++)
								{
									double sum=0;
									for(int i=0;i<m1.cols;i++)
										sum+=m1.buffer[n+i*m1.rows]*m2.buffer[j*m2.rows+i];
									buffer[n+j*rows]=sum;
								}
				}
	}
	return * this;
}
CMatrix & CMatrix::reverse()
{
	if(M_temp==NULL)
		M_temp=new CMatrix(cols,rows);
	M_temp->reshape(cols,rows);
	for(int i=1;i<=rows;i++)
		for(int j=1;j<=cols;j++)
			M_temp->SetAt(j,i,this->GetAt(i,j));
		
		return *M_temp;

}
void CMatrix::Print()
{

	for(int i=0;i<rows;i++)
	{for(int j=0;j<cols;j++)
			printf("%f\t",buffer[j*rows+i]);
		printf("\n");
	}
}
