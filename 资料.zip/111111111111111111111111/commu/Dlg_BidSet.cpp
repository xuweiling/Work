﻿#include "Dlg_BidSet.h"
#include "ui_Dlg_BidSet.h"
 #include <QMessageBox>

#include "GlabalDefine.h"

CDlg_BIDSet::CDlg_BIDSet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CDlg_BIDSet)
{
    ui->setupUi(this);
    //connect(ui->delButton,SIGNAL(clicked()),this,SLOT(OnButton()));
    pBIDCount = 0;
}

CDlg_BIDSet::~CDlg_BIDSet()
{
    delete ui;
}

void CDlg_BIDSet::init()
{
    // TODO:  Add extra initialization here
    double tempValue_D;
    DWORD tempValue_DW;
    QString newAddr;
    int BIDIndex=0;
    ui->m_NewBID_va->clear();

    for(BIDIndex=0; BIDIndex<pBIDCount; BIDIndex++)
    {
        newAddr=newAddr.sprintf("%.8x", pBID[BIDIndex]);
        ui->m_ExistBIDList->addItem(newAddr);
    }

    if (ui->m_ExistBIDList->count() >0)
    {
        ui->m_ExistBIDList->setCurrentRow(0);
    }
}

void CDlg_BIDSet::on_addButton_clicked()
{
    qDebug("AddButton");
    if(ui->m_ExistBIDList->count()>=21)
    {
        QMessageBox::information(0, QString("Message"),
                                       QString("超出设计范围，不再添加新的外部说明BID"),
                                       QMessageBox::Ok,
                                       QMessageBox::Ok);
        return;
    }
    QString newAdd = ui->m_NewBID_va->text();
    ui->m_ExistBIDList->addItem(newAdd);
    return;
}



void CDlg_BIDSet::on_delButton_clicked()
{
    qDebug("DelButton");
    // TODO: Add your control notification handler code here
    int nItem = 0;
    if(ui->m_ExistBIDList->count()  >0)
        nItem = 0;
    else
        return;
    nItem = ui->m_ExistBIDList->currentRow ();
    if(nItem<0)
    {
        TRACE("NO item selected\n");
    }
    else
    {
        ui->m_ExistBIDList->takeItem(nItem);//先清空之前的列表
    }
}

void CDlg_BIDSet::on_okButton_clicked()
{
    qDebug("OkButton");
    // TODO: Add your control notification handler code here
    pBIDCount = ui->m_ExistBIDList->count();

    double tempValue_D;
    DWORD tempValue_DW;
    QString newAddr;
    int BIDIndex=0;

   // int cou = ui->m_ExistBIDList.count();
    for(BIDIndex=0; BIDIndex<ui->m_ExistBIDList->count(); BIDIndex++)
    {
        QListWidgetItem * newAddrItem=ui->m_ExistBIDList->item(BIDIndex);
        newAddr=newAddrItem->text();
        tempValue_DW =CharToHex(newAddr);//不得超过4byte
        pBID[BIDIndex] = tempValue_DW;
    }

    accept();
}
