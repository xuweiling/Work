﻿#include <stdlib.h>
#include <signal.h>

#include <agent_pp/agent++.h>
#include <agent_pp/snmp_group.h>
#include <agent_pp/system_group.h>
#include <agent_pp/snmp_target_mib.h>
#include <agent_pp/snmp_notification_mib.h>
#include <agent_pp/snmp_community_mib.h>
#include <agent_pp/notification_originator.h>
#include <agent_pp/notification_log_mib.h>
#include <agent_pp/agentpp_simulation_mib.h>
#include <agent_pp/agentpp_config_mib.h>
#include <agent_pp/v3_mib.h>
#include <agent_pp/mib_policy.h>
#include <agent_pp/vacm.h>

#include <snmp_pp/oid_def.h>
#include <snmp_pp/mp_v3.h>
#include <snmp_pp/log.h>

//#include "atm_mib.h"
//#include "agentpp_notifytest_mib.h"
//#include "agentpp_test_mib.h"
#include <pthread.h>

#ifdef SNMP_PP_NAMESPACE
using namespace Snmp_pp;
#endif

#ifdef AGENTPP_NAMESPACE
using namespace Agentpp;
#endif

#include "yfprocessrequest.h"
#include <iostream>
#include <string>
using namespace std;
#include "yfmIbbrowerview.h"


extern TreeNode YFHRoot;

#define ACCESS_NUM  3
const string ACCESS[ACCESS_NUM] = {"NOTACCESS",
						  	  	  "READONLY",
								  "READWRITE"
						  	  	  };

/**
 * Internally process a request (within its own thread)
 * @param req - A request.
 */
void YFMib::YF_do_process_request(Request* req)
{
	LOG_BEGIN(EVENT_LOG | 2);
	LOG("Agent: starting thread execution (pduType)(subrequests)");
	LOG(req->get_type());
	LOG(req->subrequests());
	LOG_END;
#ifdef _SNMPv3
#ifdef _PROXY_FORWARDER
	// init myEngineID if not yet initialized
	if ((requestList) && (myEngineID.len() == 0) &&
	    (requestList->get_v3mp()))
	    requestList->get_v3mp()->get_local_engine_id(myEngineID);
	// check for proxy request
	if ((req->get_pdu()->get_context_engine_id().len() > 0) &&
	    (myEngineID != req->get_pdu()->get_context_engine_id())) {
		// use requestList directly to avoid processing by sub classes
		LOG_BEGIN(EVENT_LOG | 2);
		LOG("Mib: processing proxy request (contextEngineID)");
		LOG(req->get_pdu()->get_context_engine_id().get_printable_hex());
		LOG_END;
	        proxy_request(req);
		LOG_BEGIN(EVENT_LOG | 2);
		LOG("Agent: finished thread execution");
		LOG_END;
		return;
	}
#endif
#endif
	int n = req->subrequests();
	if (n > 0) {
		int i;
		switch (req->get_type()) {
		case (sNMP_PDU_GET): {

		  LOG_BEGIN(EVENT_LOG | 2);
		  LOG("Mib: process request: get request, oid");
		  LOG(req->get_transaction_id());
		  for (i=0; i<n; i++)
			LOG(req->get_oid(i).get_printable());
		  LOG_END;

		  for (i=0; i<n; i++) {
			if (!req->is_done(i))
				if (!YF_process_request(req, i)) break;
		  }
		  break;
		}
		case (sNMP_PDU_GETNEXT): {

		  LOG_BEGIN(EVENT_LOG | 2);
		  LOG("Mib: process request: getnext request, oid");
		  LOG(req->get_transaction_id());
		  for (i=0; i<n; i++)
			LOG(req->get_oid(i).get_printable());
		  LOG_END;

		  for (i=0; i<n; i++) {
			if (!req->is_done(i))
				if (!YF_process_request(req, i)) break;
		  }
		  break;
		}
		case (sNMP_PDU_GETBULK): {
		  process_get_bulk_request(req);
		  break;
		}
		case (sNMP_PDU_SET): {
		  process_set_request(req);
		  break;
		}
		}
	}
	// answer the request
//	Vbx vb(req->get_oid(0));
//	vb.set_value("yanfegn");
//	req->finish(0,vb);
	finalize(req);

	LOG_BEGIN(EVENT_LOG | 2);
	LOG("Agent: finished thread execution");
	LOG_END;
}

void YFMib::YF_process_set_request(Request* req)
{
	int n = req->subrequests();

	LOG_BEGIN(EVENT_LOG | 2);
	LOG("Mib: process request: set request (tid)(oid)");
	LOG(req->get_transaction_id());

	for (int j=0; j<n; j++)
		LOG(req->get_oid(j).get_printable());
	LOG_END;
	req->phase++; // indicate PHASE_PREPARE
	if (process_prepare_set_request(req) == SNMP_ERROR_SUCCESS) {
		req->phase++; // indicate PHASE_COMMIT
		if (process_commit_set_request(req) !=
		    SNMP_ERROR_SUCCESS) {

			req->phase++;

			LOG_BEGIN(WARNING_LOG | 2);
			LOG("Mib: commit failed (tid)");
			LOG(req->get_transaction_id());
			LOG_END;

			process_undo_set_request(req);
			return;
		}
	}
	req->phase = PHASE_CLEANUP;
	process_cleanup_set_request(req);
}

boolean YFMib::YF_process_request(Request* req, int reqind)
{
	// only GET and GETNEXT subrequest can be performed independently
	switch (req->get_type()) {
	case (sNMP_PDU_GET): {

	       	LOG_BEGIN(EVENT_LOG | 3);
	       	LOG("Mib: process subrequest: get request, oid");
	       	LOG(req->get_transaction_id());
	       	LOG(req->get_oid(reqind).get_printable());
	       	LOG_END;

		MibEntryPtr entry;
		Oidx tmpoid(req->get_oid(reqind));
		int err;

		lock_mib();
		// entry not available
#ifdef _SNMPv3
		if ((err = find_managing_object(get_context(req->get_context()),
					  tmpoid, entry, req)) != SNMP_ERROR_SUCCESS)
#else
		if ((err = find_managing_object(defaultContext,
						tmpoid, entry, req)) != SNMP_ERROR_SUCCESS)
#endif
		{
			unlock_mib();
			return set_exception_vb(req, reqind, err);
		}
//#ifdef _SNMPv3
//                // access control  ??????
//                int vacmErrorCode =
//                 requestList->get_vacm()->
//		  isAccessAllowed(req->viewName, tmpoid);
//		if (vacmErrorCode == VACM_notInView) {
//		    unlock_mib();
//		    return set_exception_vb(req, reqind,
//					    sNMP_SYNTAX_NOSUCHOBJECT);
//		}
//		else if (vacmErrorCode != VACM_accessAllowed) {
//		  unlock_mib();
//                  req->vacmError(reqind, vacmErrorCode);
//                  return FALSE;
//                }
//#endif
		entry->start_synch();
		unlock_mib();
		entry->get_request(req, reqind);
		entry->end_synch();
		break;
	}
	case (sNMP_PDU_GETNEXT): {

	       	LOG_BEGIN(EVENT_LOG | 3);
	       	LOG("Mib: process subrequest: getnext request, oid");
	       	LOG(req->get_transaction_id());
		LOG(req->get_oid(reqind).get_printable());
	       	LOG_END;

		MibEntryPtr entry;
		Oidx tmpoid(req->get_oid(reqind));
		lock_mib();
#ifdef _SNMPv3
		int vacmErrorCode = VACM_otherError;
		do {
		  if (find_next(get_context(req->get_context()), tmpoid, entry,
				req, reqind) != SNMP_ERROR_SUCCESS) {
#else
	reprocess:
		// this goto label is used for complex (i.g., proxy) mib
		// entries that to not exatcly know their last member
		  if (find_next(defaultContext, tmpoid, entry,
				req, reqind) != SNMP_ERROR_SUCCESS) {
#endif
			unlock_mib();
			return set_exception_vb(req, reqind,
						sNMP_SYNTAX_ENDOFMIBVIEW);
		  }
#ifdef _SNMPv3
		} while ((vacmErrorCode = next_access_control(req,
							      entry,
							      tmpoid)) ==
			  VACM_notInView);

                if (vacmErrorCode != VACM_accessAllowed) {
		  unlock_mib();
                  req->vacmError(reqind, vacmErrorCode);
                  return FALSE;
                }
#else
		switch (entry->type()) {
		case AGENTPP_TABLE: {
			tmpoid = ((MibTable*)entry)->find_succ(tmpoid, req);
			break;
		}
		case AGENTX_NODE:
		case AGENTX_LEAF:
		case AGENTPP_LEAF: { break; }
		case AGENTPP_COMPLEX: {
			Oidx nextoid;
			nextoid = entry->find_succ(tmpoid, req);
			if (!nextoid.valid()) {
				goto reprocess;
			}
			else {
				tmpoid = nextoid;
			}
			break;
		}
		case AGENTPP_PROXY: {
			Oidx nextoid;
			nextoid = entry->find_succ(tmpoid, req);
			if (!nextoid.valid()) {
				goto reprocess;
			}
			break;
		}
		default: {
			LOG_BEGIN(ERROR_LOG | 1);
			LOG("Mib::get_next_request: not implemented (entry->type)");
			LOG(entry->type());
			LOG_END;
		}
		}
#endif
		// set oid of request to found object
		// this can be done because at this point we are sure
		// that we can answer the request
		req->set_oid(tmpoid, reqind);
		entry->start_synch();
		unlock_mib();
		entry->get_next_request(req, reqind);
		entry->end_synch();
		break;
	}
	}
	return TRUE;
}

void YFMib::YFAnswerGet(Request* req)
{
	Oidx oid = req->get_oid(0);
	string YFOidString = (string)oid.get_printable();
	YFOidString=YFOidString.substr(0,YFOidString.find_last_of("0")-1);
	LOG_BEGIN(EVENT_LOG | 2);
	LOG(YFOidString.c_str());
	LOG_END;

	TreeNode *SubRootconst = NULL;
	SearchNodeFromOID(&YFHRoot,SubRootconst, YFOidString);
	if(SubRootconst == NULL)
	{
		LOG_BEGIN(WARNING_LOG | 2);
		LOG("no objects");
		LOG_END;
		YF_do_process_request(req);
	}
	else
	{
		Vbx vb(req->get_oid(0));
		vb.set_value(SubRootconst->Currentname.c_str());
//		vb.set_value("1");
		req->finish(0,vb);
		finalize(req);
	}
}

boolean YFMib::YFProcessRequest(Request* req, int reqind)
{
	// only GET and GETNEXT subrequest can be performed independently
	switch (req->get_type()) {
	case (sNMP_PDU_GET): {

	       	LOG_BEGIN(EVENT_LOG | 3);
	       	LOG("Mib: process subrequest: get request, oid");
	       	LOG(req->get_transaction_id());
	       	LOG(req->get_oid(reqind).get_printable());
	       	LOG_END;

	    	Oidx oid = req->get_oid(reqind);
	    	string YFOidString = (string)oid.get_printable();
	    	YFOidString=YFOidString.substr(0,YFOidString.find_last_of("0")-1);
	    	LOG_BEGIN(EVENT_LOG | 2);
	    	LOG(YFOidString.c_str());
	    	LOG_END;

	    	TreeNode *SubRootconst = NULL;
	    	SearchNodeFromOID(&YFHRoot,SubRootconst, YFOidString);
	    	if(SubRootconst == NULL)
	    	{
	    		LOG_BEGIN(WARNING_LOG | 2);
	    		LOG("no objects");
	    		LOG_END;
	    		YF_do_process_request(req);
	    	}
	    	else
	    	{
	    		Vbx vb(req->get_oid(reqind));
	    		if(SubRootconst->Mibdata.PSnytax == "Int")
	    			vb.set_value(SubRootconst->Mibdata.PIValue);
	    		else
	    			vb.set_value(SubRootconst->Mibdata.PSValue.c_str());
	    //		vb.set_value(SubRootconst->Currentname.c_str());
	    //		vb.set_value("1");
	    		req->finish(reqind,vb);
	    	}
		break;
	}
	case (sNMP_PDU_GETNEXT): {

	       	LOG_BEGIN(EVENT_LOG | 3);
	       	LOG("Mib: process subrequest: getnext request, oid");
	       	LOG(req->get_transaction_id());
	       	LOG(req->get_oid(reqind).get_printable());
	       	LOG_END;

	    	Oidx oid = req->get_oid(reqind);
	    	string YFOidString = (string)oid.get_printable();
	    	YFOidString=YFOidString.substr(0,YFOidString.find_last_of("0")-1);
	    	LOG_BEGIN(EVENT_LOG | 2);
	    	LOG(YFOidString.c_str());
	    	LOG_END;

	    	TreeNode *SubRootconst = NULL;
	    	SearchNodeFromOID(&YFHRoot,SubRootconst, YFOidString);
	    	SubRootconst = SubRootconst->RChildren;
	    	if(SubRootconst == NULL)
	    	{
	    		LOG_BEGIN(WARNING_LOG | 2);
	    		LOG("no objects");
	    		LOG_END;
	    		YF_do_process_request(req);
	    	}
	    	else
	    	{
	    		Oidx tmpOid(SubRootconst->Mibdata.POid.c_str());
	    		req->set_oid(tmpOid,reqind);

	    		Vbx vb(req->get_oid(reqind));
	    		if(SubRootconst->Mibdata.PSnytax == "Int")
	    			vb.set_value(SubRootconst->Mibdata.PIValue);
	    		else
	    			vb.set_value(SubRootconst->Mibdata.PSValue.c_str());

	    		req->finish(reqind,vb);
	    	}
		}
	}
	return TRUE;
}




int YFMib::YFProcessPrepareSetRequest(Request* req)
{
	LOG_BEGIN(EVENT_LOG | 3);
	LOG("Agent: preparing set request");
	LOG(req->get_transaction_id());
	LOG_END;


	for (int i=0; i<req->subrequests(); i++) {

       	LOG_BEGIN(EVENT_LOG | 3);
       	LOG("Mib: process subrequest: set request, oid");
       	LOG(req->get_transaction_id());
       	LOG(req->get_oid(i).get_printable());
       	LOG_END;

    	Oidx oid = req->get_oid(i);
    	string YFOidString = (string)oid.get_printable();
    	YFOidString=YFOidString.substr(0,YFOidString.find_last_of("0")-1);
    	LOG_BEGIN(EVENT_LOG | 2);
    	LOG(YFOidString.c_str());
    	LOG_END;

    	TreeNode *SubRootconst = NULL;
    	SearchNodeFromOID(&YFHRoot,SubRootconst, YFOidString);
    	if(SubRootconst == NULL)
    	{
    		LOG_BEGIN(WARNING_LOG | 2);
    		LOG("no objects");
    		LOG_END;
    		return SNMP_ERROR_NO_SUCH_NAME;
    	}
    	else
    	{
    		int ii;
    		for(ii=0; ii < ACCESS_NUM; ii++)
    		{
    			if(SubRootconst->Mibdata.PAccess == ACCESS[ii])
    				break;
    		}
    		if(ii <= 1) //有权限修改
    		{
    			return SNMP_ERROR_NO_ACCESS;
    		}
    		Vbx vb = req->get_value(i);
    		if(SubRootconst->Mibdata.PSnytax == "Int")
    			vb.get_value(SubRootconst->Mibdata.PIValue);
    		else
    			SubRootconst->Mibdata.PSValue = vb.get_printable_value();
    	}
	}
	return SNMP_ERROR_SUCCESS;
}

void YFMib::YFProcessSetRequest(Request* req)
{
	int n = req->subrequests();

	LOG_BEGIN(EVENT_LOG | 2);
	LOG("Mib: process request: set request (tid)(oid)");
	LOG(req->get_transaction_id());   //不明白事务ID的意思
	for (int j=0; j<n; j++)
		LOG(req->get_oid(j).get_printable());
	LOG_END;

	req->phase++; // indicate PHASE_PREPARE
	if (YFProcessPrepareSetRequest(req) == SNMP_ERROR_SUCCESS) {
		req->phase++; // indicate PHASE_COMMIT
//		if (process_commit_set_request(req) !=
//		    SNMP_ERROR_SUCCESS) {
//
//			req->phase++;
//
//			LOG_BEGIN(WARNING_LOG | 2);
//			LOG("Mib: commit failed (tid)");
//			LOG(req->get_transaction_id());
//			LOG_END;
//
//			process_undo_set_request(req);
//			return;
//		}
	}
	req->phase = PHASE_CLEANUP;
	process_cleanup_set_request(req);
}
/**
 * Internally process a request (within its own thread)
 * @param req - A request.
 */
void YFMib::YFDoProcessRequest(Request* req)
{
	LOG_BEGIN(EVENT_LOG | 2);
	LOG("Agent: starting thread execution (pduType)(subrequests)");
	LOG(req->get_type());
	LOG(req->subrequests());
	LOG_END;
#ifdef _SNMPv3
#ifdef _PROXY_FORWARDER
	// init myEngineID if not yet initialized
	if ((requestList) && (myEngineID.len() == 0) &&
	    (requestList->get_v3mp()))
	    requestList->get_v3mp()->get_local_engine_id(myEngineID);
	// check for proxy request
	if ((req->get_pdu()->get_context_engine_id().len() > 0) &&
	    (myEngineID != req->get_pdu()->get_context_engine_id())) {
		// use requestList directly to avoid processing by sub classes
		LOG_BEGIN(EVENT_LOG | 2);
		LOG("Mib: processing proxy request (contextEngineID)");
		LOG(req->get_pdu()->get_context_engine_id().get_printable_hex());
		LOG_END;
	        proxy_request(req);
		LOG_BEGIN(EVENT_LOG | 2);
		LOG("Agent: finished thread execution");
		LOG_END;
		return;
	}
#endif
#endif
	int n = req->subrequests();
	if (n > 0) {
		int i;
		switch (req->get_type()) {
		case (sNMP_PDU_GET): {

		  LOG_BEGIN(EVENT_LOG | 2);
		  LOG("Mib: process request: get request, oid");
		  LOG(req->get_transaction_id());
		  for (i=0; i<n; i++)
			LOG(req->get_oid(i).get_printable());
		  LOG_END;

		  for (i=0; i<n; i++) {
			if (!req->is_done(i))
				if (!YFProcessRequest(req, i)) break;
//				if(!process_request(req,i)) break;
		  }
		  break;
		}
		case (sNMP_PDU_GETNEXT): {

		  LOG_BEGIN(EVENT_LOG | 2);
		  LOG("Mib: process request: getnext request, oid");
		  LOG(req->get_transaction_id());
		  for (i=0; i<n; i++)
			LOG(req->get_oid(i).get_printable());
		  LOG_END;

		  for (i=0; i<n; i++) {
			if (!req->is_done(i))
				if (!YFProcessRequest(req, i)) break;
//				if (!process_request(req, i)) break;
		  }
		  break;
		}
		case (sNMP_PDU_GETBULK): {
		  process_get_bulk_request(req);
		  break;
		}
		case (sNMP_PDU_SET): {
			YFProcessSetRequest(req);
//		  YF_process_set_request(req);
		  break;
		}
		}
	}
	finalize(req);

	LOG_BEGIN(EVENT_LOG | 2);
	LOG("Agent: finished thread execution");
	LOG_END;
}

//extern ThreadPool*			threadPool;
/**
 * Process a request. If multi-threading is activated, start a
 * thread to actually process the request.
 * @param req - A request.
 */
void YFMib::YF_process_request(Request* req)
{
//	YFAnswerGet(req);
//	YF_do_process_request(req);
	YFDoProcessRequest(req);
//	do_process_request(req);
//#ifdef _THREADS
////	MibMethodCall* call = new MibMethodCall();
//	MibMethodCall* call = new MibMethodCall(this,
//					  (&YFMib::YF_do_process_request), req);
//#ifdef AGENTPP_USE_THREAD_POOL
//	MibTask* mt = new MibTask(call);
//	threadPool->execute(mt);
//#else
//#ifdef _WIN32THREADS
//	_beginthread(mib_method_routine_caller, 0, call);
//#else
//	static pthread_attr_t* attr = 0;
//	pthread_t thread;
//	if (!attr) {
//		attr = new pthread_attr_t;
//		pthread_attr_init(attr);
//		pthread_attr_setdetachstate(attr, PTHREAD_CREATE_DETACHED);
//	}
//	pthread_create(&thread, attr,
//		       &mib_method_routine_caller,
//		       (void*) call);
//#endif
//#endif /*AGENTPP_USE_THREAD_POOL*/
//#else
//	do_process_request(req);
//	LOG_BEGIN(DEBUG_LOG | 12);
//	LOG("Agent: ready to receive request");
//	LOG_END;
//#endif
}




int YFMib::YF_notify(const OctetStr& context,
		const Oidx& oid,
		Vbx* vbs, int sz,
		unsigned int timestamp)
{
	if (!YFnotificationSender) {
		YFnotificationSender = new YFNotificationOriginator();
	}
    return YFnotificationSender->notify(context, oid, vbs, sz, timestamp);
}

int YFMib::YFLocalSet(Vbx *&vb, int vbNum)
{
    int err=0;

	MibEntryPtr entry = 0;

    Pdu pdu(vb,vbNum);
    UTarget a;
    Request* req = new Request(pdu,a);


	// before processing the SET lock all affected MIB objects
	lock_mib();
	for (int i=0; i<vbNum; i++) {
			Oidx tmpoid(vb[i].get_oid());
			// entry not available
			if ((err = find_managing_object(defaultContext,
							tmpoid, entry, req)) !=
			    SNMP_ERROR_SUCCESS) {
				unlock_mib();
				req->error(i, SNMP_ERROR_NO_CREATION);
				// error status (v1) will be set by RequestList
				//requestList->answer(req);
				return err;
			}

            // entry should be available, but we have to be sure:
            if (!entry) {
                return SNMP_ERROR_COMITFAIL;
            }
            // Entry has been locked already by
            // prepare_set_request
            // entry->start_synch();
            int status = SNMP_ERROR_SUCCESS;
            if ((status = entry->commit_set_request(req, i)) !=
                SNMP_ERROR_SUCCESS) {
                // Make sure error status is set
                                // according to returned status.
                                // Should be SNMP_ERROR_COMITFAIL in most
                                // cases.
                req->error(i, status);
                return status;
            }
	}
	unlock_mib();
	return SNMP_ERROR_SUCCESS;

}

int YFMib::YFLocalGet(Vbx *vb, int vbNum)
{
    int err=0;

    MibEntryPtr entry = new MibEntry();

    Pdu pdu(vb,vbNum);
    UTarget a;
    Request* req = new Request(pdu,a);


    // before processing the SET lock all affected MIB objects
    lock_mib();
    for (int i=0; i<vbNum; i++) {
            Oidx tmpoid(vb[i].get_oid());
            // entry not available
            if ((err = find_managing_object(defaultContext,
                            tmpoid, entry, req)) !=
                SNMP_ERROR_SUCCESS) {
                unlock_mib();
                req->error(i, SNMP_ERROR_NO_CREATION);
                // error status (v1) will be set by RequestList
                //requestList->answer(req);
                return err;
            }

            entry->start_synch();
            unlock_mib();
            entry->get_request(req, i);
            entry->end_synch();

            vb[i] = req->get_value(i);
    }
//    Pdux pdux = req->get_pdu();
//    for(int i = 0; i<vbNum;i++)
//    {
//        pdux.get_vb(vb[i],i);
//    }
    unlock_mib();
    return SNMP_ERROR_SUCCESS;

}
