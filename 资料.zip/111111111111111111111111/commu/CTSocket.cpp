﻿// CTSocket.cpp: implementation of the CCTSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "commu.h"
#include "CTSocket.h"
#include <QTextCodec>
#include <NetCommuCT.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CCTSocket::CCTSocket():udpSocket(0,0),YFThread(3)
{
	pParent = NULL;
	Counter = -1;
    SocketID = -1;
#ifdef LINUXQT
    pDialog = NULL;
#endif
	pSaveBuffer = NULL;
	pBufferLength = 0;
//    YFThread::start();
}

CCTSocket::~CCTSocket()
{
    YFThread::stop();
    //YFThread::quit();
}

////////////////////////////////////////////////////////////////////////////////
//接口事件处理函数；
////////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* 
有数据到时发生的响应
	UDP: 最重要
                                                         */
/************************************************************************/
void CCTSocket::OnReceive(int nErrorCode)    //有数据到时发生	UDP: 最重要
{
    if(Type == 1)
    {

    }
    else
    {
        pBufferLength = 0;
        if(pSaveBuffer != NULL)
        {
            UINT tempPort=0;
            memset(pSaveBuffer, 0, MACRO_BUFFER_SIZE);
            pBufferLength=udprecvfrom((unsigned char *)pSaveBuffer,MACRO_BUFFER_SIZE,0,tempPort);
            if(pBufferLength>0)
            {
                DataSource.IPAdd.sin_addr.s_addr = get_recvAddress();
                DataSource.PortReceive = tempPort;
                CNetCommuCT *pP=(CNetCommuCT*)pParent;
                pP->Receive();
            }
        }
        else
        {
            pBufferLength = 0;
        }
    }
    nErrorCode=0;
    usleep(3);
    nErrorCode++;
}

////////////////////////////////////////////////////////////////////////////////////
//网络套接口处理函数；
////////////////////////////////////////////////////////////////////////////////////

/*
bool CCTSocket::Initial( CWnd* pParam1, int pParam2 )   
{
	LocalSet.IPAdd.sin_port = htons(LocalSet.PortReceive);
	LocalSet.IPAdd.sin_family = AF_INET;					//数据统一
	Create( );
	Bind((SOCKADDR*)&(LocalSet.IPAdd), sizeof(SOCKADDR));	//绑定完毕，由LocalSet设定
	Counter = 0;

	if( pParam1!=NULL )
		pDialog = pParam1;

	SocketID = pParam2;
	return true;
}
*/

////////////////////////////////////////////////////////////////////////////////////
//网络套接口处理函数；
////////////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* 
初始化本Socket，包括创建和绑定；
参数:
1.调用者指针，用于通知调用者
2.接收Socket还是发送Socket，用于决定绑在那个端口上
                                                         */
/************************************************************************/
bool CCTSocket::Initial( void* pParam1, bool RecvOrSend)   
{
    bool ret = true;
    LocalSet.IPAdd.sin_family = AF_INET;					//数据统一
    if(RecvOrSend)//为接收Socket，需要采用PortReceive
    {
        LocalSet.IPAdd.sin_port = htons(LocalSet.PortReceive);
        if(udpSocket::create( LocalSet.PortReceive, LocalSet.IPAdd.sin_addr.s_addr,1)!=0)
        {
            QMessageBox defineBox;
            struct in_addr tmpAdd;
            tmpAdd.s_addr= LocalSet.IPAdd.sin_addr.s_addr;
            defineBox.setWindowTitle(inet_ntoa(tmpAdd));
            defineBox.setText(QObject::tr("与监控机套接字创建失败！"));
            defineBox.exec();
            return FALSE;
        }
        YFThread::start();
    }
    else
    {
        LocalSet.IPAdd.sin_port = htons(LocalSet.PortSend);
        if(udpSocket::create( LocalSet.PortSend, LocalSet.IPAdd.sin_addr.s_addr,1)!=0)
        {
            QMessageBox defineBox;
            struct in_addr tmpAdd;
            tmpAdd.s_addr= LocalSet.IPAdd.sin_addr.s_addr;
            defineBox.setWindowTitle(inet_ntoa(tmpAdd));
            defineBox.setText(QObject::tr("与监控机套接字创建失败！"));
            defineBox.exec();
            return FALSE;
        }
    }
    Counter = 0;

    if( pParam1!=NULL )
        pParent = pParam1;

    return ret;
}


/************************************************************************/
/*
创建一个套接口，nSocktType==SOCK_STREAM是TCP连接；nSocktType==SOCK_DGRAM是UDP连接；
                                                         */
/************************************************************************/
BOOL CCTSocket::Create( UINT sin_port, DWORD addr )
{

   if( udpSocket::create((unsigned short int )sin_port, (unsigned long int) addr)==0)
       return true;
   else
       return false;
}


/************************************************************************/
/* 
在建立连接后，使用的数据发送函数，主要需要指明发生的目标端口号和IP地址；常用于UDP； 

UDP: 最重要         
参数：
1.发送的数据
2.数据长度
3.对方端口号
4.对方地址
5.flag: 操作选项，可不设定，默认为0
                                                         */
/************************************************************************/

int CCTSocket::SendTo(const void* lpBuf, int nBufLen, UINT nHostPort,LPCTSTR lpszHostAddress, int nFlags)
{	
    nFlags=0;
    nFlags++;
    return  udpsendto((const void*)lpBuf,nBufLen,nHostPort,lpszHostAddress);
}

/************************************************************************/
/* 
加入组            
参数为"*.*.*.*"形式的IP地址
                                                         */
/************************************************************************/
bool CCTSocket::JoinBroadCastGroup(LPCTSTR lpszBroadCastAddress)
{
    addMcastGroup(lpszBroadCastAddress,LocalSet.IPAdd.sin_addr.s_addr,0,128,1);
    return true;
}			

/************************************************************************/
/* 
退出组            
参数为"*.*.*.*"形式的IP地址
*/
/************************************************************************/

BOOL CCTSocket::DropBroadCastGroup(LPCTSTR lpszBroadCastAddress)
{
    dropMcastGroup(lpszBroadCastAddress,LocalSet.IPAdd.sin_addr.s_addr);
	pParent = NULL;
	Counter = -1;
	SocketID = -1;
#ifdef LINUXQT
    pDialog = NULL;
#endif
	pSaveBuffer = NULL;
	pBufferLength = 0;
	return TRUE;
}

/************************************************************************/
/* 
加入组            
参数为"*.*.*.*"形式的IP地址
*/
/************************************************************************/
bool CCTSocket::JoinSSMBroadCastGroup( LPCTSTR lpszBroadCastAddress, LPCTSTR lpszSourceAddress )
{
    addSourceMcastGroup(lpszBroadCastAddress,lpszSourceAddress,LocalSet.IPAdd.sin_addr.s_addr,0,128,1);
    return true;
}			

/************************************************************************/
/* 
退出组            
参数为"*.*.*.*"形式的IP地址
*/
/************************************************************************/

BOOL CCTSocket::DropSSMBroadCastGroup(LPCTSTR lpszBroadCastAddress, LPCTSTR lpszSourceAddress )
{
    dropSourceMcastGroup(lpszBroadCastAddress,lpszSourceAddress,LocalSet.IPAdd.sin_addr.s_addr);
	pParent = NULL;
	Counter = -1;
	SocketID = -1;
#ifdef LINUXQT
    pDialog = NULL;
#endif
	pSaveBuffer = NULL;
	pBufferLength = 0;
	return TRUE;
}

//析构
bool CCTSocket::CloseConnect( )
{
    YFThread::stop();
    ::usleep(50000);
    YFThread::terminate();
    //YFThread::quit();
    udpSocket::udpClose();
	pParent = NULL;
	Counter = -1;
	SocketID = -1;
#ifdef LINUXQT
    pDialog = NULL;
#endif
	pSaveBuffer = NULL;
	pBufferLength = 0;
	return TRUE;
}


void CCTSocket::ShutDown(int flag)
{
    YFThread::stop();
    ::usleep(50000);
    YFThread::terminate();
    ::usleep(50000);
    //YFThread::quit();
    shutdown(get_sockfd(),flag);
}

void  CCTSocket::OnReceiveThread()
{
    CCTSocket::OnReceive(0);
}
