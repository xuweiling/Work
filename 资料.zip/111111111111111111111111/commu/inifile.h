﻿    /********************************************************   
	*   文件名      : IniFile.h
	*   用途        : 读写INI配置文件
	*   编写人      : Jerry
	*   编写时间    : 2002-04-20
	*   最后修改人  : Jerry
	*   最后修改时间: 2002-05-01
	********************************************************/
    
#if !defined(AFX_INIFILE_H__CA058C80_58E0_4DB4_A50C_1D2D82CCBEB9__INCLUDED_)
#define AFX_INIFILE_H__CA058C80_58E0_4DB4_A50C_1D2D82CCBEB9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <QString>
    /********************************************************   
    *   类名        : CIniFile
	*   用途        : 读写INI配置文件 
	*   编写人      : Jerry
	*   编写时间    : 2002-04-20
	*   最后修改人  : Jerry
	*   最后修改时间: 2002-05-01
	********************************************************/
#define MAXNAME_LENGTH	256
class CIniFile  
{
public:
	CIniFile();
	virtual ~CIniFile();
	
	/*				功能描述: 将从Key值为char型的Key值写入INI文件中
	*				参数	:
    *						QString lpAppName	段名

    *						QString lpKeyName	Key项名称
    *						QString lpString    Key值
    *						QString path		Ini文件路径和文件名

	*
	*				返回值	: 无
	*/	
    void WriteIniVal(QString lpAppName,QString lpKeyName,QString lpString,QString path );

	/*				功能描述: 从INI文件中获得段中Key值为char型的Key值
	*				参数	:
    *						QString lpAppName	段名

    *						QString lpKeyName	Key项名称
    *						QString path        Ini文件路径和文件名。
	*				返回值	: Key值
	*/	
    QString GetIniStr(QString lpAppName, QString lpKeyName,QString  path );

	/*				功能描述: 从INI文件中获得段中Key值为整数的Key值
	*				参数	:
    *						QString lpAppName	段名

    *						QString lpKeyName	Key项名称
    *						QString path		Ini文件路径和文件名

	*
	*				返回值	: Int    Key值
	*/	
    int GetIniInt(QString lpAppName, QString lpKeyName ,QString path);
	
	/*				功能描述: 返回当前目录中该INI文件的文件路径和文件名

	*				参数	:
	*							char *pFileName		文件名

    *				返回值	:	QString  文件路径和文件名

	*/	
    QString GetIniFilePath(char *pFileName);

	/*				功能描述: 判断当前目录是否存在该INI文件,如果不存在，则新建一个Ini文件
	*				参数	:
	*						char *pFileName		文件名

	*				返回值	: 无
	*/	
	void CreateOrFindFile(char *pFileName);
	
	/*				含义：存储INI文件的文件名

	*				取值：
	*/
	
	char pIniFileName[MAXNAME_LENGTH];
};

#define MAX_COL_SIZE 2048
void fileConvert();
int unencode(char *src, char *dest);

#endif // !defined(AFX_INIFILE_H__CA058C80_58E0_4DB4_A50C_1D2D82CCBEB9__INCLUDED_)
