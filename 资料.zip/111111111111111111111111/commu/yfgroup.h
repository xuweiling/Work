/*
 * YFGroup.h
 *
 *  Created on: Jan 6, 2015
 *      Author: feng
 */

#ifndef YFGROUP_H_
#define YFGROUP_H_

#include <agent_pp/mib.h>

#include <agent_pp/snmp_textual_conventions.h>
#include <agent_pp/notification_originator.h>
#include <snmp_pp/log.h>

#include <agent_pp/sim_mib.h>


#ifdef AGENTPP_NAMESPACE
namespace Agentpp {
#endif

class YFLeaf: public MibLeaf {

public:
	YFLeaf(const Oidx& id, mib_access acc, NS_SNMP SnmpSyntax* pointer);
	YFLeaf(const Oidx& id);
	YFLeaf(const Oidx& id,mib_access acc);
	virtual ~YFLeaf();

	virtual long       	get_state();
	virtual void       	set_state(long);
	virtual int        	set(const Vbx&);
	virtual int        	prepare_set_request(Request*, int&);
	virtual boolean    	value_ok(const Vbx&);
	virtual int         YFLocalSetRequest(Request* req, int& ind);

	virtual MibEntryPtr	clone();
//	virtual int        	prepare_set_request(Request*, int&);
//	virtual boolean    	value_ok(const Vbx&);
};

class YFSLeaf: public MibLeaf {

public:
	YFSLeaf(const Oidx& id, mib_access acc, NS_SNMP SnmpSyntax* pointer);
	YFSLeaf(const Oidx& id);
	YFSLeaf(const Oidx& id,mib_access acc);
	virtual ~YFSLeaf();

	virtual NS_SNMP OctetStr       	get_state();
	virtual void       	set_state(const NS_SNMP OctetStr&);
	virtual int        	set(const Vbx&);
	virtual int        	prepare_set_request(Request*, int&);
	virtual boolean    	value_ok(const Vbx&);

	virtual int 		YFLocalSetRequest(Request* req, int& ind);
	virtual MibEntryPtr	clone();
//	virtual int        	prepare_set_request(Request*, int&);
//	virtual boolean    	value_ok(const Vbx&);
};

class YFGroup: public MibGroup
{
  public:
	YFGroup(const Oidx& id, const NS_SNMP OctetStr& name);
	YFGroup(const Oidx& id, const NS_SNMP OctetStr& name,YFLeaf* yfleaf);
	virtual ~YFGroup() { }
};

#ifdef AGENTPP_NAMESPACE
}
#endif


#endif /* YFGROUP_H_ */
