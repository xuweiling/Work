﻿#include "commu.h"
#include "ui_commu.h"
#include <QValidator>//文本输入验证类
#include<string.h>
#include<QStringList>
#include<stdlib.h>
#include <QDir>
 #include <QFileDialog>
#include <QMessageBox>
#include<QList>
#include <QApplication>
#include<stdafx.h>
#include"BaseFile.h"
#include <arpa/inet.h>
#include "Dlg_BidSet.h"
#include"Dlg_SetInner.h"
#include <QTextCodec>

#include "Dlg_MulResourceSet.h"

#define OK 12

extern bool	 IsTimecardExist;
class QComboBox;


commu::commu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::commu)
{
    ui->setupUi(this);
    connect(ui->MULTICASTSOURCE,SIGNAL(clicked()),this,SLOT(OnBnClickedButtonSetupMulsource()));//设置组播员按键绑定
    connect(ui->ADD_NEWADD1,SIGNAL(clicked()),this,SLOT(OnButtonNewAdd1()));//添加到单播按键绑定
    connect(ui->ADD_DELADD1,SIGNAL(clicked()),this,SLOT(OnButtonDelAdd1()));//删除一个单播监控机
    connect(ui->ADD_NEWADD2_1,SIGNAL(clicked()),this,SLOT(OnButtonNewAdd2_1()));//增加一个组播接收监控机
    connect(ui->ADD_DELADD2_1,SIGNAL(clicked()),this,SLOT(OnButtonDelAdd2_1()));//删除一个组播接收监控机
    connect(ui->ADD_NEWADD2_2,SIGNAL(clicked()),this,SLOT(OnButtonNewAdd2_2()));//增加一个组播发送监控机
    connect(ui->ADD_DELADD2_2,SIGNAL(clicked()),this,SLOT(OnButtonDelAdd2_2()));//删除一个组播发送监控机
    connect(ui->Setup_TIP,SIGNAL(clicked()),this,SLOT(OnBnClickedButtonSetupTip()));//
    connect(ui->SETSAVEPATH,SIGNAL(clicked()),this,SLOT(OnButtonSetPath()));//
    connect(ui->SETUP_INNER,SIGNAL(clicked()),this,SLOT(OnButtonSetupInner()));//更多设置 绑定
    connect(ui->SETUP_SAVE,SIGNAL(clicked()),this,SLOT(OnButtonSetupSave()));//保存并应用
    connect(ui->SETUP_APPLY,SIGNAL(clicked()),this,SLOT(OnButtonSetupApply()));//应用
    connect(ui->SETUP_CANCEL,SIGNAL(clicked()),this,SLOT(OnSetupCancel()));//取消
    connect(ui->m_AddList1,SIGNAL(itemClicked(QTableWidgetItem*)),this,SLOT(setflag(QTableWidgetItem*)));
    connect(ui->m_Addlist2_1,SIGNAL(itemClicked(QTableWidgetItem*)),this,SLOT(setflag(QTableWidgetItem*)));
    connect(ui->m_Addlist2_2,SIGNAL(itemClicked(QTableWidgetItem*)),this,SLOT(setflag(QTableWidgetItem*)));

    QValidator  *vali_ZKPort=new QDoubleValidator(1,32000,0,this);//限制输入在1到32000的double
    ui->m_ZKPort->setValidator(vali_ZKPort);
    ui->m_SendCTPort->setValidator(vali_ZKPort);

    flag1=0;
    flag2=0;
    flag3=0;
    /*初始化个lineedit*/
    ui->m_stDID->clear();
    ui->m__stBIDExam->clear();
    ui->m_stBIDTimer->clear();
    ui->m_stBIDWyd1->clear();
    ui->m_stBIDWyd2->clear();
    ui->m_stBIDWyd3->clear();
    ui->m_stBIDWyd4->clear();
    ui->m_stBIDWyd5->clear();
    ui->m_stBIDWyd6->clear();
    ui->m_stBIDWyd7->clear();
    ui->m_stBIDWyd8->clear();
    ui->m_stBIDWyd9->clear();
    ui->m_stBIDMeasure->clear();
    ui->m__stBIDTO->clear();
    ui->m__stMID->clear();
    ui->m_NewName1->clear();
    ui->m_NewName2->clear();
    ui->m_NewIP1->clear();
    ui->m_NewIP2->clear();
    ui->m_NewDID1->clear();
    ui->m_NewDID2->clear();
    ui->IDC_EDIT_NPRECEIVE1->clear();
    ui->IDC_EDIT_NPRECEIVE2->clear();
    ui->IDC_EDIT_NPSEND1->clear();
    ui->IDC_EDIT_NPSEND2->clear();
    ui->m_LocaltoCT_IP1->clear();
    ui->m_LocaltoCT_IP2->clear();
    ui->m_LocaltoZK_IP->clear();
    ui->m_RecvCTPort->clear();
    ui->m_SendCTPort->clear();
    ui->m_ZKIP->clear();

    ui->m_WayNo1->setChecked(false);
    ui->m_WayNo1_2->setChecked(false);
    ui->m_ZKPort->setText("0");
    ui->m_stVersion->clear();
    ui->m_stSID->clear();
    ui->m_RecvCTPort->setText("0");
    ui->m_SendCTPort->setText("0");
    ui->m_DataSavePath->clear();
    ui->m_MeasureEnable_va->setChecked(false);
    ui->m_stMID_T->clear();

    //memset(iniFilePath_a,' ',256);     //iniFilePath_a[256]=""
    ui->m_DataSavePath->setMaxCount(8);
    ui->m_WayNo1->setChecked(false);
    ui->m_WayNo2->setChecked(false);
    ui->m_TimeSource->setChecked(false);
    ui->m_MeasureEnable_va->setChecked(FALSE);
    ui->m_TOEnable_va->setChecked(FALSE);
    ui->m_WYDEnable_va->setChecked(FALSE);

    ui->m_RecvSocketTP->setChecked(TRUE);
    ui->m_SendSocketTP->setChecked(TRUE);
    str_EjectB.clear();               //????????????????有绑定,其他的对话框
    str_EjectL.clear();//????????????
    str_EjectH.clear();//???????????
    str_EjectAngle.clear();//??????????

    CTP2PSet.clear();
    CTMulSetSe.clear();
    CTMulSetRe.clear();
    CTSrcSet.clear();
    CTP2PNum = 0;
    CTMulNumSe = 0;
    CTMulNumRe = 0;
    CTSrcNum = 0;

    FZSock1.clear();
    FZSock2.clear();
    FZSockNum=0;

    INI_DATALENGTH_MEASURE = 32;
    INI_DATALENGTH_THEORY = 60;
    INI_DATALENGTH_EXAM = 48;
    INI_DATALENGTH_T0 = 36;
    INI_REVERSE_DATALENGTH = 20;//正式实算数据中最后保留的数据长度		Jerry 20110629
    INI_REVERSE_DATACONTENT = "ffffff7f00000000ff7f";//正式实算数据中最后保留的数据内容	Jerry 20110629
    Is_ZhuKongTai = false;
    INI_DATALENGTH_ZK = 152;
    INI_DATALENGTH_ZXZ = 22;

    memset(&MeasureHEADER, 0,sizeof(HEADERStruct));
    memset(&TimerSendHEADER, 0,	sizeof(HEADERStruct));
    memset(&TimerRecvHEADER, 0,	sizeof(HEADERStruct));
    memset(&ExamSendHEADER, 0,	sizeof(HEADERStruct));
    memset(&ExamRecvHEADER, 0,	sizeof(HEADERStruct));
    memset(&T0HEADER, 0,sizeof(HEADERStruct));
    memset(WYDHEADER, 0,30*sizeof(HEADERStruct));

     EjectPosB = 0.0;
     EjectPosL = 0.0;
     EjectPosH = 0.0;
     EjectAngle = 0.0;
     DataSavePath = "/home/chenyanan/桌面/longxin/111111111111111111111111/text";
     TimeSource = Time_GPS;
     SendSocketTP = Socket_Udp;
     RecvSocketTP = Socket_Udp;
     ui->m_AddList1->clear();
     ui->m_Addlist2_2->clear();
     ui->m_Addlist2_1->clear();

     ui->m_AddList1->setColumnCount(6); //设置列数
     ui->m_Addlist2_2->setColumnCount(6); //设置列数
     ui->m_Addlist2_1->setColumnCount(6); //设置列数
     QStringList header;
     header<<tr("IP")<<tr("接收Port")<<tr("发送Port")<<tr("名称  ") <<tr("DID码") <<tr("路由");
     ui->m_AddList1->setHorizontalHeaderLabels(header);
     ui->m_Addlist2_2->setHorizontalHeaderLabels(header);
     ui->m_Addlist2_1->setHorizontalHeaderLabels(header);

     ui->m_AddList1->setSelectionMode(QAbstractItemView::ExtendedSelection);
     ui->m_AddList1->setSelectionBehavior(QAbstractItemView::SelectRows); //设置选择行为时每次选择一行
     ui->m_AddList1->setEditTriggers(QAbstractItemView::NoEditTriggers); //设置不可编辑
     // ui->m_AddList1->setEditTriggers(QAbstractItemView::NoEditTriggers); //设置不可编辑
     // ui->m_AddList1->horizontalHeader()->resizeSection(0,150); //设置表头第一列的宽度为150
     //ui->m_AddList1>horizontalHeader()->setFixedHeight(25); //设置表头的高度
     // ui->m_AddList1>setStyleSheet("selection-background-color:lightblue;"); //设置选中背景色
     ui->m_AddList1->horizontalHeader()->setStyleSheet("QHeaderView::section{background:skyblue;}");

     ui->m_Addlist2_2->setSelectionMode(QAbstractItemView::ExtendedSelection);
     ui->m_Addlist2_2->setSelectionBehavior(QAbstractItemView::SelectRows); //设置选择行为时每次选择一行
     ui->m_Addlist2_2->horizontalHeader()->setStyleSheet("QHeaderView::section{background:skyblue;}");
     ui->m_Addlist2_2->setEditTriggers(QAbstractItemView::NoEditTriggers); //设置不可编辑

     ui->m_Addlist2_1->setSelectionMode(QAbstractItemView::ExtendedSelection);
     ui->m_Addlist2_1->setSelectionBehavior(QAbstractItemView::SelectRows); //设置选择行为时每次选择一行
     ui->m_Addlist2_1->horizontalHeader()->setStyleSheet("QHeaderView::section{background:skyblue;}");
     ui->m_Addlist2_1->setEditTriggers(QAbstractItemView::NoEditTriggers); //设置不可编辑
}

commu::~commu()
{
    delete ui;
}


void commu::setflag(QTableWidgetItem *it)
{
    flag1=1;
    if(flag1>1)
    {
        flag1=1;
    }

    flag2=1;
    if(flag2>1)
    {
        flag2=1;
    }

    flag3=1;
    if(flag3>1)
    {
        flag3=1;
    }
    clickitem=it;
}

/************************************************************************/
/* 清除数据                                                         */
/************************************************************************/
void commu::UnInitData()
{
    int addrIndex = 0;
    int byteCounter = 0;

    for(addrIndex=0; addrIndex<CTP2PNum; addrIndex++)
    {
        memset(&(CTP2PSet[addrIndex]), 0, sizeof(AddStruct));
    }
    CTP2PSet.clear();
    CTP2PNum = 0;

    for(addrIndex=0; addrIndex<CTMulNumRe; addrIndex++)
    {
        memset(&(CTMulSetRe[addrIndex]), 0, sizeof(AddStruct));
    }
    CTMulSetRe.clear();
    CTMulNumRe = 0;

    for(addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
    {
        memset(&(CTMulSetSe[addrIndex]), 0, sizeof(AddStruct));
    }
    CTMulSetSe.clear();
    CTMulNumSe = 0;
    CTSrcSet.clear();
    CTSrcNum = 0;
    ui->m_AddList1->clear();
    ui->m_Addlist2_1->clear();
    ui->m_Addlist2_2->clear();
}
/************************************************************************/
/* 网络配置初始化                                                       */
/************************************************************************/
void commu::InitNetData()
{
     struct in_addr tmp_inAdd;

    QString iniFilePath = INIFILE;
    QString iniFilePath_a;
    iniFilePath_a=QApplication::applicationDirPath();
    iniFilePath = iniFilePath_a;
    iniFilePath+= "/settest.ini";

    CBaseFile iniFile;
    QString sectionName;
    QString secContent;
    int secValue = 0;
    BYTE ip1, ip2, ip3, ip4;
    QString tempName;
    QString tempDID;
    QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
    DWORD tempValue;
    int CTCounter = 0;
    int tempCTCounter = 0;
    int tempFZCounter=0;
    int addrIndex = 0;
    int byteCounter = 0;

    for(addrIndex=0; addrIndex<CTP2PNum; addrIndex++)
    {
        memset(&(CTP2PSet[addrIndex]), 0, sizeof(AddStruct));
    }

    CTP2PSet.clear();

    CTP2PNum = 0;
    for(addrIndex=0; addrIndex<CTMulNumRe; addrIndex++)
    {
        memset(&(CTMulSetRe[addrIndex]), 0, sizeof(AddStruct));
    }
    CTMulSetRe.clear();
    CTMulNumRe = 0;
    for(addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
    {
        memset(&(CTMulSetSe[addrIndex]), 0, sizeof(AddStruct));
    }
    CTMulSetSe.clear();
    CTMulNumSe = 0;
    CTSrcSet.clear();
    CTSrcNum = 0;

    ////IP设置
    ////网络配置
    sectionName = "网络配置";
    ip1 = iniFile.GetIniInt(sectionName, "主控IP1", iniFilePath);
    ip2 = iniFile.GetIniInt(sectionName, "主控IP2", iniFilePath);
    ip3 = iniFile.GetIniInt(sectionName, "主控IP3", iniFilePath);
    ip4 = iniFile.GetIniInt(sectionName, "主控IP4", iniFilePath);
    ZKSock.IPAdd.sin_addr.s_addr =htonl( ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);
    ZKSock.PortReceive = iniFile.GetIniInt(sectionName, "主控端口", iniFilePath);
    ZKSock.PortSend = ZKSock.PortReceive;
    ZKSock.WayChose = 0;//ZK机的配置

    ip1 = iniFile.GetIniInt(sectionName, "本地对主控路由IP1", iniFilePath);
    ip2 = iniFile.GetIniInt(sectionName, "本地对主控路由IP2", iniFilePath);
    ip3 = iniFile.GetIniInt(sectionName, "本地对主控路由IP3", iniFilePath);
    ip4 = iniFile.GetIniInt(sectionName, "本地对主控路由IP4", iniFilePath);
    LocalZKSock.IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);
    LocalZKSock.PortReceive = ZKSock.PortSend;
    LocalZKSock.PortSend = ZKSock.PortSend;
    LocalZKSock.WayChose = 0;//本地对ZK的配置

    ip1 = iniFile.GetIniInt(sectionName, "本地第一路由IP1", iniFilePath);
    ip2 = iniFile.GetIniInt(sectionName, "本地第一路由IP2", iniFilePath);
    ip3 = iniFile.GetIniInt(sectionName, "本地第一路由IP3", iniFilePath);
    ip4 = iniFile.GetIniInt(sectionName, "本地第一路由IP4", iniFilePath);
    LocalCTSock_1.IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);
    LocalCTSock_1.PortReceive = iniFile.GetIniInt(sectionName, "监控机接收端口", iniFilePath);	//24584
    LocalCTSock_1.PortSend = iniFile.GetIniInt(sectionName, "监控机发送端口", iniFilePath);		//24576

    ip1 = iniFile.GetIniInt(sectionName, "本地第二路由IP1", iniFilePath);
    ip2 = iniFile.GetIniInt(sectionName, "本地第二路由IP2", iniFilePath);
    ip3 = iniFile.GetIniInt(sectionName, "本地第二路由IP3", iniFilePath);
    ip4 = iniFile.GetIniInt(sectionName, "本地第二路由IP4", iniFilePath);
    LocalCTSock_2.IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);
    LocalCTSock_2.PortReceive = iniFile.GetIniInt(sectionName, "监控机接收端口", iniFilePath);	//24584
    LocalCTSock_2.PortSend = iniFile.GetIniInt(sectionName, "监控机发送端口", iniFilePath);		//24576

    ////协议设置
    sectionName = "协议设置";
    INI_DATALENGTH_MEASURE	= iniFile.GetIniInt(sectionName, "实算数据区长度", iniFilePath);
    INI_DATALENGTH_THEORY	= iniFile.GetIniInt(sectionName, "引入数据区长度", iniFilePath);
    INI_DATALENGTH_EXAM		= iniFile.GetIniInt(sectionName, "时延测试数据区长度", iniFilePath);
    INI_DATALENGTH_T0		= iniFile.GetIniInt(sectionName, "T0数据区长度", iniFilePath);
    INI_REVERSE_DATALENGTH	= iniFile.GetIniInt(sectionName, "填充区长度", iniFilePath); //Jerry 20110629++
    INI_REVERSE_DATACONTENT = iniFile.GetIniStr(sectionName, "填充区内容", iniFilePath);//Jerry 20110629++
    INI_DATALENGTH_ZK = iniFile.GetIniInt(sectionName, "主控数据长度", iniFilePath);
    INI_DATALENGTH_ZXZ = iniFile.GetIniInt(sectionName, "中心站数据长度", iniFilePath);

    ////单播网络配置
    sectionName = "单播网络配置";
    CTP2PNum = iniFile.GetIniInt(sectionName, "远端数目", iniFilePath);//远端数目
    //	CTP2PSet = new AddStruct[CTP2PNum];
    CTP2PSet.resize(CTP2PNum);
    for(tempCTCounter=0; tempCTCounter<CTP2PNum; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1=QString("远端%1_IP1").arg(tempCTCounter+1,0,10);//.Format("远端%d_IP1",			tempCTCounter+1);
        valueItem2=QString("远端%1_IP2").arg(tempCTCounter+1,0,10);//Format("远端%d_IP2",			tempCTCounter+1);
        valueItem3=QString("远端%1_IP3").arg(tempCTCounter+1,0,10);//.Format("远端%d_IP3",			tempCTCounter+1);
        valueItem4=QString("远端%1_IP4").arg(tempCTCounter+1,0,10);//.Format("远端%d_IP4",			tempCTCounter+1);
        valueItem7=valueItem7.sprintf("远端%d_DID",			tempCTCounter+1);
        valueItem8.sprintf("远端%d_地址名称",	tempCTCounter+1);
        valueItem9=QString("远端%1_路由").arg(tempCTCounter+1,0,10);//.Format("远端%d_路由",		tempCTCounter+1);

        ip1 = iniFile.GetIniInt(sectionName, valueItem1, iniFilePath);
        ip2 = iniFile.GetIniInt(sectionName, valueItem2, iniFilePath);
        ip3 = iniFile.GetIniInt(sectionName, valueItem3, iniFilePath);
        ip4 = iniFile.GetIniInt(sectionName, valueItem4, iniFilePath);
        CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//
                                                                                                                      //使用PortReceive来保存port，不用IPAdd.sin_port
        CTP2PSet[tempCTCounter].PortReceive = LocalCTSock_1.PortReceive;
        CTP2PSet[tempCTCounter].PortSend = LocalCTSock_1.PortSend;
        tempDID = iniFile.GetIniStr(sectionName, valueItem7, iniFilePath);
        tempValue = 0;
        tempValue = CharToHex(tempDID);       //GlabalDefine.h中定义 CharToHex
        memcpy(CTP2PSet[tempCTCounter].DID, &tempValue, 4);

        tempName = iniFile.GetIniStr(sectionName, valueItem8, iniFilePath);       
        tempName=QString::fromLocal8Bit(tempName.toAscii());
        memcpy(CTP2PSet[tempCTCounter].Name, tempName.toLocal8Bit(),40);
        CTP2PSet[tempCTCounter].Name[strlen(tempName.toLocal8Bit())] = '\0';

        CTP2PSet[tempCTCounter].WayChose = iniFile.GetIniInt(sectionName, valueItem9, iniFilePath);
    } //此时，将所有的单播网络远端都读入了
    ////组播网络配置
    sectionName = "组播网络配置";
    CTMulNumRe = iniFile.GetIniInt(sectionName, "接收远端数目", iniFilePath);//远端数目
    CTMulSetRe.resize(CTMulNumRe);
    for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1=QString("接收远端%1_IP1").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP1",			tempCTCounter+1);
        valueItem2=QString("接收远端%1_IP2").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP2",			tempCTCounter+1);
        valueItem3=QString("接收远端%1_IP3").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP3",			tempCTCounter+1);
        valueItem4=QString("接收远端%1_IP4").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP4",			tempCTCounter+1);
        valueItem7=QString("接收远端%1_DID").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_DID",			tempCTCounter+1);
        valueItem8=QString("接收远端%1_地址名称").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_地址名称",	tempCTCounter+1);
        valueItem9=QString("接收远端%1_路由").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_m路由",		tempCTCounter+1);

        ip1 = iniFile.GetIniInt(sectionName, valueItem1, iniFilePath);
        ip2 = iniFile.GetIniInt(sectionName, valueItem2, iniFilePath);
        ip3 = iniFile.GetIniInt(sectionName, valueItem3, iniFilePath);
        ip4 = iniFile.GetIniInt(sectionName, valueItem4, iniFilePath);

        CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
        CTMulSetRe[tempCTCounter].PortReceive = LocalCTSock_1.PortReceive;
        CTMulSetRe[tempCTCounter].PortSend = LocalCTSock_1.PortSend;
        tempDID = iniFile.GetIniStr(sectionName, valueItem7, iniFilePath);
        tempValue = 0;
        tempValue = CharToHex(tempDID);           //GlabalDefine.h中定义 CharToHex
        memcpy(CTMulSetRe[tempCTCounter].DID, &tempValue, 4);

        tempName = iniFile.GetIniStr(sectionName, valueItem8, iniFilePath);
        tempName=QString::fromLocal8Bit(tempName.toAscii());
        memcpy(CTMulSetRe[tempCTCounter].Name, tempName.toLocal8Bit(),40);
        CTMulSetRe[tempCTCounter].Name[strlen(tempName.toLocal8Bit())] = '\0';

        CTMulSetRe[tempCTCounter].WayChose = iniFile.GetIniInt(sectionName, valueItem9, iniFilePath);
    }

    CTMulNumSe = iniFile.GetIniInt(sectionName, "发送远端数目", iniFilePath);//远端数目
    CTMulSetSe.resize(CTMulNumSe);
    for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1=QString("发送远端%1_IP1").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP1",			tempCTCounter+1);
        valueItem2=QString("发送远端%1_IP2").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP2",			tempCTCounter+1);
        valueItem3=QString("发送远端%1_IP3").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP3",			tempCTCounter+1);
        valueItem4=QString("发送远端%1_IP4").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP4",			tempCTCounter+1);
        valueItem7=QString("发送远端%1_DID").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_DID",			tempCTCounter+1);
        valueItem8=QString("发送远端%1_地址名称").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_地址名称",	tempCTCounter+1);
        valueItem9=QString("发送远端%1_路由").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_路由",		tempCTCounter+1);

        ip1 = iniFile.GetIniInt(sectionName, valueItem1, iniFilePath);
        ip2 = iniFile.GetIniInt(sectionName, valueItem2, iniFilePath);
        ip3 = iniFile.GetIniInt(sectionName, valueItem3, iniFilePath);
        ip4 = iniFile.GetIniInt(sectionName, valueItem4, iniFilePath);
        CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256
            + ip2*256*256 + ip3*256 + ip4);//使用PortReceive来保存port，不用IPAdd.sin_port
        CTMulSetSe[tempCTCounter].PortReceive = LocalCTSock_1.PortReceive;
        CTMulSetSe[tempCTCounter].PortSend = LocalCTSock_1.PortSend;
        tempDID = iniFile.GetIniStr(sectionName, valueItem7, iniFilePath);
        tempValue = 0;
        tempValue = CharToHex(tempDID);//GlabalDefine.h中定义 CharToHex
        memcpy(CTMulSetSe[tempCTCounter].DID, &tempValue, 4);

        tempName = iniFile.GetIniStr(sectionName, valueItem8, iniFilePath);
        tempName=QString::fromLocal8Bit(tempName.toAscii());
        memcpy(CTMulSetSe[tempCTCounter].Name, tempName.toLocal8Bit(),40);
        CTMulSetSe[tempCTCounter].Name[strlen(tempName.toLocal8Bit())] = '\0';

        CTMulSetSe[tempCTCounter].WayChose = iniFile.GetIniInt(sectionName, valueItem9, iniFilePath);
    }//此时，将所有的组播网络远端都读入了
    CTSrcNum = iniFile.GetIniInt(sectionName, "组播源数目", iniFilePath);//远端数目
    CTSrcSet.resize(CTSrcNum);
    for(tempCTCounter=0; tempCTCounter<CTSrcNum; tempCTCounter++)//第2次循环保存到数组中
    {
        valueItem1.sprintf("组播源%d_IP1",			tempCTCounter+1);
        valueItem2.sprintf("组播源%d_IP2",			tempCTCounter+1);
        valueItem3.sprintf("组播源%d_IP3",			tempCTCounter+1);
        valueItem4.sprintf("组播源%d_IP4",			tempCTCounter+1);

        ip1 = iniFile.GetIniInt(sectionName, valueItem1, iniFilePath);
        ip2 = iniFile.GetIniInt(sectionName, valueItem2, iniFilePath);
        ip3 = iniFile.GetIniInt(sectionName, valueItem3, iniFilePath);
        ip4 = iniFile.GetIniInt(sectionName, valueItem4, iniFilePath);
        CTSrcSet[tempCTCounter] = ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4;//使用PortReceive来保存port，不用IPAdd.sin_port
    }//IP部分设置完毕

    ////界面更新
    for(tempCTCounter=0; tempCTCounter<CTP2PNum; tempCTCounter++)
    {
        int NewItem;
        QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;

        s_IP=QString("%1.%2.%3.%4").arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff)
                                   .arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff)
                                    .arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff)
                                     .arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff);
        s_ReceivePort.sprintf("%.5d",CTP2PSet[tempCTCounter].PortReceive);
        s_SendPort.sprintf("%.5d",CTP2PSet[tempCTCounter].PortSend);
        s_Way=QString(tr("%1路")).arg(CTP2PSet[tempCTCounter].WayChose+1,0,10);

        for(byteCounter=0; byteCounter<4; byteCounter++)
        {
            int temp_Char = (BYTE)(CTP2PSet[tempCTCounter].DID[3-byteCounter]);
            QString TempMessage;
            TempMessage.sprintf("%.2x",temp_Char);
            s_DID+=TempMessage;
        }

        s_Name =QString::fromLocal8Bit(CTP2PSet[tempCTCounter].Name);

        //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
        int row_count = ui->m_AddList1->rowCount(); //获取表单行数
        ui->m_AddList1->insertRow(row_count); //插入新行
        QTableWidgetItem *item1= new QTableWidgetItem();
        item1->setText(s_IP);
        ui->m_AddList1->setItem(row_count, 0, item1);

        QTableWidgetItem *item2 = new QTableWidgetItem();
        item2->setText(s_ReceivePort);
        ui->m_AddList1->setItem(row_count, 1, item2);

        QTableWidgetItem *item3 = new QTableWidgetItem();
        item3->setText(s_SendPort);
        ui->m_AddList1->setItem(row_count, 2, item3);

        QTableWidgetItem *item4 = new QTableWidgetItem();
        item4->setText(s_Name);
        ui->m_AddList1->setItem(row_count, 3, item4);

        QTableWidgetItem *item5= new QTableWidgetItem();
        item5->setText(s_DID);
        ui->m_AddList1->setItem(row_count, 4, item5);

        QTableWidgetItem *item6 = new QTableWidgetItem();
        item6->setText(s_Way);
        ui->m_AddList1->setItem(row_count,5, item6);

    }

    for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)
    {
        int NewItem;
        QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;
        BYTE* pIP = (BYTE*)&(CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr);
        s_IP=QString("%1.%2.%3.%4").arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff)
                                   .arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff)
                                    .arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff)
                                     .arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff);
        s_ReceivePort.sprintf("%.5d",CTMulSetRe[tempCTCounter].PortReceive);
        s_SendPort.sprintf("%.5d",CTMulSetRe[tempCTCounter].PortSend);
        s_Way=QString(tr("%1路")).arg(CTMulSetRe[tempCTCounter].WayChose+1,0,10);

        for(byteCounter=0; byteCounter<4; byteCounter++)
        {
            int temp_Char = (BYTE)(CTMulSetRe[tempCTCounter].DID[3-byteCounter]);
            QString TempMessage;
            TempMessage.sprintf("%.2x",temp_Char);
            s_DID+=TempMessage;
        }     
        //s_Name =QString( CTMulSetRe[tempCTCounter].Name);
        s_Name =QString::fromLocal8Bit(CTMulSetRe[tempCTCounter].Name);

        //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
        int row_count = ui->m_Addlist2_1->rowCount(); //获取表单行数
        ui->m_Addlist2_1->insertRow(row_count); //插入新行
        QTableWidgetItem *item7 = new QTableWidgetItem();
        item7->setText(s_IP);
        ui->m_Addlist2_1->setItem(row_count, 0, item7);

        QTableWidgetItem *item8 = new QTableWidgetItem();
        item8->setText(s_ReceivePort);
        ui->m_Addlist2_1->setItem(row_count, 1, item8);

        QTableWidgetItem *item9 = new QTableWidgetItem();
        item9->setText(s_SendPort);
        ui->m_Addlist2_1->setItem(row_count, 2, item9);

        QTableWidgetItem *item10 = new QTableWidgetItem();
        item10->setText(s_Name);
        ui->m_Addlist2_1->setItem(row_count, 3, item10);

        QTableWidgetItem *item11 = new QTableWidgetItem();
        item11->setText(s_DID);
        ui->m_Addlist2_1->setItem(row_count, 4, item11);

        QTableWidgetItem *item12 = new QTableWidgetItem();
        item12->setText(s_Way);
        ui->m_Addlist2_1->setItem(row_count,5, item12);
    }

    for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)
    {
        int NewItem;
        QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;
        BYTE* pIP = (BYTE*)&(CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr);
        s_IP=QString("%1.%2.%3.%4").arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff)
                                    .arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff)
                                    .arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff)
                                    .arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff);
        s_ReceivePort.sprintf("%.5d",CTMulSetSe[tempCTCounter].PortReceive);
        s_SendPort.sprintf("%.5d",CTMulSetSe[tempCTCounter].PortSend);
        s_Way=QString(tr("%1路")).arg(CTMulSetSe[tempCTCounter].WayChose+1,0,10);
        for(byteCounter=0; byteCounter<4; byteCounter++)
        {
            int temp_Char = (BYTE)(CTMulSetSe[tempCTCounter].DID[3-byteCounter]);
            QString TempMessage;
            TempMessage.sprintf("%.2x",temp_Char);
            //TempMessage=QString("%1").arg(temp_Char,0,10);//.Format("%.2x", temp_Char);
            s_DID+=TempMessage;
        }
        s_Name =QString::fromLocal8Bit(CTMulSetSe[tempCTCounter].Name);

        //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
        int row_count = ui->m_Addlist2_2->rowCount(); //获取表单行数
        ui->m_Addlist2_2->insertRow(row_count); //插入新行
        QTableWidgetItem *item13 = new QTableWidgetItem();
        item13->setText(s_IP);
        ui->m_Addlist2_2->setItem(row_count, 0, item13);

        QTableWidgetItem *item14 = new QTableWidgetItem();
        item14->setText(s_ReceivePort);
        ui->m_Addlist2_2->setItem(row_count, 1, item14);

        QTableWidgetItem *item15 = new QTableWidgetItem();
        item15->setText(s_SendPort);
        ui->m_Addlist2_2->setItem(row_count, 2, item15);

        QTableWidgetItem *item16= new QTableWidgetItem();
        item16->setText(s_Name);
        ui->m_Addlist2_2->setItem(row_count, 3, item16);

        QTableWidgetItem *item17= new QTableWidgetItem();
        item17->setText(s_DID);
        ui->m_Addlist2_2->setItem(row_count, 4, item17);

        QTableWidgetItem *item18= new QTableWidgetItem();
        item18->setText(s_Way);
        ui->m_Addlist2_2->setItem(row_count,5, item18);
    }

    //？？？？？？？？？？？？？？？？？？？？？对不对?????????????????????????????????????????
    DWORD temp_DWORD;
    QString IPAD;
    char IP[4];

    temp_DWORD = LocalZKSock.IPAdd.sin_addr.s_addr;//????????????????????????????
    //IP地址转换：DWORD->IP
    tmp_inAdd.s_addr=temp_DWORD;
    IPAD=QString(inet_ntoa(tmp_inAdd));
    ui->m_LocaltoZK_IP->setText(IPAD);

    temp_DWORD = LocalCTSock_1.IPAdd.sin_addr.s_addr;
    tmp_inAdd.s_addr=temp_DWORD;
    IPAD=QString(inet_ntoa(tmp_inAdd));
    ui->m_LocaltoCT_IP1->setText(IPAD);

    temp_DWORD = LocalCTSock_2.IPAdd.sin_addr.s_addr;
    tmp_inAdd.s_addr=temp_DWORD;
    IPAD=QString(inet_ntoa(tmp_inAdd));
    ui->m_LocaltoCT_IP2->setText(IPAD);//IP框

    QString dec;
    dec=QString("%1").arg(LocalCTSock_1.PortReceive,0,10);
    ui->m_RecvCTPort->setText(dec);//= LocalCTSock_1.PortReceive;

    dec=QString("%1").arg(LocalCTSock_1.PortSend,0,10);
    ui->m_SendCTPort->setText(dec); //= LocalCTSock_1.PortSend;

    temp_DWORD = ZKSock.IPAdd.sin_addr.s_addr;//?//???
    tmp_inAdd.s_addr=temp_DWORD;
    IPAD=QString(inet_ntoa(tmp_inAdd));
    ui->m_ZKIP->setText(IPAD);//IP框
    //m_ZKIP.SetAddress(temp_DWORD);//

    dec=QString("%1").arg(LocalZKSock.PortReceive,0,10);
    ui->m_ZKPort->setText(dec);//= LocalZKSock.PortReceive;

    sectionName = "网络配置";
    secContent = iniFile.GetIniStr(sectionName, "中心站_1IP", iniFilePath);
    ZhuKongTaiSock_1.IPAdd.sin_addr.s_addr = inet_addr(secContent.toAscii());
    ZhuKongTaiSock_1.PortReceive = LocalCTSock_1.PortReceive;
    ZhuKongTaiSock_1.PortSend = LocalCTSock_1.PortSend;
    secContent = iniFile.GetIniStr(sectionName, "中心站_2IP", iniFilePath);
    ZhuKongTaiSock_2.IPAdd.sin_addr.s_addr = inet_addr(secContent.toAscii());//???????????????
    ZhuKongTaiSock_2.PortReceive = LocalCTSock_1.PortReceive;
    ZhuKongTaiSock_2.PortSend = LocalCTSock_1.PortSend;

    Is_ZhuKongTai =(bool) (iniFile.GetIniStr(sectionName, "是否与主控台通信", iniFilePath).toInt());//Jerry 20110629++

    sectionName = "分站配置";
    FZSockNum = iniFile.GetIniInt(sectionName, "分站数目", iniFilePath);//远端数目
    FZSock1.clear();
    FZSock2.clear();
    FZSock1.resize(FZSockNum);
    FZSock2.resize(FZSockNum);
    for(tempFZCounter=0;tempFZCounter<FZSockNum;tempFZCounter++)
    {
        valueItem5.sprintf("分站%d_第一路由",		tempFZCounter+1);
        valueItem6.sprintf("分站%d_第二路由",		tempFZCounter+1);
        secContent=iniFile.GetIniStr(sectionName, valueItem5, iniFilePath);
        FZSock1[tempFZCounter].IPAdd.sin_addr.s_addr=inet_addr(secContent.toAscii());
        FZSock1[tempFZCounter].PortReceive = LocalCTSock_1.PortReceive;
        FZSock1[tempFZCounter].PortSend = LocalCTSock_1.PortSend;
        secContent=iniFile.GetIniStr(sectionName, valueItem6, iniFilePath);
        FZSock2[tempFZCounter].IPAdd.sin_addr.s_addr=inet_addr(secContent.toAscii());
        FZSock2[tempFZCounter].PortReceive = LocalCTSock_2.PortReceive;
        FZSock2[tempFZCounter].PortSend = LocalCTSock_2.PortSend;
    }

}


/************************************************************************/
/* HEADER包头数据初始化                                                   */
/************************************************************************/
void commu::InitHEADERData()
{
    QString iniFilePath = INIFILE;
    QString iniFilePath_a;
    iniFilePath_a=QApplication::applicationDirPath();
    iniFilePath = iniFilePath_a;
    iniFilePath+= "/settest.ini";

    CBaseFile iniFile;
    QString sectionName;
    QString secContent;
    int secValue = 0;
    BYTE ip1, ip2, ip3, ip4;
    QString tempName;
    QString tempDID;
    QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
    DWORD tempValue;
    int CTCounter=0;
    int tempCTCounter=0;
    QString tempMessage;

    ////HEADER设置
    HEADERStruct HEADER;
    HEADER.v_Version = 128;
    HEADER.v_SP1[1] = 0;
    HEADER.v_SP1[0] = 15;
    HEADER.v_SP2[3] = 0x60;
    HEADER.v_SP2[2] = 0x01;
    HEADER.v_SP2[1] = 0x0c;
    HEADER.v_SP2[0] = 0x00;
    HEADER.v_SP3[3] = 0x11;
    HEADER.v_SP3[2] = 0x11;
    HEADER.v_SP3[1] = 0x01;
    HEADER.v_SP3[0] = 0x00;
    memset(&(HEADER.v_No), 0, 4);
    WORD diffDay = GetDate();
    memcpy((HEADER.v_Date), &diffDay, 2);//可直接用在《string.h》中

    ////包头数据
    sectionName = "包头数据";

    secContent = iniFile.GetIniStr(sectionName, "VER", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(&(HEADER.v_Version), &tempValue, 1);

    secContent = iniFile.GetIniStr(sectionName, "MID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

    //以上为共有的信息，下面只处理BID

    //Time 发常时信息
    secContent = iniFile.GetIniStr(sectionName, "MID_T", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID常时", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = 04;
    HEADER.v_Length[1] = 0;

    memcpy(&TimerSendHEADER, &HEADER, sizeof(HEADERStruct));

    //Time 收常时信息
    secContent = iniFile.GetIniStr(sectionName, "SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID_T", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID常时", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = 04;
    HEADER.v_Length[1] = 0;

    memcpy(&TimerRecvHEADER, &HEADER, sizeof(HEADERStruct));

    //Measure 实算数据
    secContent = iniFile.GetIniStr(sectionName, "SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID实算数据", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = INI_DATALENGTH_MEASURE;
    HEADER.v_Length[1] = 0;

    memcpy(&MeasureHEADER, &HEADER, sizeof(HEADERStruct));

    //T0数据
    secContent = iniFile.GetIniStr(sectionName, "SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID绝对时T0", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = INI_DATALENGTH_T0;
    HEADER.v_Length[1] = 0;

    memcpy(&T0HEADER, &HEADER, sizeof(HEADERStruct));

    //外引导
    secContent = iniFile.GetIniStr(sectionName, "SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    for(int tem_I=0; tem_I<30; tem_I++)
    {
        QString temp_DD;
        temp_DD.sprintf("BID引入%d", tem_I+1);
        secContent = iniFile.GetIniStr(sectionName, temp_DD, iniFilePath);
        tempValue =CharToHex(secContent);//不得超过4byte
        memcpy(HEADER.v_SP4, &tempValue, 4);
        HEADER.v_Length[0] = INI_DATALENGTH_THEORY;
        HEADER.v_Length[1] = 0;
        memcpy(WYDHEADER+tem_I, &HEADER, sizeof(HEADERStruct));
    }

    //主动时延测试
    secContent = iniFile.GetIniStr(sectionName, "SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID时延测试", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = INI_DATALENGTH_EXAM;
    HEADER.v_Length[1] = 0;

    memcpy(&ExamSendHEADER, &HEADER, sizeof(HEADERStruct));

    //被动时延测试
    secContent = iniFile.GetIniStr(sectionName, "SID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID时延测试", iniFilePath);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(HEADER.v_SP4, &tempValue, 4);

    HEADER.v_Length[0] = INI_DATALENGTH_EXAM;
    HEADER.v_Length[1] = 0;

    memcpy(&ExamRecvHEADER, &HEADER, sizeof(HEADERStruct));

   //界面设置
        QString m;

        tempValue=0;
        memcpy(&tempValue, ExamRecvHEADER.v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m__stBIDExam->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, MeasureHEADER.v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDMeasure->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, T0HEADER.v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m__stBIDTO->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, TimerRecvHEADER.v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDTimer->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[0].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd1->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[1].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd2->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[2].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd3->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[3].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd4->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[4].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd5->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[5].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd6->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[6].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd7->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[7].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd8->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, WYDHEADER[8].v_SP4, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stBIDWyd9->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, MeasureHEADER.v_SP2, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stSID->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, MeasureHEADER.v_SP3, 4);
        m.sprintf("%.8x",tempValue);
        ui->m_stDID->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, &(MeasureHEADER.v_Version), 1);
        m.sprintf("%.2x",tempValue);
        ui->m_stVersion->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, MeasureHEADER.v_SP1, 2);
        m.sprintf("%.4x",tempValue);
        ui->m__stMID->setText(m);
        m.clear();

        tempValue=0;
        memcpy(&tempValue, TimerRecvHEADER.v_SP1, 2);
        m.sprintf("%.4x",tempValue);
        ui->m_stMID_T->setText(m);
        m.clear();
        //UpdateData(false);)

        ////HEADER设置结束
}


/************************************************************************/
/* 其他数据初始化                                                       */
/************************************************************************/
void commu::InitGeneralData()
{
    QString iniFilePath = INIFILE;
    QString iniFilePath_a;
    iniFilePath_a=QApplication::applicationDirPath();
    iniFilePath = iniFilePath_a;
    iniFilePath+= "/settest.ini";

    CBaseFile iniFile;
    QString sectionName;
    QString secContent;
    int secValue = 0;
    BYTE ip1, ip2, ip3, ip4;
    QString tempName;
    QString tempDID;
    QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
    DWORD tempValue;
    int CTCounter=0;
    int tempCTCounter=0;

    ////程序配置
    sectionName = "程序配置";
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标B", iniFilePath);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosB = atof(secContent.toAscii());//可直接用《stdlib.h》
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标L", iniFilePath);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosL = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标H", iniFilePath);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosH = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射角", iniFilePath);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectAngle = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "数据保存路径", iniFilePath);//发射点的大地直角坐标系坐标 Jerry 20110707++
    //DataSavePath = secContent;
    DataSavePath=QString::fromLocal8Bit(secContent.toAscii());
    secValue	= iniFile.GetIniInt(sectionName, "时统源选择", iniFilePath);//发射点的大地直角坐标系坐标 Jerry 20110707++
    if(secValue == 0)
        TimeSource = Time_NULL;
    else if(secValue == 1)
        TimeSource = Time_GPS;
    else if(secValue == 2)
        TimeSource = Time_DC;
    else if(secValue == 3)
        TimeSource = Time_ZK;
    else if(secValue == 4)
        TimeSource = Time_AC;
    else if(secValue == 5)
        TimeSource = Time_Local;
    else
        TimeSource = Time_GPS;

    if(!IsTimecardExist)//commu_dlg中定义的
    {
        TimeSource = Time_Local;
    }

    secContent	= iniFile.GetIniStr(sectionName, "发送网络类型", iniFilePath);
    SendSocketTP = (Sockettp)atoi(secContent.toAscii());   //直接用《stdlib.h》
    secContent	= iniFile.GetIniStr(sectionName, "接收网络类型", iniFilePath);
    RecvSocketTP = (Sockettp)atoi(secContent.toAscii());

    secValue	= iniFile.GetIniInt(sectionName, "接收监控机外引导", iniFilePath);//是否接收监控机外引导

    if(secValue>0)
        ui->m_WYDEnable_va->setChecked(TRUE);
    else
        ui->m_WYDEnable_va->setChecked(FALSE);
    secValue	= iniFile.GetIniInt(sectionName, "接收监控机T0", iniFilePath);//是否接收监控机T0
    if(secValue>0)
       ui->m_TOEnable_va->setChecked(TRUE);
    else
       ui->m_TOEnable_va->setChecked(FALSE);
    secValue	= iniFile.GetIniInt(sectionName, "向监控机发送实算数据", iniFilePath);//是否接收监控机T0
    if(secValue>0)
       ui->m_MeasureEnable_va->setChecked(TRUE);
    else
       ui->m_MeasureEnable_va->setChecked(FALSE);

    ////界面设置
    str_EjectB.sprintf("%f",EjectPosB);
    str_EjectH.sprintf("%f",EjectPosH);
    str_EjectL.sprintf("%f",EjectPosL);
    str_EjectAngle.sprintf("%f",EjectAngle);
    ui->m_DataSavePath->addItem(DataSavePath);
    ui->m_DataSavePath->setCurrentIndex(ui->m_DataSavePath->findText(DataSavePath));

    // ui->m_SendSocketTP =SendSocketTP;
    switch(SendSocketTP)
    {
    case Socket_Udp:
        ui->m_SendSocketTP->setChecked(true);
        break;
    case Socket_Multicast_ASM:
        ui->m_SendSocketTP2->setChecked(true);
        break;
     case Socket_Multicast_SSM:
           ui->m_SendSocketTP3->setChecked(true);
           break;
     default :
           break;
    }
    //m_RecvSocketTP = RecvSocketTP;

    switch(SendSocketTP)
    {
    case Socket_Udp:
        ui->m_RecvSocketTP->setChecked(true);
        break;
    case Socket_Multicast_ASM:
        ui->m_RecvSocketTP2->setChecked(true);
        break;
     case Socket_Multicast_SSM:
        ui->m_RecvSocketTP3->setChecked(true);
         break;
     default :
        break;
    }

    switch(TimeSource)
    {
    case Time_Local:
        {

            ui->m_TimeSource3->setChecked(TRUE);
            break;
        }
    case Time_ZK:
        {
            ui->m_TimeSource3->setChecked(TRUE);
            break;
        }
    case Time_GPS:
        {
            ui->m_TimeSource->setChecked(TRUE);
            break;
        }
    case Time_DC:
        {
            ui->m_TimeSource2->setChecked(TRUE);
            break;
        }
    case Time_AC:
        {
            ui->m_TimeSource2->setChecked(TRUE);
            break;
        }
    default:
            ui->m_TimeSource3->setChecked(TRUE);

    }

    //	m_MeasureEnable_va = true;
    //	m_T0Enable_va = true;
    //	m_WYDEnable_va = true;

    //UpdateData(false);?????????????????????????????????????????????????????????????????????
}



/**********************************************************/
 /*增加组播源地址，所有的接受Socket都增加
  */
/**********************************************************/
void commu::OnBnClickedButtonSetupMulsource()
{
   qDebug("OnBnClickedButtonSetupMulsource");

   CDlg_MulResourceSet dlgSet;
   double tempValue_D;
   DWORD tempValue_DW;
   int sourceIndex = 0;
   QString newAddr;

   for(sourceIndex=0; sourceIndex<CTSrcSet.size(); sourceIndex++)
   {
       tempValue_DW = CTSrcSet[sourceIndex];

       in_addr tempsoAdd;
       tempsoAdd.s_addr = htonl(tempValue_DW);
       newAddr = inet_ntoa(tempsoAdd);
       dlgSet.pAddr[sourceIndex] = CTSrcSet[sourceIndex] ;
   }

   dlgSet.pAddrLength = CTSrcSet.size();
   dlgSet.init();
   dlgSet.exec();//弹出

   CTSrcSet.clear();
   CTSrcNum = dlgSet.pAddrLength;
   CTSrcSet.resize(dlgSet.pAddrLength);
   for(sourceIndex=0; sourceIndex<dlgSet.pAddrLength; sourceIndex++)
   {
       DWORD ps = dlgSet.pAddr[sourceIndex];
       CTSrcSet[sourceIndex] = ps;
   }

}


/**********************************************************/
 /*增加一个单播监控机
  */
/**********************************************************/
void commu::OnButtonNewAdd1()
{
    qDebug("OnButtonNewAdd1");

    AddStruct NewAddress;
    //DWORD NewAddressIP;
    QString NewAddressIP;
    NewAddressIP=ui->m_NewIP1->text();
    NewAddress.IPAdd.sin_addr.s_addr = inet_addr(NewAddressIP.toAscii());//从下面得到的灵感，不知对不对

    //m_NewIP1.GetAddress( NewAddressIP );
    NewAddress.PortReceive = LocalCTSock_1.PortReceive;
    NewAddress.PortSend = LocalCTSock_1.PortSend;

    int check;
    if(ui->m_WayNo1->isChecked())
        check=1;
    else
        check=2;
    NewAddress.WayChose =check;

    DWORD tempValue;
    tempValue = 0;
    tempValue = CharToHex(ui->m_NewDID1->text());
    memcpy(&(NewAddress.DID), &tempValue, 4);

    QString tmp=ui->m_NewName1->text();
    memset(NewAddress.Name,0, 40*sizeof(char));
    memcpy(NewAddress.Name,tmp.toLocal8Bit(), 40);//获得新的数值，保存在结构体中
    NewAddress.Name[strlen(tmp.toLocal8Bit())] = '\0';

    int NewItem;
    QString s_IP, s_ReceivePort, s_SendPort, s_DID, s_Name, s_Way;
    s_IP.sprintf("%d.%d.%d.%d", (NewAddress.IPAdd.sin_addr.s_addr)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>8)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>16)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>24)&0xff);
    s_ReceivePort.sprintf("%.5d",NewAddress.PortReceive);//.Format("%.5d", NewAddress.PortReceive);
    s_SendPort.sprintf("%.5d",NewAddress.PortSend);//.Format("%.5d", NewAddress.PortSend);
    s_Way.sprintf("%d",NewAddress.WayChose);//.Format("%d路", NewAddress.WayChose);
    s_Way=s_Way+tr("路");

    for(int byteCounter=0; byteCounter<4; byteCounter++)
    {
        int temp_Char = (BYTE)(NewAddress.DID[3-byteCounter]);
        QString TempMessage;
        TempMessage.sprintf("%.2x",temp_Char);//.Format("%.2x", temp_Char);
        s_DID+=TempMessage;
    }
    //s_Name=QString(NewAddress.Name) ;
    s_Name=QString::fromLocal8Bit(NewAddress.Name);

    //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
    int row_count = ui->m_AddList1->rowCount(); //获取表单行数
    ui->m_AddList1->insertRow(row_count); //插入新行
    QTableWidgetItem *item1 = new QTableWidgetItem();
    item1->setText(s_IP);
    ui->m_AddList1->setItem(row_count, 0, item1);

    QTableWidgetItem *item2 = new QTableWidgetItem();
    item2->setText(s_ReceivePort);
    ui->m_AddList1->setItem(row_count, 1, item2);

    QTableWidgetItem *item3 = new QTableWidgetItem();
    item3->setText(s_SendPort);
    ui->m_AddList1->setItem(row_count, 2, item3);

    QTableWidgetItem *item4 = new QTableWidgetItem();
    item4->setText(s_Name);
    ui->m_AddList1->setItem(row_count, 3, item4);

    QTableWidgetItem *item5 = new QTableWidgetItem();
    item5->setText(s_DID);
    ui->m_AddList1->setItem(row_count, 4, item5);

    QTableWidgetItem *item6 = new QTableWidgetItem();
    item6->setText(s_Way);
    ui->m_AddList1->setItem(row_count,5, item6);


    //	NewItem = m_AddList1.InsertItem(0xffff, (LPCSTR)s_IP);
    //	m_AddList1.SetItem(NewItem, 1, 1, (LPCSTR)s_ReceivePort, NULL, 0, 0, 0);
    //	m_AddList1.SetItem(NewItem, 2, 1, (LPCSTR)s_SendPort, NULL, 0, 0, 0);
    //	m_AddList1.SetItem(NewItem, 3, 1, (LPCSTR)s_Name, NULL, 0, 0, 0);
    //	m_AddList1.SetItem(NewItem, 4, 1, (LPCSTR)s_DID, NULL, 0, 0, 0);
    //	m_AddList1.SetItem(NewItem, 5, 1, (LPCSTR)s_Way, NULL, 0, 0, 0);
    //	m_AddList1.SetItemData (NewItem, NewItem);
}

/**********************************************************/
 /*删除一个单播监控机
  */
/**********************************************************/
void commu::OnButtonDelAdd1()
{
    qDebug("OnButtonDelAdd1");

    // UpdateData(true);不需要
    if(flag1==1)
    {
        int nItem = 0,nrow=0;
        if(ui->m_AddList1->rowCount()>0)
            nItem = 0;
        else
            return;
        //POSITION pos = m_AddList1.GetFirstSelectedItemPosition();//???????????????????????????????????????????关于POSITION
        nrow=clickitem->row();

        QMessageBox msgBox1;
        msgBox1.setInformativeText(tr("是否要删除该行"));
        msgBox1.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        msgBox1.setDefaultButton(QMessageBox::Ok);
        int ret = msgBox1.exec();
        switch (ret) {
        case QMessageBox::Ok:
            ui->m_AddList1->removeRow(nrow);
            break;
        case QMessageBox::Cancel:
            break;
        }
    }
    else
    {
        qDebug("NO item selected");
        QMessageBox msgBox2;
        msgBox2.setText("NO item selected");
        msgBox2.exec();
    }
    flag1=0;
}
/**********************************************************/
 /*增加一个组播接收监控机删除一个单播监控机
  */
/**********************************************************/

void commu::OnButtonNewAdd2_1()
{
    qDebug("OnButtonNewAdd2_1");

    AddStruct NewAddress;
    //DWORD NewAddressIP;
    QString NewAddressIP;
    NewAddressIP=ui->m_NewIP2->text();
    NewAddress.IPAdd.sin_addr.s_addr = inet_addr(NewAddressIP.toAscii());//从下面得到的灵感，不知对不对

    //m_NewIP2.GetAddress( NewAddressIP );
    //NewAddress.IPAdd.sin_addr.s_addr = htonl(NewAddressIP);
    NewAddress.PortReceive = LocalCTSock_1.PortReceive;
    NewAddress.PortSend = LocalCTSock_1.PortSend;

    int check;
    if(ui->m_WayNo2->isChecked())
        check=1;
    else
        check=2;
    NewAddress.WayChose=check;

    DWORD tempValue;
    tempValue = 0;
    tempValue = CharToHex(ui->m_NewDID2->text());
    memcpy(&(NewAddress.DID), &tempValue, 4);

    QString tmp=ui->m_NewName2->text();
    memset(NewAddress.Name,0, 40*sizeof(char));
    memcpy(NewAddress.Name,tmp.toLocal8Bit(), 40);//获得新的数值，保存在结构体中
    NewAddress.Name[strlen(tmp.toLocal8Bit())] = '\0';

    int NewItem;
    QString s_IP, s_ReceivePort, s_SendPort, s_DID, s_Name, s_Way;
    s_IP.sprintf("%d.%d.%d.%d", (NewAddress.IPAdd.sin_addr.s_addr)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>8)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>16)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>24)&0xff);
    s_ReceivePort.sprintf("%.5d",NewAddress.PortReceive);
    s_SendPort.sprintf("%.5d",NewAddress.PortSend);
    s_Way.sprintf("%d",NewAddress.WayChose);
    s_Way=s_Way+tr("路");

    for(int byteCounter=0; byteCounter<4; byteCounter++)
    {
        int temp_Char = (BYTE)(NewAddress.DID[3-byteCounter]);
        QString TempMessage;
        TempMessage.sprintf("%.2x",temp_Char);//.Format("%.2x", temp_Char);
        s_DID+=TempMessage;
    }
    //s_Name=QString(NewAddress.Name) ;
    s_Name=QString::fromLocal8Bit(NewAddress.Name) ;

    //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
    int row_count = ui->m_Addlist2_1->rowCount(); //获取表单行数
    ui->m_Addlist2_1->insertRow(row_count); //插入新行
    QTableWidgetItem *item7 = new QTableWidgetItem();
    item7->setText(s_IP);
    ui->m_Addlist2_1->setItem(row_count, 0, item7);

    QTableWidgetItem *item8 = new QTableWidgetItem();
    item8->setText(s_ReceivePort);
    ui->m_Addlist2_1->setItem(row_count, 1, item8);

    QTableWidgetItem *item9 = new QTableWidgetItem();
    item9->setText(s_SendPort);
    ui->m_Addlist2_1->setItem(row_count, 2, item9);

    QTableWidgetItem *item10 = new QTableWidgetItem();
    item10->setText(s_Name);
    ui->m_Addlist2_1->setItem(row_count, 3, item10);

    QTableWidgetItem *item11 = new QTableWidgetItem();
    item11->setText(s_DID);
    ui->m_Addlist2_1->setItem(row_count, 4, item11);

    QTableWidgetItem *item12 = new QTableWidgetItem();
    item12->setText(s_Way);
    ui->m_Addlist2_1->setItem(row_count,5, item12);
}


/**********************************************************/
 /*删除一个组播接收监控机
  */
/**********************************************************/
void commu::OnButtonDelAdd2_1()
{
    qDebug("OnButtonDelAdd2_1");
    // UpdateData(true);不需要
    if(flag2==1)
    {
        int nItem = 0,nrow=0;
        if(ui->m_Addlist2_1->rowCount()>0)
            nItem = 0;
        else
            return;
        //POSITION pos = m_AddList1.GetFirstSelectedItemPosition();//???????????????????????????????????????????关于POSITION
        nrow=clickitem->row();

        QMessageBox msgBox1;
        msgBox1.setInformativeText(tr("是否要删除该行"));
        msgBox1.setStandardButtons(QMessageBox::Ok| QMessageBox::Cancel);
        msgBox1.setDefaultButton(QMessageBox::Ok);
        int ret = msgBox1.exec();
        switch (ret) {
        case QMessageBox::Ok:
            ui->m_Addlist2_1->removeRow(nrow);
            break;
        case QMessageBox::Cancel:
            break;
        }
    }
    else
    {
        qDebug("NO item selected");
        QMessageBox msgBox2;
        msgBox2.setText("NO item selected");
        msgBox2.exec();
    }
    flag2=0;
}
/**********************************************************/
 /*增加一个组播发送监控机
  */
/**********************************************************/
void commu::OnButtonNewAdd2_2()
{
    qDebug("OnButtonNewAdd2_2");

    AddStruct NewAddress;
    //DWORD NewAddressIP;
    QString NewAddressIP;
    NewAddressIP=ui->m_NewIP2->text();
    NewAddress.IPAdd.sin_addr.s_addr = inet_addr(NewAddressIP.toAscii());//从下面得到的灵感，不知对不对

    //m_NewIP2.GetAddress( NewAddressIP );
    //NewAddress.IPAdd.sin_addr.S_un.S_addr = htonl(NewAddressIP);
    NewAddress.PortReceive = LocalCTSock_1.PortReceive;
    NewAddress.PortSend = LocalCTSock_1.PortSend;

    int check;
    if(ui->m_WayNo2->isChecked())
        check=1;
    else
        check=2;
    NewAddress.WayChose =check;

    DWORD tempValue;
    tempValue = 0;
    tempValue = CharToHex(ui->m_NewDID2->text());
    memcpy(&(NewAddress.DID), &tempValue, 4);

    QString tmp=ui->m_NewName2->text();
    memset(NewAddress.Name,0, 40*sizeof(char));
    memcpy(NewAddress.Name,tmp.toLocal8Bit(), 40);//获得新的数值，保存在结构体中
    NewAddress.Name[strlen(tmp.toLocal8Bit())] = '\0';

    int NewItem;
    QString s_IP, s_ReceivePort, s_SendPort, s_DID, s_Name, s_Way;
    s_IP.sprintf("%d.%d.%d.%d",
                 (NewAddress.IPAdd.sin_addr.s_addr)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>8)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>16)&0xff,
                 (NewAddress.IPAdd.sin_addr.s_addr>>24)&0xff);
    s_ReceivePort.sprintf("%.5d",NewAddress.PortReceive);
    s_SendPort.sprintf("%.5d",NewAddress.PortSend);
    s_Way.sprintf("%d",NewAddress.WayChose);
    s_Way=s_Way+tr("路");

    for(int byteCounter=0; byteCounter<4; byteCounter++)
    {
        int temp_Char = (BYTE)(NewAddress.DID[3-byteCounter]);
        QString TempMessage;
        TempMessage.sprintf("%.2x",temp_Char);//.Format("%.2x", temp_Char);
        s_DID+=TempMessage;
    }
    //s_Name=QString(NewAddress.Name) ;
    s_Name=QString::fromLocal8Bit(NewAddress.Name) ;

    //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
    int row_count = ui->m_Addlist2_2->rowCount(); //获取表单行数
    ui->m_Addlist2_2->insertRow(row_count); //插入新行
    QTableWidgetItem *item1= new QTableWidgetItem();
    item1->setText(s_IP);
    ui->m_Addlist2_2->setItem(row_count, 0, item1);

    QTableWidgetItem *item2 = new QTableWidgetItem();
    item2->setText(s_ReceivePort);
    ui->m_Addlist2_2->setItem(row_count, 1, item2);

    QTableWidgetItem *item3 = new QTableWidgetItem();
    item3->setText(s_SendPort);
    ui->m_Addlist2_2->setItem(row_count, 2, item3);

    QTableWidgetItem *item4 = new QTableWidgetItem();
    item4->setText(s_Name);
    ui->m_Addlist2_2->setItem(row_count, 3, item4);

    QTableWidgetItem *item5 = new QTableWidgetItem();
    item5->setText(s_DID);
    ui->m_Addlist2_2->setItem(row_count, 4, item5);

    QTableWidgetItem *item6 = new QTableWidgetItem();
    item6->setText(s_Way);
    ui->m_Addlist2_2->setItem(row_count,5, item6);
}
/**********************************************************/
 /*删除一个组播发送监控机
  */
/**********************************************************/
void commu::OnButtonDelAdd2_2()
{
    qDebug("OnButtonDelAdd2_2");

    // UpdateData(true);不需要
    if(flag3==1)
    {
        int nItem = 0,nrow=0;
        if(ui->m_Addlist2_2->rowCount()>0)
            nItem = 0;
        else
            return;
        //POSITION pos = m_AddList1.GetFirstSelectedItemPosition();//???????????????????????????????????????????关于POSITION
        nrow=clickitem->row();

        QMessageBox msgBox1;

        msgBox1.setInformativeText(tr("是否要删除该行"));
        msgBox1.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        msgBox1.setDefaultButton(QMessageBox::Ok);
        int ret = msgBox1.exec();
        switch (ret) {
        case QMessageBox::Ok:
            ui->m_Addlist2_2->removeRow(nrow);
            break;
        case QMessageBox::Cancel:
            break;
        }
    }
    else
    {
        qDebug("NO item selected");
        QMessageBox msgBox2;
        msgBox2.setText("NO item selected");
        msgBox2.exec();
    }
    flag3=0;
}

/**********************************************************/
 /*“更多”按键绑定
  */
/**********************************************************/
void commu::OnBnClickedButtonSetupTip()
{
     qDebug("OnBnClickedButtonSetupTip");

     QString ptemStr;
     ptemStr.sprintf("外部说明Ｂｉｄ依次为理论引入、综合飞行引入、外测综合飞行引入、\n");
     ptemStr+="外测解析飞行引入、外测融合飞行引入、遥测综合飞行引入、\n";
     ptemStr+="GPS伪距差分引入、GPS自定位引入、GPS单点定位引入";

     CDlg_BIDSet  dlgSet;
     double tempValue_D;
     DWORD tempValue_DW;
     int BIDIndex = 0;
     QString newAddr;

     for(BIDIndex=0; BIDIndex<21; BIDIndex++)
     {
         memcpy(&tempValue_DW, WYDHEADER[BIDIndex+9].v_SP4, 4);
         dlgSet.pBID[BIDIndex] = tempValue_DW ;
     }

     dlgSet.pBIDCount = 21;
     dlgSet.init();
     dlgSet.exec();

     if(dlgSet.pBIDCount>21)
         return;
     for(BIDIndex=0; BIDIndex<dlgSet.pBIDCount; BIDIndex++)
     {
         DWORD ps = dlgSet.pBID[BIDIndex];
         memcpy(WYDHEADER[BIDIndex+9].v_SP4, &ps, 4);
     }

}

/**********************************************************/
 /*设置保存路径
  */
/**********************************************************/
void commu::OnButtonSetPath()
{
    qDebug("OnButtonSetPath");

    QString directory = ui->m_DataSavePath->currentText();

    directory = QFileDialog::getExistingDirectory(this,
                               tr("请选择新的数据保存路径"), QDir::currentPath());

    if (!directory.isEmpty())
    {
        if (ui->m_DataSavePath->findText(directory) == -1)
             ui->m_DataSavePath->addItem(directory);
            ui->m_DataSavePath->setCurrentIndex(ui->m_DataSavePath->findText(directory));
          if(ui->m_DataSavePath->count()>6)
          {

              ui->m_DataSavePath->removeItem(1);
          }
    }
}
/**********************************************************/
 /*更多设置
  */
/**********************************************************/
void commu::OnButtonSetupInner()
{
     qDebug("OnButtonSetupInner");

     CDlg_SetInner pDlg;//另一个对话框类CDlg_SetInner
     setinnerui=pDlg.getui();
     pDlg.Addr_1 = ntohl(ZhuKongTaiSock_1.IPAdd.sin_addr.s_addr);
     pDlg.Addr_2 = ntohl(ZhuKongTaiSock_2.IPAdd.sin_addr.s_addr);
     pDlg.isZK=Is_ZhuKongTai;

     pDlg.FZNum=FZSockNum;
     pDlg.FZSet1.resize(FZSockNum);
     pDlg.FZSet2.resize(FZSockNum);
     for(int i=0;i<FZSockNum;i++)
     {
         pDlg.FZSet1[i]=ntohl(FZSock1[i].IPAdd.sin_addr.s_addr);
         pDlg.FZSet2[i]=ntohl(FZSock2[i].IPAdd.sin_addr.s_addr);
     }

     pDlg.init();

     if(pDlg.exec()== OK)
     {
         ZhuKongTaiSock_1.IPAdd.sin_addr.s_addr = htonl(pDlg.Addr_1);
         ZhuKongTaiSock_2.IPAdd.sin_addr.s_addr = htonl(pDlg.Addr_2);
         Is_ZhuKongTai = setinnerui->m_Is_ZhuKongTai->isChecked();

         FZSockNum=pDlg.FZNum;
         FZSock1.clear();
         FZSock2.clear();
         FZSock1.resize(FZSockNum);
         FZSock2.resize(FZSockNum);
         for(int i=0;i<FZSockNum;i++)
         {
             FZSock1[i].IPAdd.sin_addr.s_addr=htonl(pDlg.FZSet1[i]);
             FZSock2[i].IPAdd.sin_addr.s_addr=htonl(pDlg.FZSet2[i]);
         }
     }
}

/**********************************************************/
 /*保存并应用
  */
/**********************************************************/
void commu::OnButtonSetupSave()
{
     qDebug("OnButtonSetupSave");
     commu::OnButtonSetupApply();

     QString iniFilePath = INIFILE;
     QString iniFilePath_a;
     iniFilePath_a=QApplication::applicationDirPath();
     iniFilePath = iniFilePath_a;
     iniFilePath+= "/settest.ini";

     CBaseFile iniFile;
     QString sectionName;
     QString secContent;
     int secValue = 0;
     BYTE ip1, ip2, ip3, ip4;
     QString tempName;
     QString tempDID;
     QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
     DWORD tempValue;
     int CTCounter = 0;
     int tempCTCounter = 0;
     int tempFZCounter=0;
     QString tempMessage;

////IP设置
         sectionName ="网络配置";
         ip1 =(ZKSock.IPAdd.sin_addr.s_addr)&0xff;
         ip2 = (ZKSock.IPAdd.sin_addr.s_addr>>8)&0xff;
         ip3 = (ZKSock.IPAdd.sin_addr.s_addr>>16)&0xff;
         ip4 = (ZKSock.IPAdd.sin_addr.s_addr>>24)&0xff;
         secContent.sprintf("%.3d", ip1);
         iniFile.WriteIniVal(sectionName, "主控IP1", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip2);
         iniFile.WriteIniVal(sectionName, "主控IP2", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip3);
         iniFile.WriteIniVal(sectionName, "主控IP3", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip4);
         iniFile.WriteIniVal(sectionName, "主控IP4", secContent, iniFilePath);
         secContent.sprintf("%.5d", ZKSock.PortReceive);
         iniFile.WriteIniVal(sectionName, "主控端口", secContent, iniFilePath);

         ip1 =(LocalZKSock.IPAdd.sin_addr.s_addr)&0xff;
         ip2 =(LocalZKSock.IPAdd.sin_addr.s_addr>>8)&0xff;
         ip3 =(LocalZKSock.IPAdd.sin_addr.s_addr>>16)&0xff;
         ip4 =(LocalZKSock.IPAdd.sin_addr.s_addr>>24)&0xff;
         secContent.sprintf("%.3d", ip1);
         iniFile.WriteIniVal(sectionName, "本地对主控路由IP1", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip2);
         iniFile.WriteIniVal(sectionName, "本地对主控路由IP2", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip3);
         iniFile.WriteIniVal(sectionName, "本地对主控路由IP3", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip4);
         iniFile.WriteIniVal(sectionName, "本地对主控路由IP4", secContent, iniFilePath);

         ip1 = (LocalCTSock_1.IPAdd.sin_addr.s_addr)&0xff;
         ip2 = (LocalCTSock_1.IPAdd.sin_addr.s_addr>>8)&0xff;
         ip3 = (LocalCTSock_1.IPAdd.sin_addr.s_addr>>16)&0xff;
         ip4 = (LocalCTSock_1.IPAdd.sin_addr.s_addr>>24)&0xff;
         secContent.sprintf("%.3d", ip1);
         iniFile.WriteIniVal(sectionName, "本地第一路由IP1", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip2);
         iniFile.WriteIniVal(sectionName, "本地第一路由IP2", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip3);
         iniFile.WriteIniVal(sectionName, "本地第一路由IP3", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip4);
         iniFile.WriteIniVal(sectionName, "本地第一路由IP4", secContent, iniFilePath);

         ip1 = (LocalCTSock_2.IPAdd.sin_addr.s_addr)&0xff;
         ip2 = (LocalCTSock_2.IPAdd.sin_addr.s_addr>>8)&0xff;
         ip3 = (LocalCTSock_2.IPAdd.sin_addr.s_addr>>16)&0xff;
         ip4 = (LocalCTSock_2.IPAdd.sin_addr.s_addr>>24)&0xff;
         secContent.sprintf("%.3d", ip1);
         iniFile.WriteIniVal(sectionName, "本地第二路由IP1", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip2);
         iniFile.WriteIniVal(sectionName, "本地第二路由IP2", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip3);
         iniFile.WriteIniVal(sectionName, "本地第二路由IP3", secContent, iniFilePath);
         secContent.sprintf("%.3d", ip4);
         iniFile.WriteIniVal(sectionName, "本地第二路由IP4", secContent, iniFilePath);

         secContent=QString("%1").arg(LocalCTSock_1.PortReceive,0,10);//.Format("%.5d", LocalCTSock_1.PortReceive);
         iniFile.WriteIniVal(sectionName, "监控机接收端口", secContent, iniFilePath);
         secContent=QString("%1").arg(LocalCTSock_1.PortSend,0,10);//.Format("%.5d", LocalCTSock_1.PortSend);
         iniFile.WriteIniVal(sectionName, "监控机发送端口", secContent, iniFilePath);

         sectionName=QString("协议设置");
         secContent=QString("%1").arg(INI_DATALENGTH_MEASURE,0,10);//.Format("%d", INI_DATALENGTH_MEASURE);
         iniFile.WriteIniVal(sectionName, "实算数据区长度", secContent, iniFilePath);
         secContent.sprintf("%.5d", INI_DATALENGTH_THEORY);
         iniFile.WriteIniVal(sectionName, "引入数据区长度", secContent, iniFilePath);
         secContent.sprintf("%.5d", INI_REVERSE_DATALENGTH);
         iniFile.WriteIniVal(sectionName, "填充区长度", secContent, iniFilePath);
         iniFile.WriteIniVal(sectionName, "填充区内容", INI_REVERSE_DATACONTENT, iniFilePath);
         secContent.sprintf("%.5d", INI_DATALENGTH_ZK);
         iniFile.WriteIniVal(sectionName, "主控数据长度", secContent, iniFilePath);
         secContent.sprintf("%.5d", INI_DATALENGTH_ZXZ);
         iniFile.WriteIniVal(sectionName, "中心站数据长度", secContent, iniFilePath);

         sectionName=QString("单播网络配置");
         secContent.sprintf("%d", CTP2PNum);
         iniFile.WriteIniVal(sectionName, "远端数目", secContent, iniFilePath);
         for(tempCTCounter=0; tempCTCounter<CTP2PNum; tempCTCounter++)//第2次循环保存到数组中
         {
             valueItem1=QString("远端%1_IP1").arg(tempCTCounter+1,0,10);//.Format("远端%d_IP1",			tempCTCounter+1);
             valueItem2=QString("远端%1_IP2").arg(tempCTCounter+1,0,10);//Format("远端%d_IP2",			tempCTCounter+1);
             valueItem3=QString("远端%1_IP3").arg(tempCTCounter+1,0,10);//.Format("远端%d_IP3",			tempCTCounter+1);
             valueItem4=QString("远端%1_IP4").arg(tempCTCounter+1,0,10);//.Format("远端%d_IP4",			tempCTCounter+1);
             valueItem7=QString("远端%1_DID").arg(tempCTCounter+1,0,10);//.Format("远端%d_DID",			tempCTCounter+1);
             valueItem8=QString("远端%1_地址名称").arg(tempCTCounter+1,0,10);//.Format("远端%d_地址名称",	tempCTCounter+1);
             valueItem9=QString("远端%1_路由").arg(tempCTCounter+1,0,10);//.Format("远端%d_路由",		tempCTCounter+1);

             ip1 = (CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff;
             ip2 = (CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff;
             ip3 = (CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff;
             ip4 = (CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff;
             secContent.sprintf("%.3d", ip1);
             iniFile.WriteIniVal(sectionName, valueItem1, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip2);
             iniFile.WriteIniVal(sectionName, valueItem2, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip3);
             iniFile.WriteIniVal(sectionName, valueItem3, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip4);
             iniFile.WriteIniVal(sectionName, valueItem4, secContent, iniFilePath);

             secContent=QString("");
             for(int byteCounter=0; byteCounter<4; byteCounter++)
             {
                 int temp_Char = (BYTE)(CTP2PSet[tempCTCounter].DID[3-byteCounter]);
                 QString TempMessage;
                 TempMessage=TempMessage.sprintf("%.2x", temp_Char);
                 secContent = secContent + TempMessage;
             }
             iniFile.WriteIniVal(sectionName, valueItem7, secContent, iniFilePath);

             iniFile.WriteIniVal(sectionName, valueItem8, CTP2PSet[tempCTCounter].Name, iniFilePath);
             secContent=QString("%1").arg(CTP2PSet[tempCTCounter].WayChose,0,10);//.Format("%d", CTP2PSet[tempCTCounter].WayChose);
             iniFile.WriteIniVal(sectionName, valueItem9, secContent, iniFilePath);
         }
         //此时，将所有的单播网络远端都写入了

         sectionName =QString("组播网络配置") ;
         secContent=QString("%1").arg(CTMulNumRe,0,10);//.Format("%d", CTMulNumRe);
         iniFile.WriteIniVal(sectionName, "接收远端数目", secContent, iniFilePath);
         for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)//第2次循环保存到数组中
         {
             valueItem1=QString("接收远端%1_IP1").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP1",			tempCTCounter+1);
             valueItem2=QString("接收远端%1_IP2").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP2",			tempCTCounter+1);
             valueItem3=QString("接收远端%1_IP3").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP3",			tempCTCounter+1);
             valueItem4=QString("接收远端%1_IP4").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_IP4",			tempCTCounter+1);
             valueItem7=QString("接收远端%1_DID").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_DID",			tempCTCounter+1);
             valueItem8=QString("接收远端%1_地址名称").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_地址名称",	tempCTCounter+1);
             valueItem9=QString("接收远端%1_路由").arg(tempCTCounter+1,0,10);//.Format("接收远端%d_m路由",		tempCTCounter+1);


             ip1 = (CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff;
             ip2 =  (CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff;
             ip3 = (CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff;
             ip4 =  (CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff;
             secContent.sprintf("%.3d", ip1);
             iniFile.WriteIniVal(sectionName, valueItem1, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip2);
             iniFile.WriteIniVal(sectionName, valueItem2, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip3);
             iniFile.WriteIniVal(sectionName, valueItem3, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip4);
             iniFile.WriteIniVal(sectionName, valueItem4, secContent, iniFilePath);

             secContent=QString("");
             for(int byteCounter=0; byteCounter<4; byteCounter++)
             {
                 int temp_Char = (BYTE)(CTMulSetRe[tempCTCounter].DID[3-byteCounter]);
                 QString TempMessage;
                 TempMessage.sprintf("%.2x", temp_Char);
                 secContent = secContent + TempMessage;
             }
             iniFile.WriteIniVal(sectionName, valueItem7, secContent, iniFilePath);

             iniFile.WriteIniVal(sectionName, valueItem8, CTMulSetRe[tempCTCounter].Name, iniFilePath);
             secContent=QString("%1").arg(CTMulSetRe[tempCTCounter].WayChose,0,10);//.Format("%d", CTMulSetRe[tempCTCounter].WayChose);
             iniFile.WriteIniVal(sectionName, valueItem9, secContent, iniFilePath);
         }


         secContent=QString("%1").arg(CTMulNumSe,0,10);//.Format("%d", CTMulNumSe);
         iniFile.WriteIniVal(sectionName, "发送远端数目", secContent, iniFilePath);
         for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)//第2次循环保存到数组中
         {
             valueItem1=QString("发送远端%1_IP1").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP1",			tempCTCounter+1);
             valueItem2=QString("发送远端%1_IP2").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP2",			tempCTCounter+1);
             valueItem3=QString("发送远端%1_IP3").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP3",			tempCTCounter+1);
             valueItem4=QString("发送远端%1_IP4").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_IP4",			tempCTCounter+1);
             valueItem7=QString("发送远端%1_DID").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_DID",			tempCTCounter+1);
             valueItem8=QString("发送远端%1_地址名称").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_地址名称",	tempCTCounter+1);
             valueItem9=QString("发送远端%1_路由").arg(tempCTCounter+1,0,10);//.Format("发送远端%d_m路由",		tempCTCounter+1);

             ip1 = (CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff;
             ip2 = (CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff;
             ip3 = (CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff;
             ip4 = (CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff;
             secContent.sprintf("%.3d", ip1);
             iniFile.WriteIniVal(sectionName, valueItem1, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip2);
             iniFile.WriteIniVal(sectionName, valueItem2, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip3);
             iniFile.WriteIniVal(sectionName, valueItem3, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip4);
             iniFile.WriteIniVal(sectionName, valueItem4, secContent, iniFilePath);

             secContent=QString("");
             for(int byteCounter=0; byteCounter<4; byteCounter++)
             {
                 int temp_Char = (BYTE)(CTMulSetSe[tempCTCounter].DID[3-byteCounter]);
                 QString TempMessage;
                 TempMessage.sprintf("%.2x", temp_Char);
                 secContent = secContent + TempMessage;
             }
             iniFile.WriteIniVal(sectionName, valueItem7, secContent, iniFilePath);

             iniFile.WriteIniVal(sectionName, valueItem8, CTMulSetSe[tempCTCounter].Name, iniFilePath);
             secContent=QString("%1").arg(CTMulSetSe[tempCTCounter].WayChose,0,10);//.Format("%d", CTMulSetSe[tempCTCounter].WayChose);
             iniFile.WriteIniVal(sectionName, valueItem9, secContent, iniFilePath);
         }
         //此时，将所有的组播网络远端都写入了

         secContent=QString("%1").arg(CTSrcNum,0,10);//.Format("%d", CTSrcNum);
         iniFile.WriteIniVal(sectionName, "组播源数目", secContent, iniFilePath);
         for(tempCTCounter=0; tempCTCounter<CTSrcNum; tempCTCounter++)//第2次循环保存到数组中
         {
             valueItem1.sprintf("组播源%d_IP1",			tempCTCounter+1);
             valueItem2.sprintf("组播源%d_IP2",			tempCTCounter+1);
             valueItem3.sprintf("组播源%d_IP3",			tempCTCounter+1);
             valueItem4.sprintf("组播源%d_IP4",			tempCTCounter+1);

             ip1 = CTSrcSet[tempCTCounter]/256/256/256;
             ip2 = CTSrcSet[tempCTCounter]/256/256%256;
             ip3 = CTSrcSet[tempCTCounter]/256%256;
             ip4 = CTSrcSet[tempCTCounter]%256;
             secContent.sprintf("%.3d", ip1);
             iniFile.WriteIniVal(sectionName, valueItem1, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip2);
             iniFile.WriteIniVal(sectionName, valueItem2, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip3);
             iniFile.WriteIniVal(sectionName, valueItem3, secContent, iniFilePath);
             secContent.sprintf("%.3d", ip4);
             iniFile.WriteIniVal(sectionName, valueItem4, secContent, iniFilePath);
         }


         //HEADER
             sectionName =QString("包头数据");

             secContent.sprintf("%.2x",MeasureHEADER.v_Version);
             iniFile.WriteIniVal(sectionName, "VER", secContent, iniFilePath);
             memcpy(&tempValue,			MeasureHEADER.v_SP2, 4);
             secContent.sprintf("%.8x",tempValue);
             iniFile.WriteIniVal(sectionName, "SID", secContent, iniFilePath);
             memcpy(&tempValue,			MeasureHEADER.v_SP3, 4);
             secContent.sprintf("%.8x",tempValue);

             iniFile.WriteIniVal(sectionName, "DID", secContent, iniFilePath);
             memcpy(&tempValue,			MeasureHEADER.v_SP1, 2);
             secContent.sprintf("%.4x",tempValue);

             iniFile.WriteIniVal(sectionName, "MID", secContent, iniFilePath);
             memcpy(&tempValue,			TimerRecvHEADER.v_SP1, 2);
             secContent.sprintf("%.4x",tempValue);

             iniFile.WriteIniVal(sectionName, "MID_T", secContent, iniFilePath);
             memcpy(&tempValue,			TimerRecvHEADER.v_SP4, 4);
             secContent.sprintf("%.8x",tempValue);

             iniFile.WriteIniVal(sectionName, "BID常时", secContent, iniFilePath);
             memcpy(&tempValue,			ExamRecvHEADER.v_SP4, 4);
             secContent.sprintf("%.8x",tempValue);

             iniFile.WriteIniVal(sectionName, "BID时延测试", secContent, iniFilePath);
             memcpy(&tempValue,			T0HEADER.v_SP4, 4);
             secContent.sprintf("%.8x",tempValue);

             iniFile.WriteIniVal(sectionName, "BID绝对时T0", secContent, iniFilePath);
             memcpy(&tempValue,			MeasureHEADER.v_SP4, 4);
             secContent.sprintf("%.8x",tempValue);

             iniFile.WriteIniVal(sectionName, "BID实算数据", secContent, iniFilePath);


             for(int tem_I=0; tem_I<30; tem_I++)
             {
                 QString temp_DD;
                 temp_DD.sprintf("BID引入%d", tem_I+1);
                 memcpy(&tempValue,	WYDHEADER[tem_I].v_SP4, 4);
                 secContent.sprintf("%.8x",tempValue);
                 iniFile.WriteIniVal(sectionName, temp_DD, secContent, iniFilePath);
             }

         //其它配置
             sectionName=QString("程序配置");
             secContent.sprintf("%f", EjectPosL);//=QString("%1").arg(EjectPosL,0,10);//.Format("%f", EjectPosL);
             iniFile.WriteIniVal(sectionName, "发射点坐标L", secContent, iniFilePath);
             secContent.sprintf("%f", EjectPosB);//QString("%1").arg( EjectPosB,0,10);//.Format("%f", EjectPosB);
             iniFile.WriteIniVal(sectionName, "发射点坐标B", secContent, iniFilePath);
             secContent.sprintf("%f", EjectPosH);//=QString("%1").arg( EjectPosH,0,10);//.Format("%f", EjectPosH);
             iniFile.WriteIniVal(sectionName, "发射点坐标H", secContent, iniFilePath);
             secContent.sprintf("%f", EjectAngle);//=QString("%1").arg( EjectAngle,0,10);//.Format("%f", EjectAngle);
             iniFile.WriteIniVal(sectionName, "发射角", secContent, iniFilePath);
             secContent.sprintf("%f", EjectAngle);

             QString PathTmp=DataSavePath.toLocal8Bit();
             iniFile.WriteIniVal(sectionName, "数据保存路径", PathTmp, iniFilePath);

             switch(TimeSource)
             {
             case Time_AC:
                 {
                     secValue = 4;
                     break;
                 }
             case Time_GPS:
                 {
                     secValue = 1;
                     break;
                 }
             case Time_NULL:
                 {
                     secValue = 0;
                     break;
                 }
             case Time_DC:
                 {
                     secValue = 2;
                     break;
                 }
             case Time_ZK:
                 {
                     secValue = 3;
                     break;
                 }
             case Time_Local:
                 {
                     secValue = 5;
                     break;
                 }
             default:
                 secValue = 1;
             }
             secContent=QString("%1").arg(secValue,0,10);//.Format("%d", secValue);
             iniFile.WriteIniVal(sectionName, "时统源选择", secContent, iniFilePath);

             secContent=QString("%1").arg((int)SendSocketTP,0,10);//.Format("%d", (int)SendSocketTP);
             iniFile.WriteIniVal(sectionName, "发送网络类型", secContent, iniFilePath);
             secContent=QString("%1").arg((int)RecvSocketTP,0,10);//.Format("%d", (int)RecvSocketTP);
             iniFile.WriteIniVal(sectionName, "接收网络类型", secContent, iniFilePath);

             secContent=QString("%1").arg(ui->m_WYDEnable_va->isChecked(),0,10);//.Format("%d", (int)m_WYDEnable_va);
             iniFile.WriteIniVal(sectionName, "接收监控机外引导", secContent, iniFilePath);
             secContent=QString("%1").arg(ui->m_TOEnable_va->isChecked(),0,10);//.Format("%d", (int)m_T0Enable_va);
             iniFile.WriteIniVal(sectionName, "接收监控机T0", secContent, iniFilePath);
             secContent=QString("%1").arg(ui->m_MeasureEnable_va->isChecked(),0,10);//.Format("%d", (int)m_MeasureEnable_va);
             iniFile.WriteIniVal(sectionName, "向监控机发送实算数据", secContent, iniFilePath);

             sectionName =QString("网络配置");
             secContent = inet_ntoa(ZhuKongTaiSock_1.IPAdd.sin_addr);
             iniFile.WriteIniVal(sectionName, "中心站_1IP", secContent, iniFilePath);
             secContent = inet_ntoa(ZhuKongTaiSock_2.IPAdd.sin_addr);
             iniFile.WriteIniVal(sectionName, "中心站_2IP", secContent, iniFilePath);
             secContent.sprintf("%d", (int)Is_ZhuKongTai);
             iniFile.WriteIniVal(sectionName, "是否与主控台通信", secContent, iniFilePath);

             sectionName = QString("分站配置");
             secContent.sprintf("%d", FZSockNum);
             iniFile.WriteIniVal(sectionName, "分站数目", secContent, iniFilePath);
             for(tempFZCounter=0; tempFZCounter<FZSockNum; tempFZCounter++)
             {
                 valueItem5.sprintf("分站%d_第一路由",		tempFZCounter+1);
                 valueItem6.sprintf("分站%d_第二路由",		tempFZCounter+1);
                 secContent = inet_ntoa(FZSock1[tempFZCounter].IPAdd.sin_addr);
                 iniFile.WriteIniVal(sectionName, valueItem5, secContent, iniFilePath);
                 secContent = inet_ntoa(FZSock2[tempFZCounter].IPAdd.sin_addr);
                 iniFile.WriteIniVal(sectionName, valueItem6, secContent, iniFilePath);
             }

             fileConvert();
}


/************************************************************************/
/* 应用，将各个m_**转存到存储量中
其中主控台/分站地址不处理，组播源地址不处理
*/
/************************************************************************/
void commu::OnButtonSetupApply()
{
     qDebug("OnButtonSetupApply");

     int addrIndex;
     for(addrIndex=0; addrIndex<CTP2PNum; addrIndex++)
     {
         memset(&(CTP2PSet[addrIndex]), 0, sizeof(AddStruct));
     }
     CTP2PSet.clear();
     CTP2PNum = 0;
     for(addrIndex=0; addrIndex<CTMulNumRe; addrIndex++)
     {
         memset(&(CTMulSetRe[addrIndex]), 0, sizeof(AddStruct));
     }
     CTMulSetRe.clear();
     CTMulNumRe = 0;
     for(addrIndex=0; addrIndex<CTMulNumSe; addrIndex++)
     {
         memset(&(CTMulSetSe[addrIndex]), 0, sizeof(AddStruct));
     }
     CTMulSetSe.clear();
     CTMulNumSe = 0;

     QString iniFilePath = INIFILE;
     QString iniFilePath_a;
     iniFilePath_a=QApplication::applicationDirPath();
     //char iniFilePath_a[256];
     // GetCurrentDirectory(256, iniFilePath_a);
     iniFilePath = iniFilePath_a;
     iniFilePath+= "/settest.ini";

     CBaseFile iniFile;
     QString sectionName;
     QString secContent;
     int secValue = 0;
     BYTE ip1, ip2, ip3, ip4;
     QString tempName;
     QString tempDID;
     QString valueItem1, valueItem2, valueItem3, valueItem4, valueItem5, valueItem6, valueItem7, valueItem8, valueItem9;
     //DWORD tempValue;
     int CTCounter = 0;
     int tempCTCounter = 0;
     int byteCounter = 0;
     long tempRecvPort = 0;
     long tempSendPort = 0;
     bool ok;
     ulong dec;

     QString tempValue;
     unsigned long tmp=0;
     tempValue=ui->m_ZKIP->text();
     ZKSock.IPAdd.sin_addr.s_addr = inet_addr(tempValue.toAscii());
     tempValue.clear();

     //删掉IP地址中的“：”
    // m_ZKIP.GetAddress(tempValue);
    // ZKSock.IPAdd.sin_addr.S_un.S_addr = htonl(tempValue);
     tempValue= ui->m_ZKPort->text();
     dec=tempValue.toULong(&ok,10);
     ZKSock.PortReceive=dec;
     ZKSock.PortSend = ZKSock.PortReceive;
     tempValue.clear();


     tempValue=ui->m_LocaltoZK_IP->text();
     LocalZKSock.IPAdd.sin_addr.s_addr = inet_addr(tempValue.toAscii());
     tempValue.clear();

     //m_LocaltoZK_IP.GetAddress(tempValue);
     //LocalZKSock.IPAdd.sin_addr.S_un.S_addr = htonl(tempValue);
     LocalZKSock.PortReceive = ZKSock.PortReceive;
     LocalZKSock.PortSend = ZKSock.PortReceive;


     tempValue=ui->m_LocaltoCT_IP1->text();

     LocalCTSock_1.IPAdd.sin_addr.s_addr = inet_addr(tempValue.toAscii());
     tempValue.clear();

     //m_LocaltoCT_IP1.GetAddress(tempValue);
     //LocalCTSock_1.IPAdd.sin_addr.S_un.S_addr = htonl(tempValue);
     tempValue= ui->m_RecvCTPort->text();
     dec=tempValue.toULong(&ok,10);
     LocalCTSock_1.PortReceive=dec;
     tempValue.clear();
     //LocalCTSock_1.PortReceive = m_RecvCTPort;
     tempValue= ui->m_SendCTPort->text();
     dec=tempValue.toULong(&ok,10);
     LocalCTSock_1.PortSend=dec;
     tempValue.clear();
     //LocalCTSock_1.PortSend = m_SendCTPort;


     tempValue=ui->m_LocaltoCT_IP2->text();

     LocalCTSock_2.IPAdd.sin_addr.s_addr = inet_addr(tempValue.toAscii());
     tempValue.clear();
     //m_LocaltoCT_IP2.GetAddress(tempValue);
     //LocalCTSock_2.IPAdd.sin_addr.S_un.S_addr = htonl(tempValue);
     tempValue= ui->m_RecvCTPort->text();
     dec=tempValue.toULong(&ok,10);
     LocalCTSock_2.PortReceive=dec;
     tempValue.clear();
     //LocalCTSock_2.PortReceive = m_RecvCTPort;
     tempValue= ui->m_SendCTPort->text();
     dec=tempValue.toULong(&ok,10);
     LocalCTSock_2.PortSend=dec;
     tempValue.clear();
    // LocalCTSock_2.PortSend = m_SendCTPort;


     CTP2PNum=ui->m_AddList1->rowCount();
     CTP2PSet.resize(CTP2PNum);
     for(tempCTCounter=0; tempCTCounter<CTP2PNum; tempCTCounter++)//第1次循环保存到数组中
     {
         QTableWidgetItem *item1 = new QTableWidgetItem();
         QTableWidgetItem *item2= new QTableWidgetItem();

         tempName=QString(ui->m_RecvCTPort->text());//.Format("%d", m_RecvCTPort);???????????????????????????改的对不对？？？？
         item1->setText(tempName);
         ui->m_AddList1->setItem(tempCTCounter, 1, item1);
         tempValue.clear();
         //m_AddList1.SetItemText(tempCTCounter,1,tempName);
         tempName=QString(ui->m_SendCTPort->text());//.Format("%d", m_SendCTPort);
         item2->setText(tempName);
         ui->m_AddList1->setItem(tempCTCounter, 2, item2);
         tempValue.clear();
         //m_AddList1.SetItemText(tempCTCounter,2,tempName);//先更新端口

         QString t_str0=ui->m_AddList1->item(tempCTCounter,0)->text();// m_AddList1.GetItemText(tempCTCounter, 0);//IP
 //		QString t_str1 = ui->m_AddList1->item(tempCTCounter,1)->text();//m_AddList1->GetItemText(tempCTCounter, 1);//RecvPort
 //		QString t_str2 = ui->m_AddList1->item(tempCTCounter,2)->text();//m_AddList1->GetItemText(tempCTCounter, 2);//SendPort
         QString t_str3 =ui->m_AddList1->item(tempCTCounter,3)->text();// m_AddList1.GetItemText(tempCTCounter, 3);//Name
         QString t_str4 =ui->m_AddList1->item(tempCTCounter,4)->text();// m_AddList1.GetItemText(tempCTCounter, 4);//DID
         QString t_str5 =ui->m_AddList1->item(tempCTCounter,5)->text();// m_AddList1.GetItemText(tempCTCounter, 5);//Way

         CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr = inet_addr(t_str0.toAscii());

         tempValue= ui->m_RecvCTPort->text();
         dec=tempValue.toULong(&ok,10);
         CTP2PSet[tempCTCounter].PortReceive=dec;
         tempValue.clear();
         //CTP2PSet[tempCTCounter].PortReceive = m_RecvCTPort;
         tempValue= ui->m_SendCTPort->text();
         dec=tempValue.toULong(&ok,10);
         CTP2PSet[tempCTCounter].PortSend=dec;
         tempValue.clear();
         //CTP2PSet[tempCTCounter].PortSend = m_SendCTPort;

         memcpy(CTP2PSet[tempCTCounter].Name, t_str3.toLocal8Bit(), strlen(t_str3.toLocal8Bit()));
         CTP2PSet[tempCTCounter].Name[strlen(t_str3.toLocal8Bit())] = '\0';

         tmp =CharToHex(t_str4);
         memcpy(CTP2PSet[tempCTCounter].DID, &tmp, 4);
         CTP2PSet[tempCTCounter].WayChose = atoi(t_str5.toAscii()) -1;
     }


     CTMulNumRe=ui->m_Addlist2_1->rowCount();
     //CTMulNumRe = m_Addlist2_1.GetItemCount();
     CTMulSetRe.resize(CTMulNumRe);//?????????????????????????????????????????????????????????转换的对不对？？？
     //CTMulSetRe.SetSize(CTMulNumRe);
     for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)//第1次循环保存到数组中
     {
         QTableWidgetItem *item3 = new QTableWidgetItem();
         QTableWidgetItem *item4= new QTableWidgetItem();

         tempName=QString(ui->m_RecvCTPort->text());//.Format("%d", m_RecvCTPort);???????????????????????????改的对不对？？？？
         item3->setText(tempName);
         ui->m_Addlist2_1->setItem(tempCTCounter, 1, item3);
         tempValue.clear();
         //m_Addlist2_1.SetItemText(tempCTCounter,1,tempName);
         tempName=QString(ui->m_SendCTPort->text());//.Format("%d", m_SendCTPort);
         item4->setText(tempName);
         ui->m_Addlist2_1->setItem(tempCTCounter, 2, item4);
         tempValue.clear();
         //m_Addlist2_1.SetItemText(tempCTCounter,2,tempName);//先更新端口

         QString t_str0=ui->m_Addlist2_1->item(tempCTCounter,0)->text();// m_Addlist2_1.GetItemText(tempCTCounter, 0);//IP
 //		QString t_str1 = ui->m_Addlist2_1->item(tempCTCounter,1)->text();//m_Addlist2_1->GetItemText(tempCTCounter, 1);//RecvPort
 //		QString t_str2 = ui->m_Addlist2_1->item(tempCTCounter,2)->text();//m_Addlist2_1->GetItemText(tempCTCounter, 2);//SendPort
         QString t_str3 =ui->m_Addlist2_1->item(tempCTCounter,3)->text();// m_Addlist2_1.GetItemText(tempCTCounter, 3);//Name
         QString t_str4 =ui->m_Addlist2_1->item(tempCTCounter,4)->text();// m_Addlist2_1.GetItemText(tempCTCounter, 4);//DID
         QString t_str5 =ui->m_Addlist2_1->item(tempCTCounter,5)->text();// m_Addlist2_1.GetItemText(tempCTCounter, 5);//Way

         CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr = inet_addr(t_str0.toAscii());

         tempValue= ui->m_RecvCTPort->text();
         dec=tempValue.toULong(&ok,10);
         CTMulSetRe[tempCTCounter].PortReceive=dec;
         tempValue.clear();
         //CTMulSetRe[tempCTCounter].PortReceive = m_RecvCTPort;
         tempValue= ui->m_SendCTPort->text();
         dec=tempValue.toULong(&ok,10);
         CTMulSetRe[tempCTCounter].PortSend=dec;
         tempValue.clear();
         //CTMulSetRe[tempCTCounter].PortSend = m_SendCTPort;

         memcpy(CTMulSetRe[tempCTCounter].Name, t_str3.toLocal8Bit(), strlen(t_str3.toLocal8Bit()));
         CTMulSetRe[tempCTCounter].Name[strlen(t_str3.toLocal8Bit())] = '\0';

         tmp =CharToHex(t_str4);
         memcpy(CTMulSetRe[tempCTCounter].DID, &tmp, 4);
         CTMulSetRe[tempCTCounter].WayChose = atoi(t_str5.toAscii()) -1;
     }



 /*    CTMulNumRe = m_Addlist2_1.GetItemCount();
     CTMulSetRe.SetSize(CTMulNumRe);
     for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)//第2次循环保存到数组中
     {
         tempName.Format("%d", m_RecvCTPort);
         m_Addlist2_1.SetItemText(tempCTCounter,1,tempName);
         tempName.Format("%d", m_SendCTPort);
         m_Addlist2_1.SetItemText(tempCTCounter,2,tempName);//先更新端口

         QString t_str0 = m_Addlist2_1.GetItemText(tempCTCounter, 0);//IP
         //		QString t_str1 = m_AddList2->GetItemText(tempCTCounter, 1);//RecvPort
         //		QString t_str2 = m_AddList2->GetItemText(tempCTCounter, 2);//SendPort
         QString t_str3 = m_Addlist2_1.GetItemText(tempCTCounter, 3);//Name
         QString t_str4 = m_Addlist2_1.GetItemText(tempCTCounter, 4);//DID
         QString t_str5 = m_Addlist2_1.GetItemText(tempCTCounter, 5);//Way

         CTMulSetRe[tempCTCounter].IPAdd.sin_addr.S_un.S_addr = inet_addr(t_str0);
         CTMulSetRe[tempCTCounter].PortReceive = m_RecvCTPort;
         CTMulSetRe[tempCTCounter].PortSend = m_SendCTPort;
         memcpy(CTMulSetRe[tempCTCounter].Name, (LPCSTR)t_str3, t_str3.GetLength());
         CTMulSetRe[tempCTCounter].Name[t_str3.GetLength()] = '\0';
         tempValue =CharToHex(t_str4);
         memcpy(CTMulSetRe[tempCTCounter].DID, &tempValue, 4);
         CTMulSetRe[tempCTCounter].WayChose = atoi(t_str5) -1;
     }
*/
     CTMulNumSe=ui->m_Addlist2_2->rowCount();
     CTMulSetSe.resize(CTMulNumSe);
     for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)//第1次循环保存到数组中
     {
         QTableWidgetItem *item5 = new QTableWidgetItem();
         QTableWidgetItem *item6= new QTableWidgetItem();

         tempName=QString(ui->m_RecvCTPort->text());//.Format("%d", m_RecvCTPort);???????????????????????????改的对不对？？？？
         item5->setText(tempName);
         ui->m_Addlist2_2->setItem(tempCTCounter, 1, item5);
         tempValue.clear();
         //m_Addlist2_2.SetItemText(tempCTCounter,1,tempName);
         tempName=QString(ui->m_SendCTPort->text());//.Format("%d", m_SendCTPort);
         item6->setText(tempName);
         ui->m_Addlist2_2->setItem(tempCTCounter, 2, item6);
         tempValue.clear();
         //m_Addlist2_2.SetItemText(tempCTCounter,2,tempName);//先更新端口

         QString t_str0=ui->m_Addlist2_2->item(tempCTCounter,0)->text();// m_Addlist2_2.GetItemText(tempCTCounter, 0);//IP
 //		QString t_str1 = ui->m_Addlist2_2->item(tempCTCounter,1)->text();//m_Addlist2_2->GetItemText(tempCTCounter, 1);//RecvPort
 //		QString t_str2 = ui->m_Addlist2_2->item(tempCTCounter,2)->text();//m_Addlist2_2->GetItemText(tempCTCounter, 2);//SendPort
         QString t_str3 =ui->m_Addlist2_2->item(tempCTCounter,3)->text();// m_Addlist2_2.GetItemText(tempCTCounter, 3);//Name
         QString t_str4 =ui->m_Addlist2_2->item(tempCTCounter,4)->text();// m_Addlist2_2.GetItemText(tempCTCounter, 4);//DID
         QString t_str5 =ui->m_Addlist2_2->item(tempCTCounter,5)->text();// m_Addlist2_2.GetItemText(tempCTCounter, 5);//Way

         CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr = inet_addr(t_str0.toAscii());

         tempValue= ui->m_RecvCTPort->text();
         dec=tempValue.toULong(&ok,10);
         CTMulSetSe[tempCTCounter].PortReceive=dec;
         tempValue.clear();
         //CTMulSetSe[tempCTCounter].PortReceive = m_RecvCTPort;
         tempValue= ui->m_SendCTPort->text();
         dec=tempValue.toULong(&ok,10);
         CTMulSetSe[tempCTCounter].PortSend=dec;
         tempValue.clear();
         //CTMulSetSe[tempCTCounter].PortSend = m_SendCTPort;

         memcpy(CTMulSetSe[tempCTCounter].Name, t_str3.toLocal8Bit(), strlen(t_str3.toLocal8Bit()));
         CTMulSetSe[tempCTCounter].Name[strlen(t_str3.toLocal8Bit())] = '\0';

         tmp =CharToHex(t_str4);
         memcpy(CTMulSetSe[tempCTCounter].DID, &tmp, 4);
         CTMulSetSe[tempCTCounter].WayChose = atoi(t_str5.toAscii()) -1;
     }

 /*    CTMulNumSe = m_Addlist2_2.GetItemCount();
     CTMulSetSe.SetSize(CTMulNumSe);
     for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)//第2次循环保存到数组中
     {
         tempName.Format("%d", m_RecvCTPort);
         m_Addlist2_2.SetItemText(tempCTCounter,1,tempName);
         tempName.Format("%d", m_SendCTPort);
         m_Addlist2_2.SetItemText(tempCTCounter,2,tempName);//先更新端口

         QString t_str0 = m_Addlist2_2.GetItemText(tempCTCounter, 0);//IP
         //		QString t_str1 = m_AddList2->GetItemText(tempCTCounter, 1);//RecvPort
         //		QString t_str2 = m_AddList2->GetItemText(tempCTCounter, 2);//SendPort
         QString t_str3 = m_Addlist2_2.GetItemText(tempCTCounter, 3);//Name
         QString t_str4 = m_Addlist2_2.GetItemText(tempCTCounter, 4);//DID
         QString t_str5 = m_Addlist2_2.GetItemText(tempCTCounter, 5);//Way

         CTMulSetSe[tempCTCounter].IPAdd.sin_addr.S_un.S_addr = inet_addr(t_str0);
         CTMulSetSe[tempCTCounter].PortReceive = m_RecvCTPort;
         CTMulSetSe[tempCTCounter].PortSend = m_SendCTPort;
         memcpy(CTMulSetSe[tempCTCounter].Name, (LPCSTR)t_str3, t_str3.GetLength());
         CTMulSetSe[tempCTCounter].Name[t_str3.GetLength()] = '\0';
         tempValue =CharToHex(t_str4);
         memcpy(CTMulSetSe[tempCTCounter].DID, &tempValue, 4);
         CTMulSetSe[tempCTCounter].WayChose = atoi(t_str5) -1;
     }
  */
 //HEADER设置
     HEADERStruct HEADER;

     tmp =CharToHex(ui->m_stVersion->text());//不得超过4byte
     memcpy(&(MeasureHEADER.v_Version), &tmp, 1);
     memcpy(&(TimerSendHEADER.v_Version), &tmp, 1);
     memcpy(&(TimerRecvHEADER.v_Version), &tmp, 1);
     memcpy(&(ExamSendHEADER.v_Version), &tmp, 1);
     memcpy(&(ExamRecvHEADER.v_Version), &tmp, 1);
     memcpy(&(T0HEADER.v_Version), &tmp, 1);
     for(int tem_I=0; tem_I<30; tem_I++)
     {
         memcpy(&(WYDHEADER[tem_I].v_Version), &tmp, 1);
     }
 /*
     memcpy(&(WYDHEADER1.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER2.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER3.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER4.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER5.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER6.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER7.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER8.v_Version), &tempValue, 1);
     memcpy(&(WYDHEADER9.v_Version), &tempValue, 1);
 */

     tmp =CharToHex(ui->m__stMID->text());//不得超过4byte
     memcpy(&(MeasureHEADER.v_SP1), &tmp, 2);
     memcpy(&(ExamSendHEADER.v_SP1), &tmp, 2);
     memcpy(&(ExamRecvHEADER.v_SP1), &tmp, 2);
     memcpy(&(T0HEADER.v_SP1), &tmp, 2);
     for(int tem_I=0; tem_I<30; tem_I++)
     {
         memcpy(&(WYDHEADER[tem_I].v_SP1), &tmp, 2);
     }
 /*
     memcpy(&(WYDHEADER1.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER2.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER3.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER4.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER5.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER6.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER7.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER8.v_SP1), &tempValue, 2);
     memcpy(&(WYDHEADER9.v_SP1), &tempValue, 2);
 */
     tmp =CharToHex(ui->m_stMID_T->text());//不得超过4byte
     memcpy(&(TimerSendHEADER.v_SP1), &tmp, 2);
     memcpy(&(TimerRecvHEADER.v_SP1), &tmp, 2);

     tmp =CharToHex(ui->m_stSID->text());//不得超过4byte
     memcpy(&(MeasureHEADER.v_SP2), &tmp, 4);
     memcpy(&(TimerSendHEADER.v_SP2), &tmp, 4);
     memcpy(&(TimerRecvHEADER.v_SP3), &tmp, 4);
     memcpy(&(ExamSendHEADER.v_SP2), &tmp, 4);
     memcpy(&(ExamRecvHEADER.v_SP3), &tmp, 4);
     memcpy(&(T0HEADER.v_SP3), &tmp, 4);
     for(int tem_I=0; tem_I<30; tem_I++)
     {
         memcpy(&(WYDHEADER[tem_I].v_SP3), &tmp, 4);
     }
 /*
     memcpy(&(WYDHEADER1.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER2.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER3.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER4.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER5.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER6.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER7.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER8.v_SP3), &tempValue, 4);
     memcpy(&(WYDHEADER9.v_SP3), &tempValue, 4);
 */
     tmp =CharToHex(ui->m_stDID->text());//不得超过4byte
     memcpy(&(MeasureHEADER.v_SP3), &tmp, 4);
     memcpy(&(TimerSendHEADER.v_SP3), &tmp, 4);
     memcpy(&(TimerRecvHEADER.v_SP2), &tmp, 4);
     memcpy(&(ExamSendHEADER.v_SP3), &tmp, 4);
     memcpy(&(ExamRecvHEADER.v_SP2), &tmp, 4);
     memcpy(&(T0HEADER.v_SP2), &tmp, 4);
     for(int tem_I=0; tem_I<30; tem_I++)
     {
         memcpy(&(WYDHEADER[tem_I].v_SP2), &tmp, 4);
     }
 /*
     memcpy(&(WYDHEADER1.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER2.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER3.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER4.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER5.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER6.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER7.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER8.v_SP2), &tempValue, 4);
     memcpy(&(WYDHEADER9.v_SP2), &tempValue, 4);
 */
     tmp =CharToHex(ui->m__stBIDExam->text());//不得超过4byte
     memcpy(&(ExamSendHEADER.v_SP4), &tmp, 4);
     memcpy(&(ExamRecvHEADER.v_SP4), &tmp, 4);

     tmp =CharToHex(ui->m_stBIDMeasure->text());//不得超过4byte
     memcpy(&(MeasureHEADER.v_SP4), &tmp, 4);

     tmp =CharToHex(ui->m__stBIDTO->text());//不得超过4byte
     memcpy(&(T0HEADER.v_SP4), &tmp, 4);

     tmp =CharToHex(ui->m_stBIDTimer->text());//不得超过4byte
     memcpy(&(TimerSendHEADER.v_SP4), &tmp, 4);
     memcpy(&(TimerRecvHEADER.v_SP4), &tmp, 4);

     tmp =CharToHex(ui->m_stBIDWyd1->text());//不得超过4byte
     memcpy(&(WYDHEADER[0].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd2->text());//不得超过4byte
     memcpy(&(WYDHEADER[1].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd3->text());//不得超过4byte
     memcpy(&(WYDHEADER[2].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd4->text());//不得超过4byte
     memcpy(&(WYDHEADER[3].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd5->text());//不得超过4byte
     memcpy(&(WYDHEADER[4].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd6->text());//不得超过4byte
     memcpy(&(WYDHEADER[5].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd7->text());//不得超过4byte
     memcpy(&(WYDHEADER[6].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd8->text());//不得超过4byte
     memcpy(&(WYDHEADER[7].v_SP4), &tmp, 4);
     tmp =CharToHex(ui->m_stBIDWyd9->text());//不得超过4byte
     memcpy(&(WYDHEADER[8].v_SP4), &tmp, 4);

 //其它设置
     DataSavePath =ui->m_DataSavePath->currentText();

     EjectPosL = atof(str_EjectL.toAscii());
     EjectPosB = atof(str_EjectB.toAscii());
     EjectPosH = atof(str_EjectH.toAscii());
     EjectAngle = atof(str_EjectAngle.toAscii());

     //?？？？？？？？？？？？？？？？？？？？？？？？？？对不对？？？？？？？？？？？？？？？？？
     if(ui->m_TimeSource->isChecked())
         TimeSource = Time_GPS;
     else if(ui->m_TimeSource2->isChecked())
         TimeSource = Time_AC;
     else if(ui->m_TimeSource3->isChecked())
         TimeSource = Time_Local;
     else
         TimeSource = Time_GPS;

     if(ui->m_SendSocketTP->isChecked())
         SendSocketTP=Socket_Udp;
     if(ui->m_SendSocketTP2->isChecked())
           SendSocketTP=Socket_Multicast_ASM;
     if(ui->m_SendSocketTP3->isChecked())
         SendSocketTP=Socket_Multicast_SSM;
     //SendSocketTP = (Sockettp)m_SendSocketTP;

     if(ui->m_RecvSocketTP->isChecked())
         RecvSocketTP=Socket_Udp;
     if(ui->m_RecvSocketTP2->isChecked())
           RecvSocketTP=Socket_Multicast_ASM;
     if(ui->m_RecvSocketTP3->isChecked())
         RecvSocketTP=Socket_Multicast_SSM;

     //RecvSocketTP = (Sockettp)m_RecvSocketTP;

     //::PostMessage(theApp.m_pMainWnd->m_hWnd, wmuserapply, NULL, NULL);
     emit wmuserapply();
}



/**********************************************************/
 /*取消
  */
/**********************************************************/
void commu::OnSetupCancel()
{
     qDebug("OnSetupCancel");

     int tempCTCounter = 0;
     int byteCounter = 0;
     int count=0;
     DWORD tempValue = 0;
     //ui->m_AddList1->clear();
     count=ui->m_AddList1->rowCount();
     while(count>=0)
     {

         ui->m_AddList1->removeRow(count);
         count--;
     }

     //ui->m_Addlist2_1->clear();//.DeleteAllItems();
     count=ui->m_Addlist2_1->rowCount();
     while(count>=0)
     {

         ui->m_Addlist2_1->removeRow(count);
         count--;
     }
     //ui->m_Addlist2_2->clear();//.DeleteAllItems();
     count=ui->m_Addlist2_2->rowCount();
     while(count>=0)
     {

         ui->m_Addlist2_2->removeRow(count);
         count--;
     }


     for(tempCTCounter=0; tempCTCounter<CTP2PNum; tempCTCounter++)
     {
         int NewItem;
         QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;

         s_IP=QString("%1.%2.%3.%4").arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff)
                                    .arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff)
                                     .arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff)
                                      .arg((CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff)

         //.Format("%d.%d.%d.%d", CTP2PSet[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b1,
                             ,
         //s_ReceivePort=QString("%1").arg(CTP2PSet[tempCTCounter].PortReceive,0,10);//.Format("%.5d", CTP2PSet[tempCTCounter].PortReceive);
         s_ReceivePort.sprintf("%.5d",CTP2PSet[tempCTCounter].PortReceive);
         s_SendPort.sprintf("%.5d",CTP2PSet[tempCTCounter].PortSend);
        // s_SendPort=QString("%1").arg(CTP2PSet[tempCTCounter].PortSend,0,10);//.Format("%.5d", CTP2PSet[tempCTCounter].PortSend);
         s_Way=QString("%1路").arg(CTP2PSet[tempCTCounter].WayChose+1,0,10);//.Format("%d路", CTP2PSet[tempCTCounter].WayChose+1);

         for(byteCounter=0; byteCounter<4; byteCounter++)
         {
             int temp_Char = (BYTE)(CTP2PSet[tempCTCounter].DID[3-byteCounter]);
             QString TempMessage;
             TempMessage.sprintf("%.2x",temp_Char);
             s_DID+=TempMessage;
         }
         s_Name =QString(CTP2PSet[tempCTCounter].Name);
           //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
         int row_count = ui->m_AddList1->rowCount(); //获取表单行数
         ui->m_AddList1->insertRow(row_count); //插入新行
         QTableWidgetItem *item1 = new QTableWidgetItem();
         item1->setText(s_IP);
         ui->m_AddList1->setItem(row_count, 0, item1);

         QTableWidgetItem *item2 = new QTableWidgetItem();
         item2->setText(s_ReceivePort);
         ui->m_AddList1->setItem(row_count, 1, item2);

         QTableWidgetItem *item3 = new QTableWidgetItem();
         item3->setText(s_SendPort);
         ui->m_AddList1->setItem(row_count, 2, item3);

         QTableWidgetItem *item4 = new QTableWidgetItem();
         item4->setText(s_Name);
         ui->m_AddList1->setItem(row_count, 3, item4);

         QTableWidgetItem *item5 = new QTableWidgetItem();
         item5->setText(s_DID);
         ui->m_AddList1->setItem(row_count, 4, item5);

         QTableWidgetItem *item6 = new QTableWidgetItem();
         item6->setText(s_Way);
         ui->m_AddList1->setItem(row_count,5, item6);

     }

     for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)
     {
         int NewItem;
         QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;
         BYTE* pIP = (BYTE*)&(CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr);
         s_IP=QString("%1.%2.%3.%4").arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff)
                                    .arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff)
                                     .arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff)
                                      .arg((CTMulSetRe[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff)

         //.Format("%d.%d.%d.%d", CTMulSetRe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b1,
                             ,
         s_ReceivePort.sprintf("%.5d",CTMulSetRe[tempCTCounter].PortReceive);
         s_SendPort.sprintf("%.5d",CTMulSetRe[tempCTCounter].PortSend);
         //s_ReceivePort=QString("%1").arg(CTMulSetRe[tempCTCounter].PortReceive,0,10);//.Format("%.5d", CTMulSetRe[tempCTCounter].PortReceive);
         //s_SendPort=QString("%1").arg(CTMulSetRe[tempCTCounter].PortSend,0,10);//.Format("%.5d", CTMulSetRe[tempCTCounter].PortSend);
         s_Way=QString("%1路").arg(CTMulSetRe[tempCTCounter].WayChose+1,0,10);//.Format("%d路", CTMulSetRe[tempCTCounter].WayChose+1);

         for(byteCounter=0; byteCounter<4; byteCounter++)
         {
             int temp_Char = (BYTE)(CTMulSetRe[tempCTCounter].DID[3-byteCounter]);
             QString TempMessage;
             TempMessage.sprintf("%.2x",temp_Char);
             //TempMessage=QString("%1").arg(temp_Char,0,10);//.Format("%.2x", temp_Char);
             s_DID+=TempMessage;
         }
         s_Name =QString( CTMulSetRe[tempCTCounter].Name);
           //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
         int row_count = ui->m_Addlist2_1->rowCount(); //获取表单行数
         ui->m_Addlist2_1->insertRow(row_count); //插入新行
         QTableWidgetItem *item7= new QTableWidgetItem();
         item7->setText(s_IP);
         ui->m_Addlist2_1->setItem(row_count, 0, item7);

         QTableWidgetItem *item8= new QTableWidgetItem();
         item8->setText(s_ReceivePort);
         ui->m_Addlist2_1->setItem(row_count, 1, item8);

         QTableWidgetItem *item9= new QTableWidgetItem();
         item9->setText(s_SendPort);
         ui->m_Addlist2_1->setItem(row_count, 2, item9);

         QTableWidgetItem *item10 = new QTableWidgetItem();
         item10->setText(s_Name);
         ui->m_Addlist2_1->setItem(row_count, 3, item10);

         QTableWidgetItem *item11 = new QTableWidgetItem();
         item11->setText(s_DID);
         ui->m_Addlist2_1->setItem(row_count, 4, item11);

         QTableWidgetItem *item12 = new QTableWidgetItem();
         item12->setText(s_Way);
         ui->m_Addlist2_1->setItem(row_count,5, item12);
     }

     for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)
     {
         int NewItem;
         QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;
         BYTE* pIP = (BYTE*)&(CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr);
         s_IP=QString("%1.%2.%3.%4").arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr)&0xff)
                                    .arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>8)&0xff)
                                     .arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>16)&0xff)
                                      .arg((CTMulSetSe[tempCTCounter].IPAdd.sin_addr.s_addr>>24)&0xff)

         //.Format("%d.%d.%d.%d", CTMulSetSe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b1,
                             ,
         s_ReceivePort.sprintf("%.5d",CTMulSetSe[tempCTCounter].PortReceive);
         s_SendPort.sprintf("%.5d",CTMulSetSe[tempCTCounter].PortSend);
         //s_ReceivePort=QString("%1").arg(CTMulSetSe[tempCTCounter].PortReceive,0,10);//.Format("%.5d", CTMulSetSe[tempCTCounter].PortReceive);
         //s_SendPort=QString("%1").arg(CTMulSetSe[tempCTCounter].PortSend,0,10);//.Format("%.5d", CTMulSetSe[tempCTCounter].PortSend);
         s_Way=QString("%1路").arg(CTMulSetSe[tempCTCounter].WayChose+1,0,10);//.Format("%d路", CTMulSetSe[tempCTCounter].WayChose+1);

         for(byteCounter=0; byteCounter<4; byteCounter++)
         {
             int temp_Char = (BYTE)(CTMulSetSe[tempCTCounter].DID[3-byteCounter]);
             QString TempMessage;
             TempMessage.sprintf("%.2x",temp_Char);
             //TempMessage=QString("%1").arg(temp_Char,0,10);//.Format("%.2x", temp_Char);
             s_DID+=TempMessage;
         }
         s_Name=QString(CTMulSetSe[tempCTCounter].Name);
           //treewidget插入????????????????????????????????????????????????????????????????????????????????????????????????
         int row_count = ui->m_Addlist2_2->rowCount(); //获取表单行数
         ui->m_Addlist2_2->insertRow(row_count); //插入新行
         QTableWidgetItem *item13 = new QTableWidgetItem();
         item13->setText(s_IP);
         ui->m_Addlist2_2->setItem(row_count, 0, item13);

         QTableWidgetItem *item14 = new QTableWidgetItem();
         item14->setText(s_ReceivePort);
         ui->m_Addlist2_2->setItem(row_count, 1, item14);

         QTableWidgetItem *item15 = new QTableWidgetItem();
         item15->setText(s_SendPort);
         ui->m_Addlist2_2->setItem(row_count, 2, item15);

         QTableWidgetItem *item16 = new QTableWidgetItem();
         item16->setText(s_Name);
         ui->m_Addlist2_2->setItem(row_count, 3, item16);

         QTableWidgetItem *item17= new QTableWidgetItem();
         item17->setText(s_DID);
         ui->m_Addlist2_2->setItem(row_count, 4, item17);

         QTableWidgetItem *item18 = new QTableWidgetItem();
         item18->setText(s_Way);
         ui->m_Addlist2_2->setItem(row_count,5, item18);
     }





     //？？？？？？？？？？？？？？？？？？？？？对不对??????????????????????????????????????????
     QString IPAD;
     DWORD temp_DWORD;
     char IP[4];

     temp_DWORD = ntohl(LocalZKSock.IPAdd.sin_addr.s_addr);//????????????????????????????
     //IP地址转换：DWORD->IP
     DWORD temp_mid;
   if(temp_DWORD)
   {
     temp_mid=temp_DWORD;
     IP[0]=temp_mid>>24;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x00ffffff;
     IP[1]=temp_mid>>16;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x0000ffff;
     IP[2]=temp_mid>>8;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x000000ff;
     IP[3]=temp_mid;
     IPAD=QString(IP[0]);
     IPAD+=".";
     IPAD+=IP[1];
     IPAD+=".";
     IPAD+=IP[2];
     IPAD+=".";
     IPAD+=IP[3];
}
   else IPAD.clear();
     ui->m_LocaltoZK_IP->setText(IPAD);//???????????????/
     temp_DWORD = ntohl(LocalCTSock_1.IPAdd.sin_addr.s_addr);//？
   if(temp_DWORD)
   {
     temp_mid=temp_DWORD;
     IP[0]=temp_mid>>24;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x00ffffff;
     IP[1]=temp_mid>>16;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x0000ffff;
     IP[2]=temp_mid>>8;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x000000ff;
     IP[3]=temp_mid;
     IPAD=QString(IP[0]);
     IPAD+=".";
     IPAD+=IP[1];
     IPAD+=".";
     IPAD+=IP[2];
     IPAD+=".";
     IPAD+=IP[3];
}
   else IPAD.clear();
     ui->m_LocaltoCT_IP1->setText(IPAD);//???????????????/

     temp_DWORD = ntohl(LocalCTSock_2.IPAdd.sin_addr.s_addr);//?
   if(temp_DWORD)
   {
     temp_mid=temp_DWORD;
     IP[0]=temp_mid>>24;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x00ffffff;
     IP[1]=temp_mid>>16;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x0000ffff;
     IP[2]=temp_mid>>8;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x000000ff;
     IP[3]=temp_mid;
     IPAD=QString(IP[0]);
     IPAD+=".";
     IPAD+=IP[1];
     IPAD+=".";
     IPAD+=IP[2];
     IPAD+=".";
     IPAD+=IP[3];
   }
   else IPAD.clear();
     ui->m_LocaltoCT_IP2->setText(IPAD);//IP框

     QString dec;
     dec=QString("%1").arg(LocalCTSock_1.PortReceive,0,10);
     ui->m_RecvCTPort->setText(dec);// = LocalCTSock_1.PortReceive;

     dec=QString("%1").arg(LocalCTSock_1.PortSend,0,10);
     ui->m_SendCTPort->setText(dec); //= LocalCTSock_1.PortSend;

     temp_DWORD = ntohl(ZKSock.IPAdd.sin_addr.s_addr);//?//???
   if(temp_DWORD)
   {
     temp_mid=temp_DWORD;
     IP[0]=temp_mid>>24;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x00ffffff;
     IP[1]=temp_mid>>16;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x0000ffff;
     IP[2]=temp_mid>>8;
     temp_mid=temp_DWORD;
     temp_mid=temp_mid&0x000000ff;
     IP[3]=temp_mid;
     IPAD=QString(IP[0]);
     IPAD+=".";
     IPAD+=IP[1];
     IPAD+=".";
     IPAD+=IP[2];
     IPAD+=".";
     IPAD+=IP[3];
   }
   else IPAD.clear();
     ui->m_ZKIP->setText(IPAD);//IP框

     //m_ZKIP.SetAddress(temp_DWORD);///??????

     dec=QString("%1").arg(LocalZKSock.PortReceive,0,10);
     ui->m_ZKPort->setText(dec);//= LocalZKSock.PortReceive;
     /*
     for(tempCTCounter=0; tempCTCounter<CTP2PNum; tempCTCounter++)
     {
         int NewItem;
         QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;
         s_IP.Format("%d.%d.%d.%d", CTP2PSet[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b1,
             CTP2PSet[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b2,
             CTP2PSet[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b3,
             CTP2PSet[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b4);
         s_ReceivePort.Format("%.5d", CTP2PSet[tempCTCounter].PortReceive);
         s_SendPort.Format("%.5d", CTP2PSet[tempCTCounter].PortSend);
         s_Way.Format("%d路", CTP2PSet[tempCTCounter].WayChose+1);

         for(byteCounter=0; byteCounter<4; byteCounter++)
         {
             int temp_Char = (BYTE)(CTP2PSet[tempCTCounter].DID[3-byteCounter]);
             QString TempMessage;
             TempMessage.Format("%.2x", temp_Char);
             s_DID = s_DID + TempMessage;
         }
         s_Name = CTP2PSet[tempCTCounter].Name;

         NewItem = m_AddList1.InsertItem(0xffff, (LPCSTR)s_IP);
         m_AddList1.SetItem(NewItem, 1, 1, (LPCSTR)s_ReceivePort, NULL, 0, 0, 0);
         m_AddList1.SetItem(NewItem, 2, 1, (LPCSTR)s_SendPort, NULL, 0, 0, 0);
         m_AddList1.SetItem(NewItem, 3, 1, (LPCSTR)s_Name, NULL, 0, 0, 0);
         m_AddList1.SetItem(NewItem, 4, 1, (LPCSTR)s_DID, NULL, 0, 0, 0);
         m_AddList1.SetItem(NewItem, 5, 1, (LPCSTR)s_Way, NULL, 0, 0, 0);
         m_AddList1.SetItemData (NewItem, NewItem);
     }
     m_AddList1.SetHotItem (0);
     m_AddList1.SetFocus ();

     for(tempCTCounter=0; tempCTCounter<CTMulNumRe; tempCTCounter++)
     {
         int NewItem;
         QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;
         BYTE* pIP = (BYTE*)&(CTMulSetRe[tempCTCounter].IPAdd.sin_addr.S_un.S_addr);
         s_IP.Format("%d.%d.%d.%d", CTMulSetRe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b1,
             CTMulSetRe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b2,
             CTMulSetRe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b3,
             CTMulSetRe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b4);
         s_ReceivePort.Format("%.5d", CTMulSetRe[tempCTCounter].PortReceive);
         s_SendPort.Format("%.5d", CTMulSetRe[tempCTCounter].PortSend);
         s_Way.Format("%d路", CTMulSetRe[tempCTCounter].WayChose+1);

         for(byteCounter=0; byteCounter<4; byteCounter++)
         {
             int temp_Char = (BYTE)(CTMulSetRe[tempCTCounter].DID[3-byteCounter]);
             QString TempMessage;
             TempMessage.Format("%.2x", temp_Char);
             s_DID = s_DID + TempMessage;
         }
         s_Name = CTMulSetRe[tempCTCounter].Name;

         NewItem = m_Addlist2_1.InsertItem(0xffff, (LPCSTR)s_IP);
         m_Addlist2_1.SetItem(NewItem, 1, 1, (LPCSTR)s_ReceivePort, NULL, 0, 0, 0);
         m_Addlist2_1.SetItem(NewItem, 2, 1, (LPCSTR)s_SendPort, NULL, 0, 0, 0);
         m_Addlist2_1.SetItem(NewItem, 3, 1, (LPCSTR)s_Name, NULL, 0, 0, 0);
         m_Addlist2_1.SetItem(NewItem, 4, 1, (LPCSTR)s_DID, NULL, 0, 0, 0);
         m_Addlist2_1.SetItem(NewItem, 5, 1, (LPCSTR)s_Way, NULL, 0, 0, 0);
         m_Addlist2_1.SetItemData (NewItem, NewItem);
     }
     m_Addlist2_1.SetHotItem (0);
     m_Addlist2_1.SetFocus ();//中心IP列表地址

     for(tempCTCounter=0; tempCTCounter<CTMulNumSe; tempCTCounter++)
     {
         int NewItem;
         QString s_IP, s_ReceivePort, s_SendPort, s_Name, s_DID, s_Way;
         BYTE* pIP = (BYTE*)&(CTMulSetSe[tempCTCounter].IPAdd.sin_addr.S_un.S_addr);
         s_IP.Format("%d.%d.%d.%d", CTMulSetSe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b1,
             CTMulSetSe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b2,
             CTMulSetSe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b3,
             CTMulSetSe[tempCTCounter].IPAdd.sin_addr.S_un.S_un_b.s_b4);
         s_ReceivePort.Format("%.5d", CTMulSetSe[tempCTCounter].PortReceive);
         s_SendPort.Format("%.5d", CTMulSetSe[tempCTCounter].PortSend);
         s_Way.Format("%d路", CTMulSetSe[tempCTCounter].WayChose+1);

         for(byteCounter=0; byteCounter<4; byteCounter++)
         {
             int temp_Char = (BYTE)(CTMulSetSe[tempCTCounter].DID[3-byteCounter]);
             QString TempMessage;
             TempMessage.Format("%.2x", temp_Char);
             s_DID = s_DID + TempMessage;
         }
         s_Name = CTMulSetSe[tempCTCounter].Name;

         NewItem = m_Addlist2_2.InsertItem(0xffff, (LPCSTR)s_IP);
         m_Addlist2_2.SetItem(NewItem, 1, 1, (LPCSTR)s_ReceivePort, NULL, 0, 0, 0);
         m_Addlist2_2.SetItem(NewItem, 2, 1, (LPCSTR)s_SendPort, NULL, 0, 0, 0);
         m_Addlist2_2.SetItem(NewItem, 3, 1, (LPCSTR)s_Name, NULL, 0, 0, 0);
         m_Addlist2_2.SetItem(NewItem, 4, 1, (LPCSTR)s_DID, NULL, 0, 0, 0);
         m_Addlist2_2.SetItem(NewItem, 5, 1, (LPCSTR)s_Way, NULL, 0, 0, 0);
         m_Addlist2_2.SetItemData (NewItem, NewItem);
     }
     m_Addlist2_2.SetHotItem (0);
     m_Addlist2_2.SetFocus ();//中心IP列表地址



     DWORD temp_DWORD;
     temp_DWORD = ntohl(LocalZKSock.IPAdd.sin_addr.S_un.S_addr);
     m_LocaltoZK_IP.SetAddress(temp_DWORD);
     temp_DWORD = ntohl(LocalCTSock_1.IPAdd.sin_addr.S_un.S_addr);
     m_LocaltoCT_IP1.SetAddress(temp_DWORD);
     temp_DWORD = ntohl(LocalCTSock_2.IPAdd.sin_addr.S_un.S_addr);
     m_LocaltoCT_IP2.SetAddress(temp_DWORD);//IP框
     m_RecvCTPort = LocalCTSock_1.PortReceive;
     m_SendCTPort = LocalCTSock_1.PortSend;
     temp_DWORD = ntohl(ZKSock.IPAdd.sin_addr.S_un.S_addr);
     m_ZKIP.SetAddress(temp_DWORD);
     m_ZKPort = LocalZKSock.PortReceive;*/

     QString m;

     tempValue=0;
     memcpy(&tempValue, ExamRecvHEADER.v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     ui->m__stBIDExam->setText(m);
     m.clear();//.Format("%.8x", tempValue);

     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//
     ui->m_stBIDMeasure->setText(m);
     m.clear();


     tempValue=0;
     memcpy(&tempValue, T0HEADER.v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDT0.Format("%.8x", tempValue);
     ui->m__stBIDTO->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, TimerRecvHEADER.v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);// m_stBIDTimer.Format("%.8x", tempValue);
     ui->m_stBIDTimer->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[0].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd1.Format("%.8x", tempValue);
     ui->m_stBIDWyd1->setText(m);
     m.clear();


     tempValue=0;
     memcpy(&tempValue, WYDHEADER[1].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd2.Format("%.8x", tempValue);
     ui->m_stBIDWyd2->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[2].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd3.Format("%.8x", tempValue);
     ui->m_stBIDWyd3->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[3].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd4.Format("%.8x", tempValue);
     ui->m_stBIDWyd4->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[4].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd5.Format("%.8x", tempValue);
     ui->m_stBIDWyd5->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[5].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd6.Format("%.8x", tempValue);
     ui->m_stBIDWyd6->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[6].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd7.Format("%.8x", tempValue);
     ui->m_stBIDWyd7->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[7].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd8.Format("%.8x", tempValue);
     ui->m_stBIDWyd8->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, WYDHEADER[8].v_SP4, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stBIDWyd9.Format("%.8x", tempValue);
     ui->m_stBIDWyd9->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP2, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stSID.Format("%.8x", tempValue);
     ui->m_stSID->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP3, 4);
     m.sprintf("%.8x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stDID.Format("%.8x", tempValue);
     ui->m_stDID->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, &(MeasureHEADER.v_Version), 1);
     m.sprintf("%.2x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stVersion.Format("%.2x", tempValue);
     ui->m_stVersion->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP1, 2);
     m.sprintf("%.4x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stMID.Format("%.4x", tempValue);
     ui->m__stMID->setText(m);
     m.clear();

     tempValue=0;
     memcpy(&tempValue, TimerRecvHEADER.v_SP1, 2);
     m.sprintf("%.4x",tempValue);
     //m=QString("%1").arg(tempValue,0,10);//m_stMID_T.Format("%.4x", tempValue);
     ui->m_stMID_T->setText(m);
     m.clear();

 /*    tempValue=0;
     memcpy(&tempValue, ExamRecvHEADER.v_SP4, 4);
     m_stBIDExam.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP4, 4);
     m_stBIDMeasure.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, T0HEADER.v_SP4, 4);
     m_stBIDT0.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, TimerRecvHEADER.v_SP4, 4);
     m_stBIDTimer.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[0].v_SP4, 4);
     m_stBIDWyd1.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[1].v_SP4, 4);
     m_stBIDWyd2.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[2].v_SP4, 4);
     m_stBIDWyd3.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[3].v_SP4, 4);
     m_stBIDWyd4.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[4].v_SP4, 4);
     m_stBIDWyd5.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[5].v_SP4, 4);
     m_stBIDWyd6.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[6].v_SP4, 4);
     m_stBIDWyd7.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[7].v_SP4, 4);
     m_stBIDWyd8.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, WYDHEADER[8].v_SP4, 4);
     m_stBIDWyd9.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP2, 4);
     m_stSID.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP3, 4);
     m_stDID.Format("%.8x", tempValue);
     tempValue=0;
     memcpy(&tempValue, &(MeasureHEADER.v_Version), 1);
     m_stVersion.Format("%.2x", tempValue);
     tempValue=0;
     memcpy(&tempValue, MeasureHEADER.v_SP1, 2);
     m_stMID.Format("%.4x", tempValue);
     tempValue=0;
     memcpy(&tempValue, TimerRecvHEADER.v_SP1, 2);
     m_stMID_T.Format("%.4x", tempValue);
     */





  //??????????????str_EjectB在MFC中绑定了？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
     str_EjectB.sprintf("%f",EjectPosB);//.Format("%f", EjectPosB);
     str_EjectH.sprintf("%f",EjectPosH);//.Format("%f", EjectPosH);
     str_EjectL.sprintf("%f",EjectPosL);//.Format("%f", EjectPosL);
     str_EjectAngle.sprintf("%f",EjectAngle);//.Format("%f", EjectAngle);
     ui->m_DataSavePath->addItem(DataSavePath);//在构造函数中设置了最大item为8个
     //directoryComboBox->addItem(directory);
     ui->m_DataSavePath->setCurrentIndex(ui->m_DataSavePath->findText(DataSavePath));
     if( ui->m_DataSavePath->count()>6)
     {
        ui->m_DataSavePath->removeItem(1);

     }


     switch(SendSocketTP)
     {
        case Socket_Udp:
                ui->m_SendSocketTP->setChecked(true);
                break;
        case Socket_Multicast_ASM:
                 ui->m_SendSocketTP2->setChecked(true);
                 break;
        case Socket_Multicast_SSM:
                 ui->m_SendSocketTP3->setChecked(true);
                 break;
        default:
                 break;
     }
     //ui->m_SendSocketTP = SendSocketTP;

     switch(RecvSocketTP)
     {
        case Socket_Udp:
                ui->m_RecvSocketTP->setChecked(true);
                break;
        case Socket_Multicast_ASM:
                 ui->m_RecvSocketTP2->setChecked(true);
                 break;
        case Socket_Multicast_SSM:
                 ui->m_RecvSocketTP3->setChecked(true);
                 break;
        default:
                 break;
     }
     //ui->m_RecvSocketTP = RecvSocketTP;



     switch(TimeSource)
     {
     case Time_Local:
         {
             ui->m_TimeSource->setChecked(TRUE);
             break;
         }
     case Time_ZK:
         {
         ui->m_TimeSource3->setChecked(TRUE);
             break;
         }
     case Time_GPS:
         {
             ui->m_TimeSource->setChecked(TRUE);
             break;
         }
     case Time_DC:
         {
             ui->m_TimeSource->setChecked(TRUE);
             break;
         }
     case Time_AC:
         {
             ui->m_TimeSource2->setChecked(TRUE);
             break;
         }
     default:
             ui->m_TimeSource->setChecked(TRUE);

     }
     ui->m_MeasureEnable_va->setChecked(TRUE);
     ui->m_TOEnable_va->setChecked(TRUE);
     ui->m_WYDEnable_va->setChecked(TRUE);

    // UpdateData(false);
}
