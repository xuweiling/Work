// ZKSocket.h: interface for the CZKSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZKSOCKET_H__86F9B413_BDDB_446A_A8D8_9C7E0D426A6E__INCLUDED_)
#define AFX_ZKSOCKET_H__86F9B413_BDDB_446A_A8D8_9C7E0D426A6E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "udpSocket.h"
#include "GlabalDefine.h"
#include "NetCommu.h"
#include "yfthread.h"

/************************************************************************/
/* 
主控通信类,即可用于接收,也可用于发送
                                                                     */
/************************************************************************/
class CZKSocket : public udpSocket,public YFThread
{
public:
	CZKSocket();
	virtual ~CZKSocket();

	SocketSetting LocalSet;					//Socket配置（本地）

//下面是需要由调用者查询的数据
	BYTE *pSaveBuffer;						//接收到的数据
	int pBufferLength;						//接收到的数据长度
	SocketSetting DataSource;				//收到的数据来源
	
//	bool Initial(CWnd *pParam1, int pParam2);	//建立
	bool Initial( void* pParam1);				//建立(在用)
	bool CloseConnect();						//关闭
protected:
	void *pParent;
	DWORD Counter;
	int SocketID;
#ifdef LINUXQT
    CWnd *pDialog;
#endif

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetSocket)
	public:
	BOOL Create( );							//建立Socket
	void OnReceive(int nErrorCode);
    int  SendTo(const void* lpBuf, int nBufLen, UINT nHostPort,LPCTSTR lpszHostAddress, int nFlags=0); 
	//}}AFX_VIRTUAL
    virtual void  OnReceiveThread();

};

#endif // !defined(AFX_ZKSOCKET_H__86F9B413_BDDB_446A_A8D8_9C7E0D426A6E__INCLUDED_)
