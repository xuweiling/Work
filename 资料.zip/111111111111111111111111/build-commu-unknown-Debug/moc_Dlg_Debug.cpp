/****************************************************************************
** Meta object code from reading C++ file 'Dlg_Debug.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../commu/Dlg_Debug.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Dlg_Debug.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Dlg_Debug[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      13,   11,   10,   10, 0x05,
      42,   10,   10,   10, 0x05,
      61,   10,   10,   10, 0x05,
      81,   10,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
     102,   10,   10,   10, 0x08,
     119,   10,   10,   10, 0x08,
     136,   10,   10,   10, 0x08,
     152,   10,   10,   10, 0x08,
     167,   10,   10,   10, 0x08,
     183,   10,   10,   10, 0x0a,
     211,   10,   10,   10, 0x0a,
     247,   10,   10,   10, 0x0a,
     284,   10,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Dlg_Debug[] = {
    "Dlg_Debug\0\0,\0WM_USER_STARTLOST(uint,long)\0"
    "WM_COMMANDStatus()\0WM_COMMANDStatus2()\0"
    "WM_COMMANDSendexam()\0OnButtonSendZK()\0"
    "OnButtonStopTO()\0OnButtonApply()\0"
    "OnButtonSave()\0OnDebugCancel()\0"
    "OnBnClickedDebugStartlost()\0"
    "OnBnClickedDebugCheckStatusswitch()\0"
    "OnBnClickedDebugCheckStatusswitch2()\0"
    "OnBnClickedButtonDebugSendexam()\0"
};

void Dlg_Debug::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Dlg_Debug *_t = static_cast<Dlg_Debug *>(_o);
        switch (_id) {
        case 0: _t->WM_USER_STARTLOST((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< long(*)>(_a[2]))); break;
        case 1: _t->WM_COMMANDStatus(); break;
        case 2: _t->WM_COMMANDStatus2(); break;
        case 3: _t->WM_COMMANDSendexam(); break;
        case 4: _t->OnButtonSendZK(); break;
        case 5: _t->OnButtonStopTO(); break;
        case 6: _t->OnButtonApply(); break;
        case 7: _t->OnButtonSave(); break;
        case 8: _t->OnDebugCancel(); break;
        case 9: _t->OnBnClickedDebugStartlost(); break;
        case 10: _t->OnBnClickedDebugCheckStatusswitch(); break;
        case 11: _t->OnBnClickedDebugCheckStatusswitch2(); break;
        case 12: _t->OnBnClickedButtonDebugSendexam(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Dlg_Debug::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Dlg_Debug::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Dlg_Debug,
      qt_meta_data_Dlg_Debug, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Dlg_Debug::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Dlg_Debug::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Dlg_Debug::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Dlg_Debug))
        return static_cast<void*>(const_cast< Dlg_Debug*>(this));
    return QDialog::qt_metacast(_clname);
}

int Dlg_Debug::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void Dlg_Debug::WM_USER_STARTLOST(unsigned int _t1, long _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Dlg_Debug::WM_COMMANDStatus()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void Dlg_Debug::WM_COMMANDStatus2()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void Dlg_Debug::WM_COMMANDSendexam()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}
QT_END_MOC_NAMESPACE
