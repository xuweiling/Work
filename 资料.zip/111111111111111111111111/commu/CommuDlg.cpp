﻿#include "CommuDlg.h"
#include "ui_CommuDlg.h"
#include "ui_CDlg_MsgDisplay.h"
#include "ui_commu.h"
#include "ui_Dlg_Debug.h"
#include "commu.h"
#include"Dlg_Debug.h"
#include"CDlg_MsgDisplay.h"
#include "stdafx.h"
#include "BaseFile.h"
#include <math.h>
//#include "piodio.h"
#include<QMessageBox>
#include <stdlib.h>   //exit()
//#include<unisd>   //sleep()
#include "inifile.h"
#include<QTextCodec>
#include <QCloseEvent>
 #include <QRect>
#include <QDesktopWidget>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

bool	IsTimecardExist;
DWORD	TimerCounter=0;
//=====PIO-DIO144 变量
WORD     wTotalBoard,wInitialCode;
WORD     wRetVal;
DWORD    wGetAddrBase;   // IO卡基地址
WORD     wGetIrqNo;      // IO卡中断号
WORD     wGetSubVendor,wGetSubDevice,wGetSubAux,wGetSlotBus,wGetSlotDevice;
HANDLE   hIntEvent;        // IO卡中断事件句柄//??????????????????????????????????
//DWORD    pio144Base;   // IO卡基地址
WORD     wBoardToActive;
WORD     wInterruptSource;   // IO卡中断源

#define DEB 1

DWORD CNetCommuCT::WYDCOUNT ;
DWORD CNetCommuCT::T0COUNT;
DWORD CNetCommuCT::LinkRecvCOUNT;
DWORD CNetCommuCT::LinkSendCOUNT;
DWORD CNetCommuCT::MeasureCOUNT;
DWORD CNetCommuCT::TimeExamSendCOUNT;
DWORD CNetCommuCT::TimeExamRecvCOUNT;
DWORD CNetCommuCT::ZKSendCOUNT;
DWORD CNetCommuCT::ZKRecvCOUNT;
DWORD CNetCommuCT::FZSendCOUNT;
DWORD CNetCommuCT::FZRecvCOUNT;

//////snmp test
//char BufferMibTest[MACRO_BUFFER_SIZE];
//extern CCommuDlg *Pf;

CCommuDlg::CCommuDlg(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CCommuDlg)
{
    ui->setupUi(this);

    QDesktopWidget *deskop=QApplication::desktop();
//    QRect deskop=QDesktopWidget::screenGeometry();
    int w=deskop->width();
    int h =deskop->height();
    this->resize(w,h);

    connect(ui->m_Connect,SIGNAL(clicked()),this,SLOT(OnButtonConnect()));
    connect(ui->m_Cancel,SIGNAL(clicked()),this,SLOT(OnCoCancel()));
    connect(ui->m_SendExam,SIGNAL(clicked()),this,SLOT(OnButtonSendExam()));
    connect(ui->m_StatusSwitch,SIGNAL(clicked()),this,SLOT(OnCheckStatusSwitch()));
    connect(ui->m_StatusSwitch2,SIGNAL(clicked()),this,SLOT(OnCheckStatusswitch2()));

    Timer1SecondHWND=new QTimer(this);
    Timer1Hz=new QTimer(this);
    connect(this->Timer1SecondHWND,SIGNAL(timeout()),this,SLOT(OnTimer()));
    connect(this->Timer1Hz,SIGNAL(timeout()),this,SLOT(OnTimer1Hz()));

    IsExamSending = false;
    ExamSendFreq = 20;//20Hz
    Counter20Hz = 0;
    ExamCount = 0;
    ExamSetNum1 = 0;
    ExamSetNum2 = 0;

    //建立Tab页,初始化界面
    ui->tabWidget->addTab(Dialog_MsgDisplay=new CDlg_MsgDisplay(this),tr("实时显示"));
    ui->tabWidget->addTab(Dialog_Setup=new commu(this),tr("参数设置"));
    ui->tabWidget->addTab(Dialog_Debug=new Dlg_Debug(this),"调试数据");
    ui->tabWidget->addTab(Dialog_Snmp=new YFMainWindow(this),"运管代理");
    debugui=Dialog_Debug->getui();
    msgdisplayui=Dialog_MsgDisplay->getui();
    commuui=Dialog_Setup->getui();

    TimeSource = (Dialog_Setup->TimeSource);

    //绑定消息与槽

    connect(Dialog_Debug,SIGNAL(WM_USER_STARTLOST(unsigned int,long)),this,SLOT(OnStartLostExam(unsigned int,long)));
    connect(Dialog_MsgDisplay,SIGNAL(WM_USER_CHECK_SEND1(unsigned int,long)),this,SLOT(OnCheckSend1(unsigned int,long)));
    connect(Dialog_MsgDisplay,SIGNAL(WM_USER_CHECK_SEND2(unsigned int,long)),this,SLOT(OnCheckSend2(unsigned int,long)));
    connect(Dialog_Debug,SIGNAL(WM_COMMANDStatus()),this,SLOT(OnCheckStatusSwitch()));
    connect(Dialog_Debug,SIGNAL(WM_COMMANDStatus2()),this,SLOT(OnCheckStatusswitch2()));
    connect(Dialog_Debug,SIGNAL(WM_COMMANDSendexam()),this,SLOT(OnButtonSendExam()));
    connect(&CTC_1,SIGNAL(WM_USER_RECEIVED_CT(unsigned int ,long )),this,SLOT(ReceivedCT(unsigned int,long)));
    connect(&CTC_1,SIGNAL(WM_USER_SENDED_CT(unsigned int ,long )),this,SLOT(SendedCT(uint,long)));
    connect(&CTC_2,SIGNAL(WM_USER_RECEIVED_CT(unsigned int ,long )),this,SLOT(ReceivedCT(unsigned int ,long)));
    connect(&CTC_2,SIGNAL(WM_USER_SENDED_CT(unsigned int ,long )),this,SLOT(SendedCT(uint,long)));
    connect(&ZKC,SIGNAL(WM_USER_RECEIVED_ZK(unsigned int,long)),this,SLOT(ReceivedZK(uint,long)));
    connect(&ZKC,SIGNAL(WM_USER_SENDED_ZK(unsigned int,long)),this,SLOT(SendedZK(uint,long)));
    connect(Dialog_Setup,SIGNAL(wmuserapply()),this,SLOT(ParamApply()));
    connect(Dialog_MsgDisplay,SIGNAL(WM_USER_ISHANDLE_AND_SOURCESOURCEWAYNO(bool,int)),this,SLOT(ChangeIshandleway(bool,int)));

     connect(&ZKC,SIGNAL(WM_TRANSDATA(const char*)),Dialog_Snmp,SLOT(TransData(const char*)));
    //connect(this,SIGNAL(WM_USER_1Hz(uint,long)),this,SLOT(OnTimer1Hz(uint,long)));

    ui->m_Connect->setEnabled(true);
    ui->m_Cancel->setEnabled(true);
    ui->m_StatusSwitch->setEnabled(false);
    ui->m_StatusSwitch2->setEnabled(false);
    ui->m_SendExam->setEnabled(false);
    //设置各个数据

    IsTimecardExist = true;
#ifdef CardType
    wInitialCode=PIODIO_DriverInit();//端口信息函数 在piodio.h中定义
    if( wInitialCode!=PIODIO_NoError )//在piodio.h中定义
    {
        QMessageBox msgBox;// AfxMessageBox("采集卡出错 !!");    //
        msgBox.setText("采集卡出错 !!");
        msgBox.exec();
        IsTimecardExist = false;
        *TimeSource = Time_Local;
    }
    else
    {

        // Searching how many PIO-D144 card in PC
        PIODIO_SearchCard(&wTotalBoard,PIO_D144);//在piodio.h中定义
        if( wTotalBoard==0 )
        {
            //			Beep(100,100);
            // AfxMessageBox("采集卡出错 !!");
            QMessageBox msgBox;
            msgBox.setText("采集卡出错 !!");
            msgBox.exec();
            IsTimecardExist = false;
            *TimeSource = Time_Local;
        }
        else
        {
            wRetVal=PIODIO_GetConfigAddressSpace(0, &wGetAddrBase, &wGetIrqNo,
                                                 &wGetSubVendor,&wGetSubDevice,&wGetSubAux,&wGetSlotBus,&wGetSlotDevice);//在piodio.h中定义
            if( wRetVal!=PIODIO_NoError )
            {
                QMessageBox msgBox;
                msgBox.setText("采集卡出错 !!");
                msgBox.exec();
                IsTimecardExist = false;
                *TimeSource = Time_Local;
            }
        }
    }
    if(IsTimecardExist)
    {
        PIODIO_OutputByte(wGetAddrBase, 1);  //使能IO卡端口//在piodio.h中定义
        PIODIO_OutputByte(wGetAddrBase+0xc8, 7);  //在piodio.h中定义
        PIODIO_OutputByte(wGetAddrBase+0xcc, 7);//在piodio.h中定义
        PIODIO_IntResetCount();//在piodio.h中定义
        *TimeSource = Time_AC;
    }
#else
#ifdef LINUXTIME
    wInitialCode=tcrc_open(0);//tcrclib.h中定义
#else
    wInitialCode=-1;
#endif
    if(wInitialCode!=0)
    {
        QMessageBox msgBox;
        msgBox.setText("采集卡出错 !!");
        msgBox.exec();
        IsTimecardExist = false;
        TimeSource = Time_Local;
    }
    else
    {
        // Searching how many PIO-D144 card in PC
#ifdef LINUXTIME
        tcrc_settimesource(0,0x04);//tcrclib.h中定义
#endif
        TimeSource =Time_AC;
    }
#endif
    InitDataMember();//本类中自定义的方法

    Thread20HzHWND = new CWinThread1;
    Thread1HzHWND =  new CWinThread2;
    connect(Thread20HzHWND,SIGNAL(WM_USER_20Hz(uint,long)),this,SLOT(OnTimer20Hz(uint,long)));

    QString psMessage;
    psMessage = "是否立即连接？\n(连接后不能更改网络设置)\n请确保本地网卡设置正确";
    QMessageBox msgBox;

    msgBox.setInformativeText(psMessage);
    msgBox.setStandardButtons(QMessageBox::Ok| QMessageBox::Cancel);
    msgBox.setDefaultButton(QMessageBox::Ok);
    int ret = msgBox.exec();
    switch (ret)
    {
    case QMessageBox::Ok://??????????????????????????????????????????????这样做行不行在构造函数中调用方法？？？？？？？？？？？????????????????????????????????????????????????????
        OnButtonConnect();
        break;
    case QMessageBox::Cancel:
        break;
    default:
        break;
    }

    //GetSystemMenu(false)->EnableMenuItem(SC_CLOSE, MF_GRAYED);//?????????????????????????????
    // return TRUE;  // return TRUE  unless you set the focus to a control
    ui->m_StatusSwitch->setHidden(true);
    ui->m_StatusSwitch2->setHidden(true);
    ui->m_SendExam->setHidden(true);

    isCloseClicked=false;
}

CCommuDlg::~CCommuDlg()
{
    delete ui;
}


/************************************************************************/
/*
数据初始化，
用于将所有数据自文件中读入。文件为INIFILE
无论在单播状态还是组播状态下，将所有的数据都先读入，其后在使用中再做选择
                                                                     */
/************************************************************************/
void CCommuDlg::InitDataMember()
{
    //	m_SaveFilePath = iniFilePath;
    Dialog_Setup->InitNetData();
    Dialog_Setup->InitHEADERData();
    Dialog_Setup->InitGeneralData();
    Dialog_Debug->InitDebugData();
    //	InitDebugData();
    //	InitGeneralData();

    ZKSock = &(Dialog_Setup->ZKSock);
    LocalCTSock_1 = &(Dialog_Setup->LocalCTSock_1);
    LocalCTSock_2 = &(Dialog_Setup->LocalCTSock_2);
    LocalZKSock = &(Dialog_Setup->LocalZKSock);

    INI_DATALENGTH_MEASURE	= &(Dialog_Setup->INI_DATALENGTH_MEASURE);
    INI_DATALENGTH_THEORY	= &(Dialog_Setup->INI_DATALENGTH_THEORY);
    INI_DATALENGTH_EXAM		= &(Dialog_Setup->INI_DATALENGTH_EXAM);
    INI_DATALENGTH_T0		= &(Dialog_Setup->INI_DATALENGTH_T0);
    INI_REVERSE_DATALENGTH	= &(Dialog_Setup->INI_REVERSE_DATALENGTH);
    INI_REVERSE_DATACONTENT = &(Dialog_Setup->INI_REVERSE_DATACONTENT);
    Is_ZhuKongTai			= &(Dialog_Setup->Is_ZhuKongTai);
    INI_DATALENGTH_ZK		= &(Dialog_Setup->INI_DATALENGTH_ZK);
    INI_DATALENGTH_ZXZ		= &(Dialog_Setup->INI_DATALENGTH_ZXZ);

    MeasureHEADER			= &(Dialog_Setup->MeasureHEADER);
    TimerSendHEADER		= &(Dialog_Setup->TimerSendHEADER);
    TimerRecvHEADER		= &(Dialog_Setup->TimerRecvHEADER);
    ExamSendHEADER		= &(Dialog_Setup->ExamSendHEADER);
    ExamRecvHEADER		= &(Dialog_Setup->ExamRecvHEADER);
    T0HEADER				= &(Dialog_Setup->T0HEADER);
    WYDHEADER			= Dialog_Setup->WYDHEADER;

    DebugHEADER_Measure	= &(Dialog_Debug->DebugHEADER_Measure);
    DebugHEADER_Timer		= &(Dialog_Debug->DebugHEADER_Timer);

    EjectPosL	= &(Dialog_Setup->EjectPosL);
    EjectPosB	= &(Dialog_Setup->EjectPosB);
    EjectPosH	= &(Dialog_Setup->EjectPosH);
    EjectAngle	= &(Dialog_Setup->EjectAngle);
    DataSavePath= &(Dialog_Setup->DataSavePath);
    TimeSource	= (Dialog_Setup->TimeSource);

    SendSocketTP = &(Dialog_Setup->SendSocketTP);
    RecvSocketTP = &(Dialog_Setup->RecvSocketTP);

    Global_CurrentMode = Disconnect;
    CTC_1.BufferSaveFilePath_Recv	= *DataSavePath;
    CTC_1.BufferSaveFilePath_Send	= *DataSavePath;
    CTC_1.TimeSource				= TimeSource;
    CTC_1.CurrentMode				= Global_CurrentMode;

    CTC_1.PDlg						= this;//?????????????????????????????PDlg为CWnd* 先直接拷贝过去？？？？？？？？？？？？？？

    CTC_2.BufferSaveFilePath_Recv	= *DataSavePath;
    CTC_2.BufferSaveFilePath_Send	= *DataSavePath;
    CTC_2.TimeSource				= TimeSource;
    CTC_2.CurrentMode				= Global_CurrentMode;

    CTC_2.PDlg						= this;//????????????????????????????PDlg为CWnd* 先直接拷贝过去？？？？？？？？？？？？？？？

    ZKC.BufferSaveFilePath_Recv		= *DataSavePath;
    ZKC.BufferSaveFilePath_Send		= *DataSavePath;
    ZKC.TimeSource				= TimeSource;
    ZKC.CurrentMode				= Global_CurrentMode;

    ZKC.PDlg						= this;//?????????????????????????????PDlg为CWnd* 先直接拷贝过去？？？？？？？？？？

    CNetCommuCT::WYDCOUNT = 0;
    CNetCommuCT::T0COUNT = 0;
    CNetCommuCT::LinkRecvCOUNT = 0;
    CNetCommuCT::LinkSendCOUNT = 0;
    CNetCommuCT::MeasureCOUNT = 0;
    CNetCommuCT::TimeExamSendCOUNT = 0;
    CNetCommuCT::TimeExamRecvCOUNT = 0;
    CNetCommuCT::ZKSendCOUNT = 0;
    CNetCommuCT::ZKRecvCOUNT = 0;

    CNetCommuCT::FZSendCOUNT = 0;
    CNetCommuCT::FZRecvCOUNT = 0;
}

/************************************************************************/
/*消息响应：收到监控机数据（含分站/主控台数据）
1.进行判断，是否分站/主控台 还是 监控机
2.进行判断，是那种类型格式
3.进行判断，是哪种模式。当采用了HDLC模式则只转发主控台的数据，当采用了Net模式则转发
监控机数据和含远控内容的主控台数据。
5.对于监控机的数据，可以直接触发CNetCommuZK.SendData,需要判断数据类型，
在这个函数中输入类型码type.
6.对于监控机的数据需要参考CNetCommuZK.TransCT2ZK进行解码
7.刷新界面

参数中wParam为路由，lParam标示是否需要转发
对于
1正常状态的接收T0、外引导，并转发主控，
2接收中心站的数据并转发主控
3接收时延测试并回应
4接收常时
这4种功能在这里实现，但是
1主动发送时延测试
2发送常时
3与主控发送调试数据
4与监控机发送调试数据
*/
/************************************************************************/
long CCommuDlg::ReceivedCT(unsigned int wParam, long lParam)
{
    int wayNO = (LONG)wParam;
    int newWYD = (LONG)lParam;
    int typeSource = -20;//-1:主控台;0:第一路由的监控机;1:第二路由的监控机
    int tempCTCounter=0;
    int recvLength = 0;
    DWORD BIDTest = 0;//临时变量，测试BID是否等于已指定的BID
    DWORD DIDTest = 0;//临时变量，测试DID是否等于本机的SID
    DWORD SIDTest = 0;//临时变量，测试SID是否等于本机的DID
    WORD lenTest = 0;//临时变量，测试SID是否等于本机的DID
    DWORD tempValue = 0;
    DWORD tempValue1 = 0;
    DWORD tempValue_X[30];
    int tem_I=0;
    DWORD tempValue_1 = 0;
    DWORD tempValue_DW = 0;
    int sourceNO = -1;//发送给显示窗口，表明数据来源：-1：中心站；>=0:监控机序号

    if(wayNO == 0)
    {
        memcpy(&SIDTest, CTC_1.BufferRecv_Passed+3, 4);	//得到当前帧的SID
        memcpy(&DIDTest, CTC_1.BufferRecv_Passed+7, 4);	//得到当前帧的DID
        memcpy(&lenTest, CTC_1.BufferRecv_Passed+30, 2);	//得到当前帧的DID
    }
    if(wayNO == 1)
    {
        memcpy(&SIDTest, CTC_2.BufferRecv_Passed+3, 4);	//得到当前帧的SID
        memcpy(&DIDTest, CTC_2.BufferRecv_Passed+7, 4);	//得到当前帧的DID
        memcpy(&lenTest, CTC_2.BufferRecv_Passed+30, 2);	//得到当前帧的DID
    }

    ////查找来源 1路
    if(wayNO == 0)
    {
        //查找来源
        bool isFZ=(CTC_1.DataSource.IPAdd.sin_addr.s_addr == Dialog_Setup->ZhuKongTaiSock_1.IPAdd.sin_addr.s_addr);
        for(tem_I=0; tem_I<Dialog_Setup->FZSockNum; tem_I++)
        {
            if(CTC_1.DataSource.IPAdd.sin_addr.s_addr == Dialog_Setup->FZSock1[tem_I].IPAdd.sin_addr.s_addr)
            {
                isFZ=true;
            }
        }
        if(isFZ)//来自于主控台
        {
            if(*Is_ZhuKongTai)
            {
                typeSource = -1;
            }
        }
        else
        {
            if(*RecvSocketTP == Socket_Udp)
            {
                for(tempCTCounter=0; tempCTCounter<Dialog_Setup->CTP2PNum; tempCTCounter++)
                {
                    if(CTC_1.DataSource.IPAdd.sin_addr.s_addr == Dialog_Setup->CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr)//找到对应的地址信息
                    {
                        memcpy(&tempValue1, Dialog_Setup->CTP2PSet[tempCTCounter].DID, 4);
                        if(SIDTest == tempValue1)//SID正确
                        {
                            typeSource = 0;
                            sourceNO = tempCTCounter;
                            break;
                        }
                    }
                }
                if(tempCTCounter>=Dialog_Setup->CTP2PNum) //该数据来源不正确，不予处理
                    return true;
            }
            else
            {
                //				for(tempCTCounter=0; tempCTCounter<Dialog_Setup.CTMulNum; tempCTCounter++)
                //				{
                //					if(CTC_1.DataSource.IPAdd.sin_addr.S_un.S_addr == Dialog_Setup.CTMulSet[tempCTCounter].IPAdd.sin_addr.S_un.S_addr)//找到对应的地址信息
                //					{
                memcpy(&tempValue1, Dialog_Setup->CTMulSetRe[0].DID, 4);
                if(SIDTest == tempValue1)//SID正确
                {
                    typeSource = 0;
                    sourceNO = -1;
                }
                //						break;
                //					}
                //				}
                //				if(tempCTCounter>=Dialog_Setup.CTMulNum) //该数据来源不正确，不予处理
                //					return;
            }
        }
    }

    ////查找来源 2路
    if(wayNO == 1)
    {
        //查找来源
        bool isFZ=(CTC_2.DataSource.IPAdd.sin_addr.s_addr == Dialog_Setup->ZhuKongTaiSock_2.IPAdd.sin_addr.s_addr);
        for(tem_I=0; tem_I<Dialog_Setup->FZSockNum; tem_I++)
        {
            if(CTC_2.DataSource.IPAdd.sin_addr.s_addr == Dialog_Setup->FZSock2[tem_I].IPAdd.sin_addr.s_addr)
            {
                isFZ=true;
            }
        }
        if(isFZ)//来自于主控台
        {
            if(*Is_ZhuKongTai)
            {
                typeSource = -1;
            }
        }
        else
        {
            if(*RecvSocketTP == Socket_Udp)
            {
                for(tempCTCounter=0; tempCTCounter<Dialog_Setup->CTP2PNum; tempCTCounter++)
                {
                    if(CTC_2.DataSource.IPAdd.sin_addr.s_addr == Dialog_Setup->CTP2PSet[tempCTCounter].IPAdd.sin_addr.s_addr)//找到对应的地址信息
                    {
                        memcpy(&tempValue1, Dialog_Setup->CTP2PSet[tempCTCounter].DID, 4);
                        if(SIDTest == tempValue1)//SID正确
                        {
                            typeSource = 1;
                            sourceNO = tempCTCounter;
                            break;
                        }
                    }
                }
                if(tempCTCounter>=Dialog_Setup->CTP2PNum) //该数据来源不正确，不予处理
                    return true;
            }
            else
            {
                //				for(tempCTCounter=0; tempCTCounter<Dialog_Setup.CTMulNum; tempCTCounter++)
                //				{
                //					if(CTC_2.DataSource.IPAdd.sin_addr.S_un.S_addr == Dialog_Setup.CTMulSet[tempCTCounter].IPAdd.sin_addr.S_un.S_addr)//找到对应的地址信息
                //					{
                memcpy(&tempValue1, Dialog_Setup->CTMulSetRe[0].DID, 4);
                if(SIDTest == tempValue1)//SID正确
                {
                    typeSource = 1;
                    sourceNO = -2;
                }
                //						typeSource = 1;
                //						sourceNO = -2;
                //						break;
                //					}
                //				}
                //				if(tempCTCounter>=Dialog_Setup.CTMulNum) //该数据来源不正确，不予处理
                //					return;
            }
        }
    }

    if(wayNO == 0)
    {
        memcpy(BufferRecv[wayNO], CTC_1.BufferRecv_Passed, MACRO_BUFFER_SIZE);
        recvLength = CTC_1.pBufferRecvLength;
    }
    else
    {
        memcpy(BufferRecv[wayNO], CTC_2.BufferRecv_Passed, MACRO_BUFFER_SIZE);
        recvLength = CTC_2.pBufferRecvLength;
    }


    ////获取来源之后的处理
    if(typeSource==-1)//来自于主控台
    {
        if(recvLength == *INI_DATALENGTH_ZXZ)
        {
            ZKC.SendData(BufferRecv[wayNO], recvLength, -1);
            CNetCommuCT::ZKRecvCOUNT++;
            if(CNetCommuCT::ZKRecvCOUNT>(256*256*256*255))
                CNetCommuCT::ZKRecvCOUNT = 0;
        }

        Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv[wayNO], recvLength, 9);
        //        if(recvLength == 26)
        if(recvLength == *INI_DATALENGTH_ZXZ)
        {
            BufferRecv[wayNO][18] = 0x04;
            recvLength = 19;
            ZKC.SendData(BufferRecv[wayNO], recvLength, -1);
            Dialog_MsgDisplay->TimeRecvLagCount_St = 0;

            CNetCommuCT::FZRecvCOUNT++;
            if(CNetCommuCT::FZRecvCOUNT>(256*256*256*255))
                CNetCommuCT::FZRecvCOUNT = 0;
        }
    }
    else if((typeSource==0)||(typeSource==1))//来自于监控机
    {
        memcpy(&BIDTest, ((BYTE*)BufferRecv[wayNO])+11, 4);	//得到当前帧的BID
        memcpy(&DIDTest, ((BYTE*)BufferRecv[wayNO])+7, 4);	//得到当前帧的DID
        memcpy(&tempValue, TimerSendHEADER->v_SP2, 4);

        if(DIDTest != tempValue)//DID不符,则不处理
        {

        }
        else
        {
            memcpy(&tempValue, TimerRecvHEADER->v_SP4, 4);
            ////常时 只显示，不处理
            if(BIDTest == tempValue)
            {
                if((recvLength==36)&&(lenTest==4))
                {
                    memcpy(&tempValue_DW, ((BYTE*)BufferRecv[wayNO])+sizeof(HEADERStruct), 4);
                    if(tempValue_DW<864000000)//判断时间是否超界
                    {
                        if(*RecvSocketTP == Socket_Udp)//Socket_Udp在Globaldefine.h中定义
                        {
                            Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv[wayNO], recvLength, 7);
                        }
                        else
                        {
                            Dialog_MsgDisplay->FreshMsg(-1-wayNO, BufferRecv[wayNO], recvLength, 7);//组播，则传输路由号 -1/-2
                        }

                        CNetCommuCT::LinkRecvCOUNT++;
                        if(CNetCommuCT::LinkRecvCOUNT>(256*256*256*255))
                            CNetCommuCT::LinkRecvCOUNT = 0;
                    }
                }
            }

            memcpy(&tempValue, T0HEADER->v_SP4, 4);
            ////T0 处理并显示
            if(BIDTest == tempValue)
            {
                if(   (recvLength==(*INI_DATALENGTH_T0 + sizeof(HEADERStruct))  )  &&  (lenTest==*INI_DATALENGTH_T0)    )
                {
                    memcpy(&tempValue_DW, ((BYTE*)BufferRecv[wayNO])+sizeof(HEADERStruct), 4);
                    if(tempValue_DW<864000000)//判断时间是否超界
                    {
                        if(*RecvSocketTP == Socket_Udp)
                        {
                            Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv[wayNO], recvLength, 5);
                        }
                        else
                        {
                            Dialog_MsgDisplay->FreshMsg(-1-wayNO, BufferRecv[wayNO], recvLength, 5);//组播，则传输路由号 -1/-2
                        }

                        if(commuui->m_TOEnable_va->isChecked())
                        {
                            memcpy(ZKC.BufferSend_Passed, BufferRecv[wayNO], MACRO_BUFFER_SIZE);
                            if((Global_CurrentMode==Normal) || (Global_CurrentMode==CT_Debug))//在正常状态和对上调试时都可以接收
                            {
                                if((!(*IsHandleWay))||(*SourceWayNO==(1+wayNO)))
                                {
                                    ZKC.SendData(1);
                                }
                            }
                            memcpy(&LastT0,  BufferRecv[wayNO]+sizeof(HEADERStruct), 4);//记录T0时刻
                        }
                        CNetCommuCT::T0COUNT++;
                        if(CNetCommuCT::T0COUNT>(256*256*256*255))
                            CNetCommuCT::T0COUNT = 0;
                    }
                }
            }

            tempValue_1=0;
            for(tem_I=0; tem_I<30; tem_I++)
            {
                memcpy(&tempValue_X[tem_I], WYDHEADER[tem_I].v_SP4, 4);
                if(BIDTest == tempValue_X[tem_I])
                {
                    tempValue_1=1;
                    break;
                }
            }

            ////外引导 处理并显示
            if(tempValue_1 == 1)
            {
                if((recvLength==(*INI_DATALENGTH_THEORY + sizeof(HEADERStruct)))&&(lenTest==*INI_DATALENGTH_THEORY))
                {
                    if(*RecvSocketTP == Socket_Udp)
                    {
                        Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv[wayNO], recvLength, 6);
                    }
                    else
                    {
                        Dialog_MsgDisplay->FreshMsg(-1-wayNO, BufferRecv[wayNO], recvLength, 6);//组播，则传输路由号 -1/-2
                    }
                    ////丢包测试+
                    if(Dialog_Debug->IsLostExaming)//开始测试
                    {
                        //Dialog_Debug.
                        if(wayNO==0)
                        {
                            memcpy(&(CTC_1.Index1), ((BYTE*)BufferRecv[wayNO])+15, 4);
                            if(CTC_1.WYDCount == 0)
                            {
                                CTC_1.Index0 = CTC_1.Index1;
                                CTC_1.WYDCount = CTC_1.Index1;
                            }
                            else
                            {
                                if(CTC_1.Index1 < CTC_1.Index0)
                                {
                                    CTC_1.MulWYD += CTC_1.Index0 - CTC_1.Index1;
                                }
                                else if((CTC_1.Index1 - CTC_1.Index0)>1)//丢包
                                {
                                    CTC_1.LostWYD += CTC_1.Index1 - CTC_1.Index0 -1;
                                }
                            }
                            //							CTC_1.WYDCount++;
                            CTC_1.Index0 = CTC_1.Index1;
                            if((CTC_1.MulWYD>(256*256*256*255))||(CTC_1.LostWYD>(256*256*256*255)))
                            {
                                Dialog_Debug->OnBnClickedDebugStartlost();
                            }
                            qDebug("1:i0=%d,i1=%d,Lo=%d,Mu=%d\n", CTC_1.Index0, CTC_1.Index1, CTC_1.LostWYD, CTC_1.MulWYD);
                        }
                        else
                        {
                            memcpy(&(CTC_2.Index1), ((BYTE*)BufferRecv[wayNO])+15, 4);
                            if(CTC_2.WYDCount == 0)
                            {
                                CTC_2.Index0 = CTC_2.Index1;
                                CTC_2.WYDCount = CTC_2.Index1;
                            }
                            else
                            {
                                if(CTC_2.Index1 < CTC_2.Index0)
                                {
                                    CTC_2.MulWYD += CTC_2.Index0 - CTC_2.Index1;
                                }
                                else if((CTC_2.Index1 - CTC_2.Index0)>1)//丢包
                                {
                                    CTC_2.LostWYD += CTC_2.Index1 - CTC_2.Index0 -1;
                                }
                            }
                            //							CTC_2.WYDCount++;
                            CTC_2.Index0 = CTC_2.Index1;
                            if((CTC_2.MulWYD>(256*256*256*255))||(CTC_2.LostWYD>(256*256*256*255)))
                            {
                                Dialog_Debug->OnBnClickedDebugStartlost();
                            }

                            qDebug("2:i0=%d,i1=%d,Lo=%d,Mu=%d\n", CTC_2.Index0, CTC_2.Index1, CTC_2.LostWYD, CTC_2.MulWYD);
                        }
                    }
                    ////丢包测试-

                    if(commuui->m_WYDEnable_va->isChecked())
                    {
                        memcpy(ZKC.BufferSend_Passed, BufferRecv[wayNO], MACRO_BUFFER_SIZE);
                        if((Global_CurrentMode==Normal) || (Global_CurrentMode==CT_Debug))//在正常状态和对上调试时都可以接收
                        {
                            //if((!(*IsHandleWay))||(*SourceWayNO==(1+wayNO)))
                            if(((*IsHandleWay))||(*SourceWayNO==(1+wayNO)))
                            {
                                memcpy(&tempValue,  BufferRecv[wayNO]+sizeof(HEADERStruct), 4);//记录时刻
                                ZKC.SendData(2);
                            }
                            else if(!(*IsHandleWay))
                            {
                                if(newWYD==1)//表明该外引导数据为新鲜有效的
                                {
                                    memcpy(&tempValue,  BufferRecv[wayNO]+sizeof(HEADERStruct), 4);//记录T0时刻
                                    ZKC.SendData(2);
                                }

                            }
                        }
                    }
                    CNetCommuCT::WYDCOUNT++;
                    if(CNetCommuCT::WYDCOUNT>(256*256*256*255))
                        CNetCommuCT::WYDCOUNT = 0;
                }
            }

            memcpy(&tempValue, ExamRecvHEADER->v_SP4, 4);
            ////时延测试 处理并显示
            if(BIDTest == tempValue)
            {
                if((recvLength==(*INI_DATALENGTH_EXAM + sizeof(HEADERStruct)))&&(lenTest==*INI_DATALENGTH_EXAM))
                {
                    if(*RecvSocketTP == Socket_Udp)
                    {
                        Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv[wayNO], recvLength, 8);
                    }
                    else
                    {
                        Dialog_MsgDisplay->FreshMsg(-1-wayNO, BufferRecv[wayNO], recvLength, 8);//组播，则传输路由号 -1/-2
                    }
                    HandleTimeExam(wayNO);//此函数具备了结果显示和数据处理转发的功能
                    CNetCommuCT::TimeExamRecvCOUNT++;
                    if(CNetCommuCT::TimeExamRecvCOUNT>(256*256*256*255))
                        CNetCommuCT::TimeExamRecvCOUNT = 0;
                }
            }

        }//DID符合,处理结束

    }//来自于监控机,处理结束

    return true;
}

/************************************************************************/
/*消息响应：发送完监控机数据（不含分站/主控台数据）
包括HEADER实算数据和常时
                                                                     */
/************************************************************************/
long CCommuDlg::SendedCT(unsigned int  wParam, long lParam)
{
    int wayNO = (LONG)wParam;
    int recvLength = (LONG)lParam;
    if(wayNO == 0)
    {
        memcpy(BufferRecv[wayNO], CTC_1.BufferSended_Passed, MACRO_BUFFER_SIZE);//#define MACRO_BUFFER_SIZE	2048
        recvLength = CTC_1.pBufferSendedLength;
    }
    else
    {
        memcpy(BufferRecv[wayNO], CTC_2.BufferSended_Passed, MACRO_BUFFER_SIZE);//#define MACRO_BUFFER_SIZE	2048
        recvLength = CTC_2.pBufferSendedLength;
    }

    int sourceNO = -2;//发送给显示窗口，表明数据来源：-2：本地
    if(recvLength>(*INI_DATALENGTH_EXAM + sizeof(HEADERStruct)))//实算数据
        Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv[wayNO], recvLength, 1);
    else if(recvLength>(*INI_DATALENGTH_T0 + sizeof(HEADERStruct)))//时延测试
        Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv[wayNO], recvLength, 4);

    return true;
}


/************************************************************************/
/*消息响应：接收完主控数据（含分站/主控台数据）
由于发送给中心站和自主控接收的数据一模一样，
故在接收实算数据时进行界面刷新，而在发送给中心站时，不再刷新界面中的变量区
值得注意的是，收到的主控数据，其中64个字节已经是基本符合HEADER的数据，之后的
19字节数据则是将要发送给主控台
                                                                     */
/************************************************************************/
long CCommuDlg::ReceivedZK(unsigned int  wParam, long lParam)
{
    int recvLength = 0;
    int sourceNO = -3;//发送给显示窗口，表明数据来源：-3：本地主控计算机
    memcpy(BufferRecv3, ZKC.BufferRecv_Passed, MACRO_BUFFER_SIZE);
    recvLength = ZKC.pBufferRecvLength;
    if(recvLength!=(*INI_DATALENGTH_ZK))//判断上位机的数据长度
    {
//        QString ps;
//        ps.sprintf("pl=%d", recvLength);
//        QMessageBox Box;
//        Box.setText(ps);
//        Box.exec();
//        //AfxMessageBox(ps);
        return true;
    }

    Dialog_MsgDisplay->FreshMsg(sourceNO, BufferRecv3, recvLength, 12);

    if(*Is_ZhuKongTai)
    {
        CTC_1.SendData(BufferRecv3, recvLength, Dialog_Setup->ZhuKongTaiSock_1, -1);
        CTC_2.SendData(BufferRecv3, recvLength, Dialog_Setup->ZhuKongTaiSock_2, -1);//直接发往中心站

        for(int i=0; i<Dialog_Setup->FZSockNum;i++)
        {
            CTC_1.SendData(BufferRecv3, recvLength, Dialog_Setup->FZSock1[i], -1);
            CTC_2.SendData(BufferRecv3, recvLength, Dialog_Setup->FZSock2[i], -1);//直接发往中心站
        }
    }

    memcpy(CTC_1.BufferSend_Passed, BufferRecv3, MACRO_BUFFER_SIZE);
    memcpy(CTC_2.BufferSend_Passed, BufferRecv3, MACRO_BUFFER_SIZE);
    if((Global_CurrentMode==Normal) || (Global_CurrentMode==ZK_Debug))//在正常状态和对下调试时都可以接收
    {
        CTC_1.SendData(1);
        CTC_2.SendData(1);//发往监控机
    }

    return true;
}

/************************************************************************/
/*消息响应：发送完主控数据（含分站/主控台数据）
暂不作处理
                                                                     */
/************************************************************************/
long CCommuDlg::SendedZK(unsigned int  wParam, long  lParam)
{

    return true;
}

/************************************************************************/
/*消息响应：配置参数发生了变化，主要是由用户点击了参数配置页的“应用”
这个函数仅对在任务过程中更改了时统源和发射点坐标而产生的需求
要将各个通信类进行更新
                                                                     */
/************************************************************************/
void CCommuDlg::ParamApply()
{
    if(Global_CurrentMode != Disconnect)//Disconnect在Globaldefine.h中定义
    {
        ZKC.EjectAngle	= *EjectAngle;
        ZKC.EjectPosL	= *EjectPosL;
        ZKC.EjectPosB	= *EjectPosB;
        ZKC.EjectPosH	= *EjectPosH;
        ZKC.TimeSource	= TimeSource;
        ZKC.CurrentMode	= Global_CurrentMode;

        CTC_1.EjectAngle	= *EjectAngle;
        CTC_1.EjectPosL		= *EjectPosL;
        CTC_1.EjectPosB		= *EjectPosB;
        CTC_1.EjectPosH		= *EjectPosH;
        CTC_1.TimeSource	= TimeSource;
        CTC_1.CurrentMode	= Global_CurrentMode;
        //		CTC_1.SendSocketTP	= *SendSocketTP;
        //		CTC_1.RecvSocketTP	= *RecvSocketTP;

        CTC_2.EjectAngle	= *EjectAngle;
        CTC_2.EjectPosL		= *EjectPosL;
        CTC_2.EjectPosB		= *EjectPosB;
        CTC_2.EjectPosH		= *EjectPosH;
        CTC_2.TimeSource	= TimeSource;
        CTC_2.CurrentMode	= Global_CurrentMode;
        //		CTC_2.SendSocketTP	= *SendSocketTP;
        //		CTC_2.RecvSocketTP	= *RecvSocketTP;
    }

}


/************************************************************************/
/*
建立连接，之后不能再设置（除了使能按钮和软件状态）
                                                                     */
/************************************************************************/
void CCommuDlg::OnButtonConnect()
{
    qDebug("OnButtonConnect");

    Dialog_Snmp->on_startAgent_clicked();

    LastT0 = 0;
    CTC_1.StartConnect(0, *SendSocketTP, *RecvSocketTP);
    CTC_2.StartConnect(1, *SendSocketTP, *RecvSocketTP);
    ZKC.StartConnect();

    Dialog_MsgDisplay->InitContent(*RecvSocketTP, *SendSocketTP);

    ui->m_Connect->setEnabled(false);//setEnable
    ui->m_Cancel->setEnabled(true);//setEnable
    ui->m_StatusSwitch->setEnabled(true);//setEnable
    ui->m_StatusSwitch2->setEnabled(true);//setEnable
    ui->m_SendExam->setEnabled(true);//setEnable

    usleep(100000);//可以直接copy

    Timer1SecondHWND->start(1000);//开始定时器, 正常状态下返回值SendTimerHWND应等于第一个参数
    Timer1Hz->start(1000);
    if(Timer1SecondHWND==NULL)
    {
        QMessageBox Box;
        Box.setText("定时器设置失败，请重新启动程序");
        Box.exec();
        return;
    }
    if(Thread20HzHWND!=NULL)   {  Thread20HzHWND ->start(); }
    // Thread20HzHWND = AfxBeginThread(Thread20Hz, THREAD_PRIORITY_NORMAL);//创建图形界面线程优先级为0 ??????????????????????????????       //开启从网络读取数据线程
    //AfxBeginThread创建一个新的CWinThread对象，调用它的CreateThread函数以启动这个线程，
#ifndef CardType
    Thread1HzHWND->start();
    //Thread1HzHWND = AfxBeginThread(Thread1Hz, THREAD_PRIORITY_NORMAL);//创建图形界面线程优先级为0 //??????????????????????????????        //开启从网络读取数据线程
#endif

    Global_CurrentMode = Normal;//Globaldefine.h
    CTC_1.CurrentMode				= Global_CurrentMode;
    CTC_2.CurrentMode				= Global_CurrentMode;
    ZKC.CurrentMode					= Global_CurrentMode;

    ExamSendFreq = 20;
    IsExamSending = false;
    Counter20Hz = 0;
    ExamCount = 0;
    ExamSetNum1 = 0;
    ExamSetNum2 = 0;
    IsHandleWay = &(Dialog_MsgDisplay->IsHandleWay);
    SourceWayNO = &(Dialog_MsgDisplay->SourceWayNO);
    return;
}


void CCommuDlg::OnTimer()
{
    // TODO: Add your message handler code here and/or call default
    int sourceNO = -2;//发送给显示窗口

    QString temp_Info;

    temp_Info.sprintf("接收常时:%.8d,T0:%.8d,外部说明%.8d,接收时延测试:%.8d,接收主站:%.8d,实算:%.8d,发送常时:%.8d,发送时延测试:%.8d,发送主站:%.8d",
                      CNetCommuCT::LinkRecvCOUNT, CNetCommuCT::T0COUNT, CNetCommuCT::WYDCOUNT, CNetCommuCT::TimeExamRecvCOUNT, CNetCommuCT::ZKRecvCOUNT,
                      CNetCommuCT::MeasureCOUNT, CNetCommuCT::LinkSendCOUNT, CNetCommuCT::TimeExamSendCOUNT, CNetCommuCT::ZKSendCOUNT);
    //    temp_Info.sprintf("接收常时:%.8d,T0:%.8d,外部说明%.8d,接收时延测试:%.8d,接收主站:%.8d,实算:%.8d,发送常时:%.8d,发送时延测试:%.8d,发送主站:%.8d",
    //        CNetCommuCT::LinkRecvCOUNT, CNetCommuCT::T0COUNT, CNetCommuCT::WYDCOUNT, CNetCommuCT::TimeExamRecvCOUNT, CNetCommuCT::FZRecvCOUNT,
    //        CNetCommuCT::MeasureCOUNT, CNetCommuCT::LinkSendCOUNT, CNetCommuCT::TimeExamSendCOUNT, CNetCommuCT::FZSendCOUNT);
    temp_Info=QString::fromLocal8Bit(temp_Info.toAscii());

    msgdisplayui->m_StIndexInfo->setText(temp_Info);
}

void CCommuDlg::OnCoCancel()
{
    qDebug("OnCoCancel");

    isCloseClicked=true;

    Dialog_MsgDisplay->UnInitData();
    Dialog_Setup->UnInitData();
    Dialog_Debug->UnInitDebugData();
    //  Dialog_Snmp->UnInitData();//?????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????snmp??????
    Global_CurrentMode = Disconnect;
    Timer1SecondHWND->stop();

    if(Thread20HzHWND!=NULL)//检测线程状态，若未关闭则强制关闭
        Thread20HzHWND->terminate();
    if(Thread1HzHWND!=NULL)
        Thread1HzHWND->terminate();

    Timer1Hz->stop();
    usleep(100000);//大于50毫秒即可保证线程退出

    CTC_1.	CloseConnect();
    CTC_2.	CloseConnect();
    ZKC.	CloseConnect();

    fileConvert();

    Dialog_Snmp->on_quitAgent_clicked();

    usleep(200000);//大于50毫秒即可保证线程退出

    //	CTC_1.	SaveFile();
    //	ZKC.	SaveFile();
#ifdef CardType
    PIODIO_IntRemove();//中断模式结束//piodio.h
    PIODIO_DriverClose();//piodio.h
    CloseHandle(hIntEvent);//?????????????????winbase.h中定义？？？？？？？？？？？？？？？？？？？？?????????????????????????????
#else
#ifdef    LINUXTIME
    tcrc_close(0);//tcrclib.h
#endif

#endif

    //::WSACleanup();    //exit network

    close();//调用该函数直接copy过去  qt
    qApp->exit(0);
}

/************************************************************************/
/* 主动发送时延测试
                                                                     */
/************************************************************************/

void CCommuDlg::OnButtonSendExam()
{
    qDebug("OnButtonSendExam");

    IsExamSending = !IsExamSending;
    if(IsExamSending)//开始了主动测试时延
    {
        ExamSetNum1 = 0;
        ExamSetNum2 = 0;
        memset(&ExamSet1, 0, sizeof(ExamSet1));
        memset(&ExamSet2, 0, sizeof(ExamSet2));
        ui->m_SendExam->setText(tr("时延测试中..."));

        debugui->DEBUG_SENDEXAM->setText(tr("时延测试中..."));
        debugui->m_ExamMax1->setText(tr("0"));
        debugui->m_ExamMax2->setText(tr("0"));
        debugui->m_ExamMax3->setText(tr("0"));
        debugui->m_ExamMax4->setText(tr("0"));
        debugui->m_ExamMax5->setText(tr("0"));
        debugui->m_ExamMax6->setText(tr("0"));
        debugui->m_ExamMin1->setText(tr("0"));
        debugui->m_ExamMin2->setText(tr("0"));
        debugui->m_ExamMin3->setText(tr("0"));
        debugui->m_ExamMin4->setText(tr("0"));
        debugui->m_ExamMin5->setText(tr("0"));
        debugui->m_ExamMin6->setText(tr("0"));
        debugui->m_ExamAve1->setText(tr("0"));
        debugui->m_ExamAve2->setText(tr("0"));
        debugui->m_ExamAve3->setText(tr("0"));
        debugui->m_ExamAve4->setText(tr("0"));
        debugui->m_ExamAve5->setText(tr("0"));
        debugui->m_ExamAve6->setText(tr("0"));
    }
    else//结束了主动测试时延
    {
        ui->m_SendExam->setText(tr("开始时延测试"));

        debugui->DEBUG_SENDEXAM->setText(tr("开始时延测试"));
        int temp_ResultIndex = 0;
        DWORD sum_1 = 0;
        DWORD sum_2 = 0;
        DWORD sum_3 = 0;
        DWORD sum_4 = 0;
        DWORD sum_5 = 0;
        DWORD sum_6 = 0;
        double max_1 = 0;
        double max_2 = 0;
        double max_3 = 0;
        double max_4 = 0;
        double max_5 = 0;
        double max_6 = 0;
        double min_1 = 65535;
        double min_2 = 65535;
        double min_3 = 65535;
        double min_4 = 65535;
        double min_5 = 65535;
        double min_6 = 65535;
        double ave_1 = 0;
        double ave_2 = 0;
        double ave_3 = 0;
        double ave_4 = 0;
        double ave_5 = 0;
        double ave_6 = 0;
        LONG diff1 = 0;
        LONG diff2 = 0;
        LONG diff3 = 0;
        LONG diff4 = 0;
        LONG diff5 = 0;
        LONG diff6 = 0;
        int diffCount = 0;
        QString tempStr;
        for(temp_ResultIndex=0; temp_ResultIndex<ExamSetNum1; temp_ResultIndex++)
        {
#ifdef DEB
            int temp1 = ExamSet1[temp_ResultIndex].TfTime %65535;
            int temp2 = ExamSet1[temp_ResultIndex].TsTime %65535;
            int temp3 = ExamSet1[temp_ResultIndex].TzTime %65535;
            int temp4 = ExamSet1[temp_ResultIndex].TqTime %65535;
            diff1 = abs(temp2 - temp1);
            diff2 = abs(temp4 - temp3);
            diff3 = abs(temp4 - temp1);
            //			diff1 = ExamSet1[temp_ResultIndex].TsTime - ExamSet1[temp_ResultIndex].TfTime;
            //			diff2 = ExamSet1[temp_ResultIndex].TqTime - ExamSet1[temp_ResultIndex].TzTime;
            //			diff3 = ExamSet1[temp_ResultIndex].TqTime - ExamSet1[temp_ResultIndex].TfTime;
#else
            if(ExamSet1[temp_ResultIndex].TfTime>ExamSet1[temp_ResultIndex].TsTime)//错误数据
                continue;
            if(ExamSet1[temp_ResultIndex].TsTime>ExamSet1[temp_ResultIndex].TqTime)//错误数据
                continue;
            diff1 = ExamSet1[temp_ResultIndex].TsTime - ExamSet1[temp_ResultIndex].TfTime;
            diff2 = ExamSet1[temp_ResultIndex].TqTime - ExamSet1[temp_ResultIndex].TzTime;
            diff3 = ExamSet1[temp_ResultIndex].TqTime - ExamSet1[temp_ResultIndex].TfTime;
#endif
            diffCount++;
            if(sum_1>65535*60000)
                break;
            if(sum_2>65535*60000)
                break;
            if(sum_3>65535*60000)
                break;
            sum_1 += diff1;
            sum_2 += diff2;
            sum_3 += diff3;
            if(diff1>max_1)
                max_1 = diff1;
            if(diff2>max_2)
                max_2 = diff2;
            if(diff3>max_3)
                max_3 = diff3;
            if(diff1<min_1)
                min_1 = diff1;
            if(diff2<min_2)
                min_2 = diff2;
            if(diff3<min_3)
                min_3 = diff3;
        }

        if(diffCount!=0)
        {
            ave_1 = sum_1/diffCount;
            ave_2 = sum_2/diffCount;
            ave_3 = sum_3/diffCount;
        }

        tempStr.sprintf("%.2f", ave_1/10);
        debugui->m_ExamAve1->setText(tempStr);
        tempStr.sprintf("%.2f", ave_2/10);
        debugui->m_ExamAve2->setText(tempStr);
        tempStr.sprintf("%.2f", ave_3/10);
        debugui->m_ExamAve3->setText(tempStr);
        tempStr.sprintf("%.2f", max_1/10);
        debugui->m_ExamMax1->setText(tempStr);
        tempStr.sprintf("%.2f", max_2/10);
        debugui->m_ExamMax2->setText(tempStr);
        tempStr.sprintf("%.2f", max_3/10);
        debugui->m_ExamMax3->setText(tempStr);
        tempStr.sprintf("%.2f", min_1/10);
        debugui->m_ExamMin1->setText(tempStr);
        tempStr.sprintf("%.2f", min_2/10);
        debugui->m_ExamMin2->setText(tempStr);
        tempStr.sprintf("%.2f", min_3/10);
        debugui->m_ExamMin3->setText(tempStr);

        diffCount = 0;
        for(temp_ResultIndex=0; temp_ResultIndex<ExamSetNum2; temp_ResultIndex++)
        {

#ifdef DEB
            int temp1 = ExamSet2[temp_ResultIndex].TfTime %65535;
            int temp2 = ExamSet2[temp_ResultIndex].TsTime %65535;
            int temp3 = ExamSet2[temp_ResultIndex].TzTime %65535;
            int temp4 = ExamSet2[temp_ResultIndex].TqTime %65535;
            diff4 = abs(temp2 - temp1);
            diff5 = abs(temp4 - temp3);
            diff6 = abs(temp4 - temp1);
            //			diff4 = ExamSet2[temp_ResultIndex].TsTime - ExamSet2[temp_ResultIndex].TfTime;
            //			diff5 = ExamSet2[temp_ResultIndex].TqTime - ExamSet2[temp_ResultIndex].TzTime;
            //			diff6 = ExamSet2[temp_ResultIndex].TqTime - ExamSet2[temp_ResultIndex].TfTime;
#else
            if(ExamSet2[temp_ResultIndex].TfTime>ExamSet2[temp_ResultIndex].TsTime)//错误数据
                continue;
            if(ExamSet2[temp_ResultIndex].TsTime>ExamSet2[temp_ResultIndex].TqTime)//错误数据
                continue;
            diff4 = ExamSet2[temp_ResultIndex].TsTime - ExamSet2[temp_ResultIndex].TfTime;
            diff5 = ExamSet2[temp_ResultIndex].TqTime - ExamSet2[temp_ResultIndex].TzTime;
            diff6 = ExamSet2[temp_ResultIndex].TqTime - ExamSet2[temp_ResultIndex].TfTime;
#endif
            diffCount++;
            if(sum_4>65535*60000)
                break;
            if(sum_5>65535*60000)
                break;
            if(sum_6>65535*60000)
                break;
            sum_4 += diff4;
            sum_5 += diff5;
            sum_6 += diff6;
            if(diff4>max_4)
                max_4 = diff4;
            if(diff5>max_5)
                max_5 = diff5;
            if(diff6>max_6)
                max_6 = diff6;
            if(diff4<min_4)
                min_4 = diff4;
            if(diff5<min_5)
                min_5 = diff5;
            if(diff6<min_6)
                min_6 = diff6;
        }
        if(diffCount!=0)
        {
            ave_4 = sum_4/diffCount;
            ave_5 = sum_5/diffCount;
            ave_6 = sum_6/diffCount;
        }

        tempStr.sprintf("%.2f", ave_4/10);
        debugui->m_ExamAve4->setText(tempStr);
        tempStr.sprintf("%.2f", ave_5/10);
        debugui->m_ExamAve5->setText(tempStr);
        tempStr.sprintf("%.2f", ave_6/10);
        debugui->m_ExamAve6->setText(tempStr);
        tempStr.sprintf("%.2f", max_4/10);
        debugui->m_ExamMax4->setText(tempStr);
        tempStr.sprintf("%.2f", max_5/10);
        debugui->m_ExamMax5->setText(tempStr);
        tempStr.sprintf("%.2f", max_6/10);
        debugui->m_ExamMax6->setText(tempStr);
        tempStr.sprintf("%.2f", min_4/10);
        debugui->m_ExamMin4->setText(tempStr);
        tempStr.sprintf("%.2f", min_5/10);
        debugui->m_ExamMin5->setText(tempStr);
        tempStr.sprintf("%.2f", min_6/10);
        debugui->m_ExamMin6->setText(tempStr);
    }

}


void CCommuDlg::OnCheckStatusSwitch()
{
    qDebug("OnCheckStatusSwitch");

    if(Global_CurrentMode == Normal)
    {
        Global_CurrentMode = CT_Debug;
        CTC_1.CurrentMode = CT_Debug;
        CTC_2.CurrentMode = CT_Debug;
        ui->m_StatusSwitch->setText(tr("与监控机正处于调试模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH->setText(tr("与监控机正处于调试模式"));
        Dialog_Debug->CTDebugIndex=0;
    }
    else if(Global_CurrentMode == ZK_Debug)
    {
        Global_CurrentMode = ZK_CT_Debug;
        CTC_1.CurrentMode = ZK_CT_Debug;
        CTC_2.CurrentMode = ZK_CT_Debug;
        ui->m_StatusSwitch->setText(tr("与监控机正处于调试模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH->setText(tr("与监控机正处于调试模式"));
        Dialog_Debug->CTDebugIndex=0;
    }
    else if(Global_CurrentMode == ZK_CT_Debug)
    {
        Global_CurrentMode = ZK_Debug;
        CTC_1.CurrentMode = ZK_Debug;
        CTC_2.CurrentMode = ZK_Debug;
        ui-> m_StatusSwitch->setText(tr("与监控机正处于任务模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH->setText(tr("与监控机正处于任务模式"));
        //		Dialog_Debug->CTDebugIndex=0;
    }
    else if(Global_CurrentMode == CT_Debug)
    {
        Global_CurrentMode = Normal;
        CTC_1.CurrentMode = Normal;
        CTC_2.CurrentMode = Normal;
        ui->m_StatusSwitch->setText(tr("与监控机正处于任务模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH->setText(tr("与监控机正处于任务模式"));
    }
}


/************************************************************************/
/* 对接收到的时延测试数据进行处理。包括时标输入，数据回送，结果显示
                                                                     */
/************************************************************************/
DWORD CCommuDlg::HandleTimeExam(int wayNO)
{
    unsigned int  TfTime = 0xffffffff;
    unsigned int  TsTime = 0xffffffff;
    unsigned int  TzTime = 0xffffffff;
    unsigned int  TqTime = 0xffffffff;

    memcpy(&TfTime, ((BYTE*)BufferRecv[wayNO])+32, 4);
    memcpy(&TsTime, ((BYTE*)BufferRecv[wayNO])+36, 4);
    memcpy(&TzTime, ((BYTE*)BufferRecv[wayNO])+40, 4);
    memcpy(&TqTime, ((BYTE*)BufferRecv[wayNO])+44, 4);

    if((TsTime==0xffffffff)&&(TzTime==0xffffffff)&&(TzTime==0xffffffff))//由监控机发起的测试
        //if((TsTime==0)&&(TzTime==0)&&(TzTime==0))//由监控机发起的测试
    {
        if(!IsExamSending)//主动发送时不再具备被动测试的功能
        {
            if(wayNO==0)//自那里来的数据回传至那里
            {
                memcpy(CTC_1.BufferSend_Passed, BufferRecv[wayNO], MACRO_BUFFER_SIZE);
                CTC_1.SendData(4);
            }
            else
            {
                memcpy(CTC_2.BufferSend_Passed, BufferRecv[wayNO], MACRO_BUFFER_SIZE);
                CTC_2.SendData(4);
            }
        }
    }
    else//由本机发起的时延
    {
        TqTime = 0;
        TqTime = GetTime(TimeSource);
        DWORD pExamresult = TqTime - TfTime;
        QString pstrExamresult;
        pstrExamresult.sprintf("总延时:%d毫秒", pExamresult/10);
        pstrExamresult.fromLocal8Bit(pstrExamresult.toLatin1());
        msgdisplayui->m_LagTime->setText(pstrExamresult);

        if(wayNO==0)
        {
            if (ExamSetNum1 < (MACRO_MAXEXAM-10))
            {
                ExamSet1[ExamSetNum1].TfTime = TfTime;
                ExamSet1[ExamSetNum1].TzTime = TzTime;
                ExamSet1[ExamSetNum1].TsTime = TsTime;
                ExamSet1[ExamSetNum1].TqTime = TqTime;
                ExamSetNum1++;
            }
        }
        else if(wayNO==1)
        {
            if (ExamSetNum2 < (MACRO_MAXEXAM-10))
            {
                ExamSet2[ExamSetNum2].TfTime = TfTime;
                ExamSet2[ExamSetNum2].TzTime = TzTime;
                ExamSet2[ExamSetNum2].TsTime = TsTime;
                ExamSet2[ExamSetNum2].TqTime = TqTime;
                ExamSetNum2++;
            }
        }
    }

    return TfTime;
}


/************************************************************************/
/* 切换与主控机通信状态
                                                                     */
/************************************************************************/
void CCommuDlg::OnCheckStatusswitch2()
{
    qDebug("OnCheckStatusswitch2");

    if(Global_CurrentMode == Normal)
    {
        Global_CurrentMode = ZK_Debug;
        CTC_1.CurrentMode = ZK_Debug;
        CTC_2.CurrentMode = ZK_Debug;
        ui->m_StatusSwitch2->setText(tr("与本地正处于调试模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH2->setText(tr("与本地正处于调试模式"));
    }
    else if(Global_CurrentMode == CT_Debug)
    {
        Global_CurrentMode = ZK_CT_Debug;
        CTC_1.CurrentMode = ZK_CT_Debug;
        CTC_2.CurrentMode = ZK_CT_Debug;
        ui->m_StatusSwitch2->setText(tr("与本地正处于调试模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH2->setText(tr("与本地正处于调试模式"));
    }
    else if(Global_CurrentMode == ZK_CT_Debug)
    {
        Global_CurrentMode = CT_Debug;
        CTC_1.CurrentMode = CT_Debug;
        CTC_2.CurrentMode = CT_Debug;
        ui->m_StatusSwitch2->setText(tr("与本地正处于任务模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH2->setText(tr("与本地正处于任务模式"));
    }
    else if(Global_CurrentMode == ZK_Debug)
    {
        Global_CurrentMode = Normal;
        CTC_1.CurrentMode = Normal;
        CTC_2.CurrentMode = Normal;
        ui->m_StatusSwitch2->setText(tr("与本地正处于任务模式"));
        debugui->DEBUG_CHECK_STATUSSWITCH2->setText(tr("与本地正处于任务模式"));
    }
}


/************************************************************************/
/*
    响应20Hz的脉冲
    向主控机发送调试数据，需要自己构成数据，只需要关注数据域
    向监控机发送调试数据，要先设置CTC.DebugHEADER，之后自己构成数据
    均在数据充实后，调用SendData(param1)这个函数形式
                                                                     */
/************************************************************************/
long CCommuDlg::OnTimer20Hz(unsigned int  wParam, long lParam)
{
    DWORD currenttime;
    currenttime = GetTime(TimeSource);
    switch(Global_CurrentMode)
    {
    case Normal://正常状态,20Hz不作处理
    {
        //			if(ZKC.PrepostValid)
        //			{
        //				if(ZKC.IsLeadExist)//无需预推
        //				{
        //					ZKC.IsLeadExist = false;
        //				}
        //				else
        //				{
        //					if(ZKC.PrepostCount==10)//超过10帧停止预推
        //					{
        //						memset(ZKC.Prepost_X, 0, sizeof(ZKC.Prepost_X));
        //						memset(ZKC.Prepost_Y, 0, sizeof(ZKC.Prepost_Y));
        //						memset(ZKC.Prepost_Z, 0, sizeof(ZKC.Prepost_Z));
        //						ZKC.PrepostCount = 0;//连续预推的数目si
        //						ZKC.PrepostDataLength = 0;//预推样本的数目
        //						ZKC.PrepostValid = false;//是否允许预推
        //					}
        //					else
        //					{
        //						ZKC.PrepostSend();
        //					}
        //				}
        //			}
        //			else
        //			{
        //			}
        break;
    }
    case ZK_Debug://与主控调试状态,20Hz 发送T0和外引导
    {
        if(Dialog_Debug->ZKStatus>0)
        {
            Dialog_Debug->ZKDebugIndex++;
            if(Dialog_Debug->ZKDebugIndex>=20*10)//10秒后不发T0发外部说明/10秒前发T0不发外部说明
                Dialog_Debug->ZKStatus=2;
            else
                Dialog_Debug->ZKStatus=1;

            DWORD tempValue_DW;
            HEADERStruct	debugHEADER_T0;								//调试时T0帧头信息
            HEADERStruct	debugHEADER_WYD;								//调试时外引导帧头信息
            memcpy(&debugHEADER_T0, T0HEADER, sizeof(HEADERStruct));
            memcpy(&debugHEADER_WYD, WYDHEADER, sizeof(HEADERStruct));

            if(Dialog_Debug->ZKStatus == 1)
            {
                //构造T0数据包
                memcpy(BufferSend3, &debugHEADER_T0, sizeof(HEADERStruct));
                memcpy(BufferSend3+sizeof(HEADERStruct), &(Dialog_Debug->ZKT0), 4);
                memcpy(ZKC.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
                ZKC.SendData(1);
            }

            if(Dialog_Debug->ZKStatus == 2)
            {
                //构造外引导数据包
                memcpy(BufferSend3, &debugHEADER_WYD, sizeof(HEADERStruct));
                memcpy(BufferSend3+sizeof(HEADERStruct), &currenttime, 4);
                tempValue_DW = Dialog_Debug->WydX*10;//1m=>0.1m
                memcpy(BufferSend3+sizeof(HEADERStruct)+4, &tempValue_DW, 4);
                tempValue_DW = Dialog_Debug->WydY*10;//1m=>0.1m
                memcpy(BufferSend3+sizeof(HEADERStruct)+8, &tempValue_DW, 4);
                tempValue_DW = Dialog_Debug->WydZ*10;//1m=>0.1m
                memcpy(BufferSend3+sizeof(HEADERStruct)+12, &tempValue_DW, 4);
                memset(BufferSend3+sizeof(HEADERStruct)+16, 0, 12);//速度假设为0
                memcpy(ZKC.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
                ZKC.SendData(2);
            }
        }
        else
        {
        }
        break;
    }
    case CT_Debug://与监控机调试状态，20Hz发送实算数据
    {
        DWORD tempValue_DW;
        LONG tempValue_L;
        double tempValue_D;
        unsigned short tempValue_S;

        //构造实算数据包
        Dialog_Debug->CTDebugIndex++;
        if(Dialog_Debug->CTDebugIndex>(65534*65534))
            Dialog_Debug->CTDebugIndex = 0;
        unsigned short diffDay = GetDate();
        memcpy(Dialog_Debug->DebugHEADER_Measure.v_Time, &currenttime, 4);
        memcpy(Dialog_Debug->DebugHEADER_Measure.v_Date, &diffDay, 2);
        memcpy(Dialog_Debug->DebugHEADER_Measure.v_No, &(Dialog_Debug->CTDebugIndex), 4);
        memcpy(BufferSend3, &(Dialog_Debug->DebugHEADER_Measure), sizeof(HEADERStruct));

        memcpy(BufferSend3+sizeof(HEADERStruct), &currenttime, 4);					//T

        if(Dialog_Debug->ServerMode == tr("单杆"))//半自动未跟踪
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 0;
        }
        if(Dialog_Debug->ServerMode == tr("程序引导"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode ==tr( "外引导"))//外引导
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 2;
        }
        if(Dialog_Debug->ServerMode ==tr( "电视自动跟踪"))//电视自动跟踪
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 5;
        }
        if(Dialog_Debug->ServerMode ==tr( "正弦引导"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode ==tr( "等速引导"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode ==tr( "定位"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode == tr("加权"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 9;									//Status
        }

        tempValue_D = Dialog_Debug->A*pow((float)2, 31)/360;
        tempValue_L = tempValue_D;
        memcpy(BufferSend3+sizeof(HEADERStruct)+5, &tempValue_L, 4);				//A
        tempValue_D = Dialog_Debug->E*pow((float)2, 31)/360;
        tempValue_L = tempValue_D;
        memcpy(BufferSend3+sizeof(HEADERStruct)+9, &tempValue_L, 4);				//E

        if(debugui->m_IsTarget->isChecked())							//目标
        {
            BufferSend3[sizeof(HEADERStruct)+13] = 1;
            tempValue_L = Dialog_Debug->OffsetX;
            memcpy(BufferSend3+sizeof(HEADERStruct)+14, &tempValue_L, 4);				//X
            tempValue_L = Dialog_Debug->OffsetY;
            memcpy(BufferSend3+sizeof(HEADERStruct)+18, &tempValue_L, 4);				//Y

            tempValue_DW = 0x7fffffff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+22, &tempValue_DW, 4);
            tempValue_DW = 0x0;
            memcpy(BufferSend3+sizeof(HEADERStruct)+26, &tempValue_DW, 4);
            tempValue_S = 0x7fff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+30, &tempValue_S, 2);
        }
        else
        {
            BufferSend3[sizeof(HEADERStruct)+13] = 0;
            tempValue_DW = 0x7fffffff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+14, &tempValue_DW, 4);
            memcpy(BufferSend3+sizeof(HEADERStruct)+18, &tempValue_DW, 4);
            memcpy(BufferSend3+sizeof(HEADERStruct)+22, &tempValue_DW, 4);
            tempValue_DW = 0x0;
            memcpy(BufferSend3+sizeof(HEADERStruct)+26, &tempValue_DW, 4);
            tempValue_S = 0x7fff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+30, &tempValue_S, 2);
        }

        memcpy(CTC_1.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
        memcpy(CTC_2.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
        CTC_1.SendData(5);
        CTC_2.SendData(5);
//        ////snmp test
//        memset(BufferMibTest, 0, MACRO_BUFFER_SIZE);
//        memcpy(BufferMibTest+100-sizeof(HEADERStruct), BufferSend3, MACRO_BUFFER_SIZE);//通过共享变量来处理
//        Pf->Dialog_Snmp->TransData(BufferMibTest);

        break;
    }
    case ZK_CT_Debug://同时发送实算数据、T0和外引导
    {
        DWORD tempValue_DW;
        LONG tempValue_L;
        double tempValue_D;
        unsigned short tempValue_S;

        //发送主控调试数据
        if(Dialog_Debug->ZKStatus>0)
        {
            Dialog_Debug->ZKDebugIndex++;
            if(Dialog_Debug->ZKDebugIndex>=20*10)//10秒后不发T0发外部说明/10秒前发T0不发外部说明
                Dialog_Debug->ZKStatus=2;
            else
                Dialog_Debug->ZKStatus=1;

            DWORD tempValue_DW;
            HEADERStruct	debugHEADER_T0;								//调试时T0帧头信息
            HEADERStruct	debugHEADER_WYD;								//调试时外引导帧头信息
            memcpy(&debugHEADER_T0, T0HEADER, sizeof(HEADERStruct));
            memcpy(&debugHEADER_WYD, WYDHEADER, sizeof(HEADERStruct));

            if(Dialog_Debug->ZKStatus == 1)
            {
                //构造T0数据包
                memcpy(BufferSend3, &debugHEADER_T0, sizeof(HEADERStruct));
                memcpy(BufferSend3+sizeof(HEADERStruct), &(Dialog_Debug->ZKT0), 4);
                memcpy(ZKC.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
                ZKC.SendData(1);
            }

            if(Dialog_Debug->ZKStatus == 2)
            {
                //构造外引导数据包
                memcpy(BufferSend3, &debugHEADER_WYD, sizeof(HEADERStruct));
                memcpy(BufferSend3+sizeof(HEADERStruct), &currenttime, 4);
                tempValue_DW = Dialog_Debug->WydX*10;//1m=>0.1m
                memcpy(BufferSend3+sizeof(HEADERStruct)+4, &tempValue_DW, 4);
                tempValue_DW = Dialog_Debug->WydY*10;//1m=>0.1m
                memcpy(BufferSend3+sizeof(HEADERStruct)+8, &tempValue_DW, 4);
                tempValue_DW = Dialog_Debug->WydZ*10;//1m=>0.1m
                memcpy(BufferSend3+sizeof(HEADERStruct)+12, &tempValue_DW, 4);
                memset(BufferSend3+sizeof(HEADERStruct)+16, 0, 12);//速度假设为0
                memcpy(ZKC.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
                ZKC.SendData(2);
            }
        }
        else
        {
        }

        //发送监控机调试数据
        Dialog_Debug->CTDebugIndex++;
        if(Dialog_Debug->CTDebugIndex>(65534*65534))
            Dialog_Debug->CTDebugIndex = 0;
        unsigned short diffDay = GetDate();
        memcpy(Dialog_Debug->DebugHEADER_Measure.v_Time, &currenttime, 4);
        memcpy(Dialog_Debug->DebugHEADER_Measure.v_Date, &diffDay, 2);
        memcpy(Dialog_Debug->DebugHEADER_Measure.v_No, &(Dialog_Debug->CTDebugIndex), 4);
        memcpy(BufferSend3, &(Dialog_Debug->DebugHEADER_Measure), sizeof(HEADERStruct));

        //构造实算数据包
        memcpy(BufferSend3+sizeof(HEADERStruct), &currenttime, 4);					//T

        if(Dialog_Debug->ServerMode == tr("单杆"))//半自动未跟踪
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 0;
        }
        if(Dialog_Debug->ServerMode ==tr( "程序引导"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode == tr("外引导"))//外引导
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 2;
        }
        if(Dialog_Debug->ServerMode ==tr( "电视自动跟踪"))//电视自动跟踪
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 5;
        }
        if(Dialog_Debug->ServerMode ==tr( "正弦引导"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode == tr("等速引导"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode == tr("定位"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 1;
        }
        if(Dialog_Debug->ServerMode == tr("加权"))//程序外部说明
        {
            BufferSend3[sizeof(HEADERStruct)+4] = 9;									//Status
        }

        tempValue_D = Dialog_Debug->A*pow((float)2, 31)/360;
        tempValue_L = tempValue_D;
        memcpy(BufferSend3+sizeof(HEADERStruct)+5, &tempValue_L, 4);				//A
        tempValue_D = Dialog_Debug->E*pow((float)2, 31)/360;
        tempValue_L = tempValue_D;
        memcpy(BufferSend3+sizeof(HEADERStruct)+9, &tempValue_L, 4);				//E

        if(debugui->m_IsTarget->isChecked())											//目标
        {
            BufferSend3[sizeof(HEADERStruct)+13] = 1;
            tempValue_L = Dialog_Debug->OffsetX;
            memcpy(BufferSend3+sizeof(HEADERStruct)+14, &tempValue_L, 4);				//X
            tempValue_L = Dialog_Debug->OffsetY;
            memcpy(BufferSend3+sizeof(HEADERStruct)+18, &tempValue_L, 4);				//Y

            tempValue_DW = 0x7fffffff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+22, &tempValue_DW, 4);
            tempValue_DW = 0x0;
            memcpy(BufferSend3+sizeof(HEADERStruct)+26, &tempValue_DW, 4);
            tempValue_S = 0x7fff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+30, &tempValue_S, 2);
        }
        else
        {
            BufferSend3[sizeof(HEADERStruct)+13] = 0;
            tempValue_DW = 0x7fffffff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+14, &tempValue_DW, 4);
            memcpy(BufferSend3+sizeof(HEADERStruct)+18, &tempValue_DW, 4);
            memcpy(BufferSend3+sizeof(HEADERStruct)+22, &tempValue_DW, 4);
            tempValue_DW = 0x0;
            memcpy(BufferSend3+sizeof(HEADERStruct)+26, &tempValue_DW, 4);
            tempValue_S = 0x7fff;
            memcpy(BufferSend3+sizeof(HEADERStruct)+30, &tempValue_S, 2);
        }

        memcpy(CTC_1.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
        memcpy(CTC_2.BufferSend_Passed, BufferSend3, MACRO_BUFFER_SIZE);
        CTC_1.SendData(5);
        CTC_2.SendData(5);

        break;
    }
    }

    if(IsExamSending)//按照频率主动发送实验测试
    {
        if((Counter20Hz%(20/ExamSendFreq)) == 0)
        {
            if(	ExamCount < MACRO_MAXEXAM )//20Hz计算，则为10分钟(每次都向多个点发送，接收时则是自多个点分别接收)
            {
                CTC_1.SendData(3);//主动测试时延
                CTC_2.SendData(3);//主动测试时延

                ExamCount++;
            }
        }
    }

    if(Counter20Hz>(65536*65530))
        Counter20Hz = 0;
    Counter20Hz++;
    //	TRACE("====Counter20Hz= %d, currenttime=%d\n", Counter20Hz, currenttime);

    return true;
}

/************************************************************************/
/*
响应20Hz的脉冲
向主控机发送调试数据，需要自己构成数据，只需要关注数据域
向监控机发送调试数据，要先设置CTC.DebugHEADER，之后自己构成数据
均在数据充实后，调用SendData(param1)这个函数形式
*/
/************************************************************************/
void CCommuDlg::OnTimer1Hz()
{
    int sourceNO = -2;//发送给显示窗口

    CTC_1.SendData(2);//常时
    CTC_2.SendData(2);//

    if(CTC_1.SocketEnable)
        Dialog_MsgDisplay->FreshMsg(sourceNO, CTC_1.BufferSended_Passed, sizeof(HEADERStruct)+4, 2);
    else if(CTC_2.SocketEnable)
        Dialog_MsgDisplay->FreshMsg(sourceNO, CTC_2.BufferSended_Passed, sizeof(HEADERStruct)+4, 2);
    else
    {
    }

    return ;
}


/************************************************************************/
/* 响应是否开始测试丢包与乱序                                                                     */
/************************************************************************/
long  CCommuDlg::OnStartLostExam(unsigned int  wParam, long lParam)
{
    if(Dialog_Debug->IsLostExaming)//开始测试
    {
        CTC_1.LostWYD = 0;
        CTC_1.WYDCount = 0;
        CTC_1.MulWYD = 0;
        CTC_1.Index0 = 0;
        CTC_1.Index1 = 0;

        CTC_2.LostWYD = 0;
        CTC_2.WYDCount = 0;
        CTC_2.MulWYD = 0;
        CTC_2.Index0 = 0;
        CTC_2.Index1 = 0;
    }
    else
    {
        if(CTC_1.WYDCount == 0)
        {
            LostRate1 = -1;
            MulRate1 = -1;
        }
        else
        {
            CTC_1.WYDCount = CTC_1.Index1 - CTC_1.WYDCount + 1;
            LostRate1 = CTC_1.LostWYD;
            LostRate1 = LostRate1/CTC_1.WYDCount;
            MulRate1 = CTC_1.MulWYD;
            MulRate1 = MulRate1/CTC_1.WYDCount;
        }
        if(CTC_2.WYDCount == 0)
        {
            LostRate2 = -1;
            MulRate2 = -1;
        }
        else
        {
            CTC_2.WYDCount = CTC_2.Index1 - CTC_2.WYDCount + 1;
            LostRate2 = CTC_2.LostWYD;
            LostRate2 = LostRate2/CTC_2.WYDCount;
            MulRate2 = CTC_2.MulWYD;
            MulRate2 = MulRate2/CTC_2.WYDCount;
        }

        QString temp_Str;
        temp_Str.sprintf("路由1丢包率:%.5f,乱序率:%.5f", LostRate1, MulRate1);
        debugui->m_StLost1->setText(temp_Str);
        temp_Str.sprintf("路由2丢包率:%.5f,乱序率:%.5f", LostRate2, MulRate2);
        debugui->m_StLost2->setText(temp_Str);
    }

    return true;
}

/************************************************************************/
/* 响应是否从第1路由发送数据                                                                */
/************************************************************************/
long  CCommuDlg::OnCheckSend1(unsigned int wParam, long lParam)
{
    CTC_1.SendEnable = !(CTC_1.SendEnable);
    if(CTC_1.SendEnable)
    {
        msgdisplayui->m_ChkSend1->setText(tr("路由1发送中"));
    }
    else
    {
        msgdisplayui->m_ChkSend1->setText(tr("路由1停发中"));
    }
    return true;
}


/************************************************************************/
/* 响应是否从第2路由发送数据                                                                     */
/************************************************************************/
long  CCommuDlg::OnCheckSend2(unsigned int wParam, long  lParam)
{
    CTC_2.SendEnable = !(CTC_2.SendEnable);
    if(CTC_2.SendEnable)
    {
        msgdisplayui->m_ChkSend2->setText(tr("路由2发送中"));
    }
    else
    {
        msgdisplayui->m_ChkSend2->setText(tr("路由2停发中"));
    }
    return true;
}

void CCommuDlg::OnSysCommand(UINT nID, LPARAM lParam)//定义qt中的公共槽？？？？？？？？
{
    //弹出about对话框

}


/************************************************************************/
/* 线程用于20Hz中断
                                                                     */
/************************************************************************/
//UINT Thread20Hz(LPVOID pParam)//???????????????????????????????????????????????????????????????

/************************************************************************/
/* 线程用于1Hz中断
*/
/************************************************************************/
//UINT Thread1Hz(LPVOID pParam)//????????????????????????????????????????????????????????????????


void CCommuDlg::ChangeIshandleway(bool HandleWay, int WayNO)
{
    *IsHandleWay=HandleWay;
    *SourceWayNO=WayNO;
}


void CCommuDlg::closeEvent(QCloseEvent *event)
{
    if(!isCloseClicked)
    {
        OnCoCancel();
    }

    event->accept();
}
