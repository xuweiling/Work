#ifndef __TRANS_H__
#define __TRANS_H__
#define  ELP_A    6378140.0
//#define  ELP_ES   0.00669438487525
#define  ELP_ES   0.00669438499959
#define  ELP_EPS  0.00673950169345
#define  PI 3.1415926535897932
struct Ground_Coord
{
	double L;
	double B;
	double H;

};
struct Cart_Coord
{
	double X;
	double Y;
	double Z;

};


////////////////////////////////////////////////////////////////////////////////

void LBH2gXYZ(Ground_Coord LBH,Cart_Coord & gXYZ);

//地心空间直角坐标系转化到地心大地坐标系
void gXYZ2LBH(Cart_Coord gXYZ,Ground_Coord & LBH);

//将法线实算坐标系(nXYZ)中一点nXYZ，转化到地心空间直角坐标系中
//LBH为法线实算坐标系的原点位置，nXYZ为法线实算坐标系(nXYZ)中一点（直角坐标表示）
//gXYZ为点nXYZ在地心空间直角坐标系中的位置表示（直角坐标形式）
void nXYZ2gXYZ(Ground_Coord LBH,Cart_Coord nXYZ,Cart_Coord & gXYZ,double nEjectAngle=0);

//将地心空间直角坐标系中的一点转化为法线实算坐标系(nXYZ)中
//法线实算坐标系(nXYZ)中的原点为LBH。
//为nXYZ2gXYZ逆转化。
void gXYZ2nXYZ(Ground_Coord LBH,Cart_Coord gXYZ,Cart_Coord & nXYZ,double nEjectAngle=0);

void XYRotate(Cart_Coord XY,double sita,Cart_Coord & rXY);

#endif 
