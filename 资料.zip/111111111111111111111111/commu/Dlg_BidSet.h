﻿#ifndef DLG_BIDSET_H
#define DLG_BIDSET_H

#include <QDialog>

#include "WinDef.h"

namespace Ui {
class CDlg_BIDSet;
}

class CDlg_BIDSet : public QDialog
{
    Q_OBJECT

public:
    explicit CDlg_BIDSet(QWidget *parent = 0);
    ~CDlg_BIDSet();
    void init();

    int pBIDCount;
    DWORD pBID[21];

private slots:
    void on_addButton_clicked();

    void on_delButton_clicked();

    void on_okButton_clicked();

public slots:

private:
    Ui::CDlg_BIDSet *ui;
};

#endif // DLG_BIDSET_H
