#include "CWinThread2.h"

CWinThread2::CWinThread2()
{

     stopped=false;
}


/************************************************************************/
/* 线程用于1Hz中断
*/
/************************************************************************/
void CWinThread2::run()
{
/*
    while (true)
        {
            if(IsTimecardExist)
            {
                tcrc_wait1pps(0, 3000);
                ::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_1Hz, NULL, NULL);
            }
            else
            {
                Sleep(1000);
                ::PostMessage(theApp.m_pMainWnd->m_hWnd, WM_USER_1Hz, NULL, NULL);
            }
        }

        return 0;
    */

}

void CWinThread2::stop()
{

    stopped=true;
}
