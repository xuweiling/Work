#ifndef MODIFYOID_H
#define MODIFYOID_H

#include <QDialog>

namespace Ui {
class ModifyOID;
}

class ModifyOID : public QDialog
{
    Q_OBJECT

public:
    explicit ModifyOID(QWidget *parent = 0);
    ~ModifyOID();

private slots:
    void on_buttonBox_accepted();

private:
    Ui::ModifyOID *ui;
    void OneLine2ModifyOId();
    void ModifyOId2OneLine();
};

#endif // MODIFYOID_H
