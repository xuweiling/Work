﻿/*_############################################################################
  _## 
  _##  agent.cpp  
  _## 
  _##
  _##  AGENT++ API Version 3.5.31
  _##  -----------------------------------------------
  _##  Copyright (C) 2000-2010 Frank Fock, Jochen Katz
  _##  
  _##  LICENSE AGREEMENT
  _##
  _##  WHEREAS,  Frank  Fock  and  Jochen  Katz  are  the  owners of valuable
  _##  intellectual  property rights relating to  the AGENT++ API and wish to
  _##  license AGENT++ subject to the  terms and conditions set forth  below;
  _##  and
  _##
  _##  WHEREAS, you ("Licensee") acknowledge  that Frank Fock and Jochen Katz
  _##  have the right  to grant licenses  to the intellectual property rights
  _##  relating to  AGENT++, and that you desire  to obtain a license  to use
  _##  AGENT++ subject to the terms and conditions set forth below;
  _##
  _##  Frank  Fock    and Jochen   Katz   grants  Licensee  a  non-exclusive,
  _##  non-transferable, royalty-free  license  to use   AGENT++ and  related
  _##  materials without  charge provided the Licensee  adheres to all of the
  _##  terms and conditions of this Agreement.
  _##
  _##  By downloading, using, or  copying  AGENT++  or any  portion  thereof,
  _##  Licensee  agrees to abide  by  the intellectual property  laws and all
  _##  other   applicable laws  of  Germany,  and  to all of   the  terms and
  _##  conditions  of this Agreement, and agrees  to take all necessary steps
  _##  to  ensure that the  terms and  conditions of  this Agreement are  not
  _##  violated  by any person  or entity under the  Licensee's control or in
  _##  the Licensee's service.
  _##
  _##  Licensee shall maintain  the  copyright and trademark  notices  on the
  _##  materials  within or otherwise  related   to AGENT++, and  not  alter,
  _##  erase, deface or overprint any such notice.
  _##
  _##  Except  as specifically   provided in  this  Agreement,   Licensee  is
  _##  expressly   prohibited  from  copying,   merging,  selling,   leasing,
  _##  assigning,  or  transferring  in  any manner,  AGENT++ or  any portion
  _##  thereof.
  _##
  _##  Licensee may copy materials   within or otherwise related   to AGENT++
  _##  that bear the author's copyright only  as required for backup purposes
  _##  or for use solely by the Licensee.
  _##
  _##  Licensee may  not distribute  in any  form  of electronic  or  printed
  _##  communication the  materials  within or  otherwise  related to AGENT++
  _##  that  bear the author's  copyright, including  but  not limited to the
  _##  source   code, documentation,  help  files, examples,  and benchmarks,
  _##  without prior written consent from the authors.  Send any requests for
  _##  limited distribution rights to fock@agentpp.com.
  _##
  _##  Licensee  hereby  grants  a  royalty-free  license  to  any  and   all 
  _##  derivatives  based  upon this software  code base,  that  may  be used
  _##  as a SNMP  agent development  environment or a  SNMP agent development 
  _##  tool.
  _##
  _##  Licensee may  modify  the sources  of AGENT++ for  the Licensee's  own
  _##  purposes.  Thus, Licensee  may  not  distribute  modified  sources  of
  _##  AGENT++ without prior written consent from the authors. 
  _##
  _##  The Licensee may distribute  binaries derived from or contained within
  _##  AGENT++ provided that:
  _##
  _##  1) The Binaries are  not integrated,  bundled,  combined, or otherwise
  _##     associated with a SNMP agent development environment or  SNMP agent
  _##     development tool; and
  _##
  _##  2) The Binaries are not a documented part of any distribution material. 
  _##
  _##
  _##  THIS  SOFTWARE  IS  PROVIDED ``AS  IS''  AND  ANY  EXPRESS OR  IMPLIED
  _##  WARRANTIES, INCLUDING, BUT NOT LIMITED  TO, THE IMPLIED WARRANTIES  OF
  _##  MERCHANTABILITY AND FITNESS FOR  A PARTICULAR PURPOSE  ARE DISCLAIMED.
  _##  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  _##  INDIRECT,   INCIDENTAL,  SPECIAL, EXEMPLARY,  OR CONSEQUENTIAL DAMAGES
  _##  (INCLUDING,  BUT NOT LIMITED  TO,  PROCUREMENT OF SUBSTITUTE  GOODS OR
  _##  SERVICES; LOSS OF  USE,  DATA, OR PROFITS; OR  BUSINESS  INTERRUPTION)
  _##  HOWEVER CAUSED  AND ON ANY THEORY  OF  LIABILITY, WHETHER IN CONTRACT,
  _##  STRICT LIABILITY, OR TORT  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
  _##  IN  ANY WAY OUT OF  THE USE OF THIS  SOFTWARE,  EVEN IF ADVISED OF THE
  _##  POSSIBILITY OF SUCH DAMAGE. 
  _##
  _##
  _##  Stuttgart, Germany, Thu Sep  2 00:07:56 CEST 2010 
  _##  
  _##########################################################################*/

#include <stdlib.h>
#include <signal.h>

#include <agent_pp/agent++.h>
#include <agent_pp/snmp_group.h>
#include <agent_pp/system_group.h>
#include <agent_pp/snmp_target_mib.h>
#include <agent_pp/snmp_notification_mib.h>
#include <agent_pp/snmp_community_mib.h>
#include <agent_pp/notification_originator.h>
#include <agent_pp/notification_log_mib.h>
#include <agent_pp/agentpp_simulation_mib.h>
#include <agent_pp/agentpp_config_mib.h>
#include <agent_pp/v3_mib.h>
#include <agent_pp/mib_policy.h>
#include <agent_pp/vacm.h>

#include <snmp_pp/oid_def.h>
#include <snmp_pp/mp_v3.h>
#include <snmp_pp/log.h>


#include "yfagent.h"

#ifdef SNMP_PP_NAMESPACE
using namespace Snmp_pp;
#endif

#ifdef AGENTPP_NAMESPACE
using namespace Agentpp;
#endif

// table size policies
#include "yfprocessrequest.h"
#include "yfmIbbrowerview.h"
#include "yfgroup.h"
#include "yftree2leaf.h"
#include "yfgetmacid.h"
//#include "yfthread.h"

#include <string>
#include <fstream>
using namespace std;
#if (__GNUC__ > 2)
#include <iostream>
using std::cerr;
using std::cout;
using std::endl;
using std::flush;
#else
#include <iostream.h>
#endif
#include <qfile.h>
#include <qstring.h>
#include <qtextstream.h>
#include <qtextcodec.h>

#include <math.h>
#include <qmessagebox.h>
//#pragma comment(lib,"libsnmp++.so.2")
// globals:

u_short port;
//Mib* mib;

RequestList* reqList;


bool localrun = true;

MibNode setNode[200];
int setNodeNum = 4;

QFile Qfile("snmplog.txt");
QTextStream txtOutPut(&Qfile);

#ifdef _SNMPv3
const table_size_def table_sizes[4] =
{ table_size_def(oidUsmUserEntry, 30),
  table_size_def(oidVacmSecurityToGroupEntry, 30),
  table_size_def(oidVacmAccessEntry, 30),
  table_size_def(oidVacmViewTreeFamilyEntry, 30)
};
MibTableSizePolicy policy(table_sizes, 4, 5000);
#endif

extern TreeNode YFHRoot;

YFSnmpAgent::YFSnmpAgent()
{
    stopListen = false;
    run = false;
    init_again = false;

    setNodeNum = 4;
    isGetNewNode = false;
    isUIWaiting = false;
    isAgentWaiting = false;

    YFmib=new YFMib();

}
YFSnmpAgent::~YFSnmpAgent()
{
    delete YFmib;
}

static void sig(int signo)
{
	if ((signo == SIGTERM) || (signo == SIGINT) ||
	    (signo == SIGSEGV)) {

		printf ("\n");
      
		switch (signo) {
		case SIGSEGV: {
			printf ("Segmentation fault, aborting.\n");
			exit(1);
		}
		case SIGTERM: 
		case SIGINT: {
                if (localrun) {
                localrun = FALSE;
				printf ("User abort\n");
			}
          }
		}
	}
}


void init_signals()
{
	signal (SIGTERM, sig);
	signal (SIGINT, sig);
	signal (SIGSEGV, sig); 
}	

//void YFGroupCreat(void)
//{
//
//}

void init(YFMib& YFmib)
{
	OctetStr sysDescr("AGENT++v");
	sysDescr += AGENTPP_VERSION_STRING;
	sysDescr += " ATM Simulation Agent";
	YFmib.add(new sysGroup(sysDescr.get_printable(),
			     "1.3.6.1.4.1.4976", 10)); 
	YFmib.add(new snmpGroup());
	YFmib.add(new TestAndIncr(oidSnmpSetSerialNo));
//	YFmib.add(new atm_mib());
	YFmib.add(new agentpp_simulation_mib());
//	YFmib.add(new agentpp_notifytest_mib());
//	YFmib.add(new agentpp_test_mib());
	YFmib.add(new snmp_target_mib());
#ifdef _SNMPv3
	YFmib.add(new snmp_community_mib());
#endif
	YFmib.add(new snmp_notification_mib());
#ifdef _SNMPv3
#ifdef _NO_THREADS
	mib.add(new agentpp_config_mib());
#else
	YFmib.add(new agentpp_config_mib(&YFmib));
#endif
	YFmib.add(new notification_log_mib());

//	OctetStr nonDefaultContext("other");
//	YFmib.add(nonDefaultContext, new atm_mib());

	UsmUserTable *uut = new UsmUserTable();

	uut->addNewRow("unsecureUser",
		       SNMP_AUTHPROTOCOL_NONE,
		       SNMP_PRIVPROTOCOL_NONE, "", "");
	
	uut->addNewRow("MD5",
		       SNMP_AUTHPROTOCOL_HMACMD5,
		       SNMP_PRIVPROTOCOL_NONE,
		       "MD5UserAuthPassword", "");
	
	uut->addNewRow("SHA",
		       SNMP_AUTHPROTOCOL_HMACSHA,
		       SNMP_PRIVPROTOCOL_NONE,
		       "SHAUserAuthPassword", "");
	
	uut->addNewRow("MD5DES",
		       SNMP_AUTHPROTOCOL_HMACMD5,
		       SNMP_PRIVPROTOCOL_DES,
		       "MD5DESUserAuthPassword",
		       "MD5DESUserPrivPassword");

	uut->addNewRow("SHADES",
		       SNMP_AUTHPROTOCOL_HMACSHA,
		       SNMP_PRIVPROTOCOL_DES,
		       "SHADESUserAuthPassword",
		       "SHADESUserPrivPassword");
	
	uut->addNewRow("MD53DES",
		       SNMP_AUTHPROTOCOL_HMACMD5,
		       SNMP_PRIVPROTOCOL_3DESEDE,
		       "MD53DESUserAuthPassword",
		       "MD53DESUserPrivPassword");

	uut->addNewRow("SHA3DES",
		       SNMP_AUTHPROTOCOL_HMACSHA,
		       SNMP_PRIVPROTOCOL_3DESEDE,
		       "SHA3DESUserAuthPassword",
		       "SHA3DESUserPrivPassword");
	
	uut->addNewRow("MD5IDEA",
		       SNMP_AUTHPROTOCOL_HMACMD5,
		       SNMP_PRIVPROTOCOL_IDEA,
		       "MD5IDEAUserAuthPassword",
		       "MD5IDEAUserPrivPassword");
	
	uut->addNewRow("SHAIDEA",
		       SNMP_AUTHPROTOCOL_HMACSHA,
		       SNMP_PRIVPROTOCOL_IDEA,
		       "SHAIDEAUserAuthPassword",
		       "SHAIDEAUserPrivPassword");

	uut->addNewRow("MD5AES128",
		       SNMP_AUTHPROTOCOL_HMACMD5,
		       SNMP_PRIVPROTOCOL_AES128,
		       "MD5AES128UserAuthPassword",
		       "MD5AES128UserPrivPassword");
	
	uut->addNewRow("SHAAES128",
		       SNMP_AUTHPROTOCOL_HMACSHA,
		       SNMP_PRIVPROTOCOL_AES128,
		       "SHAAES128UserAuthPassword",
		       "SHAAES128UserPrivPassword");

	uut->addNewRow("MD5AES192",
		       SNMP_AUTHPROTOCOL_HMACMD5,
		       SNMP_PRIVPROTOCOL_AES192,
		       "MD5AES192UserAuthPassword",
		       "MD5AES192UserPrivPassword");
	
	uut->addNewRow("SHAAES192",
		       SNMP_AUTHPROTOCOL_HMACSHA,
		       SNMP_PRIVPROTOCOL_AES192,
		       "SHAAES192UserAuthPassword",
		       "SHAAES192UserPrivPassword");

	uut->addNewRow("MD5AES256",
		       SNMP_AUTHPROTOCOL_HMACMD5,
		       SNMP_PRIVPROTOCOL_AES256,
		       "MD5AES256UserAuthPassword",
		       "MD5AES256UserPrivPassword");

	uut->addNewRow("SHAAES256",
		       SNMP_AUTHPROTOCOL_HMACSHA,
		       SNMP_PRIVPROTOCOL_AES256,
		       "SHAAES256UserAuthPassword",
		       "SHAAES256UserPrivPassword");

	// add non persistent USM statistics
	YFmib.add(new UsmStats());
	// add the USM MIB - usm_mib MibGroup is used to
	// make user added entries persistent
	YFmib.add(new usm_mib(uut));
	// add non persistent SNMPv3 engine object
	YFmib.add(new V3SnmpEngine());
	YFmib.add(new MPDGroup());
#endif

//	Oidx a[3] = {"1.3.6.1.1.4.1.1.1.0","1.3.6.1.1.4.1.1.1.2.0","1.3.6.1.1.4.1.1.3.0"};
//	mib_access   acc[3] = {READWRITE,READWRITE,READWRITE};
//	NS_SNMP SnmpSyntax* index[3] = {new SnmpInt32(),new SnmpInt32(),new SnmpInt32()};
////	YFLeaf  *YFleaf;
//	Oidx id(YFHRoot.Mibdata.POid.c_str());
//	mib_access access;
//	if(YFHRoot.Mibdata.PAccess == "NOTACCESS")
//		access = NOACCESS;
//	else if(YFHRoot.Mibdata.PAccess == "READONLY")
//		access = READONLY;
//	else if(YFHRoot.Mibdata.PAccess == "READWRITE")
//		access = READWRITE;
//	YFgroup->add(new YFLeaf(id,access,index[0]));
//	YFgroup->add(new YFLeaf(a[1],acc[1],index[1]));
//	YFgroup->add(new YFLeaf(a[2],acc[2],index[2]));

    YFGroup *YFgroup = new YFGroup(YFHRoot.Mibdata.POid.c_str(),YFHRoot.Currentname.c_str());
    tree2leaf(YFHRoot.LChildren,YFgroup);
//    DeleteTree(&YFHRoot);
	YFmib.add(YFgroup);
//	YFmib.add(new YFGroup("1.3.6.1.1.4.1.1","YFGroup",YFleaf));
}

void YFSnmpAgent::Encrypt()
{
    QString SMacID;
    string Line;
    QString readID;
    SMacID = GetLocalMac();

    //convert
    SMacID[0] = SMacID[3].toAscii() + SMacID[5].toAscii();
    for(int i = 1;i < SMacID.length();i++)
    {
        SMacID[i] = (SMacID[i-1].toAscii() + SMacID[i].toAscii())/2+SMacID[i-1].toAscii()%7;
    }
    QString temp;
    for(int i = 0; i < 8; i++)
    {
        temp[i] = (int)sqrt(SMacID[i%3+i].toAscii()) + SMacID[12-int(i*1.3)].toAscii();
    }
    SMacID += temp;
    SMacID += '\n';
//    QMessageBox::information(0,QString("this encrypt is"),SMacID,QMessageBox::Ok,QMessageBox::Ok);

    QFile file("encrypt.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    while (!file.atEnd()) {
        QString readID = file.readLine();
        if(SMacID[2] == readID[2])
        {
            run = true;
            init_again = true;
            return;
        }
     }
    if(run != true)
    {
         cout << "please input correct encrypt" << endl;
    }
}

int YFSnmpAgent::agentmain (int argc, char* argv[],QString *YFargv,int &YFargc)
{
    if(!Qfile.open( QIODevice::WriteOnly))
    {
        cout << "Open snmplog.txt failed"<<endl;
    }
    txtOutPut << "run function +1;"<< endl;


//    Encrypt();
    init_again = true;
    run = true;
    while(run && localrun)
	{
        LoadMid();
//		if(init_again == FALSE)
//		{
//			//此处添加本地修改程序
//			edittreeagain("1.3.6.1.1.4.1.1.1","String",0,"11");
//		}

	if (argc>1)
		port = atoi(argv[1]);
	else
        port = 10161;

#ifndef _NO_LOGGING
	DefaultLog::log()->set_filter(ERROR_LOG, 5);
	DefaultLog::log()->set_filter(WARNING_LOG, 5);
	DefaultLog::log()->set_filter(EVENT_LOG, 5);
	DefaultLog::log()->set_filter(INFO_LOG, 5);
	DefaultLog::log()->set_filter(DEBUG_LOG, 1);
#endif   //end of _NO_LOGGING
	int status;
	Snmp::socket_startup();  // Initialize socket subsystem
#ifdef SNMP_PP_WITH_UDPADDR
	// bind localhost only -> agent will not be reachable from
	// outside
	 //UdpAddress inaddr("127.0.0.1");
	UdpAddress inaddr("0.0.0.0");
	inaddr.set_port(port);
	Snmpx snmp(status, inaddr);
#else
	// bind on any address on local host
	Snmpx snmp(status, port);
#endif   //end of SNMP_PP_WITH_UDPADDR

	if (status == SNMP_CLASS_SUCCESS) {

		LOG_BEGIN(EVENT_LOG | 1);
		LOG("main: SNMP listen port");
		LOG(port);
		LOG_END;
	}
	else {
		LOG_BEGIN(ERROR_LOG | 0);
		LOG("main: SNMP port init failed");
		LOG(status);
		LOG(Snmp::error_msg(status));
		LOG_END;
		exit(1);
	}

//	YFmib = new YFMib();

#ifdef _SNMPv3
        unsigned int snmpEngineBoots = 0;
        OctetStr engineId(SnmpEngineID::create_engine_id(port));

        // you may use your own methods to load/store this counter
        status = YFmib->get_boot_counter(engineId, snmpEngineBoots);
        if ((status != SNMPv3_OK) && (status < SNMPv3_FILEOPEN_ERROR)) {
		LOG_BEGIN(ERROR_LOG | 0);
		LOG("main: Error loading snmpEngineBoots counter (status)");
		LOG(status);
		LOG_END;
		exit(1);
	}

        snmpEngineBoots++;
        status = YFmib->set_boot_counter(engineId,snmpEngineBoots);
        if (status != SNMPv3_OK) {
		LOG_BEGIN(ERROR_LOG | 0);
		LOG("main: Error saving snmpEngineBoots counter (status)");
		LOG(status);
		LOG_END;
		exit(1);
	}

	int stat;
        v3MP *v3mp = new v3MP(engineId, snmpEngineBoots, stat);
#endif  //end of _SNMPv3
	reqList = new RequestList();
#ifdef _SNMPv3
	// register v3MP
	reqList->set_v3mp(v3mp);
#endif
	// register requestList for outgoing requests
	YFmib->set_request_list(reqList);

	init_signals();

	// add supported objects
	init(*YFmib);

	reqList->set_snmp(&snmp);

#ifdef _SNMPv3
	// register VACM
	Vacm* vacm = new Vacm(*YFmib);
	reqList->set_vacm(vacm);

	// initialize security information
        vacm->addNewContext("");
        vacm->addNewContext("other");

        // Add new entries to the SecurityToGroupTable.
        // Used to determine the group a given SecurityName belongs to. 
        // User "new" of the USM belongs to newGroup

        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "new",
                         "newGroup", storageType_nonVolatile);

        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "test", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_V2, "public",
                         "v1v2group", storageType_nonVolatile);

        vacm->addNewGroup(SNMP_SECURITY_MODEL_V2, "private",
                         "v1v2groupw", storageType_nonVolatile);

        vacm->addNewGroup(SNMP_SECURITY_MODEL_V1, "public",
                         "v1v2group", storageType_nonVolatile);

        vacm->addNewGroup(SNMP_SECURITY_MODEL_V1, "private",
                         "v1v2groupw", storageType_nonVolatile);

        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "initial", 
                         "initial", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "unsecureUser",
                         "newGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "MD5", 
                         "testNoPrivGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "SHA", 
                         "testNoPrivGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "MD5DES", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "SHADES", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "MD53DES", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "SHA3DES", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "MD5IDEA", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "SHAIDEA", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "MD5AES128",
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "SHAAES128", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "MD5AES192",
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "SHAAES192", 
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "MD5AES256",
                         "testGroup", storageType_nonVolatile);
        vacm->addNewGroup(SNMP_SECURITY_MODEL_USM, "SHAAES256", 
                         "testGroup", storageType_nonVolatile);
	
        // remove a group with:
        //vacm->deleteGroup(SNMP_SECURITY_MODEL_USM, "neu");

        // Set access rights of groups.
        // The group "newGroup" (when using the USM with a security
	// level >= noAuthNoPriv within context "") would have full access  
        // (read, write, notify) to all objects in view "newView". 
        vacm->addNewAccessEntry("newGroup", 
				"other",        // context
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV,
				match_exact,  // context must mach exactly
				// alternatively: match_prefix  
				"newView", // readView
				"newView", // writeView
				"newView", // notifyView
				storageType_nonVolatile);
        vacm->addNewAccessEntry("testGroup", "",
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_AUTH_PRIV, 
				match_prefix,
				"testView", "testView", 
				"testView", storageType_nonVolatile);
        vacm->addNewAccessEntry("testNoPrivGroup", "",
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_AUTH_NOPRIV, 
				match_prefix,
				"testView", "testView", 
				"testView", storageType_nonVolatile);
        vacm->addNewAccessEntry("testNoPrivGroup", "",
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV, 
				match_prefix,
				"testView", "testView", 
				"testView", storageType_nonVolatile);
        vacm->addNewAccessEntry("testGroup", "",
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV, 
				match_prefix,
				"testView", "testView", 
				"testView", storageType_nonVolatile);
        vacm->addNewAccessEntry("v1v2group", "",      // public   not read
				SNMP_SECURITY_MODEL_V2,
				SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV, 
				match_exact,
                "v1ReadView", "",
				"v1NotifyView", storageType_nonVolatile);

        vacm->addNewAccessEntry("v1v2groupw", "",     //private red write notify
                SNMP_SECURITY_MODEL_V2,
                SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV,
                match_exact,
                "v1ReadView", "v1WriteView",
                "v1NotifyView", storageType_nonVolatile);

        vacm->addNewAccessEntry("v1v2group", "", 
				SNMP_SECURITY_MODEL_V1,
				SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV, 
				match_exact,
                "v1ReadView", "",
				"v1NotifyView", storageType_nonVolatile);

        vacm->addNewAccessEntry("v1v2groupw", "",
                SNMP_SECURITY_MODEL_V1,
                SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV,
                match_exact,
                "v1ReadView", "v1WriteView",
                "v1NotifyView", storageType_nonVolatile);

        vacm->addNewAccessEntry("initial", "",
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV, 
				match_exact,
				"restricted", "", 
				"restricted", storageType_nonVolatile);
        vacm->addNewAccessEntry("initial", "",
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_AUTH_NOPRIV, 
				match_exact,
				"internet", "internet", 
				"internet", storageType_nonVolatile);
        vacm->addNewAccessEntry("initial", "",
				SNMP_SECURITY_MODEL_USM,
				SNMP_SECURITY_LEVEL_AUTH_PRIV, 
				match_exact,
				"internet", "internet", 
				"internet", storageType_nonVolatile);

        // remove an AccessEntry with:
        // vacm->deleteAccessEntry("newGroup", 
	//	      		"",        
	//			SNMP_SECURITY_MODEL_USM, 
	//			SNMP_SECURITY_LEVEL_NOAUTH_NOPRIV);


        // Defining Views
        // View "v1ReadView" includes all objects starting with "1.3".
        // If the ith bit of the mask is not set (0), then also all objects
	// which have a different subid at position i are included in the 
	// view.
        // For example: Oid "6.5.4.3.2.1", Mask(binary) 110111 
        //              Then all objects with Oid with "6.5.<?>.3.2.1" 
	//              are included in the view, whereas <?> may be any
	//              natural number.

        vacm->addNewView("v1ReadView", 
			 "1.3",       
			 "",             // Mask "" is same as 0xFFFFFFFFFF...
			 view_included,  // alternatively: view_excluded
			 storageType_nonVolatile);

        vacm->addNewView("v1WriteView", 
			 "1.3",       
			 "",             // Mask "" is same as 0xFFFFFFFFFF...
			 view_included,  // alternatively: view_excluded
			 storageType_nonVolatile);

        vacm->addNewView("v1NotifyView", 
			 "1.3",       
			 "",             // Mask "" is same as 0xFFFFFFFFFF...
			 view_included,  // alternatively: view_excluded
             storageType_nonVolatile);

        vacm->addNewView("newView", "1.3", "", 
			 view_included, storageType_nonVolatile);
        vacm->addNewView("testView", "1.3.6", "",
			 view_included, storageType_nonVolatile);
        vacm->addNewView("internet", "1.3.6.1","",
			 view_included, storageType_nonVolatile);
        vacm->addNewView("restricted", "1.3.6.1.2.1.1","",
			 view_included, storageType_nonVolatile);
        vacm->addNewView("restricted", "1.3.6.1.2.1.11","", 
			 view_included, storageType_nonVolatile);
        vacm->addNewView("restricted", "1.3.6.1.6.3.10.2.1","", 
			 view_included, storageType_nonVolatile);
        vacm->addNewView("restricted", "1.3.6.1.6.3.11.2.1","",
			 view_included, storageType_nonVolatile);
        vacm->addNewView("restricted", "1.3.6.1.6.3.15.1.1","", 
			 view_included, storageType_nonVolatile);

	// add SNMPv1/v2c community to v3 security name mapping
    OctetStr co("public");
	MibTableRow* row = snmpCommunityEntry::instance->
	    add_row(Oidx::from_string(co, FALSE));
	OctetStr tag("v1v2cPermittedManagers");
	snmpCommunityEntry::instance->
        set_row(row, co, co,                                 // community,security_name,
            reqList->get_v3mp()->get_local_engine_id(),      //engine_id,
            "", tag, 3, 1);                                  //context_name,transport_tag,

    OctetStr cow("private");
    MibTableRow* roww = snmpCommunityEntry::instance->
        add_row(Oidx::from_string(cow, FALSE));
    OctetStr tagw("v1v2cPermittedManagers");
    snmpCommunityEntry::instance->
        set_row(roww, cow, cow,                                 // community,security_name,
            reqList->get_v3mp()->get_local_engine_id(),      //engine_id,
            "", tagw, 3, 1);

#endif		

#ifdef _SNMPv3
	// register table size policies
	MibTableSizePolicy::register_policy(YFmib->get_default_context(),
					    &policy);
#endif
	// load persitent objects from disk
	YFmib->init();
	
	//YF  send trap  condigure
	Vbx* vbs = 0;
	coldStartOid coldOid;
	NotificationOriginator no;
	// add an example destination
//	cout << "please input address \n";
//	string YFaddString;
//	cin >> YFaddString;
    for(int i =0;i < YFargc;i++)
    {
        UdpAddress dest((YFargv[i] +":10162").toAscii());
    //	UdpAddress dest("192.168.43.93:162");
        no.add_v1_trap_destination(dest, "defaultV1Trap", "v1trap", "public");//v1trap为标签
    //	no.add_v2_trap_destination(dest, "defaultV2Trap", "v2trap", "public");//v1trap为标签
    }

	// send the notification
	YFmib->notify("", coldOid, vbs, 0);
//	YFmib->YF_notify("", coldOid, vbs, 0);
	//trap
//	vbs = new Vbx();
//	vbs->set_oid("1.3.6.1.1.4.1.1.1");
//	vbs->set_value(1);
//	YFmib->notify("","1.3.6.1.1.4.1.1.1.1.1.1.0",vbs,1);

	Request* req;
//    YFThread YFthreadSet(4);
    while (init_again && localrun) {

        while(isAgentWaiting == true);
        isUIWaiting = false;
        req = reqList->receive(2);


        if (req && !stopListen) {
            LOG_BEGIN(DEBUG_LOG | 1);
            LOG("received succeedly");
            LOG_END;
//			YFmib->YF_process_request(req);
            YFmib->process_request(req);
            txtOutPut<<req->get_address()->get_address().get_printable() << "  "<<req->get_type()<<endl;
            if(req->get_type() == sNMP_PDU_SET)
            {
                char tempvalue[OIDNUM];
                memset(tempvalue,0,OIDNUM);
                isGetNewNode = true;
                //add up ui thread-----------------
                for(int i =0;i < req->subrequests();i++)
                {
                    agentGetNode[i].POid = req->get_value(i).get_oid().get_printable();
                    req->get_value(i).get_value(tempvalue);
//                    agentGetNode[i].PSValue=tempvalue;

                    QTextCodec *utf8=QTextCodec::codecForName("UTF-8");
                    QTextCodec *gbk = QTextCodec::codecForName("GBK");

                    QTextCodec::setCodecForCStrings(gbk);
                    QString tmp=QString::fromStdString(tempvalue);
                    QTextCodec::setCodecForCStrings(utf8);
                    agentGetNode[i].PSValue=tmp.toLocal8Bit();

                    req->get_value(i).get_value(agentGetNode[i].PIValue);
                }
            }
        }
        else {
            YFmib->cleanup();
        }
        isUIWaiting = true;
	}
    YFmib->cleanup();
	Snmp::socket_cleanup();  // Shut down socket subsystem
	}
	return 0;
    Qfile.close();
}


void YFSnmpAgent::LocalSet()
{
    txtOutPut<<"LocalSet+1;"<<endl;
//    Vbx *vb = new Vbx[OIDNUM];
    int i;
    for(i = 0; i < setNodeNum&&i < OIDNUM;i++)
    {
        vbx[i].clear();
        vbx[i].set_oid(setNode[i].POid.toStdString().c_str());
        if(setNode[i].PSnytax == "Int")
            vbx[i].set_value(setNode[i].PIValue);
        else
        {
            QTextCodec *utf8=QTextCodec::codecForName("UTF-8");
            QTextCodec *gbk = QTextCodec::codecForName("GBK");

            QString tmp=QString::fromLocal8Bit(setNode[i].PSValue.toAscii());
            QTextCodec::setCodecForCStrings(gbk);
            vbx[i].set_value(tmp.toStdString().c_str());
            QTextCodec::setCodecForCStrings(utf8);
        }
    }
    int vbNum = i;
    Vbx *vb = &vbx[0];
    YFmib->YFLocalSet(vb,vbNum);
}

void YFSnmpAgent::LocalGet()
{
    txtOutPut<<"LocalSet+1;"<<endl;
    Vbx *vb = &vbx[0];
    for(int i = 0; i < setNodeNum&&i < OIDNUM;i++)
    {
        vbx[i].set_oid(setNode[i].POid.toStdString().c_str());
    }
    int vbNum = setNodeNum;
    YFmib->YFLocalGet(vb,vbNum);
    char tempvalue[OIDNUM];
    memset(tempvalue,0,OIDNUM);
    for(int i = 0; i < setNodeNum&&i < OIDNUM;i++)
    {
        if(setNode[i].PSnytax == "Int")
             vb[i].get_value(setNode[i].PIValue);
        else
        {
            vb[i].get_value(tempvalue);
            QTextCodec *utf8=QTextCodec::codecForName("UTF-8");
            QTextCodec *gbk = QTextCodec::codecForName("GBK");

            QTextCodec::setCodecForCStrings(gbk);
            QString tmp=QString::fromStdString(tempvalue);
            QTextCodec::setCodecForCStrings(utf8);
            setNode[i].PSValue=tmp.toLocal8Bit();
        }
    }
}

//must set value of setNode/setNodeNum befor useing this function
void YFSnmpAgent::trapto(string trapOID)
{
    txtOutPut<<"trap+1;"<<endl;
    Vbx *vb = new Vbx[OIDNUM];

    if(trapOID == "1.3.6.1.6.3.1.1.5.1")
    {
        coldStartOid coldOid;
        YFmib->notify("", coldOid, vb, 0);
    }
    else if(trapOID == "1.3.6.1.6.3.1.1.5.2")
    {
        warmStartOid warmOid;
        YFmib->notify("", warmOid, vb, 0);
    }
    else if(trapOID == "1.3.6.1.6.3.1.1.5.3")
    {
        linkDownOid lDownOid;
        YFmib->notify("", lDownOid, vb, 0);
    }
    else if(trapOID == "1.3.6.1.6.3.1.1.5.4")
    {
        linkUpOid lUpOid;
        YFmib->notify("", lUpOid, vb, 0);
    }
    else if(trapOID == "1.3.6.1.6.3.1.1.5.5")
    {
        authenticationFailureOid lUpOauthenticationFailureOidid;
        YFmib->notify("", lUpOauthenticationFailureOidid, vb, 0);
    }
    else if(trapOID == "1.3.6.1.6.3.1.1.5.6")
    {
        egpNeighborLossOid egpNeighborLossOidid;
        YFmib->notify("", egpNeighborLossOidid, vb, 0);
    }
    else
    {
        for(int i = 0; i < trapNodeNum&&i < OIDNUM;i++)
        {
            vb[i].set_oid(trapNode[i].POid.toStdString().c_str());
            if(trapNode[i].PSnytax == "Int")
                vb[i].set_value(trapNode[i].PIValue);
            else
                vb[i].set_value(trapNode[i].PSValue.toStdString().c_str());
        }
        int vbNum = trapNodeNum;

        YFmib->notify("",trapOID.c_str(),vb,vbNum);
    }
}
