﻿#ifndef COMMU_H
#define COMMU_H
#include<QTableWidget>
#include <QDialog>
#include<QString>
#include <QVector>
#include <QDialog>
#include "GlabalDefine.h"
#include "ui_Dlg_SetInner.h"
#include "vector"

using namespace std;

namespace Ui {
class commu;
}

class commu : public QDialog
{
    Q_OBJECT
    
public:
    explicit commu(QWidget *parent = 0);
    ~commu();

    QTableWidgetItem *clickitem;
     int flag1,flag2,flag3;
     QString str_EjectB;
     QString str_EjectH;
     QString str_EjectL;
     QString str_EjectAngle;
    // int	m_WayNo1;
    // int	m_WayNo2;
     //int	m_TimeSource;
     //QString	m_DataSavePath;
    // bool	m_MeasureEnable_va;
     //bool	m_T0Enable_va;
    // bool	m_WYDEnable_va;
     //QString	m_stMID_T;
     //int		m_RecvSocketTP;
    // int		m_SendSocketTP;

     //以下东西，都是与CNetCommu内容重叠，仅用于从文件中读出，显示在界面上。
     //	SocketSetting CTSock_1;
     //	SocketSetting CTSock_2;
     SocketSetting ZKSock;							//主控机的网络设置
     SocketSetting LocalCTSock_1;					//本地与监控机通信网口的设置1
     SocketSetting LocalCTSock_2;					//本地与监控机通信网口的设置2
     SocketSetting LocalZKSock;				//本地与主控通信网口的设置

     SocketSetting ZhuKongTaiSock_1;					//中心站（主控台）的网络设置(只关心IP)
     SocketSetting ZhuKongTaiSock_2;					//中心站（主控台）的网络设置(只关心IP)

     vector<SocketSetting> FZSock1;
     vector<SocketSetting> FZSock2;
     int FZSockNum;

     QVector<AddStruct> CTP2PSet;			//Socket配置（单播）
     QVector<AddStruct> CTMulSetSe;			//Socket配置（组播）发送
     QVector<AddStruct> CTMulSetRe;			//Socket配置（组播）接收
     QVector<DWORD> CTSrcSet;	//Socket配置（组播源）
     int				CTP2PNum;						//单播地址数目
     int				CTMulNumSe;						//组播地址数目
     int				CTMulNumRe;						//组播地址数目
     int				CTSrcNum;						//组播源地址数目

     int			INI_DATALENGTH_MEASURE;				//实算数据中数据区有效长度 = 32, 22+10
     int			INI_DATALENGTH_THEORY;				//引入数据中数据区有效长度 = 28
     int			INI_DATALENGTH_EXAM;				//时延测试数据区长度
     int			INI_DATALENGTH_T0;					//T0数据区长度
     int			INI_REVERSE_DATALENGTH;				//正式实算数据中最后保留的数据长度		Jerry 20110629
     QString		INI_REVERSE_DATACONTENT;			//正式实算数据中最后保留的数据内容	Jerry 20110629
     bool		Is_ZhuKongTai;						//分站与主控台之间是否通信
     int			INI_DATALENGTH_ZK;					//分站主控发送的数据长度
     int			INI_DATALENGTH_ZXZ;					//中心站主控发送的数据长度

     HEADERStruct	MeasureHEADER;						//实算数据帧头信息
     HEADERStruct	TimerSendHEADER;						//常时数据帧头信息(发送)
     HEADERStruct	TimerRecvHEADER;						//常时数据帧头信息(接收)
     HEADERStruct	ExamSendHEADER;						//时延测试帧头信息(发送)
     HEADERStruct	ExamRecvHEADER;						//时延测试帧头信息(接收)
     HEADERStruct	T0HEADER;								//T0数据帧头信息
     HEADERStruct	WYDHEADER[30];						//外部说明数据帧头信息

     double EjectPosB;								//发射点坐标
     double EjectPosL;
     double EjectPosH;
     double EjectAngle;								//发射角
     QString DataSavePath;							//数据保存路径
     TimeSourceType TimeSource;						//时统来源
     Sockettp		SendSocketTP;					//发送网络属性
     Sockettp		RecvSocketTP;					//接收网络属性


     void InitNetData();
     void InitHEADERData();
     void InitGeneralData();
     void UnInitData();

     Ui::commu *getui(){return ui;}
     Ui::commu *ui;
     Ui::CDlg_SetInner *setinnerui;
signals:
           void  wmuserapply();

public slots:
    void OnBnClickedButtonSetupMulsource();
    void OnButtonNewAdd1();
    void OnButtonDelAdd1();//删除一个单播监控机
    void OnButtonNewAdd2_1();//增加一个组播接收监控机
    void OnButtonDelAdd2_1();//删除一个组播接收监控机
    void OnButtonNewAdd2_2();//增加一个组播发送监控机
    void OnButtonDelAdd2_2();//删除一个组播发送监控机
    void OnBnClickedButtonSetupTip();//“更多”按键绑定
    void OnButtonSetPath();//设置保存路径
    void OnButtonSetupInner();//
    void OnButtonSetupSave();//保存并应用
    void OnButtonSetupApply();//应用
    void OnSetupCancel();//取消
    void setflag(QTableWidgetItem *it);

protected:


};

#endif // COMMU_H
