﻿#ifndef YFTHREAD_H
#define YFTHREAD_H

#include <QThread>

class YFThread : public QThread
{
    Q_OBJECT
public:
    explicit YFThread(int falg,QObject *parent = 0);
    void stop();
    long  OnTimer1HzThread();
    virtual void  OnReceiveThread();

protected:
    void run();
    volatile int threadFalg;

private:
    volatile bool stopped;

signals:

public slots:

};

#endif // YFTHREAD_H
