﻿#include "Dlg_MulResourceSet.h"
#include "ui_Dlg_MulResourceSet.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <WinDef.h>

CDlg_MulResourceSet::CDlg_MulResourceSet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CDlg_MulResourceSet)
{
    ui->setupUi(this);
   // connect(ui->okButton,SIGNAL(clicked()),this,SLOT(OnButtonCancel()));
}

CDlg_MulResourceSet::~CDlg_MulResourceSet()
{
    delete ui;
}

void CDlg_MulResourceSet::init()
{
    QString newAddr;
    int sourceIndex=0;

    ui->m_NewAddr->clear();

    for(sourceIndex=0; sourceIndex<pAddrLength; sourceIndex++)
    {
        unsigned long tmp;
        struct in_addr in_tmp;
        tmp=htonl(pAddr[sourceIndex]);
        in_tmp.s_addr=tmp;
        newAddr=inet_ntoa(in_tmp);
        ui->m_ExistSourceList->addItem(newAddr);
    }

    if (ui->m_ExistSourceList->count() >0)
    {
        ui->m_ExistSourceList->setCurrentRow(0);
    }
}

void CDlg_MulResourceSet::on_delButton_clicked()
{
    int nItem = 0;
    if(ui->m_ExistSourceList->count()>0)
        nItem = 0;
    else
        return;
    nItem = ui->m_ExistSourceList->currentRow();
    if(nItem<0)
    {
        TRACE("NO item selected\n");
    }
    else
    {
        ui->m_ExistSourceList->takeItem(nItem);//先清空之前的列表
    }
}

void CDlg_MulResourceSet::on_addButton_clicked()
{
    ui->m_ExistSourceList->addItem(ui->m_NewAddr->text());
    return;
}

void CDlg_MulResourceSet::on_okButton_clicked()
{
    double tempValue_D;
    DWORD tempValue_DW;
    QString newAddr;
    int sourceIndex=0;

    pAddrLength = ui->m_ExistSourceList->count();
    for(sourceIndex=0; sourceIndex<pAddrLength; sourceIndex++)
    {
        in_addr tempsoAdd;
        QListWidgetItem * newAddrItem=ui->m_ExistSourceList->item(sourceIndex);
        newAddr=newAddrItem->text();
        tempsoAdd.s_addr = inet_addr(newAddr.toAscii());
        tempValue_DW = ntohl(tempsoAdd.s_addr);
        pAddr[sourceIndex] = tempValue_DW;
    }
   accept();
}



