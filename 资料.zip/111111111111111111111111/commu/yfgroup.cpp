#include "yfgroup.h"


#include "string"
using namespace std;

#ifdef SNMP_PP_NAMESPACE
using namespace Snmp_pp;
#endif

#ifdef AGENTPP_NAMESPACE
namespace Agentpp {
#endif

//typedef enum { NOACCESS, READONLY, READWRITE, READCREATE } mib_access;
YFLeaf::YFLeaf(const Oidx& id, mib_access acc, NS_SNMP SnmpSyntax* pointer):
   MibLeaf(id, acc, pointer)
{

}

YFLeaf::YFLeaf(const Oidx& id): MibLeaf(id, READONLY, new SnmpInt32())
{
//	this->set_value(1);
}

YFLeaf::YFLeaf(const Oidx& id,mib_access acc): MibLeaf(id, acc, new SnmpInt32())
{
//	this->set_value(1);
}

YFLeaf::~YFLeaf()
{
}

long YFLeaf::get_state()
{
	return (long)*((SnmpInt32*)value);
}


void YFLeaf::set_state(long l)
{

	//--AgentGen BEGIN=agentppNotifyTest::set_state
	//--AgentGen END
	*((SnmpInt32*)value) = l;
}

int YFLeaf::set(const Vbx& vb)
{
	//--AgentGen BEGIN=agentppNotifyTest::set
	long v;
	vb.get_value(v);
//	switch (v) {
//	case e_agentppNotifyTestAllTypes:
//	  send_agentppNotifyTestAllTypes();
//	  break;
//	}
	*((SnmpInt32*)value) = v;
	//--AgentGen END
	return MibLeaf::set(vb);
}

boolean YFLeaf::value_ok(const Vbx& vb)
{
	long v;
	vb.get_value(v);
//	if ((v != 1)
//	    ) return FALSE;

	//--AgentGen BEGIN=agentppNotifyTest::value_ok
	//--AgentGen END
	return TRUE;
}

int YFLeaf::YFLocalSetRequest(Request* req, int& ind)
{
//	if (get_access() >= READWRITE) {
		if (value->get_syntax() == req->get_value(ind).get_syntax()) {
			if (value_ok(req->get_value(ind))) {
			  // check if column must be locked while rowStatus is
			  // active
				if ((is_locked()) && (my_row) &&
				    (my_row->get_row_status())) {
					if (my_row->get_row_status()->get() !=
					    rowActive)
					  return SNMP_ERROR_SUCCESS;
					else
					  return SNMP_ERROR_INCONSIST_VAL;
				}
				return SNMP_ERROR_SUCCESS;
			}
			else return SNMP_ERROR_WRONG_VALUE;
		}
		else return SNMP_ERROR_WRONG_TYPE;
//	}
//	return SNMP_ERROR_NOT_WRITEABLE;
}

int YFLeaf::prepare_set_request(Request* req, int& ind)
{
	int status;
	UdpAddress inaddr("127.0.0.1");
	string a( (char*)req->get_address()->get_address().get_printable());
	string b ((char*)inaddr.get_printable());
	if(a.substr(0,9) == b.substr(0,9))
	{
		if ((status = YFLeaf::YFLocalSetRequest(req, ind)) !=
			    SNMP_ERROR_SUCCESS) return status;
	}
	else
	{
		if ((status = MibLeaf::prepare_set_request(req, ind)) !=
	    SNMP_ERROR_SUCCESS) return status;
	}

	//--AgentGen BEGIN=agentppNotifyTest::prepare_set_request
	//--AgentGen END
	return SNMP_ERROR_SUCCESS;
}

MibEntryPtr YFLeaf::clone()
{
	MibEntryPtr other = new YFLeaf(oid);
	((YFLeaf*)other)->replace_value(value->clone());
	((YFLeaf*)other)->set_reference_to_table(my_table);
	return other;
}

//boolean YFLeaf::value_ok(const Vbx& vb)
//{
//	long v;
//	vb.get_value(v);
//	if (!(((v >= 0) && (v <= 4096))))
//		 return FALSE;
//	// place additional code to check validity of new values here
//	return TRUE;
//}

//int YFLeaf::prepare_set_request(Request* req, int& ind)
//{
//	int status;
//	if ((status = SimMibLeaf::prepare_set_request(req, ind)) !=
//	    SNMP_ERROR_SUCCESS) return status;
//	// place additional code to check validity of new values here
//	return SNMP_ERROR_SUCCESS;
//}

//typedef enum { NOACCESS, READONLY, READWRITE, READCREATE } mib_access;
YFSLeaf::YFSLeaf(const Oidx& id, mib_access acc, NS_SNMP SnmpSyntax* pointer):
   MibLeaf(id, acc, pointer)
{

}

YFSLeaf::YFSLeaf(const Oidx& id): MibLeaf(id, READONLY, new OctetStr())
{
//	this->set_value(1);
}

YFSLeaf::YFSLeaf(const Oidx& id,mib_access acc): MibLeaf(id, acc, new OctetStr())
{
//	this->set_value(1);
}

YFSLeaf::~YFSLeaf()
{
}

OctetStr YFSLeaf::get_state()
{
	return  *((OctetStr*)value);
}


void YFSLeaf::set_state(const OctetStr& s)
{

	*((OctetStr*)value) = s;
}

int YFSLeaf::set(const Vbx& vb)
{
	//--AgentGen BEGIN=agentppNotifyTest::set
	OctetStr v;
	vb.get_value(v);
//	switch (v) {
//	case e_agentppNotifyTestAllTypes:
//	  send_agentppNotifyTestAllTypes();
//	  break;
//	}
	*((OctetStr*)value) = v;
	//--AgentGen END
	return MibLeaf::set(vb);
}

boolean YFSLeaf::value_ok(const Vbx& vb)
{
	OctetStr v;
	vb.get_value(v);
//	if ((v != 1)
//	    ) return FALSE;

	//--AgentGen BEGIN=agentppNotifyTest::value_ok
	//--AgentGen END
	return TRUE;
}

int YFSLeaf::YFLocalSetRequest(Request* req, int& ind)
{
//	if (get_access() >= READWRITE) {
		if (value->get_syntax() == req->get_value(ind).get_syntax()) {
			if (value_ok(req->get_value(ind))) {
			  // check if column must be locked while rowStatus is
			  // active
				if ((is_locked()) && (my_row) &&
				    (my_row->get_row_status())) {
					if (my_row->get_row_status()->get() !=
					    rowActive)
					  return SNMP_ERROR_SUCCESS;
					else
					  return SNMP_ERROR_INCONSIST_VAL;
				}
				return SNMP_ERROR_SUCCESS;
			}
			else return SNMP_ERROR_WRONG_VALUE;
		}
		else return SNMP_ERROR_WRONG_TYPE;
//	}
//	return SNMP_ERROR_NOT_WRITEABLE;
}

int YFSLeaf::prepare_set_request(Request* req, int& ind)
{
	int status;
	UdpAddress inaddr("127.0.0.1");
	string a( (char*)req->get_address()->get_address().get_printable());
	string b ((char*)inaddr.get_printable());
	if(a.substr(0,9) == b.substr(0,9))
	{
		if ((status = YFSLeaf::YFLocalSetRequest(req, ind)) !=
				  SNMP_ERROR_SUCCESS) return status;
	}
	else
	{
		if ((status = MibLeaf::prepare_set_request(req, ind)) !=
		    SNMP_ERROR_SUCCESS) return status;
	}


	//--AgentGen BEGIN=agentppNotifyTest::prepare_set_request
	//--AgentGen END
	return SNMP_ERROR_SUCCESS;
}

MibEntryPtr YFSLeaf::clone()
{
	MibEntryPtr other = new YFSLeaf(oid);
	((YFSLeaf*)other)->replace_value(value->clone());
	((YFSLeaf*)other)->set_reference_to_table(my_table);
	return other;
}



YFGroup::YFGroup(const Oidx& id, const NS_SNMP OctetStr& name): MibGroup(id,name)
{
//	add(new YFLeaf("1.3.6.1.1.4.1.1.1"));
//	add(new YFLeaf());
//	add(new atmInterfaceDs3PlcpEntry());
//	add(new atmInterfaceTCEntry());
//	add(new atmTrafficDescrParamEntry());
//	add(new atmVplEntry());
//	add(new atmVclEntry());
//	add(new atmVpCrossConnectIndexNext());
//	add(new atmVpCrossConnectEntry());
//	add(new atmVcCrossConnectIndexNext());
//	add(new atmVcCrossConnectEntry());
//	add(new aal5VccEntry());
//	add(new atmTrafficDescrParamIndexNext());
}

YFGroup::YFGroup(const Oidx& id, const NS_SNMP OctetStr& name,YFLeaf* yfleaf): MibGroup(id,name)
{
	add(yfleaf);
}

#ifdef AGENTPP_NAMESPACE
}
#endif

