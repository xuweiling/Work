﻿#include "Dlg_SetInner.h"
#include "ui_Dlg_SetInner.h"
#include "arpa/inet.h"

#define OK 12

CDlg_SetInner::CDlg_SetInner(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CDlg_SetInner)
{
    ui->setupUi(this);
    connect(ui->CancleButton,SIGNAL(clicked()),this,SLOT(OnButtonCancel()));

    ui->FZtable->setColumnCount(2); //设置列数
    ui->FZtable->setSortingEnabled(false);
    ui->FZtable->setSelectionBehavior(QAbstractItemView::SelectRows); //设置选择行为时每次选择一行
    ui->FZtable->setEditTriggers(QAbstractItemView::NoEditTriggers); //设置不可编辑

    QStringList header;
    header << tr("第一路由")<< tr("第二路由");
    ui->FZtable->setHorizontalHeaderLabels(header);

    FZSet1.clear();
    FZSet2.clear();
}

CDlg_SetInner::~CDlg_SetInner()
{
    delete ui;
}

void CDlg_SetInner::init()
{
    QString add_tmp;
    unsigned long tmp;
    struct in_addr in_tmp;
    QString ipTmp[2];

    ui->m_Is_ZhuKongTai->setChecked(isZK);

    tmp=htonl(Addr_1);
    in_tmp.s_addr=tmp;
    add_tmp=inet_ntoa(in_tmp);
    ui->m_CT_IP1->setText(add_tmp);
    ipTmp[0]=add_tmp;

    tmp=htonl(Addr_2);
    in_tmp.s_addr=tmp;
    add_tmp=inet_ntoa(in_tmp);
    ui->m_CT_IP2->setText(add_tmp);
    ipTmp[1]=add_tmp;

//    QTableWidgetItem *item1= new QTableWidgetItem();
//    QTableWidgetItem *item2= new QTableWidgetItem();
//    int row_count = ui->FZtable->rowCount(); //获取表单行数
//    ui->FZtable->insertRow(row_count); //插入新行
//    item1->setText(ipTmp[0]);
//    ui->FZtable->setItem(row_count, 0, item1);
//    item2->setText(ipTmp[1]);
//    ui->FZtable->setItem(row_count, 1, item2);

    for(int i=0;i<FZNum;i++)
    {
        tmp=htonl(FZSet1[i]);
        in_tmp.s_addr=tmp;
        add_tmp=inet_ntoa(in_tmp);
        ipTmp[0]=add_tmp;

        tmp=htonl(FZSet2[i]);
        in_tmp.s_addr=tmp;
        add_tmp=inet_ntoa(in_tmp);
        ipTmp[1]=add_tmp;

        QTableWidgetItem *item1= new QTableWidgetItem();
        QTableWidgetItem *item2= new QTableWidgetItem();
        int row_count = ui->FZtable->rowCount(); //获取表单行数
        ui->FZtable->insertRow(row_count); //插入新行
        item1->setText(ipTmp[0]);
        ui->FZtable->setItem(row_count, 0, item1);
        item2->setText(ipTmp[1]);
        ui->FZtable->setItem(row_count, 1, item2);
    }

}

void CDlg_SetInner::on_okButton_clicked()
{
    DWORD tempValue_DW;
    QString newAddr;
    in_addr tempsoAdd;
    QTableWidgetItem *item1= new QTableWidgetItem();
    QTableWidgetItem *item2= new QTableWidgetItem();

    newAddr=ui->m_CT_IP1->text();
    tempsoAdd.s_addr = inet_addr(newAddr.toAscii());
    tempValue_DW = ntohl(tempsoAdd.s_addr);
    Addr_1 = tempValue_DW;

    newAddr=ui->m_CT_IP2->text();
    tempsoAdd.s_addr = inet_addr(newAddr.toAscii());
    tempValue_DW = ntohl(tempsoAdd.s_addr);
    Addr_2 = tempValue_DW;

    FZNum=ui->FZtable->rowCount();
    FZSet1.resize(FZNum);
    FZSet2.resize(FZNum);
    for(int i=0;i<FZNum;i++)
    {
        item1=ui->FZtable->item(i,0);
        newAddr=item1->text();
        tempsoAdd.s_addr = inet_addr(newAddr.toAscii());
        tempValue_DW = ntohl(tempsoAdd.s_addr);
        FZSet1[i] = tempValue_DW;

        item2=ui->FZtable->item(i,1);
        newAddr=item2->text();
        tempsoAdd.s_addr = inet_addr(newAddr.toAscii());
        tempValue_DW = ntohl(tempsoAdd.s_addr);
        FZSet2[i] = tempValue_DW;
    }

    done(OK);
}


void CDlg_SetInner::OnButtonCancel()
{
    accept();
}

void CDlg_SetInner::on_ipAdd_clicked()
{
    QString newAddr;
    QTableWidgetItem *item1= new QTableWidgetItem();
    QTableWidgetItem *item2= new QTableWidgetItem();

    //刷新显示
    int row_count = ui->FZtable->rowCount(); //获取表单行数
    ui->FZtable->insertRow(row_count); //插入新行
    newAddr=ui->m_CT_IP1->text();
    item1->setText(newAddr);
    ui->FZtable->setItem(row_count, 0, item1);
    newAddr=ui->m_CT_IP2->text();
    item2->setText(newAddr);
    ui->FZtable->setItem(row_count, 1, item2);
}

void CDlg_SetInner::on_ipDelete_clicked()
{
    //刷新显示
    int currentRow=ui->FZtable->currentRow();
    ui->FZtable->removeRow(currentRow);
}
