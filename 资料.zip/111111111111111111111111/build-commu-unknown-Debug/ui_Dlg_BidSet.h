/********************************************************************************
** Form generated from reading UI file 'Dlg_BidSet.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DLG_BIDSET_H
#define UI_DLG_BIDSET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_CDlg_BIDSet
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QListWidget *m_ExistBIDList;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_6;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *cancleButton;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *delButton;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_7;
    QLineEdit *m_NewBID_va;
    QPushButton *addButton;
    QSpacerItem *horizontalSpacer_8;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *okButton;
    QLabel *label;

    void setupUi(QDialog *CDlg_BIDSet)
    {
        if (CDlg_BIDSet->objectName().isEmpty())
            CDlg_BIDSet->setObjectName(QString::fromUtf8("CDlg_BIDSet"));
        CDlg_BIDSet->resize(358, 369);
        verticalLayout_2 = new QVBoxLayout(CDlg_BIDSet);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_2 = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        m_ExistBIDList = new QListWidget(CDlg_BIDSet);
        m_ExistBIDList->setObjectName(QString::fromUtf8("m_ExistBIDList"));

        horizontalLayout->addWidget(m_ExistBIDList);

        horizontalSpacer = new QSpacerItem(18, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_6 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_6);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        cancleButton = new QPushButton(CDlg_BIDSet);
        cancleButton->setObjectName(QString::fromUtf8("cancleButton"));
        cancleButton->setEnabled(false);

        horizontalLayout_2->addWidget(cancleButton);

        horizontalSpacer_3 = new QSpacerItem(68, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        delButton = new QPushButton(CDlg_BIDSet);
        delButton->setObjectName(QString::fromUtf8("delButton"));

        horizontalLayout_2->addWidget(delButton);


        horizontalLayout_3->addLayout(horizontalLayout_2);

        horizontalSpacer_5 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(29);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_7 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_7);

        m_NewBID_va = new QLineEdit(CDlg_BIDSet);
        m_NewBID_va->setObjectName(QString::fromUtf8("m_NewBID_va"));

        horizontalLayout_4->addWidget(m_NewBID_va);

        addButton = new QPushButton(CDlg_BIDSet);
        addButton->setObjectName(QString::fromUtf8("addButton"));

        horizontalLayout_4->addWidget(addButton);

        horizontalSpacer_8 = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_8);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_4 = new QSpacerItem(208, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_4);

        okButton = new QPushButton(CDlg_BIDSet);
        okButton->setObjectName(QString::fromUtf8("okButton"));

        horizontalLayout_5->addWidget(okButton);


        verticalLayout->addLayout(horizontalLayout_5);

        label = new QLabel(CDlg_BIDSet);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(CDlg_BIDSet);

        QMetaObject::connectSlotsByName(CDlg_BIDSet);
    } // setupUi

    void retranslateUi(QDialog *CDlg_BIDSet)
    {
        CDlg_BIDSet->setWindowTitle(QApplication::translate("CDlg_BIDSet", "Dialog", 0, QApplication::UnicodeUTF8));
        cancleButton->setText(QApplication::translate("CDlg_BIDSet", "Cancle", 0, QApplication::UnicodeUTF8));
        delButton->setText(QApplication::translate("CDlg_BIDSet", "\345\210\240\351\231\244\351\200\211\344\270\255", 0, QApplication::UnicodeUTF8));
        m_NewBID_va->setText(QString());
        addButton->setText(QApplication::translate("CDlg_BIDSet", "\345\212\240\345\205\245\345\210\227\350\241\250", 0, QApplication::UnicodeUTF8));
        okButton->setText(QApplication::translate("CDlg_BIDSet", "\345\205\263\351\227\255", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CDlg_BIDSet", "\344\273\205\346\224\257\346\214\20121\344\270\252BID,\345\205\266\344\275\231\350\247\201\345\217\202\346\225\260\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CDlg_BIDSet: public Ui_CDlg_BIDSet {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DLG_BIDSET_H
