﻿#ifndef DLG_MULRESOURCESET_H
#define DLG_MULRESOURCESET_H

#include <QDialog>
#include "WinDef.h"

namespace Ui {
class CDlg_MulResourceSet;
}

class CDlg_MulResourceSet : public QDialog
{
    Q_OBJECT

public:
    explicit CDlg_MulResourceSet(QWidget *parent = 0);
    ~CDlg_MulResourceSet();
    void init();

    int pAddrLength;
    DWORD pAddr[500];

private slots:

    void on_delButton_clicked();

    void on_addButton_clicked();

    void on_okButton_clicked();

 //   void OnButtonCancel();

private:
    Ui::CDlg_MulResourceSet *ui;
};

#endif // DLG_MULRESOURCESET_H
