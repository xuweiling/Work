/********************************************************************************
** Form generated from reading UI file 'yfmainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YFMAINWINDOW_H
#define UI_YFMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_YFMainWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QLineEdit *sx1;
    QLabel *label_4;
    QGroupBox *groupBox_5;
    QLineEdit *sx4;
    QLabel *label_9;
    QGroupBox *groupBox_3;
    QLineEdit *sx2;
    QLabel *label_5;
    QGroupBox *groupBox_4;
    QLineEdit *sx3;
    QLabel *label_6;
    QGroupBox *groupBox_18;
    QLineEdit *sx8;
    QLabel *label_20;
    QGroupBox *groupBox_8;
    QLineEdit *sx7;
    QLabel *label_12;
    QGroupBox *groupBox_6;
    QLineEdit *sx5;
    QLabel *label_10;
    QGroupBox *groupBox_9;
    QLineEdit *sx9;
    QLabel *label_13;
    QGroupBox *groupBox_7;
    QLineEdit *sx6;
    QLabel *label_11;
    QGroupBox *groupBox_10;
    QGroupBox *groupBox_11;
    QLineEdit *bs1;
    QLabel *label_7;
    QGroupBox *groupBox_14;
    QLineEdit *bs6;
    QLabel *label_17;
    QGroupBox *groupBox_15;
    QLineEdit *bs3;
    QLabel *label_8;
    QGroupBox *groupBox_19;
    QLineEdit *bs7;
    QLabel *label_21;
    QGroupBox *groupBox_12;
    QLineEdit *bs5;
    QLabel *label_14;
    QGroupBox *groupBox_13;
    QLabel *label_15;
    QLineEdit *bs4;
    QGroupBox *groupBox_16;
    QLineEdit *trapID_16;
    QLabel *label_18;
    QCheckBox *checkBox;
    QGroupBox *groupBox_17;
    QLineEdit *bs2;
    QLabel *label_19;
    QGroupBox *groupBox_20;
    QLineEdit *trapID_13;
    QLabel *label_16;
    QGroupBox *groupBox_21;
    QLineEdit *bs8;
    QLabel *label_22;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QLineEdit *bs9;
    QLineEdit *bs10;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_24;
    QLabel *label_26;
    QGroupBox *groupBox_22;
    QGroupBox *groupBox_31;
    QLineEdit *zt4;
    QLabel *label_34;
    QGroupBox *groupBox_30;
    QLabel *label_33;
    QLineEdit *zt5;
    QGroupBox *groupBox_24;
    QLineEdit *zt3;
    QLabel *label_27;
    QGroupBox *groupBox_23;
    QLineEdit *zt1;
    QLabel *label_25;
    QGroupBox *groupBox_29;
    QLineEdit *zt2;
    QLabel *label_31;
    QGroupBox *groupBox_33;
    QGroupBox *groupBox_34;
    QLineEdit *gl3;
    QLabel *label_36;
    QLineEdit *gl4;
    QLabel *label_38;
    QGroupBox *groupBox_35;
    QLabel *label_23;
    QLineEdit *gl1;
    QGroupBox *groupBox_36;
    QLineEdit *gl2;
    QLabel *label_37;
    QGroupBox *groupBox_37;
    QLabel *label_30;
    QLabel *label_32;
    QLabel *label_39;
    QLabel *label_40;
    QLabel *label_42;
    QLabel *label_43;
    QLabel *label_44;
    QLabel *label_45;
    QLineEdit *yh1;
    QLineEdit *yh2;
    QLineEdit *yh3;
    QLineEdit *yh4;
    QLineEdit *yh5;
    QLineEdit *yh6;
    QLineEdit *yh7;
    QLineEdit *yh8;
    QPushButton *UpUIFromAgent;
    QGroupBox *groupBox_77;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout_3;
    QComboBox *B1_1;
    QComboBox *B1_2;
    QComboBox *B2_1;
    QComboBox *B2_2;
    QComboBox *B3_1;
    QComboBox *B3_2;
    QComboBox *B3_3;
    QComboBox *B3_4;
    QWidget *layoutWidget3;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_131;
    QLabel *label_130;
    QLabel *label_129;
    QLabel *label_128;
    QLabel *label_126;
    QLabel *label_127;
    QLabel *label_125;
    QLabel *label_124;
    QGroupBox *groupBox_76;
    QLabel *label_116;
    QLabel *label_117;
    QLabel *label_118;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_5;
    QComboBox *B4_1_3;
    QComboBox *B4_2_3;
    QComboBox *B4_3_3;
    QComboBox *B4_4_3;
    QComboBox *B5_1_3;
    QComboBox *B5_2_3;
    QComboBox *B5_3_3;
    QComboBox *B5_4_3;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_6;
    QComboBox *B4_1_2;
    QComboBox *B4_2_2;
    QComboBox *B4_3_2;
    QComboBox *B4_4_2;
    QComboBox *B5_1_2;
    QComboBox *B5_2_2;
    QComboBox *B5_3_2;
    QComboBox *B5_4_2;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_7;
    QComboBox *B4_1_4;
    QComboBox *B4_2_4;
    QComboBox *B4_3_4;
    QComboBox *B4_4_4;
    QComboBox *B5_1_4;
    QComboBox *B5_2_4;
    QComboBox *B5_3_4;
    QComboBox *B5_4_4;
    QWidget *layoutWidget_4;
    QHBoxLayout *horizontalLayout_8;
    QComboBox *B4_1_5;
    QComboBox *B4_2_5;
    QComboBox *B4_3_5;
    QComboBox *B4_4_5;
    QComboBox *B5_1_5;
    QComboBox *B5_2_5;
    QComboBox *B5_3_5;
    QComboBox *B5_4_5;
    QWidget *layoutWidget_5;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLabel *label_120;
    QLabel *label_121;
    QLabel *label_122;
    QLabel *label_123;
    QLabel *label_119;
    QWidget *layoutWidget_6;
    QHBoxLayout *horizontalLayout_11;
    QComboBox *B4_1_1;
    QComboBox *B4_2_1;
    QComboBox *B4_3_1;
    QComboBox *B4_4_1_;
    QComboBox *B5_1_1;
    QComboBox *B5_2_1;
    QComboBox *B5_3_1;
    QComboBox *B5_4_1;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_9;
    QLineEdit *B4_1_6;
    QLineEdit *B4_2_6;
    QLineEdit *B4_3_6;
    QLineEdit *B4_4_6;
    QLineEdit *B5_1_6;
    QLineEdit *B5_2_6;
    QLineEdit *B5_3_6;
    QLineEdit *B5_4_6;
    QLabel *label_136;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_28;
    QLabel *label_29;
    QWidget *layoutWidget6;
    QVBoxLayout *verticalLayout_7;
    QComboBox *A1;
    QComboBox *A2;
    QComboBox *A3;
    QComboBox *A4;
    QComboBox *A5;
    QComboBox *A6;
    QComboBox *A7;
    QWidget *layoutWidget7;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_52;
    QLabel *label_53;
    QLabel *label_47;
    QLabel *label_46;
    QLabel *label_48;
    QLabel *label_35;
    QLabel *label_54;
    QWidget *layoutWidget8;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_55;
    QLabel *label_56;
    QLabel *label_57;
    QLabel *label_58;
    QLabel *label_59;
    QLabel *label_60;
    QLabel *label_61;
    QWidget *layoutWidget9;
    QVBoxLayout *verticalLayout_9;
    QComboBox *A8;
    QComboBox *A9;
    QComboBox *A10;
    QComboBox *A11;
    QComboBox *A12;
    QComboBox *A13;
    QComboBox *A14;
    QWidget *layoutWidget10;
    QHBoxLayout *horizontalLayout_4;
    QCheckBox *checkBox_2;
    QLabel *label_41;
    QLineEdit *trapID_43;
    QWidget *layoutWidget11;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_49;
    QListWidget *listWidget;
    QWidget *layoutWidget12;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *writeagent;
    QPushButton *reset;
    QPushButton *traptest;
    QWidget *layoutWidget13;
    QHBoxLayout *horizontalLayout;
    QPushButton *stopAgent;
    QPushButton *startAgent;
    QPushButton *quitAgent;
    QLineEdit *readcommunity;
    QLabel *label_51;
    QLabel *label_50;
    QLineEdit *redcommunity;
    QWidget *tab_2;
    QPushButton *ModifyButton_2;
    QPushButton *DeleteButton_2;
    QPushButton *AddButton_2;
    QPushButton *ReadFButton;
    QPushButton *WriteFile;
    QListWidget *ShowList_2;
    QGroupBox *groupBox_75;
    QCheckBox *checkBox_6;
    QLineEdit *yh5_6;
    QLabel *label_110;
    QLineEdit *yh5_7;
    QLabel *label_111;
    QLineEdit *yh5_8;
    QLabel *label_112;
    QPushButton *pushButton_2;
    QGroupBox *groupBox_66;
    QGroupBox *groupBox_67;
    QLineEdit *trapID_29;
    QLabel *label_91;
    QLineEdit *trapID_31;
    QLineEdit *trapID_39;
    QGroupBox *groupBox_68;
    QLineEdit *trapID_32;
    QLabel *label_92;
    QGroupBox *groupBox_69;
    QLabel *label_93;
    QLineEdit *trapID_34;
    QLineEdit *trapID_35;
    QLineEdit *trapID_40;
    QLabel *label_94;
    QLabel *label_95;
    QLabel *label_96;
    QWidget *layoutWidget14;
    QHBoxLayout *horizontalLayout_10;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *YFMainWindow)
    {
        if (YFMainWindow->objectName().isEmpty())
            YFMainWindow->setObjectName(QString::fromUtf8("YFMainWindow"));
        YFMainWindow->resize(1861, 849);
        centralWidget = new QWidget(YFMainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 1481, 801));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(40, 20, 291, 281));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 20, 281, 21));
        sx1 = new QLineEdit(groupBox_2);
        sx1->setObjectName(QString::fromUtf8("sx1"));
        sx1->setGeometry(QRect(70, 0, 201, 21));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(0, 0, 67, 17));
        groupBox_5 = new QGroupBox(groupBox);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(10, 110, 281, 21));
        sx4 = new QLineEdit(groupBox_5);
        sx4->setObjectName(QString::fromUtf8("sx4"));
        sx4->setGeometry(QRect(70, 0, 201, 21));
        label_9 = new QLabel(groupBox_5);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(0, 0, 67, 17));
        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 50, 281, 21));
        sx2 = new QLineEdit(groupBox_3);
        sx2->setObjectName(QString::fromUtf8("sx2"));
        sx2->setGeometry(QRect(70, 0, 201, 21));
        label_5 = new QLabel(groupBox_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(0, 0, 67, 17));
        groupBox_4 = new QGroupBox(groupBox);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(10, 80, 281, 21));
        sx3 = new QLineEdit(groupBox_4);
        sx3->setObjectName(QString::fromUtf8("sx3"));
        sx3->setGeometry(QRect(70, 0, 201, 21));
        label_6 = new QLabel(groupBox_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(0, 0, 67, 17));
        groupBox_18 = new QGroupBox(groupBox);
        groupBox_18->setObjectName(QString::fromUtf8("groupBox_18"));
        groupBox_18->setGeometry(QRect(10, 230, 301, 21));
        sx8 = new QLineEdit(groupBox_18);
        sx8->setObjectName(QString::fromUtf8("sx8"));
        sx8->setGeometry(QRect(70, 0, 201, 21));
        label_20 = new QLabel(groupBox_18);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(0, 0, 67, 17));
        groupBox_8 = new QGroupBox(groupBox);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setGeometry(QRect(10, 200, 291, 21));
        sx7 = new QLineEdit(groupBox_8);
        sx7->setObjectName(QString::fromUtf8("sx7"));
        sx7->setGeometry(QRect(70, 0, 201, 21));
        label_12 = new QLabel(groupBox_8);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(0, 0, 67, 17));
        groupBox_6 = new QGroupBox(groupBox);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setGeometry(QRect(10, 140, 281, 21));
        sx5 = new QLineEdit(groupBox_6);
        sx5->setObjectName(QString::fromUtf8("sx5"));
        sx5->setGeometry(QRect(70, 0, 201, 21));
        label_10 = new QLabel(groupBox_6);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(0, 0, 67, 17));
        groupBox_9 = new QGroupBox(groupBox);
        groupBox_9->setObjectName(QString::fromUtf8("groupBox_9"));
        groupBox_9->setGeometry(QRect(10, 260, 301, 21));
        sx9 = new QLineEdit(groupBox_9);
        sx9->setObjectName(QString::fromUtf8("sx9"));
        sx9->setGeometry(QRect(70, 0, 201, 21));
        label_13 = new QLabel(groupBox_9);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(0, 0, 67, 17));
        groupBox_7 = new QGroupBox(groupBox);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setGeometry(QRect(10, 170, 281, 21));
        sx6 = new QLineEdit(groupBox_7);
        sx6->setObjectName(QString::fromUtf8("sx6"));
        sx6->setGeometry(QRect(70, 0, 201, 21));
        label_11 = new QLabel(groupBox_7);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(0, 0, 67, 17));
        groupBox_10 = new QGroupBox(tab);
        groupBox_10->setObjectName(QString::fromUtf8("groupBox_10"));
        groupBox_10->setGeometry(QRect(40, 320, 291, 331));
        groupBox_11 = new QGroupBox(groupBox_10);
        groupBox_11->setObjectName(QString::fromUtf8("groupBox_11"));
        groupBox_11->setGeometry(QRect(20, 30, 271, 21));
        bs1 = new QLineEdit(groupBox_11);
        bs1->setObjectName(QString::fromUtf8("bs1"));
        bs1->setGeometry(QRect(100, 0, 161, 21));
        label_7 = new QLabel(groupBox_11);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(0, 0, 101, 17));
        groupBox_14 = new QGroupBox(groupBox_10);
        groupBox_14->setObjectName(QString::fromUtf8("groupBox_14"));
        groupBox_14->setGeometry(QRect(20, 180, 271, 21));
        bs6 = new QLineEdit(groupBox_14);
        bs6->setObjectName(QString::fromUtf8("bs6"));
        bs6->setGeometry(QRect(100, 0, 161, 21));
        label_17 = new QLabel(groupBox_14);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(0, 0, 67, 17));
        groupBox_15 = new QGroupBox(groupBox_10);
        groupBox_15->setObjectName(QString::fromUtf8("groupBox_15"));
        groupBox_15->setGeometry(QRect(20, 90, 271, 21));
        bs3 = new QLineEdit(groupBox_15);
        bs3->setObjectName(QString::fromUtf8("bs3"));
        bs3->setGeometry(QRect(100, 0, 161, 21));
        label_8 = new QLabel(groupBox_15);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(0, 0, 67, 17));
        groupBox_19 = new QGroupBox(groupBox_10);
        groupBox_19->setObjectName(QString::fromUtf8("groupBox_19"));
        groupBox_19->setGeometry(QRect(20, 210, 271, 21));
        bs7 = new QLineEdit(groupBox_19);
        bs7->setObjectName(QString::fromUtf8("bs7"));
        bs7->setGeometry(QRect(100, 0, 161, 21));
        label_21 = new QLabel(groupBox_19);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(0, 0, 67, 17));
        groupBox_12 = new QGroupBox(groupBox_10);
        groupBox_12->setObjectName(QString::fromUtf8("groupBox_12"));
        groupBox_12->setGeometry(QRect(20, 150, 271, 21));
        bs5 = new QLineEdit(groupBox_12);
        bs5->setObjectName(QString::fromUtf8("bs5"));
        bs5->setGeometry(QRect(100, 0, 161, 21));
        label_14 = new QLabel(groupBox_12);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(0, 0, 67, 17));
        groupBox_13 = new QGroupBox(groupBox_10);
        groupBox_13->setObjectName(QString::fromUtf8("groupBox_13"));
        groupBox_13->setGeometry(QRect(20, 120, 271, 21));
        label_15 = new QLabel(groupBox_13);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(0, 0, 67, 17));
        bs4 = new QLineEdit(groupBox_13);
        bs4->setObjectName(QString::fromUtf8("bs4"));
        bs4->setGeometry(QRect(100, 0, 161, 21));
        groupBox_16 = new QGroupBox(groupBox_10);
        groupBox_16->setObjectName(QString::fromUtf8("groupBox_16"));
        groupBox_16->setGeometry(QRect(50, 330, 281, 21));
        trapID_16 = new QLineEdit(groupBox_16);
        trapID_16->setObjectName(QString::fromUtf8("trapID_16"));
        trapID_16->setGeometry(QRect(100, 0, 101, 21));
        label_18 = new QLabel(groupBox_16);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(0, 0, 91, 17));
        checkBox = new QCheckBox(groupBox_16);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(200, 0, 61, 20));
        groupBox_17 = new QGroupBox(groupBox_10);
        groupBox_17->setObjectName(QString::fromUtf8("groupBox_17"));
        groupBox_17->setGeometry(QRect(20, 60, 271, 21));
        bs2 = new QLineEdit(groupBox_17);
        bs2->setObjectName(QString::fromUtf8("bs2"));
        bs2->setGeometry(QRect(100, 0, 161, 21));
        label_19 = new QLabel(groupBox_17);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(0, 0, 67, 17));
        groupBox_20 = new QGroupBox(groupBox_10);
        groupBox_20->setObjectName(QString::fromUtf8("groupBox_20"));
        groupBox_20->setGeometry(QRect(50, 360, 251, 21));
        trapID_13 = new QLineEdit(groupBox_20);
        trapID_13->setObjectName(QString::fromUtf8("trapID_13"));
        trapID_13->setGeometry(QRect(100, 0, 151, 21));
        label_16 = new QLabel(groupBox_20);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(0, 0, 91, 17));
        groupBox_21 = new QGroupBox(groupBox_10);
        groupBox_21->setObjectName(QString::fromUtf8("groupBox_21"));
        groupBox_21->setGeometry(QRect(20, 240, 271, 21));
        bs8 = new QLineEdit(groupBox_21);
        bs8->setObjectName(QString::fromUtf8("bs8"));
        bs8->setGeometry(QRect(100, 0, 161, 21));
        label_22 = new QLabel(groupBox_21);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(0, 0, 67, 17));
        layoutWidget = new QWidget(groupBox_10);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(120, 270, 148, 62));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        bs9 = new QLineEdit(layoutWidget);
        bs9->setObjectName(QString::fromUtf8("bs9"));
        bs9->setDragEnabled(false);
        bs9->setReadOnly(true);

        verticalLayout->addWidget(bs9);

        bs10 = new QLineEdit(layoutWidget);
        bs10->setObjectName(QString::fromUtf8("bs10"));
        bs10->setReadOnly(true);

        verticalLayout->addWidget(bs10);

        layoutWidget1 = new QWidget(groupBox_10);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(20, 270, 92, 61));
        verticalLayout_5 = new QVBoxLayout(layoutWidget1);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_24 = new QLabel(layoutWidget1);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        verticalLayout_5->addWidget(label_24);

        label_26 = new QLabel(layoutWidget1);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        verticalLayout_5->addWidget(label_26);

        groupBox_22 = new QGroupBox(tab);
        groupBox_22->setObjectName(QString::fromUtf8("groupBox_22"));
        groupBox_22->setGeometry(QRect(320, 20, 381, 191));
        groupBox_31 = new QGroupBox(groupBox_22);
        groupBox_31->setObjectName(QString::fromUtf8("groupBox_31"));
        groupBox_31->setGeometry(QRect(10, 120, 371, 21));
        zt4 = new QLineEdit(groupBox_31);
        zt4->setObjectName(QString::fromUtf8("zt4"));
        zt4->setGeometry(QRect(120, 0, 221, 21));
        label_34 = new QLabel(groupBox_31);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setGeometry(QRect(0, 0, 101, 17));
        groupBox_30 = new QGroupBox(groupBox_22);
        groupBox_30->setObjectName(QString::fromUtf8("groupBox_30"));
        groupBox_30->setGeometry(QRect(10, 150, 361, 21));
        label_33 = new QLabel(groupBox_30);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setGeometry(QRect(0, 0, 121, 17));
        zt5 = new QLineEdit(groupBox_30);
        zt5->setObjectName(QString::fromUtf8("zt5"));
        zt5->setGeometry(QRect(120, 0, 221, 21));
        groupBox_24 = new QGroupBox(groupBox_22);
        groupBox_24->setObjectName(QString::fromUtf8("groupBox_24"));
        groupBox_24->setGeometry(QRect(10, 90, 351, 21));
        zt3 = new QLineEdit(groupBox_24);
        zt3->setObjectName(QString::fromUtf8("zt3"));
        zt3->setGeometry(QRect(120, 0, 221, 21));
        label_27 = new QLabel(groupBox_24);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(0, 0, 101, 17));
        groupBox_23 = new QGroupBox(groupBox_22);
        groupBox_23->setObjectName(QString::fromUtf8("groupBox_23"));
        groupBox_23->setGeometry(QRect(10, 30, 341, 21));
        zt1 = new QLineEdit(groupBox_23);
        zt1->setObjectName(QString::fromUtf8("zt1"));
        zt1->setGeometry(QRect(120, 0, 221, 21));
        label_25 = new QLabel(groupBox_23);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(0, 0, 101, 17));
        groupBox_29 = new QGroupBox(groupBox_22);
        groupBox_29->setObjectName(QString::fromUtf8("groupBox_29"));
        groupBox_29->setGeometry(QRect(10, 60, 341, 21));
        zt2 = new QLineEdit(groupBox_29);
        zt2->setObjectName(QString::fromUtf8("zt2"));
        zt2->setGeometry(QRect(120, 0, 221, 21));
        label_31 = new QLabel(groupBox_29);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setGeometry(QRect(0, 0, 101, 17));
        groupBox_33 = new QGroupBox(tab);
        groupBox_33->setObjectName(QString::fromUtf8("groupBox_33"));
        groupBox_33->setGeometry(QRect(320, 200, 411, 121));
        groupBox_34 = new QGroupBox(groupBox_33);
        groupBox_34->setObjectName(QString::fromUtf8("groupBox_34"));
        groupBox_34->setGeometry(QRect(0, 90, 441, 21));
        gl3 = new QLineEdit(groupBox_34);
        gl3->setObjectName(QString::fromUtf8("gl3"));
        gl3->setGeometry(QRect(100, 0, 71, 21));
        label_36 = new QLabel(groupBox_34);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setGeometry(QRect(10, 0, 141, 17));
        gl4 = new QLineEdit(groupBox_34);
        gl4->setObjectName(QString::fromUtf8("gl4"));
        gl4->setGeometry(QRect(250, 0, 101, 21));
        label_38 = new QLabel(groupBox_34);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setGeometry(QRect(170, 0, 141, 17));
        groupBox_35 = new QGroupBox(groupBox_33);
        groupBox_35->setObjectName(QString::fromUtf8("groupBox_35"));
        groupBox_35->setGeometry(QRect(0, 30, 381, 21));
        label_23 = new QLabel(groupBox_35);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(10, 0, 91, 17));
        gl1 = new QLineEdit(groupBox_35);
        gl1->setObjectName(QString::fromUtf8("gl1"));
        gl1->setGeometry(QRect(100, 0, 251, 21));
        groupBox_36 = new QGroupBox(groupBox_33);
        groupBox_36->setObjectName(QString::fromUtf8("groupBox_36"));
        groupBox_36->setGeometry(QRect(0, 60, 361, 21));
        gl2 = new QLineEdit(groupBox_36);
        gl2->setObjectName(QString::fromUtf8("gl2"));
        gl2->setGeometry(QRect(100, 0, 251, 21));
        label_37 = new QLabel(groupBox_36);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setGeometry(QRect(10, 0, 101, 17));
        groupBox_37 = new QGroupBox(tab);
        groupBox_37->setObjectName(QString::fromUtf8("groupBox_37"));
        groupBox_37->setGeometry(QRect(320, 330, 351, 161));
        label_30 = new QLabel(groupBox_37);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(10, 30, 101, 17));
        label_32 = new QLabel(groupBox_37);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setGeometry(QRect(10, 60, 101, 17));
        label_39 = new QLabel(groupBox_37);
        label_39->setObjectName(QString::fromUtf8("label_39"));
        label_39->setGeometry(QRect(10, 100, 101, 17));
        label_40 = new QLabel(groupBox_37);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        label_40->setGeometry(QRect(10, 130, 101, 17));
        label_42 = new QLabel(groupBox_37);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        label_42->setGeometry(QRect(160, 30, 101, 17));
        label_43 = new QLabel(groupBox_37);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        label_43->setGeometry(QRect(160, 60, 101, 17));
        label_44 = new QLabel(groupBox_37);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setGeometry(QRect(160, 100, 101, 17));
        label_45 = new QLabel(groupBox_37);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        label_45->setGeometry(QRect(160, 130, 101, 17));
        yh1 = new QLineEdit(groupBox_37);
        yh1->setObjectName(QString::fromUtf8("yh1"));
        yh1->setGeometry(QRect(90, 30, 51, 21));
        yh2 = new QLineEdit(groupBox_37);
        yh2->setObjectName(QString::fromUtf8("yh2"));
        yh2->setGeometry(QRect(90, 60, 51, 21));
        yh3 = new QLineEdit(groupBox_37);
        yh3->setObjectName(QString::fromUtf8("yh3"));
        yh3->setGeometry(QRect(90, 100, 51, 21));
        yh4 = new QLineEdit(groupBox_37);
        yh4->setObjectName(QString::fromUtf8("yh4"));
        yh4->setGeometry(QRect(90, 130, 51, 21));
        yh5 = new QLineEdit(groupBox_37);
        yh5->setObjectName(QString::fromUtf8("yh5"));
        yh5->setGeometry(QRect(200, 30, 141, 21));
        yh6 = new QLineEdit(groupBox_37);
        yh6->setObjectName(QString::fromUtf8("yh6"));
        yh6->setGeometry(QRect(220, 60, 121, 21));
        yh7 = new QLineEdit(groupBox_37);
        yh7->setObjectName(QString::fromUtf8("yh7"));
        yh7->setGeometry(QRect(210, 100, 131, 21));
        yh8 = new QLineEdit(groupBox_37);
        yh8->setObjectName(QString::fromUtf8("yh8"));
        yh8->setGeometry(QRect(220, 130, 121, 21));
        UpUIFromAgent = new QPushButton(tab);
        UpUIFromAgent->setObjectName(QString::fromUtf8("UpUIFromAgent"));
        UpUIFromAgent->setEnabled(false);
        UpUIFromAgent->setGeometry(QRect(360, 660, 99, 27));
        groupBox_77 = new QGroupBox(tab);
        groupBox_77->setObjectName(QString::fromUtf8("groupBox_77"));
        groupBox_77->setGeometry(QRect(650, -30, 811, 741));
        layoutWidget2 = new QWidget(groupBox_77);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(270, 250, 215, 260));
        verticalLayout_3 = new QVBoxLayout(layoutWidget2);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        B1_1 = new QComboBox(layoutWidget2);
        B1_1->setObjectName(QString::fromUtf8("B1_1"));

        verticalLayout_3->addWidget(B1_1);

        B1_2 = new QComboBox(layoutWidget2);
        B1_2->setObjectName(QString::fromUtf8("B1_2"));

        verticalLayout_3->addWidget(B1_2);

        B2_1 = new QComboBox(layoutWidget2);
        B2_1->setObjectName(QString::fromUtf8("B2_1"));

        verticalLayout_3->addWidget(B2_1);

        B2_2 = new QComboBox(layoutWidget2);
        B2_2->setObjectName(QString::fromUtf8("B2_2"));

        verticalLayout_3->addWidget(B2_2);

        B3_1 = new QComboBox(layoutWidget2);
        B3_1->setObjectName(QString::fromUtf8("B3_1"));

        verticalLayout_3->addWidget(B3_1);

        B3_2 = new QComboBox(layoutWidget2);
        B3_2->setObjectName(QString::fromUtf8("B3_2"));

        verticalLayout_3->addWidget(B3_2);

        B3_3 = new QComboBox(layoutWidget2);
        B3_3->setObjectName(QString::fromUtf8("B3_3"));

        verticalLayout_3->addWidget(B3_3);

        B3_4 = new QComboBox(layoutWidget2);
        B3_4->setObjectName(QString::fromUtf8("B3_4"));

        verticalLayout_3->addWidget(B3_4);

        layoutWidget3 = new QWidget(groupBox_77);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(20, 250, 246, 251));
        verticalLayout_4 = new QVBoxLayout(layoutWidget3);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_131 = new QLabel(layoutWidget3);
        label_131->setObjectName(QString::fromUtf8("label_131"));

        verticalLayout_4->addWidget(label_131);

        label_130 = new QLabel(layoutWidget3);
        label_130->setObjectName(QString::fromUtf8("label_130"));

        verticalLayout_4->addWidget(label_130);

        label_129 = new QLabel(layoutWidget3);
        label_129->setObjectName(QString::fromUtf8("label_129"));

        verticalLayout_4->addWidget(label_129);

        label_128 = new QLabel(layoutWidget3);
        label_128->setObjectName(QString::fromUtf8("label_128"));

        verticalLayout_4->addWidget(label_128);

        label_126 = new QLabel(layoutWidget3);
        label_126->setObjectName(QString::fromUtf8("label_126"));

        verticalLayout_4->addWidget(label_126);

        label_127 = new QLabel(layoutWidget3);
        label_127->setObjectName(QString::fromUtf8("label_127"));

        verticalLayout_4->addWidget(label_127);

        label_125 = new QLabel(layoutWidget3);
        label_125->setObjectName(QString::fromUtf8("label_125"));

        verticalLayout_4->addWidget(label_125);

        label_124 = new QLabel(layoutWidget3);
        label_124->setObjectName(QString::fromUtf8("label_124"));

        verticalLayout_4->addWidget(label_124);

        groupBox_76 = new QGroupBox(groupBox_77);
        groupBox_76->setObjectName(QString::fromUtf8("groupBox_76"));
        groupBox_76->setGeometry(QRect(-20, 490, 771, 241));
        label_116 = new QLabel(groupBox_76);
        label_116->setObjectName(QString::fromUtf8("label_116"));
        label_116->setGeometry(QRect(140, 20, 67, 17));
        label_117 = new QLabel(groupBox_76);
        label_117->setObjectName(QString::fromUtf8("label_117"));
        label_117->setGeometry(QRect(210, 20, 67, 17));
        label_118 = new QLabel(groupBox_76);
        label_118->setObjectName(QString::fromUtf8("label_118"));
        label_118->setGeometry(QRect(280, 20, 67, 17));
        layoutWidget4 = new QWidget(groupBox_76);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(140, 100, 612, 31));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        B4_1_3 = new QComboBox(layoutWidget4);
        B4_1_3->setObjectName(QString::fromUtf8("B4_1_3"));

        horizontalLayout_5->addWidget(B4_1_3);

        B4_2_3 = new QComboBox(layoutWidget4);
        B4_2_3->setObjectName(QString::fromUtf8("B4_2_3"));

        horizontalLayout_5->addWidget(B4_2_3);

        B4_3_3 = new QComboBox(layoutWidget4);
        B4_3_3->setObjectName(QString::fromUtf8("B4_3_3"));

        horizontalLayout_5->addWidget(B4_3_3);

        B4_4_3 = new QComboBox(layoutWidget4);
        B4_4_3->setObjectName(QString::fromUtf8("B4_4_3"));

        horizontalLayout_5->addWidget(B4_4_3);

        B5_1_3 = new QComboBox(layoutWidget4);
        B5_1_3->setObjectName(QString::fromUtf8("B5_1_3"));

        horizontalLayout_5->addWidget(B5_1_3);

        B5_2_3 = new QComboBox(layoutWidget4);
        B5_2_3->setObjectName(QString::fromUtf8("B5_2_3"));

        horizontalLayout_5->addWidget(B5_2_3);

        B5_3_3 = new QComboBox(layoutWidget4);
        B5_3_3->setObjectName(QString::fromUtf8("B5_3_3"));

        horizontalLayout_5->addWidget(B5_3_3);

        B5_4_3 = new QComboBox(layoutWidget4);
        B5_4_3->setObjectName(QString::fromUtf8("B5_4_3"));

        horizontalLayout_5->addWidget(B5_4_3);

        layoutWidget_2 = new QWidget(groupBox_76);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(140, 70, 612, 31));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        B4_1_2 = new QComboBox(layoutWidget_2);
        B4_1_2->setObjectName(QString::fromUtf8("B4_1_2"));

        horizontalLayout_6->addWidget(B4_1_2);

        B4_2_2 = new QComboBox(layoutWidget_2);
        B4_2_2->setObjectName(QString::fromUtf8("B4_2_2"));

        horizontalLayout_6->addWidget(B4_2_2);

        B4_3_2 = new QComboBox(layoutWidget_2);
        B4_3_2->setObjectName(QString::fromUtf8("B4_3_2"));

        horizontalLayout_6->addWidget(B4_3_2);

        B4_4_2 = new QComboBox(layoutWidget_2);
        B4_4_2->setObjectName(QString::fromUtf8("B4_4_2"));

        horizontalLayout_6->addWidget(B4_4_2);

        B5_1_2 = new QComboBox(layoutWidget_2);
        B5_1_2->setObjectName(QString::fromUtf8("B5_1_2"));

        horizontalLayout_6->addWidget(B5_1_2);

        B5_2_2 = new QComboBox(layoutWidget_2);
        B5_2_2->setObjectName(QString::fromUtf8("B5_2_2"));

        horizontalLayout_6->addWidget(B5_2_2);

        B5_3_2 = new QComboBox(layoutWidget_2);
        B5_3_2->setObjectName(QString::fromUtf8("B5_3_2"));

        horizontalLayout_6->addWidget(B5_3_2);

        B5_4_2 = new QComboBox(layoutWidget_2);
        B5_4_2->setObjectName(QString::fromUtf8("B5_4_2"));

        horizontalLayout_6->addWidget(B5_4_2);

        layoutWidget_3 = new QWidget(groupBox_76);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(140, 130, 612, 31));
        horizontalLayout_7 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        B4_1_4 = new QComboBox(layoutWidget_3);
        B4_1_4->setObjectName(QString::fromUtf8("B4_1_4"));

        horizontalLayout_7->addWidget(B4_1_4);

        B4_2_4 = new QComboBox(layoutWidget_3);
        B4_2_4->setObjectName(QString::fromUtf8("B4_2_4"));

        horizontalLayout_7->addWidget(B4_2_4);

        B4_3_4 = new QComboBox(layoutWidget_3);
        B4_3_4->setObjectName(QString::fromUtf8("B4_3_4"));

        horizontalLayout_7->addWidget(B4_3_4);

        B4_4_4 = new QComboBox(layoutWidget_3);
        B4_4_4->setObjectName(QString::fromUtf8("B4_4_4"));

        horizontalLayout_7->addWidget(B4_4_4);

        B5_1_4 = new QComboBox(layoutWidget_3);
        B5_1_4->setObjectName(QString::fromUtf8("B5_1_4"));

        horizontalLayout_7->addWidget(B5_1_4);

        B5_2_4 = new QComboBox(layoutWidget_3);
        B5_2_4->setObjectName(QString::fromUtf8("B5_2_4"));

        horizontalLayout_7->addWidget(B5_2_4);

        B5_3_4 = new QComboBox(layoutWidget_3);
        B5_3_4->setObjectName(QString::fromUtf8("B5_3_4"));

        horizontalLayout_7->addWidget(B5_3_4);

        B5_4_4 = new QComboBox(layoutWidget_3);
        B5_4_4->setObjectName(QString::fromUtf8("B5_4_4"));

        horizontalLayout_7->addWidget(B5_4_4);

        layoutWidget_4 = new QWidget(groupBox_76);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(140, 170, 612, 31));
        horizontalLayout_8 = new QHBoxLayout(layoutWidget_4);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        B4_1_5 = new QComboBox(layoutWidget_4);
        B4_1_5->setObjectName(QString::fromUtf8("B4_1_5"));

        horizontalLayout_8->addWidget(B4_1_5);

        B4_2_5 = new QComboBox(layoutWidget_4);
        B4_2_5->setObjectName(QString::fromUtf8("B4_2_5"));

        horizontalLayout_8->addWidget(B4_2_5);

        B4_3_5 = new QComboBox(layoutWidget_4);
        B4_3_5->setObjectName(QString::fromUtf8("B4_3_5"));

        horizontalLayout_8->addWidget(B4_3_5);

        B4_4_5 = new QComboBox(layoutWidget_4);
        B4_4_5->setObjectName(QString::fromUtf8("B4_4_5"));

        horizontalLayout_8->addWidget(B4_4_5);

        B5_1_5 = new QComboBox(layoutWidget_4);
        B5_1_5->setObjectName(QString::fromUtf8("B5_1_5"));

        horizontalLayout_8->addWidget(B5_1_5);

        B5_2_5 = new QComboBox(layoutWidget_4);
        B5_2_5->setObjectName(QString::fromUtf8("B5_2_5"));

        horizontalLayout_8->addWidget(B5_2_5);

        B5_3_5 = new QComboBox(layoutWidget_4);
        B5_3_5->setObjectName(QString::fromUtf8("B5_3_5"));

        horizontalLayout_8->addWidget(B5_3_5);

        B5_4_5 = new QComboBox(layoutWidget_4);
        B5_4_5->setObjectName(QString::fromUtf8("B5_4_5"));

        horizontalLayout_8->addWidget(B5_4_5);

        layoutWidget_5 = new QWidget(groupBox_76);
        layoutWidget_5->setObjectName(QString::fromUtf8("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(30, 40, 122, 191));
        verticalLayout_2 = new QVBoxLayout(layoutWidget_5);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget_5);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_2->addWidget(label);

        label_120 = new QLabel(layoutWidget_5);
        label_120->setObjectName(QString::fromUtf8("label_120"));

        verticalLayout_2->addWidget(label_120);

        label_121 = new QLabel(layoutWidget_5);
        label_121->setObjectName(QString::fromUtf8("label_121"));

        verticalLayout_2->addWidget(label_121);

        label_122 = new QLabel(layoutWidget_5);
        label_122->setObjectName(QString::fromUtf8("label_122"));

        verticalLayout_2->addWidget(label_122);

        label_123 = new QLabel(layoutWidget_5);
        label_123->setObjectName(QString::fromUtf8("label_123"));

        verticalLayout_2->addWidget(label_123);

        label_119 = new QLabel(layoutWidget_5);
        label_119->setObjectName(QString::fromUtf8("label_119"));

        verticalLayout_2->addWidget(label_119);

        layoutWidget_6 = new QWidget(groupBox_76);
        layoutWidget_6->setObjectName(QString::fromUtf8("layoutWidget_6"));
        layoutWidget_6->setGeometry(QRect(140, 40, 612, 31));
        horizontalLayout_11 = new QHBoxLayout(layoutWidget_6);
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(0, 0, 0, 0);
        B4_1_1 = new QComboBox(layoutWidget_6);
        B4_1_1->setObjectName(QString::fromUtf8("B4_1_1"));

        horizontalLayout_11->addWidget(B4_1_1);

        B4_2_1 = new QComboBox(layoutWidget_6);
        B4_2_1->setObjectName(QString::fromUtf8("B4_2_1"));

        horizontalLayout_11->addWidget(B4_2_1);

        B4_3_1 = new QComboBox(layoutWidget_6);
        B4_3_1->setObjectName(QString::fromUtf8("B4_3_1"));

        horizontalLayout_11->addWidget(B4_3_1);

        B4_4_1_ = new QComboBox(layoutWidget_6);
        B4_4_1_->setObjectName(QString::fromUtf8("B4_4_1_"));

        horizontalLayout_11->addWidget(B4_4_1_);

        B5_1_1 = new QComboBox(layoutWidget_6);
        B5_1_1->setObjectName(QString::fromUtf8("B5_1_1"));

        horizontalLayout_11->addWidget(B5_1_1);

        B5_2_1 = new QComboBox(layoutWidget_6);
        B5_2_1->setObjectName(QString::fromUtf8("B5_2_1"));

        horizontalLayout_11->addWidget(B5_2_1);

        B5_3_1 = new QComboBox(layoutWidget_6);
        B5_3_1->setObjectName(QString::fromUtf8("B5_3_1"));

        horizontalLayout_11->addWidget(B5_3_1);

        B5_4_1 = new QComboBox(layoutWidget_6);
        B5_4_1->setObjectName(QString::fromUtf8("B5_4_1"));

        horizontalLayout_11->addWidget(B5_4_1);

        layoutWidget5 = new QWidget(groupBox_76);
        layoutWidget5->setObjectName(QString::fromUtf8("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(140, 200, 581, 31));
        horizontalLayout_9 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        B4_1_6 = new QLineEdit(layoutWidget5);
        B4_1_6->setObjectName(QString::fromUtf8("B4_1_6"));

        horizontalLayout_9->addWidget(B4_1_6);

        B4_2_6 = new QLineEdit(layoutWidget5);
        B4_2_6->setObjectName(QString::fromUtf8("B4_2_6"));

        horizontalLayout_9->addWidget(B4_2_6);

        B4_3_6 = new QLineEdit(layoutWidget5);
        B4_3_6->setObjectName(QString::fromUtf8("B4_3_6"));

        horizontalLayout_9->addWidget(B4_3_6);

        B4_4_6 = new QLineEdit(layoutWidget5);
        B4_4_6->setObjectName(QString::fromUtf8("B4_4_6"));

        horizontalLayout_9->addWidget(B4_4_6);

        B5_1_6 = new QLineEdit(layoutWidget5);
        B5_1_6->setObjectName(QString::fromUtf8("B5_1_6"));

        horizontalLayout_9->addWidget(B5_1_6);

        B5_2_6 = new QLineEdit(layoutWidget5);
        B5_2_6->setObjectName(QString::fromUtf8("B5_2_6"));

        horizontalLayout_9->addWidget(B5_2_6);

        B5_3_6 = new QLineEdit(layoutWidget5);
        B5_3_6->setObjectName(QString::fromUtf8("B5_3_6"));

        horizontalLayout_9->addWidget(B5_3_6);

        B5_4_6 = new QLineEdit(layoutWidget5);
        B5_4_6->setObjectName(QString::fromUtf8("B5_4_6"));

        horizontalLayout_9->addWidget(B5_4_6);

        label_136 = new QLabel(groupBox_76);
        label_136->setObjectName(QString::fromUtf8("label_136"));
        label_136->setGeometry(QRect(360, 20, 67, 17));
        label_2 = new QLabel(groupBox_76);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(450, 20, 67, 17));
        label_3 = new QLabel(groupBox_76);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(510, 20, 67, 17));
        label_28 = new QLabel(groupBox_76);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(590, 20, 67, 17));
        label_29 = new QLabel(groupBox_76);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(660, 20, 67, 17));
        layoutWidget->raise();
        label_116->raise();
        label_117->raise();
        label_118->raise();
        layoutWidget->raise();
        layoutWidget_2->raise();
        layoutWidget_3->raise();
        layoutWidget_4->raise();
        layoutWidget_5->raise();
        layoutWidget_6->raise();
        label_136->raise();
        label_2->raise();
        label_3->raise();
        label_28->raise();
        label_29->raise();
        layoutWidget6 = new QWidget(groupBox_77);
        layoutWidget6->setObjectName(QString::fromUtf8("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(200, 30, 218, 227));
        verticalLayout_7 = new QVBoxLayout(layoutWidget6);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        A1 = new QComboBox(layoutWidget6);
        A1->setObjectName(QString::fromUtf8("A1"));

        verticalLayout_7->addWidget(A1);

        A2 = new QComboBox(layoutWidget6);
        A2->setObjectName(QString::fromUtf8("A2"));

        verticalLayout_7->addWidget(A2);

        A3 = new QComboBox(layoutWidget6);
        A3->setObjectName(QString::fromUtf8("A3"));

        verticalLayout_7->addWidget(A3);

        A4 = new QComboBox(layoutWidget6);
        A4->setObjectName(QString::fromUtf8("A4"));

        verticalLayout_7->addWidget(A4);

        A5 = new QComboBox(layoutWidget6);
        A5->setObjectName(QString::fromUtf8("A5"));

        verticalLayout_7->addWidget(A5);

        A6 = new QComboBox(layoutWidget6);
        A6->setObjectName(QString::fromUtf8("A6"));

        verticalLayout_7->addWidget(A6);

        A7 = new QComboBox(layoutWidget6);
        A7->setObjectName(QString::fromUtf8("A7"));

        verticalLayout_7->addWidget(A7);

        layoutWidget7 = new QWidget(groupBox_77);
        layoutWidget7->setObjectName(QString::fromUtf8("layoutWidget7"));
        layoutWidget7->setGeometry(QRect(30, 30, 167, 221));
        verticalLayout_6 = new QVBoxLayout(layoutWidget7);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_52 = new QLabel(layoutWidget7);
        label_52->setObjectName(QString::fromUtf8("label_52"));

        verticalLayout_6->addWidget(label_52);

        label_53 = new QLabel(layoutWidget7);
        label_53->setObjectName(QString::fromUtf8("label_53"));

        verticalLayout_6->addWidget(label_53);

        label_47 = new QLabel(layoutWidget7);
        label_47->setObjectName(QString::fromUtf8("label_47"));

        verticalLayout_6->addWidget(label_47);

        label_46 = new QLabel(layoutWidget7);
        label_46->setObjectName(QString::fromUtf8("label_46"));

        verticalLayout_6->addWidget(label_46);

        label_48 = new QLabel(layoutWidget7);
        label_48->setObjectName(QString::fromUtf8("label_48"));

        verticalLayout_6->addWidget(label_48);

        label_35 = new QLabel(layoutWidget7);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        verticalLayout_6->addWidget(label_35);

        label_54 = new QLabel(layoutWidget7);
        label_54->setObjectName(QString::fromUtf8("label_54"));

        verticalLayout_6->addWidget(label_54);

        layoutWidget8 = new QWidget(groupBox_77);
        layoutWidget8->setObjectName(QString::fromUtf8("layoutWidget8"));
        layoutWidget8->setGeometry(QRect(420, 30, 146, 231));
        verticalLayout_8 = new QVBoxLayout(layoutWidget8);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        label_55 = new QLabel(layoutWidget8);
        label_55->setObjectName(QString::fromUtf8("label_55"));

        verticalLayout_8->addWidget(label_55);

        label_56 = new QLabel(layoutWidget8);
        label_56->setObjectName(QString::fromUtf8("label_56"));

        verticalLayout_8->addWidget(label_56);

        label_57 = new QLabel(layoutWidget8);
        label_57->setObjectName(QString::fromUtf8("label_57"));

        verticalLayout_8->addWidget(label_57);

        label_58 = new QLabel(layoutWidget8);
        label_58->setObjectName(QString::fromUtf8("label_58"));

        verticalLayout_8->addWidget(label_58);

        label_59 = new QLabel(layoutWidget8);
        label_59->setObjectName(QString::fromUtf8("label_59"));

        verticalLayout_8->addWidget(label_59);

        label_60 = new QLabel(layoutWidget8);
        label_60->setObjectName(QString::fromUtf8("label_60"));

        verticalLayout_8->addWidget(label_60);

        label_61 = new QLabel(layoutWidget8);
        label_61->setObjectName(QString::fromUtf8("label_61"));

        verticalLayout_8->addWidget(label_61);

        layoutWidget9 = new QWidget(groupBox_77);
        layoutWidget9->setObjectName(QString::fromUtf8("layoutWidget9"));
        layoutWidget9->setGeometry(QRect(570, 30, 73, 227));
        verticalLayout_9 = new QVBoxLayout(layoutWidget9);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        A8 = new QComboBox(layoutWidget9);
        A8->setObjectName(QString::fromUtf8("A8"));

        verticalLayout_9->addWidget(A8);

        A9 = new QComboBox(layoutWidget9);
        A9->setObjectName(QString::fromUtf8("A9"));

        verticalLayout_9->addWidget(A9);

        A10 = new QComboBox(layoutWidget9);
        A10->setObjectName(QString::fromUtf8("A10"));

        verticalLayout_9->addWidget(A10);

        A11 = new QComboBox(layoutWidget9);
        A11->setObjectName(QString::fromUtf8("A11"));

        verticalLayout_9->addWidget(A11);

        A12 = new QComboBox(layoutWidget9);
        A12->setObjectName(QString::fromUtf8("A12"));

        verticalLayout_9->addWidget(A12);

        A13 = new QComboBox(layoutWidget9);
        A13->setObjectName(QString::fromUtf8("A13"));

        verticalLayout_9->addWidget(A13);

        A14 = new QComboBox(layoutWidget9);
        A14->setObjectName(QString::fromUtf8("A14"));

        verticalLayout_9->addWidget(A14);

        layoutWidget10 = new QWidget(tab);
        layoutWidget10->setObjectName(QString::fromUtf8("layoutWidget10"));
        layoutWidget10->setGeometry(QRect(320, 500, 331, 29));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget10);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        checkBox_2 = new QCheckBox(layoutWidget10);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));

        horizontalLayout_4->addWidget(checkBox_2);

        label_41 = new QLabel(layoutWidget10);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        horizontalLayout_4->addWidget(label_41);

        trapID_43 = new QLineEdit(layoutWidget10);
        trapID_43->setObjectName(QString::fromUtf8("trapID_43"));

        horizontalLayout_4->addWidget(trapID_43);

        layoutWidget11 = new QWidget(tab);
        layoutWidget11->setObjectName(QString::fromUtf8("layoutWidget11"));
        layoutWidget11->setGeometry(QRect(350, 540, 271, 80));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget11);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_49 = new QLabel(layoutWidget11);
        label_49->setObjectName(QString::fromUtf8("label_49"));

        horizontalLayout_3->addWidget(label_49);

        listWidget = new QListWidget(layoutWidget11);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        horizontalLayout_3->addWidget(listWidget);

        layoutWidget12 = new QWidget(tab);
        layoutWidget12->setObjectName(QString::fromUtf8("layoutWidget12"));
        layoutWidget12->setGeometry(QRect(350, 620, 269, 32));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget12);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        writeagent = new QPushButton(layoutWidget12);
        writeagent->setObjectName(QString::fromUtf8("writeagent"));
        writeagent->setEnabled(false);

        horizontalLayout_2->addWidget(writeagent);

        reset = new QPushButton(layoutWidget12);
        reset->setObjectName(QString::fromUtf8("reset"));
        reset->setEnabled(false);

        horizontalLayout_2->addWidget(reset);

        traptest = new QPushButton(layoutWidget12);
        traptest->setObjectName(QString::fromUtf8("traptest"));
        traptest->setEnabled(false);
        traptest->setFocusPolicy(Qt::NoFocus);

        horizontalLayout_2->addWidget(traptest);

        layoutWidget13 = new QWidget(tab);
        layoutWidget13->setObjectName(QString::fromUtf8("layoutWidget13"));
        layoutWidget13->setGeometry(QRect(350, 590, 269, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget13);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        stopAgent = new QPushButton(layoutWidget13);
        stopAgent->setObjectName(QString::fromUtf8("stopAgent"));
        stopAgent->setEnabled(false);

        horizontalLayout->addWidget(stopAgent);

        startAgent = new QPushButton(layoutWidget13);
        startAgent->setObjectName(QString::fromUtf8("startAgent"));

        horizontalLayout->addWidget(startAgent);

        quitAgent = new QPushButton(layoutWidget13);
        quitAgent->setObjectName(QString::fromUtf8("quitAgent"));
        quitAgent->setEnabled(false);

        horizontalLayout->addWidget(quitAgent);

        readcommunity = new QLineEdit(tab);
        readcommunity->setObjectName(QString::fromUtf8("readcommunity"));
        readcommunity->setGeometry(QRect(1380, 730, 113, 27));
        label_51 = new QLabel(tab);
        label_51->setObjectName(QString::fromUtf8("label_51"));
        label_51->setGeometry(QRect(1510, 730, 67, 20));
        label_50 = new QLabel(tab);
        label_50->setObjectName(QString::fromUtf8("label_50"));
        label_50->setGeometry(QRect(1300, 740, 67, 20));
        redcommunity = new QLineEdit(tab);
        redcommunity->setObjectName(QString::fromUtf8("redcommunity"));
        redcommunity->setGeometry(QRect(1560, 730, 91, 27));
        tabWidget->addTab(tab, QString());
        layoutWidget->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        groupBox->raise();
        groupBox_10->raise();
        groupBox_22->raise();
        groupBox_33->raise();
        groupBox_37->raise();
        UpUIFromAgent->raise();
        groupBox_77->raise();
        readcommunity->raise();
        label_51->raise();
        label_50->raise();
        redcommunity->raise();
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        ModifyButton_2 = new QPushButton(tab_2);
        ModifyButton_2->setObjectName(QString::fromUtf8("ModifyButton_2"));
        ModifyButton_2->setGeometry(QRect(920, 110, 121, 27));
        DeleteButton_2 = new QPushButton(tab_2);
        DeleteButton_2->setObjectName(QString::fromUtf8("DeleteButton_2"));
        DeleteButton_2->setGeometry(QRect(920, 170, 121, 27));
        AddButton_2 = new QPushButton(tab_2);
        AddButton_2->setObjectName(QString::fromUtf8("AddButton_2"));
        AddButton_2->setGeometry(QRect(920, 230, 121, 27));
        ReadFButton = new QPushButton(tab_2);
        ReadFButton->setObjectName(QString::fromUtf8("ReadFButton"));
        ReadFButton->setGeometry(QRect(890, 290, 99, 27));
        WriteFile = new QPushButton(tab_2);
        WriteFile->setObjectName(QString::fromUtf8("WriteFile"));
        WriteFile->setGeometry(QRect(1030, 290, 99, 27));
        ShowList_2 = new QListWidget(tab_2);
        ShowList_2->setObjectName(QString::fromUtf8("ShowList_2"));
        ShowList_2->setGeometry(QRect(0, 10, 871, 621));
        tabWidget->addTab(tab_2, QString());
        groupBox_75 = new QGroupBox(centralWidget);
        groupBox_75->setObjectName(QString::fromUtf8("groupBox_75"));
        groupBox_75->setGeometry(QRect(1570, 600, 371, 121));
        checkBox_6 = new QCheckBox(groupBox_75);
        checkBox_6->setObjectName(QString::fromUtf8("checkBox_6"));
        checkBox_6->setGeometry(QRect(10, 10, 141, 22));
        yh5_6 = new QLineEdit(groupBox_75);
        yh5_6->setObjectName(QString::fromUtf8("yh5_6"));
        yh5_6->setGeometry(QRect(80, 50, 81, 21));
        label_110 = new QLabel(groupBox_75);
        label_110->setObjectName(QString::fromUtf8("label_110"));
        label_110->setGeometry(QRect(20, 50, 101, 17));
        yh5_7 = new QLineEdit(groupBox_75);
        yh5_7->setObjectName(QString::fromUtf8("yh5_7"));
        yh5_7->setGeometry(QRect(220, 50, 61, 21));
        label_111 = new QLabel(groupBox_75);
        label_111->setObjectName(QString::fromUtf8("label_111"));
        label_111->setGeometry(QRect(180, 50, 61, 17));
        yh5_8 = new QLineEdit(groupBox_75);
        yh5_8->setObjectName(QString::fromUtf8("yh5_8"));
        yh5_8->setGeometry(QRect(150, 90, 151, 21));
        label_112 = new QLabel(groupBox_75);
        label_112->setObjectName(QString::fromUtf8("label_112"));
        label_112->setGeometry(QRect(20, 90, 121, 17));
        pushButton_2 = new QPushButton(groupBox_75);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(310, 50, 41, 41));
        groupBox_66 = new QGroupBox(centralWidget);
        groupBox_66->setObjectName(QString::fromUtf8("groupBox_66"));
        groupBox_66->setGeometry(QRect(1450, 480, 371, 111));
        groupBox_67 = new QGroupBox(groupBox_66);
        groupBox_67->setObjectName(QString::fromUtf8("groupBox_67"));
        groupBox_67->setGeometry(QRect(20, 30, 311, 21));
        trapID_29 = new QLineEdit(groupBox_67);
        trapID_29->setObjectName(QString::fromUtf8("trapID_29"));
        trapID_29->setGeometry(QRect(80, 0, 71, 21));
        label_91 = new QLabel(groupBox_67);
        label_91->setObjectName(QString::fromUtf8("label_91"));
        label_91->setGeometry(QRect(0, 0, 101, 17));
        trapID_31 = new QLineEdit(groupBox_67);
        trapID_31->setObjectName(QString::fromUtf8("trapID_31"));
        trapID_31->setGeometry(QRect(250, 0, 61, 21));
        trapID_39 = new QLineEdit(groupBox_67);
        trapID_39->setObjectName(QString::fromUtf8("trapID_39"));
        trapID_39->setGeometry(QRect(170, 0, 61, 21));
        groupBox_68 = new QGroupBox(groupBox_66);
        groupBox_68->setObjectName(QString::fromUtf8("groupBox_68"));
        groupBox_68->setGeometry(QRect(20, 90, 321, 21));
        trapID_32 = new QLineEdit(groupBox_68);
        trapID_32->setObjectName(QString::fromUtf8("trapID_32"));
        trapID_32->setGeometry(QRect(150, 0, 151, 21));
        trapID_32->setReadOnly(true);
        label_92 = new QLabel(groupBox_68);
        label_92->setObjectName(QString::fromUtf8("label_92"));
        label_92->setGeometry(QRect(0, 0, 141, 17));
        groupBox_69 = new QGroupBox(groupBox_66);
        groupBox_69->setObjectName(QString::fromUtf8("groupBox_69"));
        groupBox_69->setGeometry(QRect(20, 60, 311, 21));
        label_93 = new QLabel(groupBox_69);
        label_93->setObjectName(QString::fromUtf8("label_93"));
        label_93->setGeometry(QRect(0, 0, 101, 17));
        trapID_34 = new QLineEdit(groupBox_69);
        trapID_34->setObjectName(QString::fromUtf8("trapID_34"));
        trapID_34->setGeometry(QRect(80, 0, 71, 21));
        trapID_35 = new QLineEdit(groupBox_69);
        trapID_35->setObjectName(QString::fromUtf8("trapID_35"));
        trapID_35->setGeometry(QRect(170, 0, 61, 21));
        trapID_40 = new QLineEdit(groupBox_69);
        trapID_40->setObjectName(QString::fromUtf8("trapID_40"));
        trapID_40->setGeometry(QRect(250, 0, 61, 21));
        label_94 = new QLabel(groupBox_66);
        label_94->setObjectName(QString::fromUtf8("label_94"));
        label_94->setGeometry(QRect(100, 10, 67, 17));
        label_95 = new QLabel(groupBox_66);
        label_95->setObjectName(QString::fromUtf8("label_95"));
        label_95->setGeometry(QRect(200, 10, 67, 17));
        label_96 = new QLabel(groupBox_66);
        label_96->setObjectName(QString::fromUtf8("label_96"));
        label_96->setGeometry(QRect(270, 10, 67, 17));
        layoutWidget14 = new QWidget(centralWidget);
        layoutWidget14->setObjectName(QString::fromUtf8("layoutWidget14"));
        layoutWidget14->setGeometry(QRect(0, 0, 2, 2));
        horizontalLayout_10 = new QHBoxLayout(layoutWidget14);
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalLayout_10->setContentsMargins(0, 0, 0, 0);
        YFMainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(YFMainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1861, 25));
        YFMainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(YFMainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        YFMainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(YFMainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        YFMainWindow->setStatusBar(statusBar);

        retranslateUi(YFMainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(YFMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *YFMainWindow)
    {
        YFMainWindow->setWindowTitle(QApplication::translate("YFMainWindow", "YFMainWindow", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("YFMainWindow", "\345\261\236\346\200\247\347\273\204\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx1->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx1->setText(QString());
        label_4->setText(QApplication::translate("YFMainWindow", "MIB\345\205\245\345\217\243", 0, QApplication::UnicodeUTF8));
        groupBox_5->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx4->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx4->setText(QString());
        label_9->setText(QApplication::translate("YFMainWindow", "\347\240\224\345\210\266\345\216\202\345\256\266", 0, QApplication::UnicodeUTF8));
        groupBox_3->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx2->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx2->setText(QString());
        label_5->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\345\220\215\347\247\260", 0, QApplication::UnicodeUTF8));
        groupBox_4->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx3->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx3->setText(QString());
        label_6->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\346\217\217\350\277\260", 0, QApplication::UnicodeUTF8));
        groupBox_18->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx8->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx8->setText(QString());
        label_20->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\344\275\215\347\275\256", 0, QApplication::UnicodeUTF8));
        groupBox_8->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx7->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx7->setText(QString());
        label_12->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\345\210\206\347\261\273", 0, QApplication::UnicodeUTF8));
        groupBox_6->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx5->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx5->setText(QString());
        label_10->setText(QApplication::translate("YFMainWindow", "\345\207\272\346\211\200\346\227\245\346\234\237", 0, QApplication::UnicodeUTF8));
        groupBox_9->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx9->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx9->setText(QString());
        label_13->setText(QApplication::translate("YFMainWindow", "\347\256\241\347\220\206\351\203\250\351\227\250", 0, QApplication::UnicodeUTF8));
        groupBox_7->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        sx6->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        sx6->setText(QString());
        label_11->setText(QApplication::translate("YFMainWindow", "\350\243\205\345\244\207\346\203\205\345\206\265", 0, QApplication::UnicodeUTF8));
        groupBox_10->setTitle(QApplication::translate("YFMainWindow", "\346\240\207\350\257\206\347\273\204\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        groupBox_11->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        bs1->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs1->setText(QString());
        label_7->setText(QApplication::translate("YFMainWindow", "\350\242\253\347\256\241\345\257\271\350\261\241\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
        groupBox_14->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        bs6->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs6->setText(QString());
        label_17->setText(QApplication::translate("YFMainWindow", "\344\277\241\345\256\277\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
        groupBox_15->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        bs3->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs3->setText(QString());
        label_8->setText(QApplication::translate("YFMainWindow", "\344\273\273\345\212\241\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
        groupBox_19->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        bs7->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs7->setText(QString());
        label_21->setText(QApplication::translate("YFMainWindow", "\344\277\241\345\256\277", 0, QApplication::UnicodeUTF8));
        groupBox_12->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        bs5->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs5->setText(QString());
        label_14->setText(QApplication::translate("YFMainWindow", "\344\277\241\346\272\220", 0, QApplication::UnicodeUTF8));
        groupBox_13->setTitle(QString());
        label_15->setText(QApplication::translate("YFMainWindow", "\344\277\241\346\272\220\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bs4->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs4->setText(QString());
        groupBox_16->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        trapID_16->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_16->setText(QString());
        label_18->setText(QApplication::translate("YFMainWindow", "\346\234\200\346\226\260\351\205\215\347\275\256\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        checkBox->setText(QApplication::translate("YFMainWindow", "\345\217\226\346\227\266", 0, QApplication::UnicodeUTF8));
        groupBox_17->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        bs2->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs2->setText(QString());
        label_19->setText(QApplication::translate("YFMainWindow", "\350\243\205\345\244\207\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
        groupBox_20->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        trapID_13->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_13->setText(QString());
        label_16->setText(QApplication::translate("YFMainWindow", "\347\256\241\347\220\206\350\212\202\347\202\271\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
        groupBox_21->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        bs8->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs8->setText(QString());
        label_22->setText(QApplication::translate("YFMainWindow", "\344\277\241\346\201\257\347\261\273\345\210\253", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bs9->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs9->setText(QString());
#ifndef QT_NO_TOOLTIP
        bs10->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        bs10->setText(QString());
        label_24->setText(QApplication::translate("YFMainWindow", "\346\234\200\346\226\260\351\205\215\347\275\256\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        label_26->setText(QApplication::translate("YFMainWindow", "\347\256\241\347\220\206\350\212\202\347\202\271\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
        groupBox_22->setTitle(QApplication::translate("YFMainWindow", "\347\212\266\346\200\201\347\273\204\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        groupBox_31->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        zt4->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        zt4->setText(QString());
        label_34->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\347\273\274\345\220\210\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        groupBox_30->setTitle(QString());
        label_33->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\347\273\274\345\220\210\347\212\266\346\200\201\346\217\217\350\277\260", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        zt5->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        zt5->setText(QString());
        groupBox_24->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        zt3->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        zt3->setText(QString());
        label_27->setText(QApplication::translate("YFMainWindow", "\345\275\223\345\211\215\344\273\273\345\212\241", 0, QApplication::UnicodeUTF8));
        groupBox_23->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        zt1->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        zt1->setText(QString());
        label_25->setText(QApplication::translate("YFMainWindow", "\345\275\223\345\211\215\346\223\215\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        groupBox_29->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        zt2->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        zt2->setText(QString());
        label_31->setText(QApplication::translate("YFMainWindow", "\345\275\223\345\211\215\346\223\215\344\275\234\344\272\272\345\221\230", 0, QApplication::UnicodeUTF8));
        groupBox_33->setTitle(QApplication::translate("YFMainWindow", "\347\256\241\347\220\206\347\273\204", 0, QApplication::UnicodeUTF8));
        groupBox_34->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        gl3->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        gl3->setText(QString());
        label_36->setText(QApplication::translate("YFMainWindow", "\347\256\241\347\220\206\350\212\202\347\202\271\346\240\207\350\257\206", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        gl4->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        gl4->setText(QString());
        label_38->setText(QApplication::translate("YFMainWindow", "\350\256\277\351\227\256\347\224\250\346\210\267IP", 0, QApplication::UnicodeUTF8));
        groupBox_35->setTitle(QString());
        label_23->setText(QApplication::translate("YFMainWindow", "trap\346\216\245\346\224\266\350\200\205IP", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        gl1->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        gl1->setText(QApplication::translate("YFMainWindow", "192.168.1.200", 0, QApplication::UnicodeUTF8));
        groupBox_36->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        gl2->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        gl2->setText(QString());
        label_37->setText(QApplication::translate("YFMainWindow", "\345\205\201\350\256\270\350\256\277\351\227\256IP", 0, QApplication::UnicodeUTF8));
        groupBox_37->setTitle(QApplication::translate("YFMainWindow", "\347\224\250\346\210\267\347\273\204", 0, QApplication::UnicodeUTF8));
        label_30->setText(QApplication::translate("YFMainWindow", "\347\224\250\346\210\267\346\225\260", 0, QApplication::UnicodeUTF8));
        label_32->setText(QApplication::translate("YFMainWindow", "\347\224\250\346\210\267\345\210\227\350\241\250", 0, QApplication::UnicodeUTF8));
        label_39->setText(QApplication::translate("YFMainWindow", "\347\224\250\346\210\267\350\257\201\344\271\246", 0, QApplication::UnicodeUTF8));
        label_40->setText(QApplication::translate("YFMainWindow", "\347\224\250\346\210\267\351\252\214\350\257\201\347\240\201", 0, QApplication::UnicodeUTF8));
        label_42->setText(QApplication::translate("YFMainWindow", "\346\235\203\351\231\220", 0, QApplication::UnicodeUTF8));
        label_43->setText(QApplication::translate("YFMainWindow", "\350\256\276\347\275\256\346\227\266\351\227\264", 0, QApplication::UnicodeUTF8));
        label_44->setText(QApplication::translate("YFMainWindow", "\346\234\211\346\225\210\346\234\237", 0, QApplication::UnicodeUTF8));
        label_45->setText(QApplication::translate("YFMainWindow", "\346\216\210\346\235\203\347\256\241\347\220\206", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        yh1->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh1->setText(QString());
#ifndef QT_NO_TOOLTIP
        yh2->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh2->setText(QString());
#ifndef QT_NO_TOOLTIP
        yh3->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh3->setText(QString());
#ifndef QT_NO_TOOLTIP
        yh4->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh4->setText(QString());
#ifndef QT_NO_TOOLTIP
        yh5->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh5->setText(QString());
#ifndef QT_NO_TOOLTIP
        yh6->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh6->setText(QString());
#ifndef QT_NO_TOOLTIP
        yh7->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh7->setText(QString());
#ifndef QT_NO_TOOLTIP
        yh8->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh8->setText(QString());
        UpUIFromAgent->setText(QApplication::translate("YFMainWindow", "UPUI", 0, QApplication::UnicodeUTF8));
        groupBox_77->setTitle(QApplication::translate("YFMainWindow", "AB\347\261\273", 0, QApplication::UnicodeUTF8));
        B1_1->clear();
        B1_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\234\252\345\220\257\345\212\250", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\345\267\262\345\220\257\345\212\250\357\274\210\346\255\243\345\270\270\357\274\211", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\226\271\344\275\215\350\264\237\351\231\220\344\275\215", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "3.\346\226\271\344\275\215\346\255\243\351\231\220\344\275\215", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "4.\346\226\271\344\275\215\351\224\201\347\264\247", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "9.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B1_2->clear();
        B1_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\234\252\345\220\257\345\212\250", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\345\267\262\345\220\257\345\212\250\357\274\210\346\255\243\345\270\270\357\274\211", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\351\253\230\344\275\216\350\264\237\351\231\220\344\275\215", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "3.\351\253\230\344\275\216\346\255\243\351\231\220\344\275\215", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "4.\351\253\230\344\275\216\351\224\201\347\264\247", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "9.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B2_1->clear();
        B2_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B2_2->clear();
        B2_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B3_1->clear();
        B3_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B3_2->clear();
        B3_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B3_3->clear();
        B3_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B3_4->clear();
        B3_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\227\240", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.GPS", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.Glonass", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "3.\345\214\227\346\226\227", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "4.B\347\240\201", 0, QApplication::UnicodeUTF8)
        );
        label_131->setText(QApplication::translate("YFMainWindow", "\346\226\271\344\275\215\344\274\272\346\234\215\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_130->setText(QApplication::translate("YFMainWindow", "\351\253\230\344\275\216\344\274\272\346\234\215\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_129->setText(QApplication::translate("YFMainWindow", "\345\215\225\347\253\231\346\226\271\344\275\215\347\274\226\347\240\201\345\231\250\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_128->setText(QApplication::translate("YFMainWindow", "\345\215\225\347\253\231\351\253\230\344\275\216\347\274\226\347\240\201\345\231\250\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_126->setText(QApplication::translate("YFMainWindow", "\345\215\225\347\253\231\346\227\266\347\273\237\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_127->setText(QApplication::translate("YFMainWindow", "\345\215\225\347\253\231\346\227\266\347\273\237\347\263\273\347\273\237\346\227\266\351\227\264\345\220\214\346\255\245\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_125->setText(QApplication::translate("YFMainWindow", "\345\215\225\347\253\231\346\227\266\347\273\237\347\263\273\347\273\237\346\227\266\351\227\264\351\242\221\347\216\207\345\207\206\347\241\256\345\272\246\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_124->setText(QApplication::translate("YFMainWindow", "\345\215\225\347\253\231\346\227\266\347\273\237\347\263\273\347\273\237\346\227\266\351\227\264\345\220\214\346\255\245\346\272\220", 0, QApplication::UnicodeUTF8));
        groupBox_76->setTitle(QString());
        label_116->setText(QApplication::translate("YFMainWindow", "\351\253\230\351\200\237\347\233\270\346\234\2721", 0, QApplication::UnicodeUTF8));
        label_117->setText(QApplication::translate("YFMainWindow", "\351\253\230\351\200\237\347\233\270\346\234\2722", 0, QApplication::UnicodeUTF8));
        label_118->setText(QApplication::translate("YFMainWindow", "\351\253\230\351\200\237\347\233\270\346\234\2723", 0, QApplication::UnicodeUTF8));
        B4_1_3->clear();
        B4_1_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_2_3->clear();
        B4_2_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_3_3->clear();
        B4_3_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_4_3->clear();
        B4_4_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_1_3->clear();
        B5_1_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_2_3->clear();
        B5_2_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_3_3->clear();
        B5_3_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_4_3->clear();
        B5_4_3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_1_2->clear();
        B4_1_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_2_2->clear();
        B4_2_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_3_2->clear();
        B4_3_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_4_2->clear();
        B4_4_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_1_2->clear();
        B5_1_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_2_2->clear();
        B5_2_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_3_2->clear();
        B5_3_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_4_2->clear();
        B5_4_2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\260\345\275\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_1_4->clear();
        B4_1_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_2_4->clear();
        B4_2_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_3_4->clear();
        B4_3_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_4_4->clear();
        B4_4_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_1_4->clear();
        B5_1_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_2_4->clear();
        B5_2_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_3_4->clear();
        B5_3_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_4_4->clear();
        B5_4_4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_1_5->clear();
        B4_1_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_2_5->clear();
        B4_2_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_3_5->clear();
        B4_3_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_4_5->clear();
        B4_4_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_1_5->clear();
        B5_1_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_2_5->clear();
        B5_2_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_3_5->clear();
        B5_3_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_4_5->clear();
        B5_4_5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\347\251\272\351\227\262", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\344\270\213\350\275\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        label->setText(QApplication::translate("YFMainWindow", "\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_120->setText(QApplication::translate("YFMainWindow", "\345\233\276\345\203\217\344\270\213\350\275\275\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_121->setText(QApplication::translate("YFMainWindow", "\345\233\276\345\203\217\350\256\260\345\275\225\347\263\273\347\273\237\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_122->setText(QApplication::translate("YFMainWindow", "\350\260\203\347\204\246\345\260\217\347\263\273\347\273\237\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_123->setText(QApplication::translate("YFMainWindow", "\346\213\215\346\221\204\345\270\247\351\242\221", 0, QApplication::UnicodeUTF8));
        label_119->setText(QApplication::translate("YFMainWindow", "\350\260\203\345\205\211\345\260\217\347\263\273\347\273\237\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        B4_1_1->clear();
        B4_1_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_2_1->clear();
        B4_2_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_3_1->clear();
        B4_3_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B4_4_1_->clear();
        B4_4_1_->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_1_1->clear();
        B5_1_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_2_1->clear();
        B5_2_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_3_1->clear();
        B5_3_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        B5_4_1->clear();
        B5_4_1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
        );
        label_136->setText(QApplication::translate("YFMainWindow", "\351\253\230\351\200\237\347\233\270\346\234\2724", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2261", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2262", 0, QApplication::UnicodeUTF8));
        label_28->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2263", 0, QApplication::UnicodeUTF8));
        label_29->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2264", 0, QApplication::UnicodeUTF8));
        A1->clear();
        A1->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A2->clear();
        A2->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A3->clear();
        A3->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A4->clear();
        A4->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\350\256\276\345\244\207\345\276\205\345\221\275", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\350\256\276\345\244\207\350\207\252\346\243\200", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\350\256\276\345\244\207\350\260\203\350\257\225", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "3.\350\256\276\345\244\207\346\240\207\346\240\241", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "4.\346\216\245\346\224\266\344\273\273\345\212\241\346\225\260\346\215\256", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "5.\346\265\213\351\207\217\346\225\260\346\215\256\344\270\212\344\274\240", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "6.\350\256\276\345\244\207\346\211\247\350\241\214\344\273\273\345\212\241", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "7.\346\265\213\351\207\217\346\225\260\346\215\256\344\272\213\345\220\216\345\244\204\347\220\206", 0, QApplication::UnicodeUTF8)
        );
        A5->clear();
        A5->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\345\215\212\350\207\252\345\212\250\346\234\252\350\267\237\350\270\252\357\274\210\345\276\205\346\234\272\357\274\211", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\347\250\213\345\272\217\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\346\225\260\345\255\227\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "3.\345\220\214\346\255\245\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "4.\345\256\232\347\202\271\345\274\225\345\257\274", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "5.\345\215\212\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "6.\345\244\232\350\267\257\345\244\215\345\220\210\350\267\237\350\270\252\357\274\210\350\236\215\345\220\210\350\267\237\350\270\252\357\274\211", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "7.\346\277\200\345\205\211\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "8.\351\233\267\350\276\276\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "9.\344\272\213\345\211\215\350\256\276\347\275\256\357\274\210\345\207\235\350\247\206\357\274\211\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "11.\347\224\265\350\247\2061\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "12.\347\224\265\350\247\2062\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "13.\347\224\265\350\247\2063\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "14.\347\224\265\350\247\2064\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "New Item", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "21.\347\272\242\345\244\2261\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "22.\347\272\242\345\244\2262\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "23.\347\272\242\345\244\2263\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "24.\347\272\242\345\244\2264\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "31.\347\264\253\345\244\226\350\207\252\345\212\250\350\267\237\350\270\252", 0, QApplication::UnicodeUTF8)
        );
        A6->clear();
        A6->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A7->clear();
        A7->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        label_52->setText(QApplication::translate("YFMainWindow", "\344\274\272\346\234\215\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_53->setText(QApplication::translate("YFMainWindow", "\346\265\213\350\247\222\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_47->setText(QApplication::translate("YFMainWindow", "\344\270\273\346\216\247\345\276\256\346\234\272\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_46->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_48->setText(QApplication::translate("YFMainWindow", "\350\256\276\345\244\207\350\267\237\350\270\252\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
        label_35->setText(QApplication::translate("YFMainWindow", "\346\225\260\346\215\256\344\272\244\344\272\222\350\256\241\347\256\227\346\234\272\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_54->setText(QApplication::translate("YFMainWindow", "\347\224\265\350\247\2061\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_55->setText(QApplication::translate("YFMainWindow", "\347\224\265\350\247\2062\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_56->setText(QApplication::translate("YFMainWindow", "\347\224\265\350\247\2063\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_57->setText(QApplication::translate("YFMainWindow", "\347\224\265\350\247\2064\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_58->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2261\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_59->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2262\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_60->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2263\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_61->setText(QApplication::translate("YFMainWindow", "\347\272\242\345\244\2264\345\210\206\347\263\273\347\273\237\345\267\245\344\275\234\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        A8->clear();
        A8->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A9->clear();
        A9->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A10->clear();
        A10->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A11->clear();
        A11->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A12->clear();
        A12->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A13->clear();
        A13->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        A14->clear();
        A14->insertItems(0, QStringList()
         << QApplication::translate("YFMainWindow", "0.\346\255\243\345\270\270", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "1.\346\225\205\351\232\234", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("YFMainWindow", "2.\345\205\263\346\234\272", 0, QApplication::UnicodeUTF8)
        );
        checkBox_2->setText(QApplication::translate("YFMainWindow", "\345\205\250\350\256\276\345\244\207\346\211\213\345\212\250\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        label_41->setText(QApplication::translate("YFMainWindow", "\347\212\266\346\200\201\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        trapID_43->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_43->setText(QString());
        label_49->setText(QApplication::translate("YFMainWindow", "TrapID", 0, QApplication::UnicodeUTF8));

        const bool __sortingEnabled = listWidget->isSortingEnabled();
        listWidget->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = listWidget->item(0);
        ___qlistwidgetitem->setText(QApplication::translate("YFMainWindow", "192.168.2.201", 0, QApplication::UnicodeUTF8));
        QListWidgetItem *___qlistwidgetitem1 = listWidget->item(1);
        ___qlistwidgetitem1->setText(QApplication::translate("YFMainWindow", "192.168.43.201", 0, QApplication::UnicodeUTF8));
        listWidget->setSortingEnabled(__sortingEnabled);

        writeagent->setText(QApplication::translate("YFMainWindow", "\345\206\231\345\205\245\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        reset->setText(QApplication::translate("YFMainWindow", "reset", 0, QApplication::UnicodeUTF8));
        traptest->setText(QApplication::translate("YFMainWindow", "Trap Test", 0, QApplication::UnicodeUTF8));
        stopAgent->setText(QApplication::translate("YFMainWindow", "stop", 0, QApplication::UnicodeUTF8));
        startAgent->setText(QApplication::translate("YFMainWindow", "start", 0, QApplication::UnicodeUTF8));
        quitAgent->setText(QApplication::translate("YFMainWindow", "quit", 0, QApplication::UnicodeUTF8));
        readcommunity->setText(QApplication::translate("YFMainWindow", "public", 0, QApplication::UnicodeUTF8));
        label_51->setText(QApplication::translate("YFMainWindow", "\345\206\231\347\224\250\346\210\267", 0, QApplication::UnicodeUTF8));
        label_50->setText(QApplication::translate("YFMainWindow", "\350\257\273\347\224\250\346\210\267", 0, QApplication::UnicodeUTF8));
        redcommunity->setText(QApplication::translate("YFMainWindow", "private", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("YFMainWindow", "Tab 1", 0, QApplication::UnicodeUTF8));
        ModifyButton_2->setText(QApplication::translate("YFMainWindow", "ModifyButton", 0, QApplication::UnicodeUTF8));
        DeleteButton_2->setText(QApplication::translate("YFMainWindow", "DeleteButton", 0, QApplication::UnicodeUTF8));
        AddButton_2->setText(QApplication::translate("YFMainWindow", "AddButton", 0, QApplication::UnicodeUTF8));
        ReadFButton->setText(QApplication::translate("YFMainWindow", "ReadFile", 0, QApplication::UnicodeUTF8));
        WriteFile->setText(QApplication::translate("YFMainWindow", "WriteFile", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("YFMainWindow", "Tab 2", 0, QApplication::UnicodeUTF8));
        groupBox_75->setTitle(QString());
        checkBox_6->setText(QApplication::translate("YFMainWindow", "\345\210\206\350\256\276\345\244\207\346\211\213\345\212\250\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        yh5_6->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh5_6->setText(QString());
        label_110->setText(QApplication::translate("YFMainWindow", "\345\210\206\347\263\273\347\273\237", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        yh5_7->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh5_7->setText(QString());
        label_111->setText(QApplication::translate("YFMainWindow", "\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        yh5_8->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        yh5_8->setText(QString());
        label_112->setText(QApplication::translate("YFMainWindow", "\345\215\225\347\253\231\350\267\237\350\270\252\346\250\241\345\274\217\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("YFMainWindow", "\345\272\224\347\224\250", 0, QApplication::UnicodeUTF8));
        groupBox_66->setTitle(QApplication::translate("YFMainWindow", "\347\212\266\346\200\201\345\256\236\346\227\266\346\230\276\347\244\272", 0, QApplication::UnicodeUTF8));
        groupBox_67->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        trapID_29->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_29->setText(QString());
        label_91->setText(QApplication::translate("YFMainWindow", "\346\213\215\346\221\204\351\242\221\347\216\207", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        trapID_31->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_31->setText(QString());
#ifndef QT_NO_TOOLTIP
        trapID_39->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_39->setText(QString());
        groupBox_68->setTitle(QString());
#ifndef QT_NO_TOOLTIP
        trapID_32->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_32->setText(QString());
        label_92->setText(QApplication::translate("YFMainWindow", "\345\205\250\350\256\276\345\244\207\345\267\245\344\275\234\347\212\266\346\200\201\346\230\276\347\244\272", 0, QApplication::UnicodeUTF8));
        groupBox_69->setTitle(QString());
        label_93->setText(QApplication::translate("YFMainWindow", "\350\267\237\350\270\252\346\250\241\345\274\217", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        trapID_34->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_34->setText(QString());
#ifndef QT_NO_TOOLTIP
        trapID_35->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_35->setText(QString());
#ifndef QT_NO_TOOLTIP
        trapID_40->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        trapID_40->setText(QString());
        label_94->setText(QApplication::translate("YFMainWindow", "1#\346\234\272", 0, QApplication::UnicodeUTF8));
        label_95->setText(QApplication::translate("YFMainWindow", "2#\346\234\272", 0, QApplication::UnicodeUTF8));
        label_96->setText(QApplication::translate("YFMainWindow", "3#\346\234\272", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class YFMainWindow: public Ui_YFMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YFMAINWINDOW_H
