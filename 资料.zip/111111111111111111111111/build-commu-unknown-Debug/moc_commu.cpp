/****************************************************************************
** Meta object code from reading C++ file 'commu.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../commu/commu.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'commu.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_commu[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
       7,    6,    6,    6, 0x05,

 // slots: signature, parameters, type, tag, flags
      21,    6,    6,    6, 0x0a,
      55,    6,    6,    6, 0x0a,
      73,    6,    6,    6, 0x0a,
      91,    6,    6,    6, 0x0a,
     111,    6,    6,    6, 0x0a,
     131,    6,    6,    6, 0x0a,
     151,    6,    6,    6, 0x0a,
     171,    6,    6,    6, 0x0a,
     199,    6,    6,    6, 0x0a,
     217,    6,    6,    6, 0x0a,
     238,    6,    6,    6, 0x0a,
     258,    6,    6,    6, 0x0a,
     279,    6,    6,    6, 0x0a,
     298,  295,    6,    6, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_commu[] = {
    "commu\0\0wmuserapply()\0"
    "OnBnClickedButtonSetupMulsource()\0"
    "OnButtonNewAdd1()\0OnButtonDelAdd1()\0"
    "OnButtonNewAdd2_1()\0OnButtonDelAdd2_1()\0"
    "OnButtonNewAdd2_2()\0OnButtonDelAdd2_2()\0"
    "OnBnClickedButtonSetupTip()\0"
    "OnButtonSetPath()\0OnButtonSetupInner()\0"
    "OnButtonSetupSave()\0OnButtonSetupApply()\0"
    "OnSetupCancel()\0it\0setflag(QTableWidgetItem*)\0"
};

void commu::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        commu *_t = static_cast<commu *>(_o);
        switch (_id) {
        case 0: _t->wmuserapply(); break;
        case 1: _t->OnBnClickedButtonSetupMulsource(); break;
        case 2: _t->OnButtonNewAdd1(); break;
        case 3: _t->OnButtonDelAdd1(); break;
        case 4: _t->OnButtonNewAdd2_1(); break;
        case 5: _t->OnButtonDelAdd2_1(); break;
        case 6: _t->OnButtonNewAdd2_2(); break;
        case 7: _t->OnButtonDelAdd2_2(); break;
        case 8: _t->OnBnClickedButtonSetupTip(); break;
        case 9: _t->OnButtonSetPath(); break;
        case 10: _t->OnButtonSetupInner(); break;
        case 11: _t->OnButtonSetupSave(); break;
        case 12: _t->OnButtonSetupApply(); break;
        case 13: _t->OnSetupCancel(); break;
        case 14: _t->setflag((*reinterpret_cast< QTableWidgetItem*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData commu::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject commu::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_commu,
      qt_meta_data_commu, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &commu::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *commu::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *commu::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_commu))
        return static_cast<void*>(const_cast< commu*>(this));
    return QDialog::qt_metacast(_clname);
}

int commu::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void commu::wmuserapply()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
