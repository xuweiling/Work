﻿// NetCommuZK.cpp: implementation of the CNetCommuZK class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "commu.h"
#include "NetCommuZK.h"
#include "BaseFile.h"
#include <math.h>
#include "CommuDlg.h"
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

char  BufferMib[MACRO_BUFFER_SIZE];					//用于传输MIB状态

//BYTE CNetCommuZK::BufferSave_Send[MACRO_FILE_SIZE];				//将要保存到文件中的发送数据
//BYTE CNetCommuZK::BufferSave_Recv[MACRO_FILE_SIZE];				//将要保存到文件中的接收数据
int CNetCommuZK::BufferSave_SendLength;							//将要保存到文件中的发送数据长度
int CNetCommuZK::BufferSave_RecvLength;							//将要保存到文件中的接收数据长度 使用static,这样所有的数据都保存在一个文件中
QString CNetCommuZK::BufferSaveFilePath_Send;					//将要保存的发送数据文件路径
QString CNetCommuZK::BufferSaveFilePath_Recv;					//将要保存的接收数据文件路径
SYSTEMTIME CNetCommuZK::StartTime;							//起始时刻
SYSTEMTIME CNetCommuZK::EndTime;								//保存时刻
//DWORD	CNetCommu::BIDMeasure;									//实算数据帧BID(仅供SaveFile使用)
//DWORD	CNetCommu::BIDTimer;									//常时数据帧BID(仅供SaveFile使用)
//DWORD	CNetCommu::BIDExam;										//时延测试帧BID(仅供SaveFile使用)
//DWORD	CNetCommu::BIDT0;										//T0数据帧BID(仅供SaveFile使用)
//DWORD	CNetCommu::BIDWYD;										//外部说明数据帧头信息(仅供SaveFile使用)


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNetCommuZK::CNetCommuZK(QObject *parent) :
    QObject(parent)
{
    KeepConnecting = false;
    CurrentMode = Normal;
    TimeSource = Time_GPS;
    FirstSetSystemTime = true;
    memset(BufferRecv_Passed, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend_Passed, 0, MACRO_BUFFER_SIZE);
#ifdef LINUXQT
    PDlg = NULL;
#endif
    memset(BufferMib, 0, MACRO_BUFFER_SIZE);
    memset(BufferRecv, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend, 0, MACRO_BUFFER_SIZE);
//	memset(BufferSave_Send, 0, MACRO_FILE_SIZE);
//	memset(BufferSave_Recv, 0, MACRO_FILE_SIZE);
    BufferSave_SendLength = 0;
    BufferSave_RecvLength = 0;
    memset(&MeasureHEADER, 0, sizeof(HEADERStruct));
    memset(&TimerSendHEADER, 0, sizeof(HEADERStruct));
    memset(&TimerRecvHEADER, 0, sizeof(HEADERStruct));
    memset(&ExamSendHEADER, 0, sizeof(HEADERStruct));
    memset(&ExamRecvHEADER, 0, sizeof(HEADERStruct));
    memset(&T0HEADER, 0, sizeof(HEADERStruct));
    memset(WYDHEADER, 0, 30*sizeof(HEADERStruct));

    EjectPosB = 0;
    EjectPosL = 0;
    EjectPosH = 0;
//	EjectPosX = 0;
//	EjectPosY = 0;
//	EjectPosZ = 0;
    EjectAngle = 0;

    BIDTest = 0;
    pBufferRecvLength = 0;
    pBufferSendLength = 0;
    pBufferSendedLength = 0;

    INI_DATALENGTH_MEASURE = 32;						//实算数据中数据区有效长度 = 32, 22+10
    INI_DATALENGTH_THEORY = 60;							//引入数据中数据区有效长度 = 28
    INI_DATALENGTH_EXAM = 48;							//时延测试数据区长度
    INI_DATALENGTH_T0 = 36;								//T0数据区长度
    INI_REVERSE_DATALENGTH = 10;						//正式实算数据中最后保留的数据长度
    INI_REVERSE_DATACONTENT = "7fffffff000000007fff";	//正式实算数据中最后保留的数据内容

    memset(Prepost_X, 0, sizeof(Prepost_X));
    memset(Prepost_Y, 0, sizeof(Prepost_Y));
    memset(Prepost_Z, 0, sizeof(Prepost_Z));
    PrepostCount = 0;//连续预推的数目
    PrepostDataLength = 0;//预推样本的数目
    PrepostValid = false;//是否允许预推
    IsLeadExist = false;//是否正在接收外引导(即本周期内是否接受到外引导)
}

CNetCommuZK::~CNetCommuZK()
{

}

/************************************************************************/
/* 网络启动，线程启动                              */
/************************************************************************/
bool CNetCommuZK::StartConnect( )
{
    bool ret = false;
    KeepConnecting = true;
    memset(BufferRecv_Passed, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend_Passed, 0, MACRO_BUFFER_SIZE);
    memset(BufferRecv, 0, MACRO_BUFFER_SIZE);
    memset(BufferSend, 0, MACRO_BUFFER_SIZE);
//	memset(BufferSave_Send, 0, MACRO_FILE_SIZE);
//	memset(BufferSave_Recv, 0, MACRO_FILE_SIZE);
    BufferSave_SendLength = 0;
    BufferSave_RecvLength = 0;
    BIDTest = 0;
    pBufferRecvLength = 0;
    pBufferSendLength = 0;
    pBufferSendedLength = 0;

    ReadIniFile();					//读取配置

    memcpy( &(theSocket.LocalSet), &LocalSet, sizeof(SocketSetting));
    theSocket.pSaveBuffer = BufferRecv;
    ret = theSocket.Initial( this );		//建立连接
    if(!ret)
    {
        QString pMessage;
        pMessage=pMessage.sprintf("对主控的网卡:%d.%d.%d.%d绑定失败 \n  请检查网络连接和交换机\n  之后重新启动本软件，否则本网卡失效",
            (LocalSet.IPAdd.sin_addr.s_addr)&0xff,
            (LocalSet.IPAdd.sin_addr.s_addr>>8)&0xff,
            (LocalSet.IPAdd.sin_addr.s_addr>>16)&0xff,
            (LocalSet.IPAdd.sin_addr.s_addr>>24)&0xff);
        AfxMessageBox(pMessage);
        SocketEnable = false;
//		theSocket.ShutDown(2);
    }
    else
    {
        SocketEnable = true;
    }
    ReceivedNo = 0;

    GetSystemTime(&StartTime);					//起始时刻

    //文件初始化，等待写入
    QString startMessage;
    SaveFileName_Send=SaveFileName_Send.sprintf("/发送主控%d年%d月%d日%d时%d分%d秒.txt", StartTime.tm_year, StartTime.tm_mon,
        StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    startMessage=startMessage.sprintf("%d年%d月%d日%d时%d分%d秒 开始记录: \n", StartTime.tm_year, StartTime.tm_mon,
                        StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    SaveFileName_Send = BufferSaveFilePath_Send + SaveFileName_Send;
    SendFile=::open(SaveFileName_Send.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    ::write(SendFile,startMessage.toAscii(),strlen(startMessage.toAscii()));

    SaveFileName_Recv=SaveFileName_Recv.sprintf("/接收主控%d年%d月%d日%d时%d分%d秒.txt", StartTime.tm_year, StartTime.tm_mon,
                                                StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    startMessage=startMessage.sprintf("%d年%d月%d日%d时%d分%d秒 开始记录: \n", StartTime.tm_year, StartTime.tm_mon,
                                      StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    SaveFileName_Recv = BufferSaveFilePath_Recv + SaveFileName_Recv;
    RecvFile=::open(SaveFileName_Recv.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    ::write(RecvFile,startMessage.toAscii(),strlen(startMessage.toAscii()));

    OctFileName_Send = SaveFileName_Send.left(SaveFileName_Send.lastIndexOf('.')) + "解码.txt";
    OctFileName_Recv = SaveFileName_Recv.left(SaveFileName_Recv.lastIndexOf('.')) + "解码.txt";
    SendFileOct=::open(OctFileName_Send.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    RecvFileOct=::open(OctFileName_Recv.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);

    startMessage=QString("发送主控数据\n序号    时间    类别    发射坐标X(米)    发射坐标Y(米)    发射坐标Z(米)    起飞时刻    \n");
    ::write(SendFileOct,startMessage.toAscii(),strlen(startMessage.toAscii()));//写入标题
    startMessage=QString("接受主控数据\n序号    时间    方位角A(度)    俯仰角E(度)    伺服模式    目标数目    脱靶量X(秒)    脱靶量Y(秒)\n");
    ::write(RecvFileOct,startMessage.toAscii(),strlen(startMessage.toAscii()));

    DesI = 0;

    memset(Prepost_X, 0, sizeof(Prepost_X));
    memset(Prepost_Y, 0, sizeof(Prepost_Y));
    memset(Prepost_Z, 0, sizeof(Prepost_Z));
    PrepostCount = 0;//连续预推的数目
    PrepostDataLength = 0;//预推样本的数目
    PrepostValid = false;//是否允许预推
    IsLeadExist = false;//是否正在接收外引导(即本周期内是否接受到外引导)


    QString iniFilePath = INIFILE;
    char iniFilePath_a[256];
    getcwd(iniFilePath_a,256);
    iniFilePath = iniFilePath_a;
    iniFilePath = iniFilePath+ "/settest.ini";

    CBaseFile iniFile;
    QString sectionName;
    sectionName = "外引导";
    PrepostThreshold_X = iniFile.GetIniInt(sectionName, "X方向剔除阈值", iniFilePath);
    PrepostThreshold_Y = iniFile.GetIniInt(sectionName, "Y方向剔除阈值", iniFilePath);
    PrepostThreshold_Z = iniFile.GetIniInt(sectionName, "Z方向剔除阈值", iniFilePath);
    if(PrepostThreshold_X==-1)
        PrepostThreshold_X = 10000;//1Km
    if(PrepostThreshold_Y==-1)
        PrepostThreshold_Y = 10000;//1Km
    if(PrepostThreshold_Z==-1)
        PrepostThreshold_Z = 10000;//1Km

    return true;
}

/************************************************************************/
/* 发送数据，数据转换在这里进行
1.准备状态：BufferSend_Passed具有数据，数据必定为符合HEADER的外部说明数据、T0，
            暂不区分是真实数据还是调试数据（由于调试的只是数据，不调包头，
            所以无需单独处理调试状态）
            注意要保证互斥性
2.参数；1=T0;2=外部说明数据;
本函数将原始的数据 BufferSend_Passed 进行转换，然后用发送端口发出，同时记录
到文件中，同时还要通知窗口进行显示更新
a.复制
b.转换
c.网络发送
d.通知窗口更新显示
e.数据存盘
                             */
/************************************************************************/
bool CNetCommuZK::SendData(int type)
{
    if(!KeepConnecting)
    {
        return false;
    }
    if(!SocketEnable)
        return false;
//a.复制
    memset(BufferSend, 0, MACRO_BUFFER_SIZE);
    memcpy(BufferSend, BufferSend_Passed, MACRO_BUFFER_SIZE);

//b.转换
    int sendLength = TransCT2ZK(BufferSend, MACRO_BUFFER_SIZE, BufferSendtemp, MACRO_BUFFER_SIZE, type);
    memcpy(BufferSend, BufferSendtemp, MACRO_BUFFER_SIZE);

//c.网络发送
    QString pAddStr;
    pAddStr=pAddStr.sprintf("%d.%d.%d.%d",
        (ZKSet.IPAdd.sin_addr.s_addr)&0xff,
        (ZKSet.IPAdd.sin_addr.s_addr>>8)&0xff,
        (ZKSet.IPAdd.sin_addr.s_addr>>16)&0xff,
        (ZKSet.IPAdd.sin_addr.s_addr>>24)&0xff);
    theSocket.SendTo(BufferSend, sendLength, ZKSet.PortReceive, pAddStr.toAscii());

//d.通知窗口更新显示
    memcpy(BufferSended_Passed, BufferSendtemp, MACRO_BUFFER_SIZE);
    emit WM_USER_SENDED_ZK(0, 0);	//消息通知

//e.数据存盘
    //输出文件
    SYSTEMTIME curTime;
    QString startMessage;
    QString tempMessage;
    QString iPstr;
    unsigned   char   *pIP;

    //输出文件
    curTime = GetTimeMilli(TimeSource);//采用通用时间
    startMessage=startMessage.sprintf("%.2d:%.2d:%.2d::%.3d : LOCAL => ", curTime.tm_hour, curTime.tm_min,
        curTime.tm_sec, curTime.tm_msec);
    for(int byteCounter=0; byteCounter<sendLength; byteCounter++)
    {
        int temp_Char = (BYTE)(BufferSendtemp[byteCounter]);
        tempMessage=tempMessage.sprintf("%.2x", temp_Char);
        startMessage = startMessage + tempMessage;
    }

    pIP   =   (unsigned   char*)&(ZKSet.IPAdd.sin_addr.s_addr);
    iPstr=iPstr.sprintf("%.3u.%.3u.%.3u.%.3u", *pIP, *(pIP+1), *(pIP+2), *(pIP+3));
    startMessage = startMessage + " => " + iPstr + "\n";

    ::write(SendFile,startMessage.toAscii(),strlen(startMessage.toAscii()));
    OctSwitch(0, startMessage,  &tempMessage);
    ::write(SendFileOct,tempMessage.toAscii(),strlen(tempMessage.toAscii()));
    //输出文件结束
    return true;
}

/************************************************************************/
/* 发送数据，数据转换在这里进行
参数	sendDataBuffer:数据区
        sendDataBufferLength:数据区长度
强制发送
 */
/************************************************************************/
bool CNetCommuZK::SendData(BYTE* sendDataBuffer, int sendDataBufferLength, int type)
{
    if(!SocketEnable)
        return false;
    if(!KeepConnecting)
        return false;
    QString pAddStr;
    pAddStr=pAddStr.sprintf("%d.%d.%d.%d",
        (ZKSet.IPAdd.sin_addr.s_addr)&0xff,
        (ZKSet.IPAdd.sin_addr.s_addr>>8)&0xff,
        (ZKSet.IPAdd.sin_addr.s_addr>>16)&0xff,
        (ZKSet.IPAdd.sin_addr.s_addr>>24)&0xff);
    theSocket.SendTo(sendDataBuffer, sendDataBufferLength, ZKSet.PortReceive, pAddStr.toAscii());

    //输出文件
    SYSTEMTIME curTime;
    QString startMessage;
    QString tempMessage;
    QString iPstr;
    unsigned   char   *pIP;

    //输出文件
    curTime = GetTimeMilli(TimeSource);//采用通用时间
    startMessage=startMessage.sprintf("%.2d:%.2d:%.2d::%.3d : LOCAL => ", curTime.tm_hour, curTime.tm_min,
        curTime.tm_sec, curTime.tm_msec);
    for(int byteCounter=0; byteCounter<sendDataBufferLength; byteCounter++)
    {
        int temp_Char = (BYTE)(sendDataBuffer[byteCounter]);
        tempMessage=tempMessage.sprintf("%.2x", temp_Char);
        startMessage = startMessage + tempMessage;
    }

    pIP   =   (unsigned   char*)&(ZKSet.IPAdd.sin_addr.s_addr);
    iPstr=iPstr.sprintf("%.3u.%.3u.%.3u.%.3u", *pIP, *(pIP+1), *(pIP+2), *(pIP+3));
    startMessage = startMessage + " => " + iPstr + "\n";

    ::write(SendFile,startMessage.toAscii(),strlen(startMessage.toAscii()));
    OctSwitch(0, startMessage,  &tempMessage);
    ::write(SendFileOct,tempMessage.toAscii(),strlen(tempMessage.toAscii()));
    //输出文件结束

    return true;
}

/************************************************************************/
/* 关闭连接                              */
/************************************************************************/
bool CNetCommuZK::CloseConnect( )
{
    KeepConnecting = false;
    FirstSetSystemTime = true;
    theSocket.CloseConnect();

    if(::close(SendFile)==-1)
    {
        //AfxMessageBox("file close error");
    }
    if(::close(RecvFile)==-1)
    {
        //AfxMessageBox("file close error");
    }
    if(::close(SendFileOct)==-1)
    {
        //AfxMessageBox("file close error");
    }
    if(::close(RecvFileOct)==-1)
    {
        //AfxMessageBox("file close error");
    }

    return true;
}

/************************************************************************/
/* 接收到数据的通知，此时需要做数据处理
1.准备状态：BufferRecv具有数据，数据是实算数据
            注意要保证互斥性

  本函数将原始的数据 BufferRecv 通知窗口进行显示更新，同时记录到文件中，
同时还要通知窗口进行显示更新
a.复制
b.通知窗口更新显示
c.数据存盘
d.如果需要就刷新系统时间
*/
/************************************************************************/
bool CNetCommuZK::Receive()
{
    if(!SocketEnable)
        return false;
    if(!KeepConnecting)
    {
        return false;
    }

//a.复制
    int ts=errno;
    if(SOCKET_ERROR == theSocket.pBufferLength)
    {
        TRACE("接受数据出错 ErroCode=%d\n", ts);
        return false;
    }
    else
    {
        TRACE("接受\n");
    }

    pBufferRecvLength = theSocket.pBufferLength;						//保存长度
    if(theSocket.DataSource.IPAdd.sin_addr.s_addr != ZKSet.IPAdd.sin_addr.s_addr)	//来路明了的数据方予处理
    {
        return false;
    }
    memcpy(BufferRecv_Passed, BufferRecv, pBufferRecvLength);
    memcpy(BufferRecvtemp, BufferRecv, pBufferRecvLength);

    ReceivedNo++;
    if(ReceivedNo>65535)
        ReceivedNo=0;
    if((ReceivedNo%60) == 1)//请注意此处可能需要更改频率
    {
        memset(BufferMib, 0, MACRO_BUFFER_SIZE);
        memcpy(BufferMib, BufferRecvtemp, pBufferRecvLength);//通过共享变量来处理
       // (CCommuDlg *)Pf->Dialog_Snmp->TransData(BufferMib);
        emit WM_TRANSDATA(BufferMib);
//		SendMib(BufferMib, pBufferRecvLength, "运管系统"); //运管 Yan 20110529++ 20110703++ 将接收到的所有东西都给运管
    }

//b.通知窗口
    emit WM_USER_RECEIVED_ZK(4, 0);//通知窗口来取值,第1个参数表明是主控

//c.数据存盘
    //输出文件
    SYSTEMTIME curTime;
    QString startMessage;
    QString tempMessage;
    QString iPstr;
    unsigned   char   *pIP;

    curTime = GetTimeMilli(TimeSource);//采用通用时间
    pIP   =   (unsigned   char*)&(ZKSet.IPAdd.sin_addr.s_addr);
    iPstr=iPstr.sprintf("%.3u.%.3u.%.3u.%.3u", *pIP, *(pIP+1), *(pIP+2), *(pIP+3));
    startMessage=startMessage.sprintf("%.2d:%.2d:%.2d::%.3d : 主控", curTime.tm_hour, curTime.tm_min,
        curTime.tm_sec, curTime.tm_msec);
    startMessage = startMessage + iPstr + " => ";
    for(int byteCounter=0; byteCounter<pBufferRecvLength; byteCounter++)
    {
        int temp_Char = (BYTE)(BufferRecvtemp[byteCounter]);
        tempMessage=tempMessage.sprintf("%.2x", temp_Char);
        startMessage = startMessage + tempMessage;
        if((byteCounter==2)||(byteCounter==10)||(byteCounter==31)||(byteCounter==18))
        {
            startMessage = startMessage + " ";
        }
    }
    startMessage = startMessage + " => LOCAL \n";

    ::write(RecvFile,startMessage.toAscii(),strlen(startMessage.toAscii()));
    OctSwitch(1, startMessage,  &tempMessage);
    ::write(RecvFileOct,tempMessage.toAscii(),strlen(tempMessage.toAscii()));
    //输出文件结束

//d.更新系统时间
    if(	FirstSetSystemTime)
    {
        DWORD milSecondCount = 0;
        milSecondCount = GetTime(TimeSource);
        FirstSetSystemTime = false;
    }

    return true;
}

/************************************************************************/
/* 读取配置文件                             */
/************************************************************************/
bool CNetCommuZK::ReadIniFile()
{
    char tempPathString_a[256];
    getcwd(tempPathString_a,256);
    QString tempPathString;
    tempPathString = tempPathString_a;
    tempPathString = tempPathString+ "/settest.ini";

    CBaseFile iniFile;
    QString sectionName;
    QString secContent;
    BYTE ip1, ip2, ip3, ip4;
    DWORD tempValue;

//IP设置
    sectionName = "网络配置";
    ip1 = iniFile.GetIniInt(sectionName, "主控IP1", tempPathString);
    ip2 = iniFile.GetIniInt(sectionName, "主控IP2", tempPathString);
    ip3 = iniFile.GetIniInt(sectionName, "主控IP3", tempPathString);
    ip4 = iniFile.GetIniInt(sectionName, "主控IP4", tempPathString);
    ZKSet.IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);
    ZKSet.PortReceive = iniFile.GetIniInt(sectionName, "主控端口", tempPathString);
    ZKSet.PortSend = ZKSet.PortReceive;
    ZKSet.WayChose = 0;//主控机的配置

    ip1 = iniFile.GetIniInt(sectionName, "本地对主控路由IP1", tempPathString);
    ip2 = iniFile.GetIniInt(sectionName, "本地对主控路由IP2", tempPathString);
    ip3 = iniFile.GetIniInt(sectionName, "本地对主控路由IP3", tempPathString);
    ip4 = iniFile.GetIniInt(sectionName, "本地对主控路由IP4", tempPathString);
    LocalSet.IPAdd.sin_addr.s_addr = htonl(ip1*256*256*256 + ip2*256*256 + ip3*256 + ip4);
    LocalSet.PortReceive = ZKSet.PortSend;
    LocalSet.PortSend = LocalSet.PortSend;
    LocalSet.WayChose = 0;//本地对主控的配置


//协议设置
    sectionName = "协议设置";
    INI_DATALENGTH_MEASURE = iniFile.GetIniInt(sectionName, "实算数据区长度", tempPathString);
    INI_DATALENGTH_THEORY = iniFile.GetIniInt(sectionName, "引入数据区长度", tempPathString);
    INI_REVERSE_DATALENGTH = iniFile.GetIniInt(sectionName, "填充区长度", tempPathString); //Jerry 20110629++
    INI_REVERSE_DATACONTENT = iniFile.GetIniStr(sectionName, "填充区内容", tempPathString);//Jerry 20110629++
    INI_DATALENGTH_ZK = iniFile.GetIniInt(sectionName, "主控数据长度", tempPathString);
//HEADER固定值
    HEADERStruct tempHEADER;
    memset(&tempHEADER, 0, sizeof(HEADERStruct));

    sectionName = "包头数据";
    secContent = iniFile.GetIniStr(sectionName, "VER", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(&(tempHEADER.v_Version), &tempValue, 1);

//以上为共有的信息，下面只处理BID和MID
    secContent = iniFile.GetIniStr(sectionName, "MID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

//Time 发常时信息
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID_T", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID常时", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);

    tempHEADER.v_Length[0] = 04;
    tempHEADER.v_Length[1] = 0;

    memcpy(&TimerSendHEADER, &tempHEADER, sizeof(HEADERStruct));


//Time 收常时信息 注意SID和DID要颠倒
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID_T", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID常时", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);

    tempHEADER.v_Length[0] = 04;
    tempHEADER.v_Length[1] = 0;

    memcpy(&TimerRecvHEADER, &tempHEADER, sizeof(HEADERStruct));

//实算
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "MID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP1, &tempValue, 2);

    secContent = iniFile.GetIniStr(sectionName, "BID实算数据", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);

    tempHEADER.v_Length[0] = INI_DATALENGTH_MEASURE;
    tempHEADER.v_Length[1] = 0;

    memcpy(&MeasureHEADER, &tempHEADER, sizeof(HEADERStruct));

//时延测试	发
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "BID时延测试", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

    memcpy(&ExamSendHEADER, &tempHEADER, sizeof(HEADERStruct));

//时延测试	收
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "BID时延测试", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

    memcpy(&ExamRecvHEADER, &tempHEADER, sizeof(HEADERStruct));

//T0
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "BID绝对时T0", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP4, &tempValue, 4);//将时延测试的BID读入

    memcpy(&T0HEADER, &tempHEADER, sizeof(HEADERStruct));

//外部说明
    secContent = iniFile.GetIniStr(sectionName, "SID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP3, &tempValue, 4);

    secContent = iniFile.GetIniStr(sectionName, "DID", tempPathString);
    tempValue =CharToHex(secContent);//不得超过4byte
    memcpy(tempHEADER.v_SP2, &tempValue, 4);

    for(int tem_I=0; tem_I<30; tem_I++)
    {
        QString temp_DD;
        temp_DD=temp_DD.sprintf("BID引入%d", tem_I+1);
        secContent = iniFile.GetIniStr(sectionName, temp_DD, tempPathString);
        tempValue =CharToHex(secContent);//不得超过4byte
        memcpy(tempHEADER.v_SP4, &tempValue, 4);
        tempHEADER.v_Length[0] = INI_DATALENGTH_THEORY;
        tempHEADER.v_Length[1] = 0;
        memcpy(WYDHEADER+tem_I, &tempHEADER, sizeof(HEADERStruct));
    }

    sectionName = "程序配置";
    //发射点的大地直角坐标系坐标
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标B", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosB = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标L", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosL = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射点坐标H", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectPosH = atof(secContent.toAscii());
    secContent	= iniFile.GetIniStr(sectionName, "发射角", tempPathString);//发射点的大地直角坐标系坐标 Jerry 20110707++
    EjectAngle = atof(secContent.toAscii());
    //发射点的大地直角坐标系坐标

    for(int tem_I=0; tem_I<30; tem_I++)
    {
        memcpy(BIDWYD+tem_I, WYDHEADER[tem_I].v_SP4, 4);			//复制标准
    }

    memcpy(&BIDT0, T0HEADER.v_SP4, 4);			//复制标准
    memcpy(&BIDExam, ExamSendHEADER.v_SP4, 4);	//复制标准
    memcpy(&BIDTimer, TimerSendHEADER.v_SP4, 4);	//复制标准
    memcpy(&BIDMeasure, MeasureHEADER.v_SP4, 4);	//复制标准

    unsigned short diffDay;
    diffDay = GetDate();
    memcpy(MeasureHEADER.v_Date, &diffDay, 2);
    memcpy(TimerSendHEADER.v_Date, &diffDay, 2);
    memcpy(TimerRecvHEADER.v_Date, &diffDay, 2);
    memcpy(ExamSendHEADER.v_Date, &diffDay, 2);
    memcpy(ExamRecvHEADER.v_Date, &diffDay, 2);
    memcpy(T0HEADER.v_Date, &diffDay, 2);
    for(int tem_I=0; tem_I<30; tem_I++)
    {
        memcpy(WYDHEADER[tem_I].v_Date, &diffDay, 2);				//在程序开启时得到日期
    }

    return true;
}

/************************************************************************/
/* 设置系统时间
参数 MSend 为0.1毫秒                       */
/************************************************************************/
bool CNetCommuZK::SetSystemT( DWORD MSend )
{
    SYSTEMTIME pRecvTime;
    GetSystemTime(&pRecvTime);
    pRecvTime.tm_hour = MSend/10000/60/60;
    pRecvTime.tm_min = (MSend/10000/60)%60;
    pRecvTime.tm_sec =	(MSend/10000)%60;
    pRecvTime.tm_msec = (MSend%1000)/10;
#ifdef LINUXTIME
    if(!SetSystemTime(&pRecvTime))
    {
        TRACE("Set Time Error");
    }
#endif
    return true;
}

/************************************************************************/
/* 保存到文件中                              */
/************************************************************************/
bool CNetCommuZK::SaveFile( )
{
    GetSystemTime(&EndTime);
    QString saveFileName_Send;
    QString startMessage;
    int pout_SendData;
    saveFileName_Send=saveFileName_Send.sprintf("/发送主控%d年%d月%d日%d时%d分%d秒.txt", EndTime.tm_year, EndTime.tm_mon,
        EndTime.tm_mday, EndTime.tm_hour, EndTime.tm_min,EndTime.tm_sec);
    startMessage=startMessage.sprintf("%d年%d月%d日%d时%d分%d秒 开始记录: \n", EndTime.tm_year, EndTime.tm_mon,
                                      EndTime.tm_mday, EndTime.tm_hour, EndTime.tm_min,EndTime.tm_sec);
    saveFileName_Send = BufferSaveFilePath_Send + saveFileName_Send;

    pout_SendData=open(saveFileName_Send.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    ::write(pout_SendData,startMessage.toAscii(),strlen(startMessage.toAscii()));
    ::close(pout_SendData);

    QString saveFileName_Recv;
    int pout_RecvData;
    saveFileName_Recv=saveFileName_Recv.sprintf("/接收主控%d年%d月%d日%d时%d分%d秒.txt", EndTime.tm_year, EndTime.tm_mon,
                                                EndTime.tm_mday, EndTime.tm_hour, EndTime.tm_min,EndTime.tm_sec);
    startMessage=startMessage.sprintf("%d年%d月%d日%d时%d分%d秒 开始记录: \n", StartTime.tm_year, StartTime.tm_mon,
                        StartTime.tm_mday, StartTime.tm_hour, StartTime.tm_min,StartTime.tm_sec);
    saveFileName_Recv = BufferSaveFilePath_Recv + saveFileName_Recv;

    pout_RecvData=open(saveFileName_Send.toAscii(),O_CREAT|O_RDWR, S_IRUSR|S_IRGRP|S_IROTH);
    ::write(pout_RecvData,startMessage.toAscii(),strlen(startMessage.toAscii()));
    ::close(pout_RecvData);

    usleep(100000);
    FormatOctFile( saveFileName_Send, saveFileName_Recv );

    return true;
}

/************************************************************************/
/* 设置MIB数据                              */
/************************************************************************/
void CNetCommuZK::SendMib(char* pSendData, int pSendDataLength, QString WindowName)
{
#ifdef LINUXQT
    COPYDATASTRUCT  ds;
    int i;
    BYTE b0,val;
    int len = pSendDataLength;
    HWND hd;

    char SendBuffer[512];
    memcpy(SendBuffer, pSendData, pSendDataLength);

    ds.dwData = 0;
    ds.cbData= len;// 要传输的数据大小
    ds.lpData=&SendBuffer; // 要传输的数据指针


    hd = ::FindWindow(NULL, WindowName);

    if(hd!=0)
    {
        ::SendMessage(hd, WM_COPYDATA, 0,(LPARAM)&ds); // 发送WM_COPYDATA消息

        return;
    }
    else
    {
        TRACE("目标窗口没找到！运管程序没有打开");
        return;
    }
#endif
      //FreeMem (ds.lpData); //释放资源 传递记录内容
    return;
}

/************************************************************************/
/*
主要的！！！！！！！！！
数据转换（编解码）；该函数需要继承时重构，以满足不同设备
参数：
1.源数据
2.源数据的最长长度（实际长度不需传入，函数内可根据协议自行截取）
3.结果数据
4.结果数据的最长长度（实际长度不需传入，函数内可根据协议自行截取）
5.type:用于当源数据无法在本函数内辨识类型时，由此从外面指定数据类型
        当type=-1,则用户自输入的HEADER数据中提取BID作判断（这只针对
        外引导和T0有效，对其他数据类型，则必须强制指定）


仅将HEADER转为主控可识别的数据
返回值:
转换后pDest的有效长度
*/
/************************************************************************/
int CNetCommuZK::TransCT2ZK(BYTE* pSource, int pSourceLength, BYTE* pDest, int pDestLength, int type)//转换函数
{
    int ret = 0;
    LONG p_temp_1, p_temp_2, p_temp_3;
    double p_temp_Double_1, p_temp_Double_2, p_temp_Double_3, p_temp_Double_4, p_temp_Double_5, p_temp_Double_6;
    LONG  p_temp_Float_1, p_temp_Float_2, p_temp_Float_3, p_temp_Float_4, p_temp_Float_5, p_temp_Float_6;

    DWORD CTTimeMilCount;//用于保存临时时间
    BYTE TM[4];//用于分解出时分秒毫秒

    if(type == 1)//T0信息 48 byte
    {
        memcpy(pDest, pSource, 36);
        ret = 36;
    }
    else if(type == 2) //2
    {
        memcpy(pDest, pSource, 60);
        ret = 60;
    }
    else
    {
        return 0;
    }

    return ret;
}

/************************************************************************/
/* 将原始数据进行解码之后保存到文件中                              */
/************************************************************************/
/************************************************************************/
/*
生成10进制可视化文件
2个参数：
SaveFileName_Send：发送数据文件路径
SaveFileName_Recv：接收数据文件路径
*/
/************************************************************************/
bool CNetCommuZK::FormatOctFile( QString SaveFileName_Send, QString SaveFileName_Recv )
{


    return true;
}


/************************************************************************/
/*
生成10进制可视化字符串
3个参数：
type:0代表发送字符串；1代表接收字符串
输入字符串
输出字符串
*/
/************************************************************************/
void CNetCommuZK::OctSwitch( int Type, QString InputString,  QString* OutputString )
{
    QString ReadContent;
    QString TempString;//填充内容
    QString TempOutput;
    QString Timestr;
    BOOL re;
    DWORD LineIndex=0;
    int tempValue = 0;//LONG tempValue = 0;
    int  tempValue_D = 0;//DWORD tempValue_D = 0;
    int type=0; //数据类别：1.T0; 2.外引导; 3.时延测试; 4.实算数据; 5.常时
    int LengthThreshold = 110;
    QString SourceIPstr;

    ReadContent = InputString;
    TempOutput = "";
    SourceIPstr = "";
    TempString = "";
    *OutputString = "";

    if(ReadContent.length()<LengthThreshold)//判断是否为无效的标题行
    {
        *OutputString = "";
        return;
    }

    if(Type==0)
    {
        Timestr = ReadContent.left(ReadContent.indexOf(" : "));//将时间保存
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf("LOCAL => ") - 9);
        ReadContent = ReadContent.left(ReadContent.indexOf(" => "));
        ReadContent.remove(' ');//连续数值
        tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(11*2, 4*2));	//Bid
        if(tempValue_D == BIDT0)
        {
            DesI++;
            TempOutput.sprintf("%.5d  ", DesI);											//序号
            type = 1;
            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//起飞时刻
            TempString.sprintf("%.2d:%.2d:%.2d:%.3d.%d",tempValue_D/3600/10000,
                tempValue_D/60/10000%60, tempValue_D/10000%60, tempValue_D%10000/10,tempValue_D%10);
            //TempOutput = TempOutput + Timestr + "  ";
            TempOutput = TempOutput + TempString + "  ";
            TempOutput = TempOutput + "起飞时刻" + "  ";											//type
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + "*******" + "  ";												//大地坐标
            TempOutput = TempOutput + TempString + "  \n";
        }
        else
        {
            DesI++;
            TempOutput.sprintf("%.5d  ", DesI);											//序号
            type = 2;

            tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));						//T (必须乘以2)
            TempString.sprintf("%.2d:%.2d:%.2d::%.3d.%d",
                tempValue_D/3600/10000,
                tempValue_D/60/10000%60,
                tempValue_D/10000%60,
                tempValue_D%10000/10, tempValue_D%10);
            TempOutput = TempOutput + TempString + "  ";											//T
            TempOutput = TempOutput + "引导数据" + "  ";											//type
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4)*2, 4*2));						//发射坐标
            TempString.sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue =(int) CharToSignedHexReverse(ReadContent.mid((32+4+4)*2, 4*2));					//发射坐标
            TempString.sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  ";
            tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+4+4)*2, 4*2));					//发射坐标
            TempString.sprintf("%.2f", ((double)tempValue)/10);
            TempOutput = TempOutput + TempString + "  \n";
        }
        *OutputString = TempOutput;
    }
    else
    {
        DesI++;//有标题行
        TempOutput.sprintf("%.5d  ", DesI);											//序号
        ReadContent = ReadContent.left(ReadContent.indexOf(" => LOCAL"));
        ReadContent = ReadContent.right(ReadContent.length() - ReadContent.indexOf(" => ") - 4);
        ReadContent.remove(' ');//连续数值
        tempValue_D = CharToUnsignedHexReverse(ReadContent.mid(32*2, 4*2));							//T (必须乘以2)
        TempString.sprintf("%.2d:%.2d:%.2d::%.3d", tempValue_D/10000/60/60, (tempValue_D/10000/60)%60, (tempValue_D/10000)%60, (tempValue_D%10000)/10);
        TempOutput = TempOutput + TempString + "  ";
        tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1)*2, 4*2));					//A 1@
        TempString.sprintf("%.4f", ((double)tempValue)*360/pow((float)2,31));
        TempOutput = TempOutput + TempString + "  ";
        tempValue =(int) CharToSignedHexReverse(ReadContent.mid((32+4+1+4)*2, 4*2));					//E 1@
        TempString.sprintf("%.4f", ((double)tempValue)*360/pow((float)2,31));
        TempOutput = TempOutput + TempString + "  ";
        tempValue =(int) CharToSignedHexReverse(ReadContent.mid((32+4)*2, 2));						//Status
        TempString.	sprintf("%.2d", tempValue);
        TempOutput = TempOutput + TempString + "  ";
        tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4)*2, 1*2));				//NUM
        TempString.sprintf("%.1d", tempValue);
        TempOutput = TempOutput + TempString + "  ";
        tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4+1)*2, 4*2));				//x 1S
        TempString.sprintf("%.1f", ((double)tempValue)/10);
        TempOutput = TempOutput + TempString + "  ";
        tempValue = (int)CharToSignedHexReverse(ReadContent.mid((32+4+1+4+4+1+4)*2, 4*2));			//y 1S
        TempString. sprintf("%.1f", ((double)tempValue)/10);
        TempOutput = TempOutput + TempString + "  \n";

        *OutputString = TempOutput;
    }

    return;
}

void CNetCommuZK::PrepostSend()//将预推结果发送给上位机
{

    return;
}
