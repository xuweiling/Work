﻿#ifndef AGENT_H
#define AGENT_H
#include "yfmIbbrowerview.h"
#include <QString>
using namespace std;
#include <stdlib.h>
#include <signal.h>

#include <agent_pp/agent++.h>
#include <agent_pp/snmp_group.h>
#include <agent_pp/system_group.h>
#include <agent_pp/snmp_target_mib.h>
#include <agent_pp/snmp_notification_mib.h>
#include <agent_pp/snmp_community_mib.h>
#include <agent_pp/notification_originator.h>
#include <agent_pp/notification_log_mib.h>
#include <agent_pp/agentpp_simulation_mib.h>
#include <agent_pp/agentpp_config_mib.h>
#include <agent_pp/v3_mib.h>
#include <agent_pp/mib_policy.h>
#include <agent_pp/vacm.h>

#include <snmp_pp/oid_def.h>
#include <snmp_pp/mp_v3.h>
#include <snmp_pp/log.h>

//#include "atm_mib.h"
//#include "agentpp_notifytest_mib.h"
//#include "agentpp_test_mib.h"
#include <pthread.h>

#ifdef SNMP_PP_NAMESPACE
using namespace Snmp_pp;
#endif

#ifdef AGENTPP_NAMESPACE
using namespace Agentpp;
#endif

#include "yfprocessrequest.h"
#include <iostream>
#include <string>
using namespace std;
#include "yfmIbbrowerview.h"


#define OIDNUM 200
#define TRAPID "1.3.6.1.4.1.1.1.1.0"

class YFSnmpAgent
{

public:
    YFSnmpAgent();
    ~YFSnmpAgent();


    int agentmain (int argc, char* argv[],QString *YFargv,int &YFargc);
    void LocalSet();
    void LocalGet();
    //must set value of setNode/setNodeNum befor useing this function
    void trapto(string trapOID);

    bool stopListen;
    bool run;
    bool init_again;

    bool isUIWaiting;
    bool isAgentWaiting;

    int setNodeNum;
    Vbx vbx[2*OIDNUM];
    QMibNode setNode[OIDNUM];

    int      trapNodeNum;
    QMibNode trapNode[OIDNUM];

    bool isGetNewNode;
    QMibNode agentGetNode[2];

    YFMib* YFmib;

private:
    void Encrypt();

};
//class YFSnmpAgent
//{
//    int agentmain (int argc, char* argv[],string &YFaddString);
//    void LocalSet();
//    void LocalGet();
//    //must set value of setNode/setNodeNum befor useing this function
//    void trapto(string trapOID);
//};
#endif // AGENT_H
