/*
 * tree2leaf.h
 *
 *  Created on: Jan 6, 2015
 *      Author: feng
 */

#ifndef TREE2LEAF_H_
#define TREE2LEAF_H_

//struct LeafNode
//{
//   int Snytax;   //保存SNMP变量数据类型信息
//   mib_access Access;   //保存SNMP变量访问权限信息
//   string Status;   //保存SNMP变量状态信息
//   string Descr;    //保存SNMP变量文字描述信息
//   string Index;    //保存表辅助节点的索引信息
//   Oidx Oid;      //保存节点OID信息
//   OctetStr SValue;
//   int    IValue;
//   vector<string> *Integer;   //保存数据类型为枚举型整数时的信息，其他类型时指针为0
//};
//
//struct LeafNodeList
//{
//	unsigned int len;
//	LeafNode *leafnode;
//	LeafNodeList *next;
//};

void tree2leaf(TreeNode *ht,YFGroup *&YFgroup);
void edittreeagain(string YFOidString,string access,int ivalue,string svalue);
#endif /* TREE2LEAF_H_ */
