#ifndef CWINTHREAD2_H
#define CWINTHREAD2_H

#include <QThread>

class CWinThread2 : public QThread
{
public:
    CWinThread2();
        void stop();
protected :
        void run();
private :
         volatile bool stopped;
 signals:
    public slots:
};

#endif // CWINTHREAD2_H
