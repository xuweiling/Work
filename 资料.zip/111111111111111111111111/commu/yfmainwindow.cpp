﻿#include "yfmainwindow.h"
#include "ui_yfmainwindow.h"
#include "yfagent.h"
#include "yfthread.h"
#include "yftrapdata1HZ.h"
#include <QFile>
#include "modifyoid.h"
#include <QTextStream>
#include "yfmIbbrowerview.h"
#include "yfdoubleclick_trapid.h"

YFThread YFthreadAgent(1);
YFThread YFthreadTrap(2);
//YFThread YFthreadSet(3);

YFSnmpAgent yfsnmpagent;
QString YFtrapID[YFAGENTPARNUM];
int     YFtrapIDNum;
extern bool istrapdata1hz;
extern QString CurrentOID;
extern TreeNode YFHRoot;
extern QTreeNode YFQHRoot;
extern trapdata trapda1hz;

YFMainWindow::YFMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::YFMainWindow)
{
    isTimerStarting = false;
    ui->setupUi(this);
    connect(ui->ShowList_2,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(GetOneLineOID(QListWidgetItem*)));

    timer = new QTimer(this);
    if(connect(this->timer, SIGNAL(timeout()), this, SLOT(UpUIFromAgent())))
        timer->start(1000);
}

YFMainWindow::~YFMainWindow()
{
    delete ui;
}

void YFMainWindow::on_startAgent_clicked()
{
    ui->startAgent->setEnabled(false);
    ui->stopAgent->setEnabled(true);
    ui->reset->setEnabled(true);
    ui->traptest->setEnabled(true);
    ui->quitAgent->setEnabled(true);
    ui->writeagent->setEnabled(true);
    ui->UpUIFromAgent->setEnabled(true);

    if(!yfsnmpagent.stopListen)
    {
      YFQLoadMId();
      upUI();
      int i;
      for(i = 0; i < ui->listWidget->count(); i++)
      {
          YFtrapID[i] = ui->listWidget->item(i)->text();
      }
      YFtrapIDNum = i;
      YFtrapID[++i] = ui->readcommunity->text();
      YFtrapID[++i] = ui->writeagent->text();

      istrapdata1hz = true;
      isTimerStarting = true;


      YFthreadAgent.start();

    }
    yfsnmpagent.stopListen = false;
}

void YFMainWindow::on_stopAgent_clicked()
{
    if(YFthreadAgent.isRunning())
    {
        ui->startAgent->setEnabled(true);
        ui->stopAgent->setEnabled(false);
        ui->reset->setEnabled(false);
        ui->traptest->setEnabled(false);
        YFthreadAgent.stop();
        yfsnmpagent.stopListen = true;
        ui->quitAgent->setEnabled(false);
        ui->writeagent->setEnabled(false);
    }
}

void YFMainWindow::on_quitAgent_clicked()
{
    isTimerStarting = false;

    yfsnmpagent.run = false;
    YFthreadAgent.terminate();

    yfsnmpagent.init_again = false;
    ui->startAgent->setEnabled(true);
    ui->stopAgent->setEnabled(false);
    ui->reset->setEnabled(false);
    ui->traptest->setEnabled(false);
    ui->quitAgent->setEnabled(false);
    ui->writeagent->setEnabled(false);
    ui->UpUIFromAgent->setEnabled(false);
    SaveUIData2file();
}

void YFMainWindow::on_traptest_clicked()
{
    ui->traptest->setEnabled(false);
    YFthreadTrap.start();
    if(YFthreadTrap.isRunning())
    {
        ui->traptest->setEnabled(true);
        YFthreadTrap.stop();
    }
}

void YFMainWindow::on_reset_clicked()
{
//    ui->reset->setEnabled(false);
//    YFthreadSet.start();
//    if(YFthreadSet.isRunning())
//    {
//        ui->reset->setEnabled(true);
//        YFthreadSet.stop();
//    }
}

void YFMainWindow::on_writeagent_clicked()
{
    ui->writeagent->setEnabled(false);
    QTreeNode *currentNode;
    currentNode = &YFQHRoot;
     yfsnmpagent.setNodeNum = 0;
    GetValueFromUI2Agnet(currentNode,ui->sx1->text());
    GetValueFromUI2Agnet(currentNode,ui->sx2->text());
    GetValueFromUI2Agnet(currentNode,ui->sx3->text());
    GetValueFromUI2Agnet(currentNode,ui->sx4->text());
    GetValueFromUI2Agnet(currentNode,ui->sx5->text());
    GetValueFromUI2Agnet(currentNode,ui->sx6->text());
    GetValueFromUI2Agnet(currentNode,ui->sx7->text());
    GetValueFromUI2Agnet(currentNode,ui->sx8->text());
    GetValueFromUI2Agnet(currentNode,ui->sx9->text());

    GetValueFromUI2Agnet(currentNode,ui->zt1->text());
    GetValueFromUI2Agnet(currentNode,ui->zt2->text());
    GetValueFromUI2Agnet(currentNode,ui->zt3->text());
    GetValueFromUI2Agnet(currentNode,ui->zt4->text());
    GetValueFromUI2Agnet(currentNode,ui->zt5->text());

    GetValueFromUI2Agnet(currentNode,ui->bs1->text());
    GetValueFromUI2Agnet(currentNode,ui->bs2->text());
    GetValueFromUI2Agnet(currentNode,ui->bs3->text());
    GetValueFromUI2Agnet(currentNode,ui->bs4->text());
    GetValueFromUI2Agnet(currentNode,ui->bs5->text());
    GetValueFromUI2Agnet(currentNode,ui->bs6->text());
    GetValueFromUI2Agnet(currentNode,ui->bs7->text());
    GetValueFromUI2Agnet(currentNode,ui->bs8->text());
    GetValueFromUI2Agnet(currentNode,ui->bs9->text());
    GetValueFromUI2Agnet(currentNode,ui->bs10->text());

    GetValueFromUI2Agnet(currentNode,ui->gl1->text());
    GetValueFromUI2Agnet(currentNode,ui->gl2->text());
    GetValueFromUI2Agnet(currentNode,ui->gl3->text());
    GetValueFromUI2Agnet(currentNode,ui->gl4->text());

    GetValueFromUI2Agnet(currentNode,ui->yh1->text());
    GetValueFromUI2Agnet(currentNode,ui->yh2->text());
    GetValueFromUI2Agnet(currentNode,ui->yh3->text());
    GetValueFromUI2Agnet(currentNode,ui->yh4->text());
    GetValueFromUI2Agnet(currentNode,ui->yh5->text());
    GetValueFromUI2Agnet(currentNode,ui->yh6->text());
    GetValueFromUI2Agnet(currentNode,ui->yh7->text());


    if(yfsnmpagent.setNodeNum != 0)
    {
        yfsnmpagent.isAgentWaiting = true;
        while(yfsnmpagent.isUIWaiting);
        yfsnmpagent.LocalSet();
        yfsnmpagent.isAgentWaiting = false;
    }

    ui->writeagent->setEnabled(true);
    //    YFthreadAgent.usleep();
}

void YFMainWindow::GetValueFromUI2Agnet(QTreeNode *&currentNode,QString Value)
{
    while(currentNode->LChildren->QMibdata.isTrap != "2")
        currentNode = currentNode->LChildren;
    currentNode = currentNode->LChildren;

    int NodeNum = yfsnmpagent.setNodeNum;

    yfsnmpagent.setNode[NodeNum].POid = currentNode->QMibdata.POid;
    if(currentNode->QMibdata.PSnytax == "Int")
    {
        if(currentNode->QMibdata.PIValue == Value.toInt())
            return;
        yfsnmpagent.setNode[NodeNum].PSnytax = "Int";
        currentNode->QMibdata.PIValue = Value.toInt();
        yfsnmpagent.setNode[NodeNum].PIValue = currentNode->QMibdata.PIValue;
    }
    else
    {
        if(currentNode->QMibdata.PSValue == Value)
            return;
        yfsnmpagent.setNode[NodeNum].PSnytax = "String";
        currentNode->QMibdata.PSValue = Value;
        yfsnmpagent.setNode[NodeNum].PSValue = currentNode->QMibdata.PSValue;
    }
    yfsnmpagent.setNodeNum ++;
}

void YFMainWindow::upUI(void)
{
    QTreeNode *currentNode;
    currentNode = &YFQHRoot;

    ui->sx1->setText(GetValuefromfile2UI(currentNode));
    ui->sx2->setText(GetValuefromfile2UI(currentNode));
    ui->sx3->setText(GetValuefromfile2UI(currentNode));
    ui->sx4->setText(GetValuefromfile2UI(currentNode));
    ui->sx5->setText(GetValuefromfile2UI(currentNode));
    ui->sx6->setText(GetValuefromfile2UI(currentNode));
    ui->sx7->setText(GetValuefromfile2UI(currentNode));
    ui->sx8->setText(GetValuefromfile2UI(currentNode));
    ui->sx9->setText(GetValuefromfile2UI(currentNode));

    ui->zt1->setText(GetValuefromfile2UI(currentNode));
    ui->zt2->setText(GetValuefromfile2UI(currentNode));
    ui->zt3->setText(GetValuefromfile2UI(currentNode));
    ui->zt4->setText(GetValuefromfile2UI(currentNode));
    ui->zt5->setText(GetValuefromfile2UI(currentNode));

    ui->bs1->setText(GetValuefromfile2UI(currentNode));
    ui->bs2->setText(GetValuefromfile2UI(currentNode));
    ui->bs3->setText(GetValuefromfile2UI(currentNode));
    ui->bs4->setText(GetValuefromfile2UI(currentNode));
    ui->bs5->setText(GetValuefromfile2UI(currentNode));
    ui->bs6->setText(GetValuefromfile2UI(currentNode));
    ui->bs7->setText(GetValuefromfile2UI(currentNode));
    ui->bs8->setText(GetValuefromfile2UI(currentNode));
    ui->bs9->setText(GetValuefromfile2UI(currentNode));
    ui->bs10->setText(GetValuefromfile2UI(currentNode));

    ui->gl1->setText(GetValuefromfile2UI(currentNode));
    ui->gl2->setText(GetValuefromfile2UI(currentNode));
    ui->gl3->setText(GetValuefromfile2UI(currentNode));
    ui->gl4->setText(GetValuefromfile2UI(currentNode));

    ui->yh1->setText(GetValuefromfile2UI(currentNode));
    ui->yh2->setText(GetValuefromfile2UI(currentNode));
    ui->yh3->setText(GetValuefromfile2UI(currentNode));
    ui->yh4->setText(GetValuefromfile2UI(currentNode));
    ui->yh5->setText(GetValuefromfile2UI(currentNode));
    ui->yh6->setText(GetValuefromfile2UI(currentNode));
    ui->yh7->setText(GetValuefromfile2UI(currentNode));
    ui->yh8->setText(GetValuefromfile2UI(currentNode));

//    TreeNode *YFSubtreeNode = NULL;
//    string name;
//    QString value;
//    name = "MIB入口";
//    FindNode(&YFHRoot,YFSubtreeNode, name);
//    if(YFSubtreeNode != NULL)
//    {
//        if(YFSubtreeNode->Mibdata.PSnytax == "Int")
//            value = QString(YFSubtreeNode->Mibdata.PIValue);
//        else
//            value = QString(YFSubtreeNode->Mibdata.PSValue.c_str());

//        ui->sx1->setText(value);
//    }
}

QString YFMainWindow::GetValuefromfile2UI(QTreeNode *&currentNode)
{
    while(currentNode->LChildren->QMibdata.isTrap != "2")
        currentNode = currentNode->LChildren;
    currentNode = currentNode->LChildren;
    QString value;
    if(currentNode->QMibdata.PSnytax == "Int")
    {
        value = QString(currentNode->QMibdata.PIValue+'0');
        return value;
    }
    else
        return(QString(currentNode->QMibdata.PSValue));
}

void YFMainWindow::SaveUIData2file()
{
    QString QLine;
    string Line;
    on_ReadFButton_clicked();

    int n1,n2;
    int i = 0;
    int Numth=0;
    for(;i<ui->ShowList_2->count();i++)
    {
        QLine = ui->ShowList_2->item(i)->text();
        Line = QLine.toStdString();

        if(strcmp(Line.c_str()," ") == 0) continue;//空行，直接读入下一行
        if (Line.find("--")==0) continue;    //注释行直接读下一行
        n1 = Line.find("--");
        if (n1 > 0)           //去掉行后边注释部分
            Line=Line.substr(0,Line.find("--")+1);
        n1 = Line.find_first_not_of(" ");
        n2 = Line.length()-n1;
        if(n1 == -1)
            n1 = 0;
        Line = Line.substr(n1,n2);
        n2 = Line.find_last_not_of(" ");
        Line = Line.substr(0,n2+1); //？？？？？取出左右测空格
        n1 = Line.find_first_not_of("\t");
        n2 = Line.length()-n1;
        if(n1 == -1)
            n1 = 0;
        Line = Line.substr(n1,n2);
        if(Line == "\r") continue;

        n1 = Line.find("PIsTrap:");
        if(n1 != string::npos)
        {
            n2 = Line.find_first_of(',',Line.find("PIsTrap:"));
            QLine = Line.substr(n1+8,n2-n1-8).c_str();
            if(QLine == "2")
            {
                n1 = Line.find("PValue:");
                if(n1 != string::npos)
                {
                    Numth ++;
                    n2 = Line.find_first_of(',',Line.find("PValue:"));
                    if(Numth == 1)
                        Line.replace(n1+7,n2-n1-7,ui->sx1->text().toAscii());
                    else if(Numth == 2)
                        Line.replace(n1+7,n2-n1-7,ui->sx2->text().toAscii());
                    else if(Numth == 3)
                        Line.replace(n1+7,n2-n1-7,ui->sx3->text().toAscii());
                    else if(Numth == 4)
                        Line.replace(n1+7,n2-n1-7,ui->sx4->text().toAscii());
                    else if(Numth == 5)
                        Line.replace(n1+7,n2-n1-7,ui->sx5->text().toAscii());
                    else if(Numth == 6)
                        Line.replace(n1+7,n2-n1-7,ui->sx6->text().toAscii());
                    else if(Numth == 7)
                        Line.replace(n1+7,n2-n1-7,ui->sx7->text().toAscii());
                    else if(Numth == 8)
                        Line.replace(n1+7,n2-n1-7,ui->sx8->text().toAscii());
                    else if(Numth == 9)
                        Line.replace(n1+7,n2-n1-7,ui->sx9->text().toAscii());

                    else if(Numth == 10)
                        Line.replace(n1+7,n2-n1-7,ui->zt1->text().toAscii());
                    else if(Numth == 11)
                        Line.replace(n1+7,n2-n1-7,ui->zt2->text().toAscii());
                    else if(Numth == 12)
                        Line.replace(n1+7,n2-n1-7,ui->zt3->text().toAscii());
                    else if(Numth == 13)
                        Line.replace(n1+7,n2-n1-7,ui->zt4->text().toAscii());
                    else if(Numth == 14)
                        Line.replace(n1+7,n2-n1-7,ui->zt5->text().toAscii());

                    else if(Numth == 15)
                        Line.replace(n1+7,n2-n1-7,ui->bs1->text().toAscii());
                    else if(Numth == 16)
                        Line.replace(n1+7,n2-n1-7,ui->bs2->text().toAscii());
                    else if(Numth == 17)
                        Line.replace(n1+7,n2-n1-7,ui->bs3->text().toAscii());
                    else if(Numth == 18)
                        Line.replace(n1+7,n2-n1-7,ui->bs4->text().toAscii());
                    else if(Numth == 19)
                        Line.replace(n1+7,n2-n1-7,ui->bs5->text().toAscii());
                    else if(Numth == 20)
                        Line.replace(n1+7,n2-n1-7,ui->bs6->text().toAscii());
                    else if(Numth == 21)
                        Line.replace(n1+7,n2-n1-7,ui->bs7->text().toAscii());
                    else if(Numth == 22)
                        Line.replace(n1+7,n2-n1-7,ui->bs8->text().toAscii());
                    else if(Numth == 23)
                        Line.replace(n1+7,n2-n1-7,ui->bs9->text().toAscii());
                    else if(Numth == 24)
                        Line.replace(n1+7,n2-n1-7,ui->bs10->text().toAscii());

                    else if(Numth == 25)
                        Line.replace(n1+7,n2-n1-7,ui->gl1->text().toAscii());
                    else if(Numth == 26)
                        Line.replace(n1+7,n2-n1-7,ui->gl2->text().toAscii());
                    else if(Numth == 27)
                        Line.replace(n1+7,n2-n1-7,ui->gl3->text().toAscii());
                    else if(Numth == 28)
                        Line.replace(n1+7,n2-n1-7,ui->gl4->text().toAscii());

                    else if(Numth == 29)
                        Line.replace(n1+7,n2-n1-7,ui->yh1->text().toAscii());
                    else if(Numth == 30)
                        Line.replace(n1+7,n2-n1-7,ui->yh2->text().toAscii());
                    else if(Numth == 31)
                        Line.replace(n1+7,n2-n1-7,ui->yh3->text().toAscii());
                    else if(Numth == 32)
                        Line.replace(n1+7,n2-n1-7,ui->yh4->text().toAscii());
                    else if(Numth == 33)
                        Line.replace(n1+7,n2-n1-7,ui->yh5->text().toAscii());
                    else if(Numth == 34)
                        Line.replace(n1+7,n2-n1-7,ui->yh6->text().toAscii());
                    else if(Numth == 35)
                        Line.replace(n1+7,n2-n1-7,ui->yh7->text().toAscii());
                    else if(Numth == 36)
                        Line.replace(n1+7,n2-n1-7,ui->yh8->text().toAscii());


                    QLine = Line.c_str();
                    ui->ShowList_2->openPersistentEditor(ui->ShowList_2->item(i));
                    ui->ShowList_2->item(i)->setText(QLine);
                    ui->ShowList_2->closePersistentEditor(ui->ShowList_2->item(i));
                }
            }
        }
    }
    on_WriteFile_clicked();
}

void YFMainWindow::on_listWidget_doubleClicked(const QModelIndex &index)
{
    QString text = ui->listWidget->currentItem()->text();

    YFDoubleClick_TrapID YFTrapIDUI;
    YFTrapIDUI.exec();


    if(YFTrapIDUI.other == ADDBUTTON)
    {
        if(text == "")
        {
            ui->listWidget->openPersistentEditor(ui->listWidget->currentItem());
            ui->listWidget->currentItem()->setText(YFTrapIDUI.text);
            ui->listWidget->closePersistentEditor(ui->listWidget->currentItem());
        }
        else
            ui->listWidget->insertItem(ui->listWidget->currentRow(),YFTrapIDUI.text);
    }
    else if(YFTrapIDUI.other == MODIFYBUTTON)
    {
        ui->listWidget->openPersistentEditor(ui->listWidget->currentItem());
        ui->listWidget->currentItem()->setText(YFTrapIDUI.text);
        ui->listWidget->closePersistentEditor(ui->listWidget->currentItem());
    }
    else if(YFTrapIDUI.other == DELETEBUTTON)
    {
        ui->listWidget->takeItem(ui->listWidget->currentRow());
    }
}



void YFMainWindow::on_ReadFButton_clicked()
{
    ui->ShowList_2->clear();
    QFile file("MyMib.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    while (!file.atEnd()) {
        QString line = file.readLine();
        ui->ShowList_2->addItem(line);
     }
    file.close();
}

void YFMainWindow::GetOneLineOID(QListWidgetItem * item)
{
    QLWitem = item;
    GetOneLine = item->text();
}


void YFMainWindow::on_ModifyButton_2_clicked()
{
    CurrentOID = ui->ShowList_2->currentItem()->text();
//   int currentrow = ui->ShowList_2->currentRow();
//    on_DeleteButton_2_clicked();
    ModifyOID modifyOID;
    modifyOID.exec();
//    ui->ShowList_2->insertItem(currentrow,CurrentOID);
    ui->ShowList_2->openPersistentEditor(ui->ShowList_2->currentItem());
    ui->ShowList_2->currentItem()->setText(CurrentOID);
    ui->ShowList_2->closePersistentEditor(ui->ShowList_2->currentItem());
}

void YFMainWindow::on_DeleteButton_2_clicked()
{
    ui->ShowList_2->takeItem(ui->ShowList_2->currentRow());
}


void YFMainWindow::on_AddButton_2_clicked()
{
    CurrentOID = "";
    ModifyOID modifyOID;
    modifyOID.exec();
    ui->ShowList_2->insertItem(ui->ShowList_2->currentRow(),CurrentOID);
}

void YFMainWindow::on_WriteFile_clicked()
{
    QFile file("MyMib.txt");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    QTextStream out(&file);
    for(int i = 0; i < ui->ShowList_2->count(); i++)
    {
        out << ui->ShowList_2->item(i)->text();
    }
    file.close();
}


//transdata and trap when data changed;
void YFMainWindow::TransData(const char *recData)
{
    QTreeNode *currentNode;
    currentNode = &YFQHRoot;
    yfsnmpagent.setNodeNum = 0;

 //   int ltest=sizeof(MasterControl2SJ);

 //   memset((unsigned char *)&pData,0,sizeof(MasterControl2SJ));
//    memcpy((unsigned char*)&pData,recData,sizeof(MasterControl2SJ));

    //A
    if(recData[68] == 1 && recData[69] == 1)
        ui->A1->setCurrentIndex(GetAValueFromCYN(currentNode,0));//1#zhuang tai
    else
        ui->A1->setCurrentIndex(GetAValueFromCYN(currentNode,1));//1#zhuang tai
    ui->A2->setCurrentIndex(GetAValueFromCYN(currentNode,0));
    ui->A3->setCurrentIndex(GetAValueFromCYN(currentNode,recData[64]));
    ui->A4->setCurrentIndex(GetAValueFromCYN(currentNode,recData[98]));//1#geng zong mo shi
    ui->A5->setCurrentIndex(GetAValueFromCYN(currentNode,recData[65]));
    ui->A6->setCurrentIndex(GetAValueFromCYN(currentNode,0));
    ui->A7->setCurrentIndex(GetAValueFromCYN(currentNode,recData[77+36]));//1#tu xiang ji lu xi tong zhuang tai
    ui->A8->setCurrentIndex(GetAValueFromCYN(currentNode,recData[84+36]));

    ui->B1_1->setCurrentIndex(GetBValueFromCYN(currentNode,recData[68]));
    ui->B1_2->setCurrentIndex(GetBValueFromCYN(currentNode,recData[69]));

    ui->B2_1->setCurrentIndex(GetBValueFromCYN(currentNode,recData[70]));
    ui->B2_2->setCurrentIndex(GetBValueFromCYN(currentNode,recData[71]));

    ui->B3_1->setCurrentIndex(GetBValueFromCYN(currentNode,recData[72]));
    ui->B3_2->setCurrentIndex(GetBValueFromCYN(currentNode,recData[73]));
    ui->B3_3->setCurrentIndex(GetBValueFromCYN(currentNode,recData[74]));
    ui->B3_4->setCurrentIndex(GetBValueFromCYN(currentNode,recData[75]));

    ui->B4_1_1->setCurrentIndex(GetBValueFromCYN(currentNode,recData[76]));
    ui->B4_1_2->setCurrentIndex(GetBValueFromCYN(currentNode,recData[77]));
    ui->B4_1_3->setCurrentIndex(GetBValueFromCYN(currentNode,recData[78]));
    ui->B4_1_4->setCurrentIndex(GetBValueFromCYN(currentNode,recData[79]));
    ui->B4_1_5->setCurrentIndex(GetBValueFromCYN(currentNode,recData[80]));
    QString ps;
    ps.fromUtf8(recData+81,2);
    int tmp = GetBValueFromCYN(currentNode,ps.toInt());
    ui->B4_1_6->setText(QString(tmp));

    ui->B4_2_1->setCurrentIndex(GetBValueFromCYN(currentNode,recData[83]));
    ui->B4_2_2->setCurrentIndex(GetBValueFromCYN(currentNode,recData[84]));
    ui->B4_2_3->setCurrentIndex(GetBValueFromCYN(currentNode,recData[85]));
    ui->B4_2_4->setCurrentIndex(GetBValueFromCYN(currentNode,recData[86]));
    ui->B4_2_5->setCurrentIndex(GetBValueFromCYN(currentNode,recData[87]));

    ps.fromUtf8(recData+88,2);
    tmp = GetBValueFromCYN(currentNode,ps.toInt());
    ui->B4_2_6->setText(QString(tmp));
    if(yfsnmpagent.run)
        yfsnmpagent.LocalSet();
}
int YFMainWindow::GetAValueFromCYN(QTreeNode *&currentNode,char Value)
{
    while(currentNode->LChildren->QMibdata.Currentname != "A")
        currentNode = currentNode->LChildren;
    currentNode = currentNode->LChildren;

    int NodeNum = yfsnmpagent.setNodeNum;
    yfsnmpagent.setNode[NodeNum].POid = currentNode->QMibdata.POid;

    if(currentNode->QMibdata.PSnytax == "Int")
    {
        if(currentNode->QMibdata.PIValue == (int)Value)
            return (int)Value;
        yfsnmpagent.setNode[NodeNum].PSnytax = "Int";
        yfsnmpagent.setNode[NodeNum].PIValue = (int)Value;
        if(currentNode->QMibdata.isTrap == "1" && currentNode->QMibdata.PIValue != (int)Value)
        {
            yfsnmpagent.trapNode[0].POid = currentNode->QMibdata.POid;
            yfsnmpagent.trapNode[0].PSnytax = "Int";
            yfsnmpagent.trapNode[0].PIValue = currentNode->QMibdata.PIValue;
            yfsnmpagent.trapNodeNum = 1;
            yfsnmpagent.trapto(TRAPID);
        }
        currentNode->QMibdata.PIValue = Value;
    }
    else
    {
        if(currentNode->QMibdata.PSValue == (QString)Value)
            return (int)Value;
        yfsnmpagent.setNode[NodeNum].PSnytax = "String";
        yfsnmpagent.setNode[NodeNum].PSValue = currentNode->QMibdata.PSValue;
        if(currentNode->QMibdata.isTrap == "1" && currentNode->QMibdata.PSValue != (QString)Value)
        {
            yfsnmpagent.trapNode[0].POid = currentNode->QMibdata.POid;
            yfsnmpagent.trapNode[0].PSnytax = "String";
            yfsnmpagent.trapNode[0].PSValue = currentNode->QMibdata.PSValue;
            yfsnmpagent.trapNodeNum = 1;
            yfsnmpagent.trapto(TRAPID);
        }
        currentNode->QMibdata.PSValue = (QString)Value;
    }
    yfsnmpagent.setNodeNum ++;
    return (int)Value;
}


int YFMainWindow::GetBValueFromCYN(QTreeNode *&currentNode,int Value)
{
    while( currentNode->LChildren->QMibdata.Currentname != "B")
        currentNode = currentNode->LChildren;
    currentNode = currentNode->LChildren;

    int NodeNum = yfsnmpagent.setNodeNum;
    yfsnmpagent.setNode[NodeNum].POid = currentNode->QMibdata.POid;

    if(currentNode->QMibdata.PSnytax == "Int")
    {
        if(currentNode->QMibdata.PIValue == (int)Value)
            return (int)Value;
        yfsnmpagent.setNode[NodeNum].PSnytax = "Int";
        yfsnmpagent.setNode[NodeNum].PIValue = (int)Value;
        if(currentNode->QMibdata.isTrap == "1" && currentNode->QMibdata.PIValue != (int)Value)
        {
            yfsnmpagent.trapNode[0].POid = currentNode->QMibdata.POid;
            yfsnmpagent.trapNode[0].PSnytax = "Int";
            yfsnmpagent.trapNode[0].PIValue = currentNode->QMibdata.PIValue;
            yfsnmpagent.trapNodeNum = 1;
            yfsnmpagent.trapto(TRAPID);
        }
        currentNode->QMibdata.PIValue = Value;
    }
    else
    {
        if(currentNode->QMibdata.PSValue == (QString)Value)
            return (int)Value;
        yfsnmpagent.setNode[NodeNum].PSnytax = "String";
        yfsnmpagent.setNode[NodeNum].PSValue = currentNode->QMibdata.PSValue;
        if(currentNode->QMibdata.isTrap == "1" && currentNode->QMibdata.PSValue != (QString)Value)
        {
            yfsnmpagent.trapNode[0].POid = currentNode->QMibdata.POid;
            yfsnmpagent.trapNode[0].PSnytax = "String";
            yfsnmpagent.trapNode[0].PSValue = currentNode->QMibdata.PSValue;
            yfsnmpagent.trapNodeNum = 1;
            yfsnmpagent.trapto(TRAPID);
        }
        currentNode->QMibdata.PSValue = (QString)Value;
    }
    yfsnmpagent.setNodeNum ++;
    return (int)Value;
}

void YFMainWindow::GetABValueFromCYN(QTreeNode *&currentNode,char Value)
{
    while(currentNode->LChildren->QMibdata.Currentname != "A"
          && currentNode->LChildren->QMibdata.Currentname != "B")
        currentNode = currentNode->LChildren;
    currentNode = currentNode->LChildren;

    int NodeNum = yfsnmpagent.setNodeNum;
    yfsnmpagent.setNode[NodeNum].POid = currentNode->QMibdata.POid;

    if(currentNode->QMibdata.PSnytax == "Int")
    {
        if(currentNode->QMibdata.PIValue == (int)Value)
            return;
        yfsnmpagent.setNode[NodeNum].PSnytax = "Int";
        yfsnmpagent.setNode[NodeNum].PIValue = (int)Value;
//        if(currentNode->QMibdata.isTrap == "1" && currentNode->QMibdata.PIValue != Value)
//            yfsnmpagent.trapto(TRAPID);
        currentNode->QMibdata.PIValue = Value;
    }
    else
    {
        if(currentNode->QMibdata.PSValue == (QString)Value)
            return;
        yfsnmpagent.setNode[NodeNum].PSnytax = "String";
        yfsnmpagent.setNode[NodeNum].PSValue = currentNode->QMibdata.PSValue;
//        if(currentNode->QMibdata.isTrap == "1" && currentNode->QMibdata.PSValue != (QString)Value)
//             yfsnmpagent.trapto(TRAPID);
        currentNode->QMibdata.PSValue = Value;
    }
    yfsnmpagent.setNodeNum ++;
}


void YFMainWindow::upUIFromAgent()
{
    QTreeNode *currentNode;
    currentNode = &YFQHRoot;

    ui->bs3->setText(GetValueFromAgnet2UI(currentNode));
    ui->bs4->setText(GetValueFromAgnet2UI(currentNode));
    ui->bs5->setText(GetValueFromAgnet2UI(currentNode));
    ui->bs6->setText(GetValueFromAgnet2UI(currentNode));
    ui->bs7->setText(GetValueFromAgnet2UI(currentNode));
    ui->bs8->setText(GetValueFromAgnet2UI(currentNode));
    ui->bs9->setText(GetValueFromAgnet2UI(currentNode));
    ui->bs10->setText(GetValueFromAgnet2UI(currentNode));

    ui->gl1->setText(GetValueFromAgnet2UI(currentNode));
    ui->gl2->setText(GetValueFromAgnet2UI(currentNode));
    ui->gl3->setText(GetValueFromAgnet2UI(currentNode));
    ui->gl4->setText(GetValueFromAgnet2UI(currentNode));

    ui->yh1->setText(GetValueFromAgnet2UI(currentNode));
    ui->yh2->setText(GetValueFromAgnet2UI(currentNode));
    ui->yh3->setText(GetValueFromAgnet2UI(currentNode));
    ui->yh4->setText(GetValueFromAgnet2UI(currentNode));
    ui->yh5->setText(GetValueFromAgnet2UI(currentNode));
    ui->yh6->setText(GetValueFromAgnet2UI(currentNode));
    ui->yh7->setText(GetValueFromAgnet2UI(currentNode));
    ui->yh8->setText(GetValueFromAgnet2UI(currentNode));
}

QString YFMainWindow::GetValueFromAgnet2UI(QTreeNode *&currentNode)
{
    while(currentNode->LChildren->QMibdata.PAccess != "READWRITE"
          || currentNode->LChildren->QMibdata.isTrap != "2")
        currentNode = currentNode->LChildren;
    currentNode = currentNode->LChildren;

//    yfsnmpagent.setNodeNum = 1;
    if(currentNode->QMibdata.POid == yfsnmpagent.agentGetNode[0].POid)
    {
        if(currentNode->QMibdata.PSnytax == "Int")
        {
            currentNode->QMibdata.PIValue = yfsnmpagent.agentGetNode[0].PIValue;
            return QString(yfsnmpagent.agentGetNode[0].PIValue + '0');
        }
        else
        {
            currentNode->QMibdata.PSValue = yfsnmpagent.agentGetNode[0].PSValue;
            return yfsnmpagent.agentGetNode[0].PSValue;
        }
    }
    else
    {
        if(currentNode->QMibdata.PSnytax == "Int")
        {
            return QString(currentNode->QMibdata.PIValue + '0');
        }
        else
        {
            return currentNode->QMibdata.PSValue;
        }
    }
}

void YFMainWindow::on_UpUIFromAgent_clicked()
{
    if(yfsnmpagent.isGetNewNode == true && isTimerStarting == true)
    {
        yfsnmpagent.isGetNewNode = false;
        upUIFromAgent();
    }
}

void YFMainWindow::UpUIFromAgent()
{
    if(yfsnmpagent.isGetNewNode == true && isTimerStarting == true)
    {
        yfsnmpagent.isGetNewNode = false;
        upUIFromAgent();
    }
}


