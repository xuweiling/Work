﻿// ZKSocket.cpp: implementation of the CZKSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "commu.h"
#include "ZKSocket.h"
#include <QTextCodec>
#include "NetCommuZK.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CZKSocket::CZKSocket():udpSocket(0,0),YFThread(3)
{
	pParent = NULL;
	Counter = -1;
	SocketID = -1;
#ifdef LINUXQT
    pDialog = NULL;
#endif
	pSaveBuffer = NULL;
	pBufferLength = 0;
//    YFThread::start();
}

CZKSocket::~CZKSocket()
{
    YFThread::stop();
    //YFThread::quit();
}


////////////////////////////////////////////////////////////////////////////////
//接口事件处理函数；
////////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* 
有数据到时发生的响应
	UDP: 最重要
                                                         */
/************************************************************************/

void CZKSocket::OnReceive(int nErrorCode)    //有数据到时发生	UDP: 最重要
{	
    pBufferLength = 0;
    if(pSaveBuffer != NULL)
    {
        UINT tempPort=0;
        memset(pSaveBuffer, 0, MACRO_BUFFER_SIZE);
        pBufferLength=udprecvfrom((unsigned char *)pSaveBuffer,MACRO_BUFFER_SIZE,0,tempPort);
        if(pBufferLength>0)
        {
            DataSource.IPAdd.sin_addr.s_addr = get_recvAddress();
            DataSource.PortReceive = tempPort;
            CNetCommuZK *pP=(CNetCommuZK*)pParent;
            pP->Receive();
        }
    }
    else
    {
        pBufferLength = 0;
    }

    //add for no warnning
    nErrorCode=0;
    usleep(3);
    nErrorCode++;
}

////////////////////////////////////////////////////////////////////////////////////
//网络套接口处理函数；
////////////////////////////////////////////////////////////////////////////////////

/*
bool CZKSocket::Initial( CWnd* pParam1, int pParam2 )   
{
	LocalSet.IPAdd.sin_port = htons(LocalSet.PortReceive);
	LocalSet.IPAdd.sin_family = AF_INET;					//数据统一
	Create( );
	int ret = Bind((SOCKADDR*)&(LocalSet.IPAdd), sizeof(SOCKADDR));	//绑定完毕，由LocalSet设定
	Counter = 0;

	if( pParam1!=NULL )
		pDialog = pParam1;

	SocketID = pParam2;
	return ret;
}
*/

////////////////////////////////////////////////////////////////////////////////////
//网络套接口处理函数；
////////////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* 
初始化本Socket，包括创建和绑定；
参数:
1.调用者指针，用于通知调用者
2.接收Socket还是发送Socket，用于决定绑在那个端口上
                                                         */
/************************************************************************/
bool CZKSocket::Initial( void* pParam1)   
{
	bool ret = true;
	LocalSet.IPAdd.sin_port = htons(LocalSet.PortReceive);
	LocalSet.IPAdd.sin_family = AF_INET;					//数据统一
    if(udpSocket::create( LocalSet.PortReceive, LocalSet.IPAdd.sin_addr.s_addr,1)!=0)
	{
        QMessageBox defineBox;
        struct in_addr tmpAdd;
        tmpAdd.s_addr= LocalSet.IPAdd.sin_addr.s_addr;
        defineBox.setWindowTitle(inet_ntoa(tmpAdd));
        defineBox.setText(QObject::tr("主控套接字创建失败！"));
        defineBox.exec();
		return FALSE;
	}
    YFThread::start();
//	bool ret = Bind((SOCKADDR*)&(LocalSet.IPAdd), sizeof(SOCKADDR));	//绑定完毕，由LocalSet设定
	Counter = 0;

	if( pParam1!=NULL )
		pParent = pParam1;

	return ret;
}

/************************************************************************/
/* 
创建一个套接口，nSocktType==SOCK_STREAM是TCP连接；nSocktType==SOCK_DGRAM是UDP连接；
                                                         */
/************************************************************************/
BOOL CZKSocket::Create( )   
{
    unsigned short int sin_port=LocalSet.IPAdd.sin_port ;
    unsigned long int addr = LocalSet.IPAdd.sin_addr.s_addr;
    if( udpSocket::create((unsigned short int )sin_port, (unsigned long int) addr,1)==0)
        return true;
    else
        return false;
}


/************************************************************************/
/* 
在建立连接后，使用的数据发送函数，主要需要指明发生的目标端口号和IP地址；常用于UDP； 

UDP: 最重要         
参数：
1.发送的数据
2.数据长度
3.对方端口号
4.对方地址
5.flag: 操作选项，可不设定，默认为0
                                                         */
/************************************************************************/
int CZKSocket::SendTo(const void* lpBuf, int nBufLen, UINT nHostPort,LPCTSTR lpszHostAddress, int nFlags) 
{	
    //add to remove warning
    nFlags=0;
    nFlags++;
    return  udpsendto(lpBuf,nBufLen,nHostPort,lpszHostAddress);
}

//析构
bool CZKSocket::CloseConnect( ) 
{
    YFThread::stop();
    YFThread::terminate();
    //YFThread::quit();
    udpSocket::udpClose();
    pParent = NULL;
    Counter = -1;
    SocketID = -1;
#ifdef LINUXQT
    pDialog = NULL;
#endif
    pSaveBuffer = NULL;
    pBufferLength = 0;
    //Close();
    udpSocket::udpClose();
    return TRUE;
}

void  CZKSocket::OnReceiveThread()
{
    CZKSocket::OnReceive(0);
}
