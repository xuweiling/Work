﻿// CTSocket.h: interface for the CCTSocket class.
//
//////////////////////////////////////////////////////////////////////

#ifndef __CTSocket_H__
#define __CTSocket_H__

#include "udpSocket.h"
#include "GlabalDefine.h"
#include "NetCommu.h"
#include "yfthread.h"

/************************************************************************/
/* 
主监控机通信类,即可用于接收,也可用于发送
                                                                     */
/************************************************************************/
class CCTSocket : public udpSocket,public YFThread
{
public:
	CCTSocket();
	virtual ~CCTSocket();

	SocketSetting LocalSet;					//Socket配置（本地）

//下面是需要由调用者查询的数据
    BYTE* pSaveBuffer;						//接收到的数据
	int pBufferLength;						//接收到的数据长度
	SocketSetting DataSource;				//收到的数据来源
	int Type;								//Recv=0/ Send=1

//	bool Initial(CWnd *pParam1, int pParam2);	//建立
	bool Initial( void* pParam1, bool RecvOrSend);				//建立(在用)
	bool JoinBroadCastGroup( LPCTSTR lpszBroadCastAddress );	//加入组
	BOOL DropBroadCastGroup(LPCTSTR lpszBroadCastAddress) ;		//退出组
	bool JoinSSMBroadCastGroup( LPCTSTR lpszBroadCastAddress, LPCTSTR lpszSourceAddress );	//加入组
	BOOL DropSSMBroadCastGroup(LPCTSTR lpszBroadCastAddress, LPCTSTR lpszSourceAddress ) ;//退出组
	bool CloseConnect();						//关闭
    void ShutDown(int flag);
    BOOL Create( UINT sin_port, DWORD addr );							//建立Socket
protected:
	void *pParent;
	DWORD Counter;
	int SocketID;
#ifdef LINUXQT
	CWnd *pDialog;
#endif

public:
	void OnReceive(int nErrorCode);
    int   SendTo(const void* lpBuf, int nBufLen, UINT nHostPort,LPCTSTR lpszHostAddress, int nFlags=0);
    virtual void  OnReceiveThread();
};

#endif // !defined(AFX_CTSOCKET_H__BC7BE104_472C_46E4_B7D2_BD4CAD931641__INCLUDED_)
