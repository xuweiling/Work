﻿/********************************************************
 *   文件名      : IniFile.cpp
 *   用途        : 读写INI配置文件
 *   编写人      : Jerry
 *   编写时间    : 2002-04-20
 *   最后修改人  : Jerry
 *   最后修改时间: 2002-05-01
 ********************************************************/

//l/#include "stdafx.h"
//#include "1307.h"
#include "inifile.h"
#include <unistd.h>
#include "string.h"
//#include "WriteLogFile.h"
#include <QSettings>
#include <QFile>
#include <QTextCodec>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


 /********************************************************
 *   方法名			: CIniFile
 *   功能			: 初试化CIniFile
 *   编写人			: Jerry
 *   编写时间		: 2002-04-20
 *   最后修改人		: Jerry
 *   最后修改时间	: 2002-05-01
 *   参数意义说明	: 无
 *   返回值意义		: 无
 *********************************************************/

CIniFile::CIniFile()
{
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("0"));
    memset(pIniFileName,0x00,MAXNAME_LENGTH);
}

CIniFile::~CIniFile()
{
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
}


 /********************************************************
 *   方法名			: WriteIniVal
 *   功能			: 将从Key值为char型的Key值写入INI文件中
 *   编写人			: Jerry
 *   编写时间		: 2002-04-20
 *   最后修改人		: Jerry
 *   最后修改时间	: 2002-05-01
 *   参数意义说明	:
 *						QString lpAppName	段名

 *						QString lpKeyName	Key项名称
 *						QString lpString    Key值
 *						QString path		Ini文件路径和文件名

 *   返回值意义		: 无
 *********************************************************/

void CIniFile::WriteIniVal(QString lpAppName,QString lpKeyName,QString lpString,QString path )
{
    QTextCodec *Latin=QTextCodec::codecForName("0");
    QTextCodec* utf8=QTextCodec::codecForName("UTF-8");
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("0"));
    QSettings settings(path, QSettings::IniFormat);
    settings.setIniCodec("UTF-8");
    lpString=utf8->toUnicode( lpString.toAscii());
    settings.beginGroup(lpAppName);
    settings.setValue(lpKeyName, lpString);
    settings.endGroup();
}

 /********************************************************
 *   方法名			: GetIniStr
 *   功能			: 从INI文件中获得段中Key值为char型的Key值
 *   编写人			: Jerry
 *   编写时间		: 2002-04-20
 *   最后修改人		: Jerry
 *   最后修改时间	: 2002-05-01
 *   参数意义说明	:
 *						QString lpAppName	段名

 *						QString lpKeyName	Key项名称
 *						QString path		Ini文件路径和文件名

 *   返回值意义		: QString	Key值
 *********************************************************/

QString CIniFile::GetIniStr(QString lpAppName, QString lpKeyName,QString  path )
{
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("0"));
    QString ReturnString;
    QString strResult;
    int val=-1;
    QSettings settings(path, QSettings::IniFormat);
    QString appkey=lpAppName;
    appkey+="/";
    appkey+=lpKeyName;
    ReturnString = settings.value(appkey).toString();
    val=ReturnString.length();
    if (val==4095-1)//内容太长
    {
        strResult="";
    }
    else if (val==4095-2)//lpAppName或lpKeyName中有一个是NULL
    {
        strResult="";
    }
    else
    {
        //strResult=(LPCTSTR)ReturnString;
        strResult=ReturnString;
    }
    return strResult;
}

 /********************************************************
 *   方法名			: GetIniInt
 *   功能			: 从INI文件中获得段中Key值为整数的Key值
 *   编写人			: Jerry
 *   编写时间		: 2002-04-20
 *   最后修改人		: Jerry
 *   最后修改时间	: 2002-05-01
 *   参数意义说明	:
 *						QString lpAppName	段名

 *						QString lpKeyName	Key项名称
 *						QString path		Ini文件路径和文件名

 *   返回值意义		:	Int    Key值
 *********************************************************/

int  CIniFile::GetIniInt(QString lpAppName, QString lpKeyName ,QString path)
{
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("0"));
    int value=0;

    QSettings settings(path, QSettings::IniFormat);
    QString appkey=lpAppName;
    appkey+="/";
    appkey+=lpKeyName;
    value= settings.value(appkey).toInt();

    return value;
}

 /********************************************************
 *   方法名			: GetIniFilePath
 *   功能			: 返回当前目录中该INI文件的文件路径和文件名

 *   编写人			: Jerry
 *   编写时间		: 2002-04-20
 *   最后修改人		: Jerry
 *   最后修改时间	: 2002-05-01
 *   参数意义说明	:
 *						char *pFileName		文件名

 *   返回值意义		:	QString  文件路径和文件名

 *********************************************************/

QString CIniFile::GetIniFilePath(char *pFileName)
{
 char lpszFileName[100];
 char pDir[100];
 getcwd(pDir,100);
 strcpy(lpszFileName,pDir);
 strcat(lpszFileName,"/");
 strcat(lpszFileName,pFileName);

 QString strFileName(lpszFileName);
 //strFileName=(LPCTSTR)lpszFileName;
 return strFileName;
}

 /********************************************************
 *   方法名			: CreateOrFindFile
 *   功能			: 判断当前目录是否存在该INI文件,如果不存在，则新建一个Ini文件
 *   编写人			: Jerry
 *   编写时间		: 2002-04-20
 *   最后修改人		: Jerry
 *   最后修改时间	: 2002-05-01
 *   参数意义说明	:
 *					  char *pFileName		文件名

 *   返回值意义		: 无
 *********************************************************/

void CIniFile::CreateOrFindFile(char *pFileName)
{
 /*
 CFile file;
 CFileException fileException;
 QString strFileName;
 strFileName=GetIniFilePath(pFileName);

 CFileFind fFind;
 if (fFind.FindFile(strFileName))
 {
     if (!file.Open(strFileName,CFile::modeReadWrite,&fileException))
     {
         TRACE("Can not open file %s,error=%u\n",strFileName,fileException.m_cause);
     }
 }
 else
 {
     if (!file.Open(strFileName,CFile::modeCreate|CFile::modeReadWrite,&fileException))
     {
         TRACE("Can not open file %s,error=%u\n",strFileName,fileException.m_cause);
     }
 }
 file.Close();
 */

    QString strFileName;
    strFileName=GetIniFilePath(pFileName);

    QFile file(strFileName);

    if (!file.open( QIODevice::ReadWrite))
    {
        perror("Can not open file");
        return;
    }

    file.close();
}

void fileConvert()
{
    char pDir[100];
    char pDirOld[100];
    char pDirNew[100];
    memset(pDir,0,100);
    memset(pDirOld,0,100);
    memset(pDirNew,0,100);

    getcwd(pDir,100);
    strcat(pDir,"/");
    strcpy(pDirOld,pDir);
    strcat(pDirOld,"settest.ini");
    strcpy(pDirNew,pDir);
    strcat(pDirNew,"setConvert.ini");

    FILE *fp=fopen(pDirOld,"r");
    FILE *fptmp=fopen(pDirNew,"wb+");
    if(fptmp!=NULL)
    {
           fclose(fptmp);
    }
    FILE *fpNew=fopen(pDirNew,"ab+");

    char pContent[MAX_COL_SIZE];
    char pDest[MAX_COL_SIZE];
    memset(pContent,0,MAX_COL_SIZE);
    memset(pDest,0,MAX_COL_SIZE);

    while(fgets(pContent,MAX_COL_SIZE,fp)!=NULL)
    {
         unencode(pContent,pDest);
         fwrite(pDest,sizeof(char),strlen(pDest),fpNew);
         memset(pContent,0,MAX_COL_SIZE);
         memset(pDest,0,MAX_COL_SIZE);
    }

    fclose(fp);
    fclose(fpNew);

    ::remove(pDirOld);
    ::rename(pDirNew,pDirOld);
}

int unencode(char *src, char *dest)
{
    int code;

    for(;*src!='\0';src++,dest++)
    {
        if(*src=='%')
        {
            if(sscanf(src+1,"%2x",&code)!=1)
                code='?';
            *dest=code;
            src+=2;
        }
        else if(*src=='+')
        {
            *dest=' ';
        }
        else
        {
            *dest=*src;
        }
    }
    *dest='\0';
    return 0;
}
