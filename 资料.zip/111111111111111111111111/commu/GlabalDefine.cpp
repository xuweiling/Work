﻿#include "stdafx.h"
#include "Matrix.h"
#include "trans.h"
#include "tcrclib.h"
#include "GlabalDefine.h"
#include <QTime>
//#include "piodio.h"

extern WORD     wTotalBoard,wInitialCode;
extern WORD     wRetVal;
extern DWORD    wGetAddrBase;   // IO卡基地址
extern WORD     wGetIrqNo;      // IO卡中断号
extern WORD     wGetSubVendor,wGetSubDevice,wGetSubAux,wGetSlotBus,wGetSlotDevice;

extern HANDLE   hIntEvent;        // IO卡中断事件句柄

//DWORD    pio144Base;   // IO卡基地址
extern WORD     wBoardToActive;   
extern WORD     wInterruptSource;   // IO卡中断源

DWORD CharToHex(char* inputText, int TextLength)//不得超过4byte
{
	DWORD returnNUM = 0;
	for(int index=0; index<TextLength; index++)
	{
		BYTE resultNUM;
		char tempChar = inputText[index];
		if(tempChar>='a' && tempChar<='f')
		{
			resultNUM = (tempChar-'a'+10);
		}
		else if(tempChar>='A' && tempChar<='F')
		{
			resultNUM = (tempChar-'A'+10);
		}
		else if(tempChar>='0' && tempChar<='9')
		{
			resultNUM = (tempChar-'0');
		}
		else
		{
			returnNUM = 0;
			return returnNUM;
		}
		returnNUM = resultNUM + returnNUM*16;
	}
	return returnNUM;
}

DWORD CharToHex(QString inputText)//不得超过4byte
{
	DWORD returnNUM = 0;
    int TextLength = inputText.length();
	if(TextLength>8)
		return 0;
	for(int index=0; index<TextLength; index++)
	{
		BYTE resultNUM;
        char tempChar = inputText[index].toAscii();
		if(tempChar>='a' && tempChar<='f')
		{
			resultNUM = (tempChar-'a'+10);
		}
		else if(tempChar>='A' && tempChar<='F')
		{
			resultNUM = (tempChar-'A'+10);
		}
		else if(tempChar>='0' && tempChar<='9')
		{
			resultNUM = (tempChar-'0');
		}
		else
		{
			returnNUM = 0;
			return returnNUM;
		}
		returnNUM = resultNUM + returnNUM*16;
	}
	return returnNUM;
}

/************************************************************************/
/*   将字符串转为无符号整型 输入低位在前                                                                   */
/************************************************************************/
DWORD CharToUnsignedHexReverse(QString inputText)//不得超过4byte 返回无符号整型 输入低位在前
{
	DWORD returnNUM = 0;
    int TextLength = inputText.length();
	if(TextLength>8)
		return 0;
    switch(inputText.length())
	{
	case 2:
		{
			for(int index=0; index<TextLength; index++)
			{
				BYTE resultNUM;
                char tempChar = inputText[index].toAscii();
				if(tempChar>='a' && tempChar<='f')
				{
					resultNUM = (tempChar-'a'+10);
				}
				else if(tempChar>='A' && tempChar<='F')
				{
					resultNUM = (tempChar-'A'+10);
				}
				else if(tempChar>='0' && tempChar<='9')
				{
					resultNUM = (tempChar-'0');
				}
				else
				{
					returnNUM = 0;
					return returnNUM;
				}
				returnNUM = resultNUM + returnNUM*16;
			}
			break;
		}
	case 4:
		{
			char tempP;
            tempP = inputText[0].toAscii();
            //inputText.SetAt(0, inputText[2]);
            inputText[0]=inputText[2];
            //inputText.SetAt(2, tempP);
            inputText[2]=tempP;
            tempP = inputText[1].toAscii();
            //inputText.SetAt(1, inputText[3]);
            inputText[1]=inputText[3];
            //inputText.SetAt(3, tempP);
             inputText[3]=tempP;

			for(int index=0; index<TextLength; index++)
			{
				BYTE resultNUM;
                char tempChar = inputText[index].toAscii();
				if(tempChar>='a' && tempChar<='f')
				{
					resultNUM = (tempChar-'a'+10);
				}
				else if(tempChar>='A' && tempChar<='F')
				{
					resultNUM = (tempChar-'A'+10);
				}
				else if(tempChar>='0' && tempChar<='9')
				{
					resultNUM = (tempChar-'0');
				}
				else
				{
					returnNUM = 0;
					return returnNUM;
				}
				returnNUM = resultNUM + returnNUM*16;
			}
			break;
		}
	case 6:
		{
			char tempP;
        /*
            tempP = inputText[0];
			inputText.SetAt(0, inputText[4]);
			inputText.SetAt(4, tempP);
			tempP = inputText[1];
			inputText.SetAt(1, inputText[5]);
			inputText.SetAt(5, tempP);
*/
            tempP = inputText[0].toAscii();
            inputText[0]=inputText[4];
            inputText[4]=tempP;
            tempP = inputText[1].toAscii();
            inputText[1]=inputText[5];
             inputText[5]=tempP;

			for(int index=0; index<TextLength; index++)
			{
				BYTE resultNUM;
                char tempChar = inputText[index].toAscii();
				if(tempChar>='a' && tempChar<='f')
				{
					resultNUM = (tempChar-'a'+10);
				}
				else if(tempChar>='A' && tempChar<='F')
				{
					resultNUM = (tempChar-'A'+10);
				}
				else if(tempChar>='0' && tempChar<='9')
				{
					resultNUM = (tempChar-'0');
				}
				else
				{
					returnNUM = 0;
					return returnNUM;
				}
				returnNUM = resultNUM + returnNUM*16;
			}
			break;
		}
	case 8:
		{
			char tempP;
            /*
			tempP = inputText[0];
			inputText.SetAt(0, inputText[6]);
			inputText.SetAt(6, tempP);
			tempP = inputText[1];
			inputText.SetAt(1, inputText[7]);
			inputText.SetAt(7, tempP);
			tempP = inputText[2];
			inputText.SetAt(2, inputText[4]);
			inputText.SetAt(4, tempP);
			tempP = inputText[3];
			inputText.SetAt(3, inputText[5]);
			inputText.SetAt(5, tempP);
*/
            tempP = inputText[0].toAscii();
            inputText[0]=inputText[6];
            inputText[6]=tempP;
            tempP = inputText[1].toAscii();
            inputText[1]=inputText[7];
             inputText[7]=tempP;
             tempP = inputText[2].toAscii();
             inputText[2]=inputText[4];
             inputText[4]=tempP;
             tempP = inputText[3].toAscii();
             inputText[3]=inputText[5];
              inputText[5]=tempP;

			for(int index=0; index<TextLength; index++)
			{
				BYTE resultNUM;
                char tempChar = inputText[index].toAscii();
				if(tempChar>='a' && tempChar<='f')
				{
					resultNUM = (tempChar-'a'+10);
				}
				else if(tempChar>='A' && tempChar<='F')
				{
					resultNUM = (tempChar-'A'+10);
				}
				else if(tempChar>='0' && tempChar<='9')
				{
					resultNUM = (tempChar-'0');
				}
				else
				{
					returnNUM = 0;
					return returnNUM;
				}
				returnNUM = resultNUM + returnNUM*16;
			}
			break;
		}
	}
	return returnNUM;
}

/************************************************************************/
/*   将字符串转为有符号整型 输入低位在前                                                                   */
/************************************************************************/
LONG CharToSignedHexReverse(QString inputText)//不得超过4byte
{
	LONG returnNUM = 0;
	DWORD reNUM = 0;
    int TextLength = inputText.length();
	if(TextLength>8)
		return 0;
	char tempChar = 0;
	BYTE* pTem = (BYTE*)&returnNUM;

    switch(inputText.length())
	{
	case 2:
		{
            tempChar = inputText[0].toAscii();
			for(int index=0; index<TextLength; index++)
			{
				BYTE resultNUM;
                char tempChar = inputText[index].toAscii();
				if(tempChar>='a' && tempChar<='f')
				{
					resultNUM = (tempChar-'a'+10);
				}
				else if(tempChar>='A' && tempChar<='F')
				{
					resultNUM = (tempChar-'A'+10);
				}
				else if(tempChar>='0' && tempChar<='9')
				{
					resultNUM = (tempChar-'0');
				}
				else
				{
					returnNUM = 0;
					return returnNUM;
				}
				returnNUM = resultNUM + returnNUM*16;
			}
			if(returnNUM>=128)
			{
				pTem[0] = 0xff;
				pTem[1] = 0xff;
				pTem[2] = 0xff;
			}
			break;
		}
	case 4:
		{
			char tempP;
            tempP = inputText[0].toAscii();
            inputText[2]=tempP;
            tempP = inputText[1].toAscii();
            inputText[1]=inputText[3];
             inputText[3]=tempP;
			
            tempChar = inputText[0].toAscii();
			for(int index=0; index<TextLength; index++)
			{
				BYTE resultNUM;
                char tempChar = inputText[index].toAscii();
				if(tempChar>='a' && tempChar<='f')
				{
					resultNUM = (tempChar-'a'+10);
				}
				else if(tempChar>='A' && tempChar<='F')
				{
					resultNUM = (tempChar-'A'+10);
				}
				else if(tempChar>='0' && tempChar<='9')
				{
					resultNUM = (tempChar-'0');
				}
				else
				{
					returnNUM = 0;
					return returnNUM;
				}
				returnNUM = resultNUM + returnNUM*16;
			}
			if(pTem[2]>=128)
			{
				pTem[0] = 0xff;
				pTem[1] = 0xff;
			}
			break;
		}
	case 6:
		{
			char tempP;
            tempP = inputText[0].toAscii();
            inputText[0]=inputText[4];
            inputText[4]=tempP;
            tempP = inputText[1].toAscii();
            inputText[1]=inputText[5];
             inputText[5]=tempP;

            tempChar = inputText[0].toAscii();
			for(int index=0; index<TextLength; index++)
			{
				BYTE resultNUM;
                char tempChar = inputText[index].toAscii();
				if(tempChar>='a' && tempChar<='f')
				{
					resultNUM = (tempChar-'a'+10);
				}
				else if(tempChar>='A' && tempChar<='F')
				{
					resultNUM = (tempChar-'A'+10);
				}
				else if(tempChar>='0' && tempChar<='9')
				{
					resultNUM = (tempChar-'0');
				}
				else
				{
					returnNUM = 0;
					return returnNUM;
				}
				returnNUM = resultNUM + returnNUM*16;
			}
			if(pTem[1]>=128)
			{
				pTem[0] = 0xff;
			}
			break;
		}
	case 8:
		{
			char tempP;
            tempP = inputText[0].toAscii();
            inputText[0]=inputText[6];
            inputText[6]=tempP;
            tempP = inputText[1].toAscii();
            inputText[1]=inputText[7];
             inputText[7]=tempP;
             tempP = inputText[2].toAscii();
             inputText[2]=inputText[4];
             inputText[4]=tempP;
             tempP = inputText[3].toAscii();
             inputText[3]=inputText[5];
              inputText[5]=tempP;

			inputText = "0x" + inputText;
			char* pT;
            QString T1, T2;
            T1 = inputText.left(6);
            T2 = "0x"+inputText.right(4);
            DWORD KT1 = strtol( (LPCSTR)T1.toAscii(), &pT, 16 );
            DWORD KT2 = strtol( (LPCSTR)T2.toAscii(), &pT, 16 );
			DWORD PKT = KT1*65536 + KT2;
			memcpy(&returnNUM, &PKT, 4);
//			returnNUM = strtol( (LPCSTR)inputText, &pT, 16 );
//			returnNUM = atoi((LPCSTR)inputText);
//			memcpy(&returnNUM, (LPCSTR)inputText, 8);
			break;
		}
	default:
		returnNUM = 0;
	}
	return returnNUM;
}



/************************************************************************/
/* 将外引导数据进行坐标变换，由CalcuType控制转换方式
其他输入参数可随计算方式的不同而定义不一 
20110707++
BLH=>xyz                                                                     */
/************************************************************************/
void TransCoor(float Input_x, float Input_y, float Input_z, float Input_u, float Input_v, float Input_w, float Input_t, double* Output_x, double* Output_y, double* Output_z, int CalcuType)
{
	Ground_Coord LBH;
	Cart_Coord gXYZ;
	Cart_Coord nXYZ;
/*
	LBH.L = Input_u;
	LBH.B = Input_v;
	LBH.H = Input_w;
	gXYZ.X = Input_x;
	gXYZ.Y = Input_y;
	gXYZ.Z = Input_z;
	nXYZ.X = Output_x;
	nXYZ.Y = Output_y;
	nXYZ.Z = Output_z;
	gXYZ2nXYZ(LBH,Cart_Coord gXYZ,Cart_Coord & nXYZ);
*/

	if(CalcuType == 0)//发射系转地心直角
	//	Input_x为发射系数据， Input_u为发射点的地心坐标(BLH) ， Output_x为计算得到的地心系坐标
	{
		LBH.L = Input_u;
		LBH.B = Input_v;
		LBH.H = Input_w;
		nXYZ.X = Input_x;
		nXYZ.Y = Input_y;
		nXYZ.Z = Input_z;
		nXYZ2gXYZ(LBH, nXYZ, gXYZ, Input_t);

		*Output_x = gXYZ.X;
		*Output_y = gXYZ.Y;
		*Output_z = gXYZ.Z;
	}
	if(CalcuType == 1)//地心直角转发射系
	//	Input_x为地心系数据 ， Input_u为发射点的地心坐标(BLH)， Output_x为计算得到的发射系坐标
	{
		LBH.L = Input_u;
		LBH.B = Input_v;
		LBH.H = Input_w;
		gXYZ.X = Input_x;
		gXYZ.Y = Input_y;
		gXYZ.Z = Input_z;
		gXYZ2nXYZ(LBH, gXYZ, nXYZ, Input_t);

		*Output_x = nXYZ.X;
		*Output_y = nXYZ.Y;
		*Output_z = nXYZ.Z;
	}
}

/************************************************************************/
/*  
将XX:XX:XX::XXX 形式的字符串转化为SYSTEMTIME(其中只有时、分、秒、毫秒有效)
*/
/************************************************************************/
void Str2Time(QString pInput, SYSTEMTIME *pOutput)
{
    QString pcontent;
	int i1,i2,i3,i4;
    i1 = pInput.indexOf(":");
    pcontent = pInput.left(i1);
    pOutput->tm_hour = atoi((LPCSTR)pcontent.toAscii());
    i2 = pInput.indexOf(":", i1+1);
    pcontent = pInput.mid(i1+1, i2-i1-1);
    pOutput->tm_min= atoi((LPCSTR)pcontent.toAscii());
    i3 = pInput.indexOf("::", i2+1);
    pcontent = pInput.mid(i2+1, i3-i2-1);
    pOutput->tm_sec = atoi((LPCSTR)pcontent.toAscii());
    pcontent = pInput.right(pInput.length() - i3-2);
   //l/ pOutput->wMilliseconds = atoi((LPCSTR)pcontent.toAscii());
}



/************************************************************************/
/*自时统卡得到时间                                          */
/************************************************************************/
DWORD GetTimeFromPIO( )
{
	int hour,minute, second,msecond;

	BYTE BTime0;  //毫秒低8位
	BYTE BTime1;  //秒钟7位，100ms位
	BYTE BTime6;  //分钟7位，200ms位
	BYTE BTime7;  //小时6位，800ms 、400ms位
	BYTE BTime8;  //小时6位，800ms 、400ms位
	
	//毫秒低8位
	BTime0 = 0;
    //l/PIODIO_OutputByte(wGetAddrBase+0xc4, 0);  //激活读取端口port0;  1Ms~80Ms  低1ms\2ms\4ms\8ms\10ms\20ms\40ms\80ms
    //l/PIODIO_OutputByte(wGetAddrBase+0xc0,0x00);   // clear port
    //l/BTime0=PIODIO_InputByte(wGetAddrBase+0xc0);

	//秒钟7位，100ms位
	BTime1 = 0;
//l/	PIODIO_OutputByte(wGetAddrBase+0xc4, 1);  //激活读取端口port1;  100Ms~秒个位 低100ms\200ms\400ms\800ms\1s\2s\4s\8s
//l/	PIODIO_OutputByte(wGetAddrBase+0xc0,0x00);   // clear port
//l/	BTime1=PIODIO_InputByte(wGetAddrBase+0xc0);

	//分钟7位，200ms位
//l/	PIODIO_OutputByte(wGetAddrBase+0xc4, 6);  //激活读取端口port6;分钟十位 低10min\20min\40min
//l/	PIODIO_OutputByte(wGetAddrBase+0xc0,0x00);   // clear port
//l/	BTime6=PIODIO_InputByte(wGetAddrBase+0xc0);
	
	//小时6位，800ms 、400ms位
//l/	PIODIO_OutputByte(wGetAddrBase+0xc4, 7);  //激活读取端口port7;小时   低1h\2h\4h\8h\10h\20h
//l/	PIODIO_OutputByte(wGetAddrBase+0xc0,0x00);   // clear port
//l/	BTime7=PIODIO_InputByte(wGetAddrBase+0xc0);

//l/	PIODIO_OutputByte(wGetAddrBase+0xc4, 8);  //激活读取端口port8;分钟个位&秒十位  低10s\20s\40s\1min\2min\4min\8min
//	PIODIO_OutputByte(wGetAddrBase+0xc0,0x00);   // clear port
//l/	BTime8=PIODIO_InputByte(wGetAddrBase+0xc0);
    msecond = BTime8&0x07;
	
	//处理数据分离出小时、分钟、秒钟、毫秒等数据
  
	int temp1, temp2, temp3;

	temp1 = ((BTime7&0x30)>>4)*10;
	temp2 = ((BTime7&0x0f));
	hour = temp1 + temp2;

	temp1 = ((int)BTime6&0x07)*10;
	temp2 = ((int)BTime8&0xF0)>>4;
	minute = temp1 + temp2;

	temp1 = (BTime8&0x07)*10;
	temp2 = (BTime1&0xF0)>>4;
	second= temp1 + temp2;


	temp1 = BTime1&0x0F;
	temp2 = (BTime0&0xF0)>>4;
	temp3 = (BTime0&0x0F);
	msecond = temp1 *100 + temp2 *10 + temp3;

	DWORD RealTime_Y = (hour *3600 + minute *60 + second) *10000 + msecond*10;
	return RealTime_Y;
}

/************************************************************************/
/*自时统卡TCRC得到时间                                          */
/************************************************************************/
DWORD GetTimeFromTCRC( )
{
	int nHour = 0;
	int nMinute = 0;
	int nSecond = 0;
	int nMillSecond = 0;
	int nCardNo = 0;

	unsigned char ucTimeValid=0;
	unsigned char ucSetTimeSource=0;
	int tempTimesour=0;

//l/	tcrc_readtime(nCardNo, &nHour, &nMinute, &nSecond, &nMillSecond, &ucTimeValid, &ucSetTimeSource, &tempTimesour);
	if(tempTimesour == 1)
		nHour = (nHour+8)%24;
	DWORD RealTime_Y = ((nHour*60 + nMinute)*60 + nSecond)*10000 + nMillSecond;

//	DWORD RealTime_Y = (hour *3600 + minute *60 + second) *10000 + msecond*10;
	return RealTime_Y;
}

/************************************************************************/
/* 自计算机得到日期,属于集中处理的函数                                 */
/************************************************************************/
unsigned short GetDate()
{
//	CTime curTime = CTime::GetCurrentTime();
//	CTime curTime2000(2000,1,1,0,0,0);
//	CTimeSpan diffT;
//	diffT = curTime-curTime2000;
//	unsigned short diffDay = (unsigned short)diffT.GetDays()+1;
//	return diffDay;
    time_t  curTime=time(NULL);
    struct tm curTime2000;
    curTime2000.tm_year=100; //since 1900
    curTime2000.tm_mon=0; //0-11
    curTime2000.tm_mday=1;//1-31
    curTime2000.tm_hour=0;
    curTime2000.tm_min=0;
    curTime2000.tm_sec=0;
    time_t curTime2000tmp=mktime(&curTime2000);
    double diffT=difftime(curTime,curTime2000tmp);
    unsigned short diffDay=diffT/(24*60*60) + 1;
    return diffDay;
}

/************************************************************************/
/*得到时间                                          */
/************************************************************************/
DWORD GetTime(TimeSourceType TimeSource)
{
	DWORD milSecondCount = 0;
	switch(TimeSource)
	{
	case Time_Local:
		{
//			SYSTEMTIME currentTime;
//			GetSystemTime(&currentTime);
//			milSecondCount = currentTime.wHour*60*60*1000*10 + currentTime.wMinute*60*1000*10 + currentTime.wSecond*1000*10 + currentTime.wMilliseconds*10;//精确到0.1MS

            QTime curntTime= QTime::currentTime () ;
            milSecondCount = curntTime.hour()*60*60*1000*10 + curntTime.minute()*60*1000*10 +
                    curntTime.second()*1000*10+ curntTime.msec()*10;//精确到0.1MS
            break;
		}
	case Time_ZK:
	case Time_GPS:
	case Time_DC:
	case Time_AC:
		{
#ifdef CardType
			milSecondCount = GetTimeFromPIO( );
#else
			milSecondCount = GetTimeFromTCRC( );
#endif
			break;
		}
	}

	return milSecondCount;
}

/************************************************************************/
/*得到时间                                          */
/************************************************************************/
SYSTEMTIME GetTimeMilli(TimeSourceType TimeSource)
{
	SYSTEMTIME currentTime;
	DWORD milSecondCount = 0;
	switch(TimeSource)
	{
	case Time_Local:
		{
//			SYSTEMTIME currentTime;
//			GetSystemTime(&currentTime);
//			milSecondCount = currentTime.wHour*60*60*1000*10 + currentTime.wMinute*60*1000*10 + currentTime.wSecond*1000*10 + currentTime.wMilliseconds*10;//精确到0.1MS
        QTime curntTime= QTime::currentTime () ;
        milSecondCount = curntTime.hour()*60*60*1000*10 + curntTime.minute()*60*1000*10 +
                curntTime.second()*1000*10+ curntTime.msec()*10;//精确到0.1MS
            break;
		}
	case Time_ZK:
		{
//			SYSTEMTIME currentTime;
//			GetSystemTime(&currentTime);
//			milSecondCount = currentTime.wHour*60*60*1000*10 + currentTime.wMinute*60*1000*10 + currentTime.wSecond*1000*10 + currentTime.wMilliseconds*10;//精确到0.1MS
        QTime curntTime= QTime::currentTime () ;
        milSecondCount = curntTime.hour()*60*60*1000*10 + curntTime.minute()*60*1000*10 +
                curntTime.second()*1000*10+ curntTime.msec()*10;//精确到0.1MS
            break;
		}

	case Time_GPS:
	case Time_DC:
	case Time_AC:
		{
#ifdef CardType
			milSecondCount = GetTimeFromPIO( );
#else
			milSecondCount = GetTimeFromTCRC( );
#endif
			break;
		}

	}

    GetSystemTime(&currentTime);

    currentTime.tm_hour = milSecondCount/10000/3600;
    currentTime.tm_min = milSecondCount/10000/60%60;
    currentTime.tm_sec = milSecondCount/10000%60;
    currentTime.tm_msec = milSecondCount/10%1000;

	return currentTime;
}

bool PrePost(float A1, float A2, float A3, float A4, float *A5)
{
	*A5 = (9*A4 - 3*A3 - 5*A2 + 3*A1) /4;
	return true;
}

void GetSystemTime(SYSTEMTIME *currentTime)
{
    DWORD milSecondCount = 0;

    time_t the_time=time((time_t*) 0);
    struct tm *tm_ptr;
    //tm_ptr=gmtime(&the_time);
    tm_ptr=localtime(&the_time);
    currentTime->tm_year=tm_ptr->tm_year+1900;
    currentTime->tm_mon=tm_ptr->tm_mon+1;
    currentTime->tm_mday=tm_ptr->tm_mday;

    QTime qtime= QTime::currentTime() ;
//    qDebug(qtime.toString("hh:mm:ss.zzz").toAscii());
    milSecondCount = qtime.hour()*60*60*1000*10 + qtime.minute()*60*1000*10 +
                qtime.second()*1000*10+ qtime.msec()*10;//精确到0.1MS
    currentTime->tm_hour = milSecondCount/10000/3600;
    currentTime->tm_min = milSecondCount/10000/60%60;
    currentTime->tm_sec = milSecondCount/10000%60;
    currentTime->tm_msec = milSecondCount/10%1000;
}
