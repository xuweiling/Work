#ifndef __TCRCLIB_H__
#define __TCRCLIB_H__

///////////////////////////////////////////////////////////////////////////
#define MAX_CARD_COUNT   8





int tcrc_open(int nCardNo);

int tcrc_close(int nCardNo);

int tcrc_readtime(int nCardNo,int* nHour,int* nMinute,int* nSecond,int* nMillSecond,unsigned char* ucTimeValid,unsigned char* ucSetTimeSource,int* nSateNum);

int tcrc_settime(int nCardNo,int nHour,int nMinute,int nSecond);

int tcrc_setinten(int nCardNo,int nIntEnable,int nIntShield);

int tcrc_settimesource(int nCardNo,unsigned char ucSetSource);

int tcrc_setinttime(int nCardNo,int nHour,int nMinute,int nSecond,int nMillSecond);

int tcrc_setdowntime(int nCardNo,unsigned long ulDownTime);

int tcrc_writedelay(int nCardNo,int n01ms,int n01us);

int tcrc_wait1pps(int nCardNo,unsigned int unMilliseconds);

int tcrc_wait20pps(int nCardNo,unsigned int unMilliseconds);

int tcrc_wait100pps(int nCardNo,unsigned int unMilliseconds);

int tcrc_waitdowntime(int nCard,unsigned int unMilliseconds);

int tcrc_waitinttime(int nCard,unsigned int unMilliseconds);


#endif
