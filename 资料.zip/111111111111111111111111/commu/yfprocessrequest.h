/*
 * process_request.h
 *
 *  Created on: Dec 11, 2014
 *      Author: feng
 */

#ifndef PROCESS_REQUEST_H_
#define PROCESS_REQUEST_H_

#include "yfnotify.h"
#include "yfmIbbrowerview.h"
class YFMib : public Mib
{

public :
	void YF_process_request(Request* req);
	void YF_do_process_request(Request* req);
	boolean YF_process_request(Request* req, int reqind);
	void YF_process_set_request(Request* req);

	void YFAnswerGet(Request* req);
	boolean YFProcessRequest(Request* req, int reqind);
	void YFDoProcessRequest(Request* req);
	void YFProcessSetRequest(Request* req);
	int YFProcessPrepareSetRequest(Request* req);


    int YF_notify(const OctetStr& context,
            const Oidx& oid,
            Vbx* vbs, int sz,
            unsigned int timestamp = 0);

//	int YFLocalSet(Vbx *vb,int vbNum);
    int YFLocalSet(Vbx *&vb, int vbNum);

    int YFLocalGet(Vbx *vb, int vbNum);
    YFNotificationOriginator* YFnotificationSender;
};



#endif /* PROCESS_REQUEST_H_ */
