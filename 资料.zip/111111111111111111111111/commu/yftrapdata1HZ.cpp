#include "yftrapdata1HZ.h"
#include <qtimer.h>
#include "yfagent.h"

extern YFSnmpAgent yfsnmpagent;
bool istrapdata1hz = false;
extern QTreeNode YFQHRoot;

void trapdata::uptrapdata()
{
    if(istrapdata1hz == true)
    {
//        yfsnmpagent.setNode[0].POid = "1.3.6.1.4.1.13526.12.1.2.0";
//        yfsnmpagent.setNode[0].PSnytax = "String";
    //            yfsnmpagent.setNode[0].PIValue = a++;

//        yfsnmpagent.setNode[1].POid = "1.3.6.1.2.1.111.2.0";
//        yfsnmpagent.setNode[1].PSnytax = "String";
//    //           yfsnmpagent.setNode[1].PSValue = "3";
//        yfsnmpagent.setNode[2].POid = "1.3.6.1.2.1.111.4.0";
//        yfsnmpagent.setNode[2].PSnytax = "Int";
//    //            yfsnmpagent.setNode[2].PIValue = 2;
//        yfsnmpagent.setNode[3].POid = "1.3.6.1.2.1.111.5.0";
//        yfsnmpagent.setNode[3].PSnytax = "String";
//    //            yfsnmpagent.setNode[3].PSValue = "3";

//        yfsnmpagent.setNodeNum = 1;

//        yfsnmpagent.LocalGet();
//       yfsnmpagent.setNode[0].PIValue += 1;
//        yfsnmpagent.LocalSet();


//        yfsnmpagent.trapto("1.3.6.1.4.1.1.1.0");

//        isuptrapdata();

//        if(yfsnmpagent.isGetNewNode == true)
//        {

//        }
    }
}

trapdata::trapdata(QObject *parent) :
    QObject(parent)
{
    timer = new QTimer();
    if(connect(timer, SIGNAL(timeout()), this, SLOT(uptrapdata())))
        timer->start(10000);
}

void trapdata::isuptrapdata()
{
    QTreeNode *currentNode;
    currentNode = &YFQHRoot;
    while(currentNode->LChildren != NULL)
    {
        while(currentNode->LChildren->QMibdata.isTrap != "1")
        {
            if(currentNode->LChildren->LChildren == NULL)
                return;
            currentNode = currentNode->LChildren;
        }
        currentNode = currentNode->LChildren;

        yfsnmpagent.setNode[0].POid = currentNode->QMibdata.POid;
        if(currentNode->QMibdata.PSnytax == "Int")
        {
            yfsnmpagent.setNode[0].PSnytax = "Int";
        }
        else
        {
            yfsnmpagent.setNode[0].PSnytax = "String";
        }
        yfsnmpagent.setNodeNum = 1;
        yfsnmpagent.LocalGet();
        if(currentNode->QMibdata.PSnytax == "Int")
        {
            if(currentNode->QMibdata.PIValue != yfsnmpagent.setNode[0].PIValue)
            {
                yfsnmpagent.trapto(TRAPID);
                currentNode->QMibdata.PIValue = yfsnmpagent.setNode[0].PIValue;
            }
        }
        else
        {
            if(currentNode->QMibdata.PSValue != yfsnmpagent.setNode[0].PSValue)
            {
                yfsnmpagent.trapto(TRAPID);
                currentNode->QMibdata.PSValue = yfsnmpagent.setNode[0].PSValue;
            }
        }
    }
}
