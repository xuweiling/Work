// BaseFile.cpp: implementation of the CBaseFile class.
//
//////////////////////////////////////////////////////////////////////

//#include "stdafx.h"
#include "BaseFile.h"
 #include <QSettings>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBaseFile::CBaseFile()
	:CIniFile()
{
}

CBaseFile::~CBaseFile()
{

}


	/********************************************************   
	*   方法名			: DeleteSection
	*   功能			: 将从Section中的所有KEY值均删除
	*   编写人			: Jerry
	*   编写时间		: 2008-01-04
	*   最后修改人		: Jerry
	*   最后修改时间	: 
	*   参数意义说明	: 
    *						QString lpAppName	段名
    *						QString path		Ini文件路径和文件名

	*   返回值意义		: 无
	*********************************************************/

void CBaseFile::DeleteSection(QString lpAppName,QString path )
{    
    //::WritePrivateProfileString(lpAppName, NULL, NULL, path);

    //linux
    QSettings settings(path, QSettings::IniFormat);
    settings.beginGroup(lpAppName);
    settings.remove("");
    settings.endGroup();
}

	/********************************************************   
	*   方法名			: DeleteKey
	*   功能			: 将从Key值为char型的Key值写入INI文件中
	*   编写人			: Jerry
	*   编写时间		: 2002-04-20
	*   最后修改人		: Jerry
	*   最后修改时间	: 2002-05-01
	*   参数意义说明	: 
    *						QString lpAppName	段名

    *						QString lpKeyName	Key项名称
    *						QString lpString    Key值
    *						QString path		Ini文件路径和文件名

	*   返回值意义		: 无
	*********************************************************/

void CBaseFile::DeleteKey(QString lpAppName, QString lpKeyName, QString path )
{    
    //::WritePrivateProfileString(lpAppName, lpKeyName, NULL, path);
    //linux
    QSettings settings(path, QSettings::IniFormat);
    settings.beginGroup(lpAppName);
    settings.remove(lpKeyName);
    settings.endGroup();
}

